# Separate next experiment: actual-arrival handoff replanning

Stage61 remains unchanged. Its map resets each leg's cursor to the previous fixed anchor even though arrival can stop within 35 cm. The next route therefore unnecessarily reconnects to an anchor already accepted as reached.

Proposed deterministic controller correction:

1. Keep leg0 unchanged. Only after an original goal is reached and the actor's command queue is drained, obtain the same delivered stationary pose used by the controller. Preserve actor state, yaw and time; do not move it to the goal or source mesh.
2. Use the unchanged source55 registered Polycam mesh, native configuration, world-origin 5 cm grid, eight-neighbor native-raycast edges, 2 m wall-distance cap and cost `length * (1 + (0.30 / (clearance + 0.05))²)`. Keep grid sampling height fixed from the original anchors, not changing with the new query.
3. Associate the actual start and unchanged next original task goal using the existing 10 cm XZ association and source-height checks. Add both query nodes to the frozen source grid, connecting native-visible grid nodes within the existing 15 cm connector radius. Run the same deterministic Dijkstra tie ordering.
4. Apply unchanged stage56 farthest-original-vertex LOS simplification: bidirectional native LOS, samples at most 25 mm apart, no sampled minimum-clearance degradation and no integrated-cost increase beyond the existing 1e-6 numerical tolerances.
5. Retain exact delivered start and exact original goal as endpoint connectors. Source native heights and projection offsets remain recorded; actual body height remains governed by stage61 measured support. No snap or replacement goal is permitted.
6. Before any next-leg command, require the entire source route expanded by the full rectangle circumradius to remain inside that leg's existing frozen membership/extraction bounds. Reject an out-of-bounds or incomplete route; do not select another route using evaluator geometry.
7. Save the actual query pose, deterministic source route and source-only checks. The unchanged stage61 body, floor, continuity, unknown-support and underbody guards independently evaluate movement. Preserve the 2,500-tick and 900/1,200-second limits.

Only pose and fixed next goal enter this query. No reference contacts, failed-face IDs, evaluator support masks or ground truth steer the route. This may remove redundant anchor returns; it does not repair the measured source/reference standing-table discrepancy or promise a completed lap.

## Frozen implementation and resource scope

Stage63 keeps the original stage61 actor, five goal regions, source mesh, source cost, native parameters, local support law, floor membership IDs and collision guards. Leg0 is unchanged. On the first delivered pose after each drained handoff, one source query is made and saved; failure remains terminal/no-route and never falls back to the previous anchor. The actual XYZ connector is retained in the source query evidence; level-map association uses the existing Y=0 convention without changing actor height. Native source height checks do not become an absolute physical-floor-height gate.

The same 15-second IPC timeout remains; an original-anchor source-only timing test took 2.434 seconds including graph construction. This is offline timing, not an on-phone real-time claim.

Predeclared run limits: 900 CPU seconds, 1,200 wall seconds, 3.5 GiB process-tree RSS, 2,500 ticks, 4 MiB output, 768 MiB disk reserve and 4.3 GiB available RAM admission. The output limit is stricter than stage61. Full tick/query JSON is losslessly XZ-compressed at preset6; heartbeat is gzip-compressed; every committed actual CSV row remains uncompressed and flushed. No fields or numeric precision are removed. Codec metadata and readers are provided. Interrupted XZ may lag recent verbose events; only complete recovered lines may be used, and the actual CSV remains the partial committed-motion record.

The measured codec forecast is 3,669,117 bytes for 1,775 movement ticks including four query receipts and an extra64KiB allowance, leaving about525KiB under the4MiB cap. This is a forecast, not a promise; the unchanged watchdog stops before exhausting the cap and preserves partial evidence.

This controller correction does not repair the standing-table source/reference geometry disagreement seen in61. Any newly rejected physical motion remains rejected. No reference collision or support information chooses a route.
