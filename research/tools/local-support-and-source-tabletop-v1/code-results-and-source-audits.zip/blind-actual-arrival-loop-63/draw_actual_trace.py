from pathlib import Path
import json,gzip,numpy as np
from PIL import Image,ImageDraw,ImageFont
H=Path(__file__).resolve().parent;W=H.parent;r=json.loads((H/'run-01/result/RESULT.json').read_text());plan=json.loads((H/'SELECTED_PLAN.json').read_text())
with np.load(W/'blind-polycam-alignment-feasibility-36/POLYCAM_INTRINSIC_GEOMETRY.npz')as z:v=z['verticesOBJ'];tri=z['triangles']
with np.load(W/'blind-polycam-rigid-registration-37/run-01/CANDIDATE_RIGID_TRANSFORM.npz')as z:lev=v@z['rotationOBJToLevel'].T+z['translationOBJToLevel']
with np.load(W/'blind-split-candidate-game-03/inputs/koivu_5cm_v2_pipeline2_out.npz')as z:R=z['R'];t=z['t']
with np.load(W/'blind-pose-experiments-review-17/upstream/pose-consistency/runs/koivu_floorfix/pipeline2_out.npz')as z:N=z['R'];nt=z['t']
old=((lev-nt)@N)@R.T+t;v=np.c_[old[:,0],old[:,2],-old[:,1]];xyz=v[tri];keep=(xyz.mean(1)[:,1]>.15)&(xyz.mean(1)[:,1]<1.8)
lo=v[:,[0,2]].min(0);hi=v[:,[0,2]].max(0);im=Image.new('RGB',(1100,1300),'white');d=ImageDraw.Draw(im);font='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf';big=ImageFont.truetype(font,25);sm=ImageFont.truetype(font,17);scale=min(950/(hi[0]-lo[0]),1020/(hi[1]-lo[1]))
def p(q):return(65+(q[0]-lo[0])*scale,160+(q[2]-lo[1])*scale)
d.text((35,20),'Executed 15.530 m; four of five goals reached; NO table lap',font=big,fill='black');d.text((35,58),'45 x 30 x 160 cm body, zero margin. Actual-arrival source queries; measured local floor support.',font=sm,fill='black')
for q in xyz[keep]:d.line([p(x)for x in q]+[p(q[0])],fill='#dddddd',width=1)
for i,leg in enumerate(plan['legs']):
 path=leg['originalFramePath']
 query=H/'run-01/result'/f'SOURCE_REPLAN_LEG{i}.json.gz'
 if query.exists():
  with gzip.open(query,'rt')as f:path=json.load(f)['points']
 d.line([p(q)for q in path],fill='#8cc9e4',width=3)
with np.load(H/'run-01/result/ACTOR_TRACE.npz')as z:trace=z['trace']
d.line([p(q)for q in trace[:,2:5]],fill='#187b38',width=6)
for j,q in enumerate([plan['start'],*[x['originalTaskGoal']for x in plan['legs']]]):
 
 if j==5:continue
 x,y=p(q);d.ellipse((x-5,y-5,x+5,y+5),fill='#222222');d.text((x+8,y),('0 / 5' if j==0 else str(j)),font=sm,fill='black')
x,y=p(r['finalPosition']);d.ellipse((x-8,y-8,x+8,y+8),fill='#c53125');d.text((x+10,y-25),'STOP',font=sm,fill='#c53125')
d.text((35,1215),'Green = committed simulated movement. Blue = unexecuted source proposal. Grey = source mesh.',font=sm,fill='black');d.text((35,1245),'Stop: predicted full-body contact with standing-table rim; rejected step was not executed.',font=sm,fill='black');d.text((35,1270),'Evaluator-assisted simulation; source sensor uncertainty remains unresolved. Not device safety.',font=sm,fill='black');im.save(H/'ACTUAL_PATH.png')
