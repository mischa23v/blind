# Actual-arrival loop replanning: four goals, still no lap

**15.529728 m horizontal travel**, **four original goals reached**, **zero completed laps**. The next command was rejected by the unchanged reference body collider against the standing-table rim. No rejected movement was committed, and committed body contacts remain zero. This is an assisted offline simulation, not a phone-navigation or human-safety result.

## Isolated change

Stage61 restarted each leg from a fixed source anchor after accepting arrival within 35 cm. Stage63 instead queries the same source55 grid/cost and source56 LOS simplification from the actual delivered stationary pose to the unchanged next original goal. The actor, yaw, command queue, body, floor memberships, local support law, unknown-support rejection and collision/underbody guards remain unchanged. Leg0 is unchanged. All four source queries succeeded and stayed within the pre-existing per-leg extraction bounds. No reference contacts or geometry selected the route.

This fixes redundant fixed-anchor reconnection; it **does not repair incomplete source furniture geometry**.

## Terminal contact

The second half of the proposed 2 cm movement intersects reference face **5355064**, at **1.087–1.092 m** above the original floor datum. The first half was clear, but neither half was committed because the complete command failed. The original RGB overlay in `diagnosis/frame_00021_seed_overlay.jpg` places the face on the round standing-table rim. Its centroid is about 10.3 cm from the stage61 rejected rim facet. This is not floor noise.

The independent stage64 source-only rim audit is a separate investigation; stage63 made no geometry augmentation or contact exemption based on it.

## Verification and resources

- **63 fixtures**, **492 frozen input hashes**; independent prelaunch and terminal review.
- **1,292 committed movement ticks** passed the local continuity and both half-segment guards.
- Every actual-start query matches its preceding drained arrival and unchanged next goal.
- **454.62 s wall / 459.69 s CPU**, peak process-tree RSS **2.38 GB**.
- Run output **about 2.7 MiB**, below the predeclared 4 MiB cap.
- Full verbose JSON fields and precision preserved using lossless XZ; actual CSV stayed uncompressed and flushed per row. Abrupt interruption can leave a verbose compressed tail unavailable; this run terminated normally and independently decoded evidence matches the trace.

## Files

`ACTUAL_PATH.png` shows committed movement and actual queried source routes. `run-01/result/` contains exact CSV/NPZ, XZ tick/query evidence, four compressed source-query receipts and terminal results. `evidence_codec.py` reads the codec formats and explicitly marks incomplete-stream recovery. `diagnosis/` contains direct original PLY extraction and RGB/depth association. `INDEPENDENT_TERMINAL_REVIEW.json` records the independent recount.

The source mesh disagreement remains an open blocker. No completed lap, no three-lap test and no physical-device trial are claimed.
