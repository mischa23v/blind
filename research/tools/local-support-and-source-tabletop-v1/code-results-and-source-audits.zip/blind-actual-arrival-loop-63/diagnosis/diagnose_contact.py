from pathlib import Path
import json,struct,math,hashlib,numpy as np
H=Path(__file__).resolve().parent;P=H.parent;W=P.parent;r=json.loads((P/'run-01/result/RESULT.json').read_text());half,hit=next((i,c['actualBody'])for i,c in enumerate(r['terminal']['contacts'])if c['actualBody']['contact']);cid=hit['firstReferenceCellID'];mesh=W/'blind-koivu-faro-acquisition-04/selected-reference/gt_mesh.ply'
with np.load(W/'blind-split-candidate-game-03/inputs/koivu_5cm_v2_pipeline2_out.npz')as z:R=z['R'];t=z['t']
A=np.array(json.loads((W/'blind-koivu-faro-acquisition-04/selected-reference/icp_iphone.json').read_text())['gt_transformation']);B=np.array([[1.,0,0],[0,0,-1],[0,1,0]]);M=np.eye(4);M[:3,:3]=R.T@B;M[:3,3]=-R.T@t;T=A@M;I=np.linalg.inv(T)
with mesh.open('rb')as f:
 header=b''
 while not header.endswith(b'end_header\n'):header+=f.readline()
 assert b'element vertex 8940320\n'in header
 f.seek(len(header)+8940320*48+cid*13);n,*ids=struct.unpack('<BIII',f.read(13));assert n==3;ref=[]
 for v in ids:f.seek(len(header)+v*48);ref.append(struct.unpack('<ddd',f.read(24)))
ref=np.array(ref);q=ref.astype(np.float32).astype(float)@I[:3,:3].T+I[:3,3];normal=np.cross(q[1]-q[0],q[2]-q[0]);normal/=np.linalg.norm(normal);state=np.array(r['finalPosition']);yaw=r['finalYawRadians'];forward=np.array([math.cos(yaw),math.sin(yaw)]);lat=np.array([-math.sin(yaw),math.cos(yaw)]);relative=q[:,[0,2]]-state[[0,2]];local=np.c_[relative@forward,relative@lat]
o={'scope':'exact rejected body face direct PLY extraction; no classification or route changes','referenceTransformSHA256':hashlib.sha256(T.tobytes()).hexdigest(),'rows':[{'referenceCellID':cid,'vertexIDs':ids,'referenceVerticesDouble':ref.tolist(),'verticesOriginalGameXYZ':q.tolist(),'centroidOriginalGameXYZ':q.mean(0).tolist(),'triangleXYZExtentMetres':np.ptp(q,axis=0).tolist(),'normalOriginalGameXYZ':normal.tolist(),'heightAboveFinalFootRangeMetres':(q[:,1]-state[1]).tolist(),'orientedForwardLateralFromFinalActorCentre':local.tolist()}],'finalCommittedPose':state.tolist(),'finalYawRadians':yaw,'actorHalfForwardLateral':[.15,.225],'rejectedHalfIndex':half,'rejectedHalfSweep':hit['sweep'],'referenceGeometryContact':hit,'noPhysicalCollisionCommitted':True};(H/'CONTACT_FACE_DIAGNOSIS.json').write_text(json.dumps(o,indent=2)+'\n');print(json.dumps(o['rows'],indent=2))
