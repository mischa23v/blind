from pathlib import Path
import hashlib,json,time,resource,signal,gzip
H=Path(__file__).resolve().parent
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2));resource.setrlimit(resource.RLIMIT_CPU,(30,30));signal.alarm(45)
from source_replan import ActualArrivalPlanner
p=json.loads((H/'SELECTED_PLAN.json').read_text());start=p['legs'][1]['sourceStartOriginalXYZ'];goal=p['legs'][1]['originalTaskGoal']
protocol={'scope':'fixed original-anchor source-only timing; no world or movement','leg':1,'start':start,'goal':goal,'codeSHA256':hashlib.sha256((H/'source_replan.py').read_bytes()).hexdigest(),'querySelection':'original second-leg endpoints, not failed evaluator pose'}
(H/'SOURCE_TIMING_PROTOCOL.json').write_text(json.dumps(protocol,indent=2)+'\n')
t=time.monotonic();n=ActualArrivalPlanner();built=time.monotonic();r=n.query(start,goal,1);done=time.monotonic();n.close()
with gzip.open(H/'SOURCE_TIMING_QUERY.json.gz','wt')as f:json.dump(r,f,separators=(',',':'))
receipt={'complete':r['complete'],'reason':r['reason'],'buildSeconds':built-t,'querySeconds':done-built,'totalSeconds':done-t,'belowInherited15SecondIPCDeadline':done-t<15,'points':len(r.get('points',[])),'peakRSSKiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'movement':False,'referenceUsed':False}
(H/'SOURCE_TIMING_RESULT.json').write_text(json.dumps(receipt,indent=2)+'\n');print(receipt)
