from pathlib import Path
import gzip,lzma,json,time,resource,hashlib,gc
H=Path(__file__).resolve().parent;W=H.parent
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2));resource.setrlimit(resource.RLIMIT_CPU,(90,90))
rows=[]
for name in ['TICK_EVIDENCE.jsonl.gz','QUERY_OPTIMIZATION.json.gz']:
 p=W/'blind-local-support-loop-61/run-01/result'/name;packed=p.read_bytes();raw=gzip.decompress(packed);digest=hashlib.sha256(raw).hexdigest()
 for preset in [3,6]:
  before=time.process_time();t=time.monotonic();compressed=lzma.compress(raw,format=lzma.FORMAT_XZ,preset=preset);elapsed=time.monotonic()-t;cpu=time.process_time()-before
  restored=lzma.decompress(compressed);verified=restored==raw and hashlib.sha256(restored).hexdigest()==digest
  rows.append({'file':name,'preset':preset,'rawBytes':len(raw),'originalGzipBytes':len(packed),'xzBytes':len(compressed),'compressionWallSeconds':elapsed,'compressionCPUSeconds':cpu,'byteExactRoundtrip':verified,'rawSHA256':digest,'peakRSSKiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss})
  del compressed,restored;gc.collect()
 del raw,packed;gc.collect()
out={'scope':'in-memory lossless codec benchmark on unchanged61 evidence; no evidence fields omitted','rows':rows,'temporaryCompressedFilesWritten':False};(H/'LOSSLESS_CODEC_BENCHMARK.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
