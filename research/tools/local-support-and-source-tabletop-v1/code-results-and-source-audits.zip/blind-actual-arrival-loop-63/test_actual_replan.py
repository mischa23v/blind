import unittest
from unittest.mock import patch
import numpy as np
from source_replan import ActualArrivalPlanner
from planner import edge_cost
class FlatNative:
 def sample(self,p,ext=None):return np.asarray(p,float),.5
 def segment(self,a,b):return True
class Tests(unittest.TestCase):
 def planner(self):
  p=object.__new__(ActualArrivalPlanner);p.native=FlatNative();p.points=np.array([[x,0.,0.]for x in(-.1,0.,.1,.2,.3)]);p.clearance=np.full(5,.5);p.adj=[[]for _ in range(5)]
  for i in range(4):
   c=edge_cost(p.points[i],p.points[i+1],.5,.5);p.adj[i].append((i+1,c));p.adj[i+1].append((i,c))
  p.corrected=lambda a:np.array(a);p.original=lambda a:np.array(a);p.bounds=[{'floorCandidateXZBounds':[[-2,-2],[2,2]]}for _ in range(5)]
  return p
 def test_exact_actual_xyz_and_original_goal(self):
  p=self.planner();a=np.array([-.04,.012,.01]);g=np.array([.24,0.,.01]);r=p.query(a,g,1)
  self.assertTrue(r['complete']);np.testing.assert_array_equal(r['points'][0],a);np.testing.assert_array_equal(r['points'][-1],g);self.assertFalse(r['actorSnapped']);self.assertFalse(r['referenceInputUsed']);np.testing.assert_array_equal(a,[-.04,.012,.01])
 def test_graph_immutable_across_queries(self):
  p=self.planner();before=[list(x)for x in p.adj];v=p.points.copy();p.query([-.04,.012,.01],[.24,0,.01],1);self.assertEqual(p.adj,before);np.testing.assert_array_equal(v,p.points)
 def test_full_rotating_envelope_rejects_bounds(self):
  p=self.planner();p.bounds[1]={'floorCandidateXZBounds':[[-.1,-.1],[.4,.1]]};r=p.query([-.04,0,.01],[.24,0,.01],1);self.assertFalse(r['complete']);self.assertEqual(r['reason'],'sourceRouteOutsideFrozenLegBounds')
 def test_missing_source_association_rejects(self):
  p=self.planner();p.native.sample=lambda *a:None;self.assertFalse(p.query([0,0,0],[.2,0,0],1)['complete'])
 def test_no_nonfinite_or_initial_leg_query(self):
  p=self.planner()
  for a,leg in [([float('nan'),0,0],1),([0,0,0],0),([0,0,0],5)]:
   with self.assertRaises(ValueError):p.query(a,[.2,0,0],leg)
 def test_exact_goal_not_mutated(self):
  p=self.planner();g=np.array([.24,.003,.01]);copy=g.copy();r=p.query([-.04,0,.01],g,4);np.testing.assert_array_equal(g,copy);np.testing.assert_array_equal(r['unchangedOriginalGoalXYZ'],copy)
 def test_failed_handoff_query_never_falls_back_or_retries(self):
  import tempfile
  from pathlib import Path
  from test_loop_contract import FakeModel
  import loop_map as lm
  p=lm.load_plan();m=FakeModel(p);m.begin_next(1)
  class Fail:
   calls=0
   def query(self,*args):self.calls+=1;return {'complete':False,'reason':'test missing source route'}
  m.replanner=Fail()
  with tempfile.TemporaryDirectory()as tmp:
   h=Path(tmp);(h/'run-01/result').mkdir(parents=True)
   with patch.object(lm,'H',h):
    a=m.route(np.array([1.,.012,2.]),p['legs'][1]['originalTaskGoal'])
    b=m.route(np.array([1.,.012,2.]),p['legs'][1]['originalTaskGoal'])
  self.assertFalse(a['complete']);self.assertFalse(b['complete']);self.assertEqual(m.replanner.calls,1);self.assertEqual(m.points.shape,(0,3))
 def test_delivered_height_not_native_height_gate(self):
  from test_loop_contract import FakeModel
  import loop_map as lm
  p=lm.load_plan();m=FakeModel(p)
  actual=np.array(p['start']);actual[1]=.06
  r=m.route(actual,p['legs'][0]['originalTaskGoal'])
  self.assertEqual(r['projectedStart'][1],0.);self.assertEqual(actual[1],.06)
if __name__=='__main__':unittest.main()
