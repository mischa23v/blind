from pathlib import Path
import json,hashlib
H=Path(__file__).resolve().parent;W=H.parent
f=json.loads((W/'blind-local-support-loop-61/FROZEN.json').read_text());files=f['files'].copy()
for stage in ['blind-clearance-centered-loop-55','blind-clearance-los-simplification-56']:
 files.update(json.loads((W/stage/'FROZEN.json').read_text())['files'])
for p in [*H.glob('*.py'),H/'SELECTED_PLAN.json',H/'MOVEMENT_PROTOCOL.md',H/'EVIDENCE_CODEC.json',H/'LOSSLESS_CODEC_BENCHMARK.json',H/'OUTPUT_FORECAST.json',H/'SOURCE_TIMING_PROTOCOL.json',H/'SOURCE_TIMING_RESULT.json']:
 files[str(p.relative_to(W))]=hashlib.sha256(p.read_bytes()).hexdigest()
for p,digest in files.items():assert hashlib.sha256((W/p).read_bytes()).hexdigest()==digest,p
for name in ['SELECTED_PLAN.json','local_support.py']:
 assert(H/name).read_bytes()==(W/'blind-local-support-loop-61'/name).read_bytes(),name
assert not(H/'FROZEN.json').exists()
f['resourceLimits']['outputBytes']=4*1024**2
f['sourcePathUnchangedFrom57']=False
f.update(files=files,scope='63 actual-arrival source-only handoff replanning; same61world/body/support; lossless output codec change',actualArrivalSourceReplanning=True,sourceGridCostAndLOSSimplificationUnchanged=True,physicalPoliciesUnchangedFrom61=True,outputCapBytes=4*1024**2)
# Update any inherited declared budget field as well as explicit cap.
if 'budgets'in f:
 for k in list(f['budgets']):
  if k in ['outputBytes','outputCapBytes']:f['budgets'][k]=4*1024**2
(H/'FROZEN.json').write_text(json.dumps(f,indent=2)+'\n');print(hashlib.sha256((H/'FROZEN.json').read_bytes()).hexdigest(),len(files))
