exec(open(__file__.replace('validate.py','compare_source.py')).read().split('rows=[]')[0])
import hashlib
checks=[]
for k in [0,123,21010,len(tri)-1]:
 p=xyz[k].mean(0);distance=nearest(p)['distanceMetres'];assert distance<1e-8;checks.append({'triangleCentroid':k,'nearestDistance':distance})
for r in result['fits']:assert r['pointReprojectionMaxPixels']<1e-8
paths=[W/'blind-polycam-alignment-feasibility-36/POLYCAM_INTRINSIC_GEOMETRY.npz',W/'blind-polycam-rigid-registration-37/run-01/CANDIDATE_RIGID_TRANSFORM.npz',W/'blind-pose-experiments-review-17/upstream/pose-consistency/runs/koivu_floorfix/pipeline2_out.npz']
inv={r['frame_id']:r for r in json.loads((W/'koivu-room-photo-catalog/inventory.json').read_text())['frames']}
for n in [19,20,21]:paths.extend([W/f'blind-koivu-game-07/map/depths/frame_{n:05}.png',Path(inv[f'frame_{n:05}']['path'])])
pins={str(p.relative_to(W)):hashlib.sha256(p.read_bytes()).hexdigest()for p in paths}
(H/'VALIDATION.json').write_text(json.dumps({'nativePointReprojectionMaxPixels':max(r['pointReprojectionMaxPixels']for r in result['fits']),'exactTriangleCentroidChecks':checks,'inputSHA256':pins,'noReferenceInputs':True,'sourceMeshComparisonCoordinateChain':'OBJ -> frozen stage37 corrected-level rigid transform -> inverse corrected R,t -> original phone coordinates; source camera poses are original, uncorrected','allPassed':True},indent=2)+'\n');print('PASS')
