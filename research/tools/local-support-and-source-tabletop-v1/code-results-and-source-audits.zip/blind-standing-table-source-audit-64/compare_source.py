from pathlib import Path
import numpy as np,json
H=Path(__file__).resolve().parent;W=H.parent;result=json.loads((H/'RESULT.json').read_text())
with np.load(W/'blind-polycam-alignment-feasibility-36/POLYCAM_INTRINSIC_GEOMETRY.npz')as z:obj=z['verticesOBJ'];tri=z['triangles']
with np.load(W/'blind-polycam-rigid-registration-37/run-01/CANDIDATE_RIGID_TRANSFORM.npz')as z:lev=obj@z['rotationOBJToLevel'].T+z['translationOBJToLevel']
with np.load(W/'blind-pose-experiments-review-17/upstream/pose-consistency/runs/koivu_floorfix/pipeline2_out.npz')as z:v=(lev-z['t'])@z['R']
xyz=v[tri];a=xyz[:,0];u=xyz[:,1]-a;w=xyz[:,2]-a;normal=np.cross(u,w);n2=(normal*normal).sum(1);du=(u*u).sum(1);dw=(w*w).sum(1);uw=(u*w).sum(1);det=du*dw-uw*uw

def nearest(query):
 proj=query-normal*np.divide(((query-a)*normal).sum(1),n2,out=np.zeros(len(n2)),where=n2>0)[:,None];pu=((proj-a)*u).sum(1);pw=((proj-a)*w).sum(1);s=np.divide(pu*dw-pw*uw,det,out=np.full(len(det),np.nan),where=abs(det)>1e-20);tt=np.divide(pw*du-pu*uw,det,out=np.full(len(det),np.nan),where=abs(det)>1e-20);inside=(s>=0)&(tt>=0)&(s+tt<=1);best=np.full((len(tri),3),np.nan);bestd=np.full(len(tri),np.inf)
 for aa,bb in((0,1),(1,2),(2,0)):
  start=xyz[:,aa];edge=xyz[:,bb]-start;den=(edge*edge).sum(1);f=np.clip(np.divide(((query-start)*edge).sum(1),den,out=np.zeros(len(den)),where=den>0),0,1);p=start+f[:,None]*edge;dist=((p-query)**2).sum(1);take=dist<bestd;best[take]=p[take];bestd[take]=dist[take]
 pd=((proj-query)**2).sum(1);take=inside&(pd<bestd);best[take]=proj[take];bestd[take]=pd[take];ix=int(np.argmin(bestd));return {'triangle':ix,'distanceMetres':float(np.sqrt(bestd[ix])),'sourcePointPhone':best[ix].tolist()}
rows=[]
for fit in result['fits']:
 pts=np.array(fit['contourPhoneXYZ']);found=[nearest(q)for q in pts];center=nearest(np.array(fit['circleCenterPhone']));rows.append({'frame':fit['frame'],'contourNearestSourceTriangles':found,'contourDistanceP0P50P95P100Metres':np.quantile([x['distanceMetres']for x in found],[0,.5,.95,1]).tolist(),'fittedCenterNearestSourceTriangle':center})
(H/'SOURCE_MESH_COMPARISON.json').write_text(json.dumps({'noFAROInputs':True,'scope':'Fixed source registration vs independent source RGB/depth contour; nearest triangle distances are not collision or clearance proof','rows':rows},indent=2)+'\n');print(json.dumps(rows,indent=2))
