exec(open(__file__.replace('overlay_source.py','compare_source.py')).read().split('rows=[]')[0])
from PIL import Image,ImageDraw
inv={r['frame_id']:r['path']for r in json.loads((W/'koivu-room-photo-catalog/inventory.json').read_text())['frames']}
poses={int(Path(f['file_path']).stem.split('_')[-1]):f for f in json.loads((W/'blind-mushroom-koivu-acquisition-01/selected/room_datasets/koivu/iphone/long_capture/transformations.json').read_text())['frames']}
f=poses[21];T=np.array(f['transform_matrix']);cam=(v-T[:3,3])@T[:3,:3];uv=np.c_[cam[:,0]/-cam[:,2]*f['fl_x']+f['cx']-.5,-cam[:,1]/-cam[:,2]*f['fl_y']+f['cy']-.5]
fit=result['fits'][0];center=np.array(fit['circleCenterPhone']);plane=np.array(fit['planeNormalPhone']);# only source triangles within60cm of fittedcentre, so background doesnot falsely imply tablecoverage
near=(np.linalg.norm(xyz-center,axis=2).min(1)<.6)&(np.abs(xyz@plane-fit['planeOffsetPhone']).min(1)<.05)
im=Image.open(inv['frame_00021']).convert('RGB');d=ImageDraw.Draw(im)
for ids in tri[near]:
 if np.all(cam[ids,2]<0):d.line([tuple(x)for x in uv[ids]]+[tuple(uv[ids[0]])],fill='#00cfff',width=1)
p=json.loads((H/'PROTOCOL.json').read_text());d.line([tuple(x)for x in p['views']['21']['contour']]+[tuple(p['views']['21']['contour'][0])],fill='red',width=2)
im.crop((280,490,670,640)).resize((780,300)).save(H/'SOURCE_MESH_OVERLAY.jpg',quality=85)
print('triangles',near.sum())
