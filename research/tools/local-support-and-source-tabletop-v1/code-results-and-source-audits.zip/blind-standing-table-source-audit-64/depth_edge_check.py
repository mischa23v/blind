from pathlib import Path
import json,numpy as np
from PIL import Image
H=Path(__file__).resolve().parent;W=H.parent
P=json.loads((H/'PROTOCOL.json').read_text());R=json.loads((H/'RESULT.json').read_text());frames={int(Path(f['file_path']).stem.split('_')[-1]):f for f in json.loads((W/'blind-mushroom-koivu-acquisition-01/selected/room_datasets/koivu/iphone/long_capture/transformations.json').read_text())['frames']};rows=[]
for r in R['fits']:
 n=r['frame'];f=frames[n];T=np.array(f['transform_matrix']);xyz=np.array(r['contourPhoneXYZ']);cam=(xyz-T[:3,3])@T[:3,:3];uv=np.array(P['views'][str(n)]['contour']);D=np.array(Image.open(W/f'blind-koivu-game-07/map/depths/frame_{n:05}.png'))*.001;depth=D[uv[:,1],uv[:,0]];delta=depth+cam[:,2];rows.append({'frame':n,'nativeCells':((uv+3)//4).tolist(),'observedAxialDepthm':depth.tolist(),'sourcePlaneExpectedAxialDepthm':(-cam[:,2]).tolist(),'observedMinusPlaneDepthm':delta.tolist(),'absDeltaP50P95m':np.quantile(abs(delta),[.5,.95]).tolist(),'over10cmCount':int((abs(delta)>.1).sum()),'count':len(delta),'caveat':'Exact manually selected RGB boundary may mix foreground/background; this is edge-depth disagreement, not measured sensor error.'})
(H/'EDGE_DEPTH_CHECK.json').write_text(json.dumps(rows,indent=2)+'\n');print([(r['frame'],r['absDeltaP50P95m'],r['over10cmCount'])for r in rows])
