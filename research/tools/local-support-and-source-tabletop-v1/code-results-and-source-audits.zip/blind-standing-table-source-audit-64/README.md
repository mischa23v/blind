# Standing-table source-only rim audit (64)

## Finding
The exported original Polycam mesh does not adequately represent the visibly complete tabletop outline in three source RGB views. This finding uses **no FARO geometry**. It makes source mesh incompleteness a supported explanation, rather than blaming room width or asserting furniture changed between captures. It does not settle every source/reference registration or capture discrepancy.

## Frozen test
Before fitting, PROTOCOL.json fixed manually identified entire tabletop ROIs and contours in original public RGB frames21 and19; frame20 was held out for reprojection. Frame22 is cropped and frame249 shows a partial underside, so neither substitutes for a complete top contour. Interior native-depth blocks fit a plane; RGB contour rays intersect that plane. Camera poses/intrinsics are original. One centre sample per repeated4x4 depth block prevents treating upscaled pixels as independent. Native block equality is checked. No depth filtering, parameter search, reference fit, path carving or map mutation occurred.

Assisted semantic contour selection is **not an automatic production detector**. A descriptive circle is fitted to measure instability, never adopted as a collider or used to invent unobserved sides. All contours and interior boxes are visible in FROZEN_ROIS.jpg.

| Result | frame21 | frame19 | heldout20 |
|---|---:|---:|---:|
| Native interior samples |188|184|184|
| Interior plane RMS |1.98mm|2.25mm|1.45mm|
| Descriptive circle radius |40.55cm|39.22cm|35.34cm|
| Contour-to-circle residual p95 |5.03cm|4.68cm|5.88cm|
| +/-3px boundary sensitivity maximum |6.78cm|6.69cm|4.78cm|
| RGB/depth contour nearest-source-mesh median |24.43cm|23.04cm|18.16cm|
| Fitted centre nearest-source-mesh distance |0.76cm|1.36cm|0.31cm|

Source frame19 contour projects into heldout20 at median1.00px/p952.13px from its independently selected observed contour. Frame21->20 is3.69/7.33px. Independent fitted centres differ2.4–4.1cm. Small local plane RMS therefore **does not imply millimetre rim accuracy**: shallow intersection angles, plane tilt, manual boundary uncertainty and pose disagreement amplify error.

SOURCE_MESH_OVERLAY.jpg projects unchanged source mesh triangles near the tabletop into original RGB21. Red is observed full contour; cyan is nearby source mesh. The central/right fragments do not cover the large visible left edge. The exact nearest-triangle diagnostic uses all original triangles, not the display subset. The fixed source registration itself has nonzero error; comparing to three independent source observations and the near-centre agreement reduces but does not eliminate this confound.

At the14 selected RGB rim points per view, source axial depth differs from plane-expected axial depth by median9.4/20.7/18.0cm.6/12/8 points respectively exceed10cm. Boundary pixels mix table/background and are not clean sensor-error samples. This helps explain why a mesh can miss a thin rim despite a visible RGB edge and good interior depth.

## Verdict
This is sufficient evidence to **develop and test** a source RGB-contour + interior-depth conservative object-envelope candidate rather than trust the exported mesh alone. It is **not sufficient to adopt the fitted circle as a trusted collider**. Rim position varies by several centimetres, underside/thickness/legs are not bounded, and source pose bias/confidence are unavailable. A convex envelope of observed outline candidates could be a conservative diagnostic, but its margin is not calibrated. No free-space or safety authority follows; missing mesh must not become permission to walk through the tabletop.

The table is visible in RGB; its outline can be estimated using code without LLM geometry or FARO sizing. Whether that improves complete movement safely remains an unrun downstream experiment. No motion trials, map edits, source/reference furniture-change claim, or live-device proof are produced here.

## Reproduce / validation
From repository workspace root:
```
OPENBLAS_NUM_THREADS=1 python blind-standing-table-source-audit-64/audit.py
OPENBLAS_NUM_THREADS=1 python blind-standing-table-source-audit-64/compare_source.py
OPENBLAS_NUM_THREADS=1 python blind-standing-table-source-audit-64/depth_edge_check.py
OPENBLAS_NUM_THREADS=1 python blind-standing-table-source-audit-64/overlay_source.py
OPENBLAS_NUM_THREADS=1 python blind-standing-table-source-audit-64/validate.py
```
VALIDATION.json pins source inputs and records exact native point reprojection and nearest-triangle zero-distance checks. No original files modified, no full RGB copies, no raw mesh copy, no downloads/installations. Approximately180KiB output. Public dataset derivatives only.
