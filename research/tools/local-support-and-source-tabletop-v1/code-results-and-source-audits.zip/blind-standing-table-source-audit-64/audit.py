from pathlib import Path
import json,hashlib,numpy as np
from PIL import Image
H=Path(__file__).resolve().parent;W=H.parent
P=json.loads((H/'PROTOCOL.json').read_text());pp=W/'blind-mushroom-koivu-acquisition-01/selected/room_datasets/koivu/iphone/long_capture/transformations.json'
F={int(Path(f['file_path']).stem.split('_')[-1]):f for f in json.loads(pp.read_text())['frames']}
def ray(n,uv):
 f=F[n];T=np.array(f['transform_matrix']);uv=np.asarray(uv);d=np.c_[(uv[:,0]+.5-f['cx'])/f['fl_x'],-(uv[:,1]+.5-f['cy'])/f['fl_y'],-np.ones(len(uv))];return T[:3,3],d@T[:3,:3].T

def project(n,p):
 f=F[n];T=np.array(f['transform_matrix']);q=(p-T[:3,3])@np.linalg.inv(T[:3,:3]).T;return np.c_[q[:,0]/-q[:,2]*f['fl_x']+f['cx']-.5,-q[:,1]/-q[:,2]*f['fl_y']+f['cy']-.5]

def fit(n):
 p=P['views'][str(n)];D=np.array(Image.open(W/f'blind-koivu-game-07/map/depths/frame_{n:05d}.png'))*.001
 # Crop15 of4x nearest-neighbour upscale: intact blocks start1,5,9; centres2.5,6.5,10.5.
 b=D[1:981,1:729].reshape(245,4,182,4);assert np.all(np.ptp(b,axis=(1,3))==0)
 u0,v0,u1,v1=p['interior'];u=np.arange(2.5,D.shape[1]-2,4);v=np.arange(2.5,D.shape[0]-2,4);u=u[(u>=u0)&(u<u1)];v=v[(v>=v0)&(v<v1)];uu,vv=np.meshgrid(u,v);uv=np.c_[uu.ravel(),vv.ravel()];depth=D[np.round(uv[:,1]).astype(int),np.round(uv[:,0]).astype(int)];assert np.all(depth>0)
 c,r=ray(n,uv);xyz=c+r*depth[:,None];mean=xyz.mean(0);_,_,vt=np.linalg.svd(xyz-mean,full_matrices=False);normal=vt[-1];basis=vt[:2];offset=mean@normal;error=xyz@normal-offset
 def intersect(uv):
  cc,rr=ray(n,uv);return cc+rr*((offset-cc@normal)/(rr@normal))[:,None]
 points=intersect(np.array(p['contour']));q=(points-mean)@basis.T;A=np.c_[2*q,np.ones(len(q))];sol=np.linalg.lstsq(A,(q*q).sum(1),rcond=None)[0];center=mean+sol[:2]@basis;radius=np.sqrt(sol[2]+(sol[:2]**2).sum());res=np.linalg.norm(points-center,axis=1)-radius
 pert=np.array([intersect(np.array(p['contour'])+s) for s in [[-3,-3],[-3,3],[3,-3],[3,3]]]);out={'frame':n,'nativeSamples':len(xyz),'depthRange':list(map(float,[depth.min(),depth.max()])),'planeNormalPhone':normal.tolist(),'planeOffsetPhone':float(offset),'interiorRMSEm':float(np.sqrt(np.mean(error**2))),'interiorMaxResidualm':float(abs(error).max()),'pointReprojectionMaxPixels':float(abs(project(n,xyz)-uv).max()),'contourPhoneXYZ':points.tolist(),'circleCenterPhone':center.tolist(),'circleRadiusm':float(radius),'circleResidualP50P95m':np.quantile(abs(res),[.5,.95]).tolist(),'contourPlusMinus3PixelMaxDisplacementm':float(np.linalg.norm(pert-points,axis=2).max()),'planeBasis':basis.tolist()};return out
rows=[fit(n)for n in [21,19,20]]
a,b,h=rows
# Fixed cross-view plane distances, contour nearest-neighbour distances, independent radius/centre agreement.
checks=[]
for x,y in [(a,b),(a,h),(b,h)]:
 pts=np.array(x['contourPhoneXYZ']);projected=project(y['frame'],pts);target=np.array(P['views'][str(y['frame'])]['contour']);seg0=target;seg1=np.roll(target,-1,axis=0);d=seg1-seg0;alpha=np.clip(((projected[:,None]-seg0)*d).sum(2)/(d*d).sum(1),0,1);dist=np.linalg.norm(projected[:,None]-seg0-alpha[:,:,None]*d,axis=2).min(1)
 checks.append({'frames':[x['frame'],y['frame']],'centerDistanceMetres':float(np.linalg.norm(np.array(x['circleCenterPhone'])-y['circleCenterPhone'])),'radiusDifferenceMetres':abs(x['circleRadiusm']-y['circleRadiusm']),'contourToOtherPlaneP50P95Metres':np.quantile(abs(pts@np.array(y['planeNormalPhone'])-y['planeOffsetPhone']),[.5,.95]).tolist(),'reprojectedContourToObservedPolylinePixelP50P95':np.quantile(dist,[.5,.95]).tolist(),'reprojectedContourPixels':projected.tolist()})
result={'scope':P['scope'],'poses':'original uncorrected phone camera poses; no reference-derived transform used','fits':rows,'crossViewChecks':checks,'nativeGridCheck':'100% intact 4x4 blocks identical, one sample per block at centre','uncertainty':'No confidence/tracking/extrinsic metadata. Adjacent views share pose bias; +/-3px not confidence interval. Descriptive circle is not adopted collider.','inputHashes':{str(pp.relative_to(W)):hashlib.sha256(pp.read_bytes()).hexdigest(),'PROTOCOL.json':hashlib.sha256((H/'PROTOCOL.json').read_bytes()).hexdigest()}}
(H/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'fits':[{k:r[k]for k in ['frame','nativeSamples','interiorRMSEm','circleRadiusm','circleResidualP50P95m','contourPlusMinus3PixelMaxDisplacementm']}for r in rows],'checks':checks},indent=2))
