# One-pass triangle-normal conditioning: one additional floor face

All five membership jobs completed, verifying the exact baseline52ground-ID bytes before applying the predeclared general rule. The rule added **one face in leg1**,16422577. The other four memberships are unchanged. Earlier53near-chair face921994 remains excluded everywhere. No movement occurred in59.

This is not a face whitelist: every original candidate is tested for finite positive quality<0.01 (minimum altitude/longest edge), an independently fitted rank-valid local patch<=5°, every vertex<=unchanged2mm residual, and exact edge adjacency to BASELINE accepted ground. One pass only; no recursive expansion or candidate-fed fitting. All original geometry remains. Nondegenerate45°raw-normal guard is unchanged.

30implementation fixtures and4independent full-classifier fixtures passed, including a10mmvertical sliver. A genuine sub2mmvertical ridge can still meet this model; that ambiguity is explicit, not a detection or safety claim.

| Leg | Baseline faces | Added faces | Final faces |
|---|---:|---:|---:|
|0|555862|0|555862|
|1|801739|1|801740|
|2|464207|0|464207|
|3|679229|0|679229|
|4|1023067|0|1023067|

Peak processRSS3.119GB. Every serial job stayed below180CPU/240wall and3.5GiB bounds. **Aggregate retained output6.34MB exceeded the declared5MiB total preparation target**, mainly the five compressed ground-ID arrays; this discrepancy is reported, not retroactively relabeled as passing. No evidence was deleted. Disk reserve remained above768MiB.

`SUMMARY.json` contains post-classification regression checks. Per-leg `RESULT.json` is compact; verbose independent fit receipts are retained losslessly as `PATCH_FITS.json.gz` with checksums. `GROUND_IDS.npz` contains original face IDs, not changed geometry.

Pre-run manifest: `4e7d6738ba73ac9f408f39aea7df6d22d74a7c9f578a97154fb0236bf647c939`.

A separate60movement attempt must freeze these inputs and preserve57path/body/guards. These evaluator-assisted support labels do not establish autonomous phone sensing, completed navigation or human safety.
