from pathlib import Path
import json,hashlib
H=Path(__file__).resolve().parent;W=H.parent;f=json.loads((W/'blind-seed-recovery-order-52/MEMBERSHIP_FROZEN.json').read_text());files=f['files'].copy()
paths=[*H.glob('*.py'),H/'PROTOCOL.md',W/'blind-guarded-table-loop-53/diagnosis/TERMINAL_FACE_DIAGNOSIS.json',W/'blind-clearance-guarded-loop-57/diagnosis/TERMINAL_FACE_DIAGNOSIS.json']
for i in range(5):paths.append(W/f'blind-seed-recovery-order-52/membership-leg{i}/GROUND_IDS.npz')
for p in paths:files[str(p.relative_to(W))]=hashlib.sha256(p.read_bytes()).hexdigest()
for p,h in files.items():assert hashlib.sha256((W/p).read_bytes()).hexdigest()==h,p
assert not(H/'MEMBERSHIP_FROZEN.json').exists();(H/'MEMBERSHIP_FROZEN.json').write_text(json.dumps({'scope':'isolated59one-pass geometry conditioning after exact52baseline, no movement','files':files},indent=2)+'\n');print(hashlib.sha256((H/'MEMBERSHIP_FROZEN.json').read_bytes()).hexdigest())
