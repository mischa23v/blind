import unittest,sys,importlib.util
from pathlib import Path
import numpy as np
H=Path(__file__).resolve().parent;W=H.parent;sys.path.insert(0,str(H));import ground_classifier_resource as new
s=importlib.util.spec_from_file_location('old_classifier50',W/'blind-polycam-varpu-executor-40/ground_classifier_resource.py');old=importlib.util.module_from_spec(s);sys.modules[s.name]=old;s.loader.exec_module(old)
def grid(height=0.,n=41,spacing=.01):
 v=np.array([[i*spacing,0.,j*spacing]for i in range(n)for j in range(n)]);v[(n//2)*n+n//2,1]=height;t=[]
 for i in range(n-1):
  for j in range(n-1):a=i*n+j;t.extend([[a,a+n,a+1],[a+n,a+n+1,a+1]])
 return v,np.array(t)
def run(module,v,t,seeds):return module.GroundSupport.from_geometry(np.arange(len(t),dtype=np.int64),t,np.arange(len(v),dtype=np.int64),v,np.ones(len(t),bool),seeds)
def seeds_for(v,t):
 bad=int(np.flatnonzero(v[t,:,][...,1].max(1)>0)[0]);return [0,100,500,900,1500,2200,2700,3100,bad],bad
class Tests(unittest.TestCase):
 def test_rejected_tiny_seed_recovers_without_widening(self):
  v,t=grid(.0011);seeds,bad=seeds_for(v,t)
  with self.assertRaises(old.GroundSupportUnavailable):run(old,v,t,seeds)
  g=run(new,v,t,seeds);self.assertTrue(all(g.is_ground(i)for i in seeds));self.assertIn(bad,g.receipt['recoveredOriginalSeedIDs']);self.assertEqual(g.receipt['maximumLocalEveryVertexResidualMetres'],.002);self.assertEqual(g.receipt['rawSteepEdgeGuardDegrees'],45.);self.assertTrue(g.receipt['deferredSeedFacesExcludedFromTraining'])
 def test_all_eligible_baseline_parity(self):
  v,t=grid();seeds=[0]*9;a=run(old,v,t,seeds);b=run(new,v,t,seeds);np.testing.assert_array_equal(a.ground_cell_ids,b.ground_cell_ids);np.testing.assert_array_equal(a.plane_coefficients,b.plane_coefficients)
 def test_four_mm_raised_bump_seed_rejected(self):
  v,t=grid(.004);seeds,bad=seeds_for(v,t)
  with self.assertRaises(new.GroundSupportUnavailable):run(new,v,t,seeds)
 def test_one_cm_toy_seed_rejected(self):
  v,t=grid(.01);seeds,bad=seeds_for(v,t)
  with self.assertRaises(new.GroundSupportUnavailable):run(new,v,t,seeds)
 def test_all_invalid_seeds_rejected(self):
  v,t=grid(.0011);seeds,bad=seeds_for(v,t)
  with self.assertRaisesRegex(new.GroundSupportUnavailable,'all original seeds'):run(new,v,t,[bad]*9)
 def test_one_eligible_seed_can_anchor_spanning_component(self):
  v,t=grid(.0011);seeds,bad=seeds_for(v,t);g=run(new,v,t,[0]*8+[bad]);self.assertTrue(g.is_ground(bad));self.assertGreater(g.receipt['trainingVertices'],3)
 def test_rank_deficient_training_component_rejected(self):
  v=np.array([[0.,0,0],[1e-10,0,0],[0,0,1e-10]]);t=np.array([[0,1,2]])
  with self.assertRaisesRegex(new.GroundSupportUnavailable,'rank deficient'):run(new,v,t,[0]*9)
 def test_disconnected_eligible_seed_island_rejected(self):
  v,t=grid(.0011);seeds,bad=seeds_for(v,t);k=len(v);v=np.vstack([v,[[.7,0,.7],[.8,0,.7],[.7,0,.8]]]);t=np.vstack([t,[k,k+1,k+2]]);seeds[0]=len(t)-1
  with self.assertRaisesRegex(new.GroundSupportUnavailable,'disconnected'):run(new,v,t,seeds)
 def test_missing_seed_id_rejected(self):
  v,t=grid();
  with self.assertRaises(new.GroundSupportUnavailable):run(new,v,t,[0,100,500,900,1500,2200,2700,3100,999999])
 def test_geometry_immutable(self):
  v,t=grid(.0011);before=v.copy();bt=t.copy();seeds,bad=seeds_for(v,t);run(new,v,t,seeds);np.testing.assert_array_equal(v,before);np.testing.assert_array_equal(t,bt)
if __name__=='__main__':unittest.main(verbosity=2)
