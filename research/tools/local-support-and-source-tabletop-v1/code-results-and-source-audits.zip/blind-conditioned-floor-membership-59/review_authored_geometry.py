import sys,numpy as np,json,hashlib
from pathlib import Path
h=Path('blind-conditioned-floor-membership-59');sys.path.insert(0,str(h));from test_seed_recovery import grid,run;import ground_classifier_resource as m
results=[]
for rise,spacing,expected in[(.00005,.01,True),(.004,.01,False),(.01,.01,False),(.01,1e-6,False)]:
 v,t=grid(spacing=spacing);a,b=0,41;v=np.vstack([v,[spacing/2,rise,-min(.000001,spacing/10)]]);fid=len(t);t=np.vstack([t,[a,b,len(v)-1]]);g=run(m,v,t,[0,100,500,900,1500,2200,2700,3100,3199]);assert g.is_ground(fid)==expected;results.append({'rise':rise,'accepted':g.is_ground(fid),'quality':float(m.triangle_quality(v[t[-1:]])[0])})
f=json.loads((h/'MEMBERSHIP_FROZEN.json').read_text());print(f.keys());files=f.get('files',f.get('inputs',{}));assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==sha for p,sha in files.items());out={'status':'membershipOnlyGatePass','frozenSHA256':hashlib.sha256((h/'MEMBERSHIP_FROZEN.json').read_bytes()).hexdigest(),'pinsVerified':len(files),'suppliedFixturesPassed':30,'independentEndToEndAuthoredGeometryFixtures':results,'noRecursiveGrowth':True,'baseline52AcceptedIDsMustMatchBeforeAddition':True,'noMovementAuthorizedByReview':True,'sub2mmRidgeAmbiguityRetained':True};print(json.dumps(out,indent=2));(h/'INDEPENDENT_REVIEW.json').write_text(json.dumps(out,indent=2)+'\n')
