# Frozen59: isolated one-pass geometry-conditioning support variant

Preserve52baseline classifier, all original faces/coordinates, source bounds/seeds and47/48active datum. First compute the exact baseline52accepted component and verify its ID-byte hash against saved52arrays. Training, robust independent local patch fits and2mm all-vertex residual are unchanged.

Add an original face ONLY if all hold:
- finite positive triangle quality `minimum altitude / longest3Dedge = |cross| / longest_edge²` is strictly below0.01;
- face is within original candidate bounds;
- independently fitted existing training patch is rank-valid/noncollinear and its tilt<=existing5degrees;
- EVERY original vertex residual<=unchanged2mm;
- face shares a complete original vertex-ID edge with the frozen BASELINE accepted component.

One pass, no recursive propagation, no added face or its unsupported vertices fed back into fitting. Vertices already legitimately shared with training faces remain legitimate evidence. Nondegenerate45degree raw-normal guard remains unchanged. Degenerate zero-area/nonfinite triangles are not newly admitted. All nine original seeds remain required by the baseline52stage. This is geometry conditioning, not a claim that all discrepancy is floating-point roundoff.

Fixtures cover strictqualityboundary, real thinverticalwall above2mm, raisedtoy, steep patch, rank-deficient/missing support, disconnected and point-only adjacency, no recursive chain, baselineparity and saved53near-chair face. Explicit counterexample: a genuine vertical ridge entirely inside2mm may pass; sub2mmgeometry remains unresolved and cannot be claimed safely detectable.

The rule has no face whitelist. Saved53face921994 and57face16422577 are post-run regression checks only. Do not clear the former to force movement. No movement occurs in59; new60would reuse unchanged57path/body/world/guard/controller with only newly frozen memberships.

Resource limits per serial leg:3.5GiB addressspace/RSS,180CPU/240wall,4.3GiB availableRAM preflight,6million candidate cap,768MiB disk reserve. Write verbose independent patch fits as lossless `PATCH_FITS.json.gz` with checksum; compactJSONreceipt and unchanged lossless ground-ID NPZ. No archive deletion, downloads or installs. Keep output<=5MiB total for five legs. Preserve all earlier results.
