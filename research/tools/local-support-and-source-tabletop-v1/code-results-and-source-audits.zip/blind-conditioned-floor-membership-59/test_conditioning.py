from pathlib import Path
import sys,json,numpy as np,unittest
H=Path(__file__).resolve().parent;sys.path.insert(0,str(H));from ground_classifier_resource import conditioned_additions,triangle_quality,robust_plane,GroundSupportUnavailable
class Tests(unittest.TestCase):
 def run_case(self,quality=.005,tilt=0.,residual=.001,fit=True,shared=True,within=True):
  ids=np.array([1,2]);tri=np.array([[0,1,2],[1,0,3]if shared else[4,5,6]]);return conditioned_additions(ids,tri,np.array([True,within]),np.array([.5,quality]),np.array([True,fit]),np.array([0,tilt]),np.array([0,residual]),np.array([1]))[0]
 def test_sliver_admitted(self):np.testing.assert_array_equal(self.run_case(),[2])
 def test_boundary_not_sliver(self):self.assertEqual(len(self.run_case(quality=.01)),0)
 def test_just_below_boundary(self):self.assertEqual(len(self.run_case(quality=np.nextafter(.01,0))),1)
 def test_degenerate_zero_rejected(self):self.assertEqual(len(self.run_case(quality=0)),0)
 def test_nonfinite_quality_rejected(self):self.assertEqual(len(self.run_case(quality=np.nan)),0)
 def test_vertical_wall_above_band_rejected(self):self.assertEqual(len(self.run_case(residual=.01)),0)
 def test_raised_toy_rejected(self):self.assertEqual(len(self.run_case(residual=.004)),0)
 def test_steep_true_patch_rejected(self):self.assertEqual(len(self.run_case(tilt=10)),0)
 def test_missing_rank_valid_fit_rejected(self):self.assertEqual(len(self.run_case(fit=False)),0)
 def test_disconnected_rejected(self):self.assertEqual(len(self.run_case(shared=False)),0)
 def test_out_of_bounds_rejected(self):self.assertEqual(len(self.run_case(within=False)),0)
 def test_sub2mm_vertical_ridge_ambiguity_explicit(self):self.assertEqual(len(self.run_case(residual=.0015)),1)
 def test_nonrecursive_chain(self):
  ids=np.array([1,2,3]);tri=np.array([[0,1,2],[1,0,3],[0,3,4]]);a,r=conditioned_additions(ids,tri,np.ones(3,bool),np.array([.5,.005,.005]),np.ones(3,bool),np.zeros(3),np.zeros(3),np.array([1]));np.testing.assert_array_equal(a,[2]);self.assertTrue(r['onePassNonRecursive'])
 def test_point_only_adjacency_rejected(self):
  ids=np.array([1,2]);tri=np.array([[0,1,2],[0,3,4]]);a,_=conditioned_additions(ids,tri,np.ones(2,bool),np.array([.5,.005]),np.ones(2,bool),np.zeros(2),np.zeros(2),np.array([1]));self.assertEqual(len(a),0)
 def test_original53chair_remains_rejected(self):
  r=json.loads((H.parent/'blind-guarded-table-loop-53/diagnosis/TERMINAL_FACE_DIAGNOSIS.json').read_text())['rows'][0];q=triangle_quality(np.array([r['verticesOriginalGameXYZ']]))[0];self.assertGreaterEqual(q,.01);self.assertEqual(len(self.run_case(quality=q,residual=r['maximumAbsoluteLocalResidualMetres'])),0)
 def test_57sliver_quality_conditioned(self):
  r=json.loads((H.parent/'blind-clearance-guarded-loop-57/diagnosis/TERMINAL_FACE_DIAGNOSIS.json').read_text())['rows'][0];q=triangle_quality(np.array([r['verticesOriginalGameXYZ']]))[0];self.assertLess(q,.01);self.assertEqual(len(self.run_case(quality=q,residual=r['maximumAbsoluteLocalResidualMetres'],tilt=r['frozenLocalPatchFit']['tiltDegrees'])),1)
 def test_normal_quality_equilateral(self):self.assertAlmostEqual(triangle_quality(np.array([[[0,0,0],[1,0,0],[.5,0,np.sqrt(3)/2]]]))[0],np.sqrt(3)/2)
 def test_actual_thin_vertical_wall_geometry(self):
  q=np.array([[[0,0,0],[0,.01,0],[.000001,.009,0]]]);quality=triangle_quality(q)[0];self.assertLess(quality,.01);self.assertEqual(len(self.run_case(quality=quality,residual=.01)),0)
 def test_actual_rank_deficient_patch_rejected(self):
  with self.assertRaises(GroundSupportUnavailable):robust_plane(np.array([[0,0,0],[1,0,0],[2,0,0]]),4096)
 def test_actual_steep_patch_rejected(self):
  with self.assertRaises(GroundSupportUnavailable):robust_plane(np.array([[0,0,0],[1,.5,0],[0,0,1],[1,.5,1]]),4096)
if __name__=='__main__':unittest.main(verbosity=2)
