# 65: frozen source-only tabletop exclusion hypothesis

**Candidate only. No navigation use, physical collider, or safety authority.** Original Polycam mesh is unchanged. This is an additive horizontal exclusion for the current1.60m-body scenario: observed tabletop extent falls within that body height. It does not reconstruct legs, underside, or solid volume below the tabletop.

## Construction frozen before scoring
Only source views19/21 contribute geometry: frozen64 manually selected full RGB contour rays intersect their independently fitted interior native-depth planes. Each contour point is considered at nominal pixel and four combinations of ±3px offsets. Their horizontal convex hull in the existing planner coordinate frame gives19vertices from140observed/perturbed hypotheses. No fitted circle, FARO, rejected contact point, route, or heldout20 geometry enters construction. No geometry was enlarged after scoring.

**±3px is a stress assumption, not a calibrated confidence bound.** Union includes measured per-view spread, but unknown systematic pose/depth biases remain. Convex enclosure conservatively bridges between observed outline points for exclusion; it does not assert that every enclosed location is a measured solid. Boundary samples do not prove all intervening unseen geometry.

`FROZEN_EXCLUSION.json` exports the polygon in corrected source-level XY and planner XZ, contributing hypotheses, input hashes and authorityfalse/unknowntrue flags. No body inflation is applied: a future planner must account for full oriented-body footprint separately and must not inflate twice.

## Geometrically held-out check
Frame20 was excluded from construction but **already inspected in audit64**. This is not fresh blind validation.

- Nominal fit-view hull area:0.495978m².
- Stress-union hull area:0.586735m², +0.090757m² (+18.3%).
- Heldout20 nominal points:14/14contained, minimum8.48mm inside boundary.
- Heldout20 ±3px hypotheses:70/70contained, minimum1.06mm inside boundary.
- Projected candidate source-point hull contains14/14independently selected frame20RGB contour points.

Containment margins are **geometric test results, not physical safety margins**. Heldout stress-point clearance is only~1mm; unsupported stronger error assumptions could escape the hull. No adjustment made after seeing this.

`HELDOUT20_PREVIEW.jpg`: cyan is projected candidate hypothesis hull; red is the frozen observed RGB outline. Projection combines observed per-view plane heights, not a generated solid.

## Camera matrix precision
Saved rotations have max|RᵀR−I|4.41e−8 to5.25e−8, determinant0.999999958 to1.000000026. Using inverse instead of transpose reduces native-point numerical roundtrip from~1.05e−5pixels to2.27e−13pixels. This tiny numerical issue **does not explain centimetre-scale mapping errors**.

## Limits and next gate
The envelope demonstrates a source-only way to conservatively exclude tabletop footprint missing from exported mesh. It does not establish complete obstacle detection, body clearance, small-object recall, source/reference capture consistency, live phone feasibility, or safe movement. Original data lack confidence/tracking/body-extrinsic metadata. Adjacent source views share correlated bias. No reference comparison or movement run was performed here. Root review is required before any experimental navigation use.

## Reproduce
```
OPENBLAS_NUM_THREADS=1 python blind-tabletop-exclusion-hypothesis-65/build.py
python blind-tabletop-exclusion-hypothesis-65/validate_and_preview.py
```
Candidate is written and hashed before scoring. Validation confirms matching hash, all construction points enclosed, strict convexity, coordinate conversion, and construction-view restrictions. Public source derivatives only; no downloads, installs, copied raw data, or original mesh modifications.
