from pathlib import Path
import json,hashlib,numpy as np
H=Path(__file__).resolve().parent;W=H.parent;S=W/'blind-standing-table-source-audit-64';P=json.loads((H/'PROTOCOL.json').read_text());roi=json.loads((S/'PROTOCOL.json').read_text());fits={r['frame']:r for r in json.loads((S/'RESULT.json').read_text())['fits']};posespath=W/'blind-mushroom-koivu-acquisition-01/selected/room_datasets/koivu/iphone/long_capture/transformations.json';F={int(Path(f['file_path']).stem.split('_')[-1]):f for f in json.loads(posespath.read_text())['frames']};metapath=W/'blind-pose-experiments-review-17/upstream/pose-consistency/runs/koivu_floorfix/pipeline2_out.npz'
with np.load(metapath)as z:N=z['R'];nt=z['t']
def points(n,shifts):
 f=F[n];r=fits[n];T=np.array(f['transform_matrix']);normal=np.array(r['planeNormalPhone']);offset=r['planeOffsetPhone'];out=[]
 for shift in shifts:
  uv=np.array(roi['views'][str(n)]['contour'])+shift;ray=np.c_[(uv[:,0]+.5-f['cx'])/f['fl_x'],-(uv[:,1]+.5-f['cy'])/f['fl_y'],-np.ones(len(uv))]@T[:3,:3].T;phone=T[:3,3]+ray*((offset-T[:3,3]@normal)/(ray@normal))[:,None];out.extend(phone@N.T+nt)
 return np.array(out)
def hull(pts):
 pts=sorted(set(map(tuple,pts)));cross=lambda o,a,b:(a[0]-o[0])*(b[1]-o[1])-(a[1]-o[1])*(b[0]-o[0]);lo=[];up=[]
 for p in pts:
  while len(lo)>=2 and cross(lo[-2],lo[-1],p)<=0:lo.pop()
  lo.append(p)
 for p in reversed(pts):
  while len(up)>=2 and cross(up[-2],up[-1],p)<=0:up.pop()
  up.append(p)
 return np.array(lo[:-1]+up[:-1])
def area(p):return float(abs(np.sum(p[:,0]*np.roll(p[:,1],-1)-p[:,1]*np.roll(p[:,0],-1)))/2)
def inside_dist(p,h):
 e=np.roll(h,-1,axis=0)-h;a=p[:,None]-h;cross=e[None,:,0]*a[:,:,1]-e[None,:,1]*a[:,:,0];inside=np.all(cross>=-1e-10,axis=1);alpha=np.clip((a*e).sum(2)/(e*e).sum(1),0,1);d=np.linalg.norm(a-alpha[:,:,None]*e,axis=2).min(1);return inside,d
shifts=[[0,0],[-3,-3],[-3,3],[3,-3],[3,3]];source=np.concatenate([points(n,shifts)for n in P['fitViews']]);nominal=np.concatenate([points(n,[[0,0]])for n in P['fitViews']]);h=hull(source[:,:2]);hn=hull(nominal[:,:2]);
# This file is the frozen candidate, written and hashed BEFORE reading heldout geometry into scoring.
obj={'authority':False,'unknown':True,'type':'additive_tabletop_navigation_exclusion_hypothesis','bodyHeightScenarioMetres':1.6,'bodyInflationApplied':False,'coordinateFrame':'corrected source-level XY horizontal, Z up; existing planner game=(X,Z,-Y)','polygonLevelXY':h.tolist(),'polygonPlannerXZ':np.c_[h[:,0],-h[:,1]].tolist(),'observedTopPointHeightRangeNotBounds': [float(source[:,2].min()),float(source[:,2].max())],'sourceFrames':P['fitViews'],'contourHypotheses':len(source),'nominalHullAreaSquareMetres':area(hn),'stressHullAreaSquareMetres':area(h),'areaIncreaseSquareMetres':area(h)-area(hn),'sourceHypothesisLevelXYZ':source.tolist(),'noFAROOrHeldoutUsed':True,'noUndersideLegsOrFilledVolumeClaim':True,'frozenInputsSHA256':{str(p.relative_to(W)):hashlib.sha256(p.read_bytes()).hexdigest()for p in [H/'PROTOCOL.json',S/'PROTOCOL.json',S/'RESULT.json',posespath,metapath]}}
frozen=H/'FROZEN_EXCLUSION.json';frozen.write_text(json.dumps(obj,indent=2)+'\n');sha=hashlib.sha256(frozen.read_bytes()).hexdigest()
heldnom=points(20,[[0,0]]);heldstress=points(20,shifts);checks=[]
for label,p in [('heldout_nominal',heldnom),('heldout_declared_stress',heldstress),('fit_nominal',nominal)]:
 ok,d=inside_dist(p[:,:2],h);checks.append({'set':label,'points':len(p),'contained':int(ok.sum()),'outside':int((~ok).sum()),'maxOutsideDistanceMetres':float(d[~ok].max())if (~ok).any()else 0,'minInsideBoundaryClearanceMetres':float(d[ok].min())if ok.any()else None})
# Reprojection of already frozen candidate top hypotheses to heldout original RGB; report bounds and manually frozen contour containment, not pixel-scale geometry.
f=F[20];T=np.array(f['transform_matrix']);phone=(source-nt)@np.linalg.inv(N).T;cam=(phone-T[:3,3])@np.linalg.inv(T[:3,:3]).T;uv=np.c_[cam[:,0]/-cam[:,2]*f['fl_x']+f['cx']-.5,-cam[:,1]/-cam[:,2]*f['fl_y']+f['cy']-.5];pixh=hull(uv);pixobs=np.array(roi['views']['20']['contour']);ok,d=inside_dist(pixobs,pixh)
rot=[]
for n in [19,20,21]:
 m=np.array(F[n]['transform_matrix'])[:3,:3];rot.append({'frame':n,'maxAbsRtRMinusI':float(abs(m.T@m-np.eye(3)).max()),'frobeniusRtRMinusI':float(np.linalg.norm(m.T@m-np.eye(3))),'determinant':float(np.linalg.det(m)),'maxAbsInverseMinusTranspose':float(abs(np.linalg.inv(m)-m.T).max())})
score={'frozenCandidateSHA256':sha,'scoredAfterFreeze':True,'candidateNotEnlargedAfterScoring':True,'containment':checks,'heldoutRGBReprojection':{'observedContourPoints':len(pixobs),'containedByProjectedCandidateHull':int(ok.sum()),'maxOutsidePixels':float(d[~ok].max())if (~ok).any()else 0,'projectedCandidateHullPixels':pixh.tolist(),'caveat':'Projection hull combines observed top heights across views. It is not a reconstructed solid or calibrated bound.'},'poseMatrixChecks':rot,'priorTransposeRoundtripMaxPixels':1.0465074069543334e-5,'trueInverseRoundtripMaxPixels':2.2737367544323206e-13,'noReferenceComparisonRun':True};(H/'HELDOUT_SCORE.json').write_text(json.dumps(score,indent=2)+'\n');print(json.dumps({'area':[area(hn),area(h)],'vertices':len(h),'checks':checks,'RGB':score['heldoutRGBReprojection'],'rotations':rot},indent=2))
