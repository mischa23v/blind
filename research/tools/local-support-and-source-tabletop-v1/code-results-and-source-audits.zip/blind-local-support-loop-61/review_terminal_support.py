from pathlib import Path
import json,gzip,numpy as np,math
h=Path('blind-local-support-loop-61');p=h/'run-01/result';r=json.load(open(p/'RESULT.json'));a=np.load(p/'ACTOR_TRACE.npz')['trace'];ev=[json.loads(s) for s in gzip.open(p/'TICK_EVIDENCE.jsonl.gz','rt')];total=0;count=0
for i,x in enumerate(ev):
 if not x['candidateStateCommitted'] or x['movement'] is None:continue
 rows=x['movement']['supportRows'];pos=[a[i,2:5].copy(),(a[i,2:5]+a[i+1,2:5])/2,a[i+1,2:5].copy()];pos[1][1]=max(t['modelHeightY'] for t in rows[1]['probes'])
 length=np.linalg.norm(pos[1]-pos[0])+np.linalg.norm(pos[2]-pos[1]);assert abs(length-x['movement']['attempted3DDistanceMetres'])<1e-12;assert length<=.025000001;total+=length;assert len(x['underbodyGuard']['halfSegments'])==2
 for j in range(2):
  old=rows[j]['probes'];new=rows[j+1]['probes'];disp=max(np.linalg.norm(np.array(q['modelXZ'])-v['modelXZ'])for q,v in zip(old,new));limit=.004+math.tan(math.radians(5))*disp;change=abs(max(q['modelHeightY']for q in new)-pos[j][1]);assert change<=limit+1e-12;g=x['underbodyGuard']['halfSegments'][j];assert not g['contact'];assert abs(g['lowerY']-(min(q['modelHeightY']for q in old+new)-.02))<1e-12;assert abs(g['upperY']-(max(pos[j][1],pos[j+1][1])+.002))<1e-12
 count+=1
assert abs(total-r['actual3DDistanceMetres'])<1e-10
for t in r['legTransitions']:
 assert not t['pendingMotion'] and not t['appliedMotion'];assert t['nextMembershipOverlap']['accepted'];assert t['nextMembershipOverlap']['observedHeightMatchesActualFoot'];assert not t['nextMembershipUnderbodyGuard']['contact']
f=h/'INDEPENDENT_TERMINAL_REVIEW.json';d=json.load(open(f));d['endpointChordDistance3DMetres']=d.pop('actual3DDistanceMetres',d.get('endpointChordDistance3DMetres'));d['actual3DDistanceMetresRecomputedIncludingMidpoints']=float(total);d['allFourGoalsReachedWithDrainedActor']=True;d.pop('firstGoalReachedWithDrainedActor',None);d['allCommittedContinuityAndBothGuardBoundsRecomputed']=count;d['rejectedBodyContactFace']=r['terminal']['contacts'][0]['actualBody']['firstReferenceCellID'];d['originalStartError3DMetres']=r['finalOriginalStartError3DMetres'];d['initialVerticalSettlementMetres']=r['initialVerticalSettlementMetres'];f.write_text(json.dumps(d,indent=2)+'\n');print(total,count,r['finalOriginalStartError3DMetres'])
