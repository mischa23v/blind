from pathlib import Path
import json,hashlib
H=Path(__file__).resolve().parent;W=H.parent;f=json.loads((W/'blind-conditioned-guarded-loop-60/FROZEN.json').read_text());files=f['files'].copy()
for p in [*H.glob('*.py'),H/'SELECTED_PLAN.json',H/'MOVEMENT_PROTOCOL.md']:files[str(p.relative_to(W))]=hashlib.sha256(p.read_bytes()).hexdigest()
for p,h in files.items():assert hashlib.sha256((W/p).read_bytes()).hexdigest()==h,p
assert (H/'SELECTED_PLAN.json').read_bytes()==(W/'blind-conditioned-guarded-loop-60/SELECTED_PLAN.json').read_bytes();assert not(H/'FROZEN.json').exists();f.update(files=files,scope='61 measured local max9 floor following with stricter continuity; same60path/memberships/body/geometry',onlyFloorMembershipVariantChanged=False,floorMembershipUnchangedFrom60=True,globalPlaneProvenanceOnly=True,localObservedHeightModel=True);(H/'FROZEN.json').write_text(json.dumps(f,indent=2)+'\n');print(hashlib.sha256((H/'FROZEN.json').read_bytes()).hexdigest())
