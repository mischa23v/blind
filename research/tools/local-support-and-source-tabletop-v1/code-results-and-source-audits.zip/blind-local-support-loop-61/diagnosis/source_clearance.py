from pathlib import Path
import json,numpy as np
H=Path(__file__).resolve().parent
# Reuse already reviewed source transforms and polygon clipping, before native work.
s=(H/'source_reference_contact.py').read_text();exec(s[:s.index('hits=[];centre=')])
centre=(state+mid)/2;rect=np.array([[-.155,-.225],[.155,-.225],[.155,.225],[-.155,.225]])
def point_segment(p,a,b):
 e=b-a;d=float(e@e);q=a+np.clip(float((p-a)@e)/d if d else 0.,0,1)*e
 return float(np.linalg.norm(p-q))
best=float('inf');bestid=None
upper=r['terminal']['contacts'][0]['actualBody']['sweep']['verticalBoundsMetres'][1]
# Any triangle outside this2m center box cannot set the near-body minimum.
mask=(xyz[:,:,1].max(1)>=.5)&(xyz[:,:,1].min(1)<=upper)&(xyz[:,:,0].max(1)>=centre[0]-2)&(xyz[:,:,0].min(1)<=centre[0]+2)&(xyz[:,:,2].max(1)>=centre[2]-2)&(xyz[:,:,2].min(1)<=centre[2]+2)
for i in np.flatnonzero(mask):
 poly=clip(xyz[i],.5,True)
 if len(poly)<3:continue
 poly=clip(poly,upper,False)
 if len(poly)<3:continue
 if overlap(poly,centre,.155,.225):distance=0.
 else:
  q=poly[:,[0,2]]-centre[[0,2]];q=np.c_[q@fwd,q@lat];distance=float('inf')
  for a,b in zip(q,np.roll(q,-1,axis=0)):
   for c,d in zip(rect,np.roll(rect,-1,axis=0)):
    distance=min(distance,point_segment(a,c,d),point_segment(b,c,d),point_segment(c,a,b),point_segment(d,a,b))
 if distance<best:best=distance;bestid=int(i)
out={'scope':'post-failure original source upper-body raw-geometry XZ clearance; no new planner','sourceTriangleID':bestid,'minimumXZSeparationFromRejectedHalfSweepMetres':best,'heightBand':[.5,upper],'sourceTriangleOriginalXYZ':xyz[bestid].tolist(),'limits':'Not full-body clearance or vertical clearance; excludes floor band below0.5m. Source/reference centroid mismatch is separate. Exact fixed-yaw half-sweep footprint; no geometry changed.'}
(H/'RAW_SOURCE_UPPER_BODY_CLEARANCE.json').write_text(json.dumps(out,indent=2)+'\n');print(out)
