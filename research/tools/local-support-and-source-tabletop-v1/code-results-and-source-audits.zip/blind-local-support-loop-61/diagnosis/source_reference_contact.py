from pathlib import Path
import json,sys,numpy as np,math
H=Path(__file__).resolve().parent;P=H.parent;W=P.parent;sys.path.insert(0,str(W/'blind-clearance-centered-loop-55'));from planner import Native
r=json.loads((P/'run-01/result/RESULT.json').read_text());d=json.loads((H/'CONTACT_FACE_DIAGNOSIS.json').read_text());query=np.array(d['rows'][0]['centroidOriginalGameXYZ'])
with np.load(W/'blind-polycam-alignment-feasibility-36/POLYCAM_INTRINSIC_GEOMETRY.npz')as z:obj=z['verticesOBJ'];tri=z['triangles']
with np.load(W/'blind-polycam-rigid-registration-37/run-01/CANDIDATE_RIGID_TRANSFORM.npz')as z:lev=obj@z['rotationOBJToLevel'].T+z['translationOBJToLevel']
with np.load(W/'blind-split-candidate-game-03/inputs/koivu_5cm_v2_pipeline2_out.npz')as z:R=z['R'];t=z['t']
with np.load(W/'blind-pose-experiments-review-17/upstream/pose-consistency/runs/koivu_floorfix/pipeline2_out.npz')as z:N=z['R'];nt=z['t']
old=((lev-nt)@N)@R.T+t;v=np.c_[old[:,0],old[:,2],-old[:,1]];xyz=v[tri];a=xyz[:,0];u=xyz[:,1]-a;w=xyz[:,2]-a;normal=np.cross(u,w);n2=(normal*normal).sum(1);proj=query-normal*np.divide(((query-a)*normal).sum(1),n2,out=np.zeros(len(n2)),where=n2>0)[:,None];du=(u*u).sum(1);dw=(w*w).sum(1);uw=(u*w).sum(1);det=du*dw-uw*uw;pu=((proj-a)*u).sum(1);pw=((proj-a)*w).sum(1);s=np.divide(pu*dw-pw*uw,det,out=np.full(len(det),np.nan),where=abs(det)>1e-20);tt=np.divide(pw*du-pu*uw,det,out=np.full(len(det),np.nan),where=abs(det)>1e-20);inside=(s>=0)&(tt>=0)&(s+tt<=1);best=np.full((len(tri),3),np.nan);bestd=np.full(len(tri),np.inf)
for aa,bb in((0,1),(1,2),(2,0)):
 start=xyz[:,aa];edge=xyz[:,bb]-start;den=(edge*edge).sum(1);f=np.clip(np.divide(((query-start)*edge).sum(1),den,out=np.zeros(len(den)),where=den>0),0,1);p=start+f[:,None]*edge;dist=((p-query)**2).sum(1);take=dist<bestd;best[take]=p[take];bestd[take]=dist[take]
pd=((proj-query)**2).sum(1);take=inside&(pd<bestd);best[take]=proj[take];bestd[take]=pd[take];ix=int(np.argmin(bestd));near=best[ix]
state=np.array(r['finalPosition']);yaw=r['finalYawRadians'];fwd=np.array([math.cos(yaw),math.sin(yaw)]);lat=np.array([-math.sin(yaw),math.cos(yaw)]);cmd=r['terminal']['appliedCommand'];end=state.copy();end[[0,2]]+=cmd['forward_metres']*fwd;mid=(state+end)/2
# Diagnostic upper-body source triangle projection: original source geometry only.
def clip(poly,y,lower):
 out=[]
 for aa,bb in zip(poly,np.roll(poly,-1,axis=0)):
  ain=aa[1]>=y if lower else aa[1]<=y;bin=bb[1]>=y if lower else bb[1]<=y
  if ain:out.append(aa)
  if ain!=bin:out.append(aa+(bb-aa)*(y-aa[1])/(bb[1]-aa[1]))
 return np.array(out)
def overlap(poly,centre,hf,hl):
 q=poly[:,[0,2]]-centre[[0,2]];q=np.c_[q@fwd,q@lat];axes=[np.array([1.,0]),np.array([0.,1])]
 for aa,bb in zip(q,np.roll(q,-1,axis=0)):
  e=bb-aa
  if np.linalg.norm(e)>1e-12:axes.append(np.array([-e[1],e[0]]))
 for ax in axes:
  pq=q@ax;extent=hf*abs(ax[0])+hl*abs(ax[1])
  if pq.min()>extent or pq.max()<-extent:return False
 return True
hits=[];centre=(state+mid)/2
for i in np.flatnonzero((xyz[:,:,1].max(1)>=.5)&(xyz[:,:,1].min(1)<=r['terminal']['contacts'][0]['actualBody']['sweep']['verticalBoundsMetres'][1])):
 poly=clip(xyz[i],.5,True)
 if len(poly)<3:continue
 poly=clip(poly,r['terminal']['contacts'][0]['actualBody']['sweep']['verticalBoundsMetres'][1],False)
 if len(poly)>=3 and overlap(poly,centre,.155,.225):hits.append(int(i))
n=Native(np.c_[lev[:,0],lev[:,2],-lev[:,1]],tri)
def correct(p):
 level=np.array([p[0],-p[2],p[1]]);new=((level-t)@R)@N.T+nt;return np.array([new[0],new[2],-new[1]])
wall=[]
for name,p in [('lastCommitted',state),('rejectedHalfEndpoint',mid),('proposedEnd',end)]:
 hit=n.sample(correct(p),(.2,.3,.2));wall.append({'pose':name,'originalXYZ':p.tolist(),'projectedCorrectedXYZ':hit[0].tolist()if hit else None,'residualNavmeshClearanceMetres':hit[1]if hit else None})
n.close();o={'scope':'post-failure source-vs-reference geometry diagnosis; no planner or registration modification','rejectedReferenceFaceCentroid':query.tolist(),'nearestSourceTriangleID':ix,'nearestSourcePointOriginalXYZ':near.tolist(),'referenceToSourceVectorMetres':(near-query).tolist(),'referenceToSourceDistanceMetres':float(np.sqrt(bestd[ix])),'nearestSourceTriangleOriginalXYZ':xyz[ix].tolist(),'nearestSourceTriangleHeightRange': [float(xyz[ix,:,1].min()),float(xyz[ix,:,1].max())],'rejectedFaceCentroidOrientedForwardLateral':((query-state)[[0,2]]@np.c_[fwd,lat]).tolist(),'nearestSourcePointOrientedForwardLateral':((near-state)[[0,2]]@np.c_[fwd,lat]).tolist(),'sourceUpperBodySweepOverlaps':hits,'sourceUpperBodyDiagnosticHeightBand':[.5,float(r['terminal']['contacts'][0]['actualBody']['sweep']['verticalBoundsMetres'][1])],'sourceUpperBodyOverlapNotFullBodyOrSensorValidation':True,'nativeWallSamples':wall,'registration':'unchanged stage37 source-only fixed-scale rigid registration; FARO alignment is evaluator-only; no refit here'};(H/'SOURCE_REFERENCE_COMPARISON.json').write_text(json.dumps(o,indent=2)+'\n');print(json.dumps(o,indent=2))
