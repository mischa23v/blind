from pathlib import Path
import json,hashlib,numpy as np
from PIL import Image,ImageDraw,ImageFont
H=Path(__file__).resolve().parent;W=H.parent.parent;diag=json.loads((H/'CONTACT_FACE_DIAGNOSIS.json').read_text());posespath=W/'blind-mushroom-koivu-acquisition-01/selected/room_datasets/koivu/iphone/long_capture/transformations.json';frames=json.loads(posespath.read_text())['frames'];inv={f['frame_id']:f for f in json.loads((W/'koivu-room-photo-catalog/inventory.json').read_text())['frames']}
with np.load(W/'blind-split-candidate-game-03/inputs/koivu_5cm_v2_pipeline2_out.npz')as z:R=z['R'];t=z['t']
game=np.array([r['centroidOriginalGameXYZ']for r in diag['rows']]);level=np.c_[game[:,0],-game[:,2],game[:,1]];phone=(level-t)@R;views=[]
for idx,f in enumerate(frames):
 name=Path(f['file_path']).stem;T=np.array(f['transform_matrix']);cam=(phone-T[:3,3])@T[:3,:3];z=-cam[:,2];uv=np.c_[cam[:,0]/z*f['fl_x']+f['cx']-.5,-cam[:,1]/z*f['fl_y']+f['cy']-.5];visible=(z>0)&(uv[:,0]>=5)&(uv[:,0]<733)&(uv[:,1]>=5)&(uv[:,1]<989)
 if not visible[-1]:continue
 D=np.asarray(Image.open(W/'blind-koivu-game-07/map/depths'/(name+'.png')),float)*.001;points=[]
 for i,(u,v)in enumerate(uv):
  row={'referenceCellID':diag['rows'][i]['referenceCellID'],'UV':[float(u),float(v)],'predictedAxialDepth':float(z[i]),'visible':bool(visible[i])}
  if visible[i]:
   a,b=int(round(u)),int(round(v));patch=D[b-2:b+3,a-2:a+3];good=patch[patch>0];dep=float(np.median(good))if len(good)else None;row.update(sourcePatchMedianDepth=dep,sourceMinusPredictedDepth=None if dep is None else dep-float(z[i]),depthWithin10cm=bool(dep is not None and abs(dep-z[i])<=.1))
  points.append(row)
 if not points[-1].get('depthWithin10cm'):continue
 views.append({'poseIndex':idx,'frameID':name,'points':points,'validDepthPoints':sum(q.get('depthWithin10cm',False)for q in points),'visiblePoints':int(visible.sum()),'RGBPath':inv[name]['path'],'calibration':{k:f[k]for k in('fl_x','fl_y','cx','cy')},'originalCameraToPhoneOpenGL':T.tolist()})
ranked=sorted(views,key=lambda q:(-q['validDepthPoints'],-q['visiblePoints'],abs(q['poseIndex']-20),q['poseIndex']));selected=[]
for row in ranked:
 if not selected or all(abs(row['poseIndex']-v['poseIndex'])>=10 for v in selected):selected.append(row)
 if len(selected)==3:break
font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',18)
for v in selected:
 im=Image.open(v['RGBPath']).convert('RGB');d=ImageDraw.Draw(im)
 for q in v['points']:
  if not q['visible']:continue
  u,w=q['UV'];color='#ff3030'if q['referenceCellID']==5352615 else'#00caff';d.ellipse((u-5,w-5,u+5,w+5),outline=color,width=3)
 q=v['points'][-1];u,w=q['UV'];d.line((u-12,w,u+12,w),fill='#ff3030',width=2);d.line((u,w-12,u,w+12),fill='#ff3030',width=2)
 d.rectangle((0,0,738,65),fill='black');d.text((8,5),f"{v['frameID']}: red = rejected body face5352615",font=font,fill='white');d.text((8,30),'Post-failure identity overlay only; not automatic floor classification.',font=font,fill='white')
 out=H/(v['frameID']+'_seed_overlay.jpg');im.save(out,quality=92);v['overlayPath']=str(out.relative_to(W));v['RGBSHA256']=hashlib.sha256(Path(v['RGBPath']).read_bytes()).hexdigest();v['overlaySHA256']=hashlib.sha256(out.read_bytes()).hexdigest()
receipt={'scope':'source RGB/depth association of unchanged evaluator seeds after classifier rejection; not used for planning or map repair','originalGameToPhoneViaOriginalRAndT':True,'pointSelection':'exact terminal failed face centroid','viewSelection':'require offending point visible and depth agreement<=10cm; maximize single point depth agreement/visibility, then closest poseindex20; choose up to3 separated>=10pose indices','depthAgreementIsAssociationCheckNotProofOfGeometryOrSafety':True,'allCandidateViews':views,'selectedViews':selected,'sourcePoseSHA256':hashlib.sha256(posespath.read_bytes()).hexdigest(),'movementExecuted':True}
(H/'SOURCE_VIEW_ASSOCIATION.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'views':len(views),'selected':[{k:v[k]for k in('poseIndex','frameID','validDepthPoints','overlayPath')}for v in selected]}))
