# Frozen61: observed local-support actor height, not global plane extrapolation

Preserve60result. Same immutable59floor IDs, source56path, exact goals, original startXZ/yaw,45x30x160cm body with zero margin, reference mesh, controller, FIFO and full-body geometry. No horizontal correction, source route change, new floor labeling, missing-surface fill or threshold increase. Global47/48plane remains provenance; it does not set physical foot height or veto an otherwise identical handoff.

## Exact support law

At initialization, preserve the existing nine-hit nominal-start numeric admission (spread<=20mm, each hit within30mm of nominal zero-height start). Require all nine original floor IDs known before assigning footY=max of the nine measured heights. Record this one initial vertical settlement; no subsequent reset.

For each actor command, query observed support at current pose, actual halfwayXZ/yaw and proposed endpoint. All nine must be finite first-hit known-floor observations. Preserve existing spread<=20mm and each hit's association to previous actual footY<=20mm. Previous actual footY must equal its previous observed max9 within1e-6m; otherwise reject rather than snap.

Before assigning midpoint/end height, apply the independently stricter continuity bound:
`abs(newMax9Y - previousActualFootY) <= 2*0.002 + tan(5degrees)*max_i(distanceXZ(previousProbe_i,newProbe_i))`, plus1e-12 numerical comparison tolerance.

Every support row is validated against the pinned centre/quadrant/corner XZ pattern for its supplied pose/yaw within1e-9m before continuity arithmetic. Reordered or malformed rows reject; yaw uses corresponding corner displacements, not centre translation. The2mm band and5degree slope are existing model constants, not newly claimed calibrated sensor accuracy. A real abrupt sub4mm feature may remain admitted; this is explicitly unresolved, not proof that all steps are detected. Max9is conservative highest observed support, not an outlier-rejecting estimate. Jitter can cause a new stop; do not smooth after seeing results.

Set each accepted midpoint/end footY to its observed max9, retain XZ/yaw, and recheck local foot association. Preserve total three-dimensional two-segment travel<=25mm per tick and existing1degree yaw cap. Reject missing support, nonground hits, excessive spread, continuity violations and motion-cap violations before committing.

## Collision and underbody

Check full body on both actual3D half-segments exactly as before. Then check underbody separately on each same half-segment using its two accepted raw support rows:
- lowerY=min(all18observed endpoint support heights)−20mm;
- upperY=max(actual endpoint footY)+2mm;
- full swept horizontal45x30cm enclosure, including rotation padding;
- only the same immutable floor IDs exempted.

Both endpoint actual foot heights must match their observed max9within1e-6. Separate half-segments retain actual midpoint vertical extrema. This does not prove continuous support between nine probes or three time samples. Classified-ground contact remains unmeasured; all nonground geometry remains tested.

Handoff checks the same current raw row against both old/new memberships, requires observed max9to equal actual footYwithin1e-6, and performs next-cache static body and underbody checks. No actor/FIFO/pose reset; provenance plane equality is recorded but not an admission condition.

## Resource and outcome gates

Same900CPU/1200wall,3.5GiBRSS,4.3GiB availableRAM,2500ticks,8MiB lossless output and768MiB disk reserve. Preserve flushed committedCSV and compressed evidence on every failure. One lap only; five drained actual goal arrivals plus intended committed-trajectory winding are necessary. Source low-obstacle uncertainty remains unresolved. This is a simulated world-support correction, NOT a phone-perception or human-safety result.
