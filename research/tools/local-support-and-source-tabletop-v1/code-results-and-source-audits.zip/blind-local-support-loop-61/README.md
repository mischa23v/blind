# Measured local support: four goals, no table lap

The unchanged 45 × 30 × 160 cm simulated body travelled **15.658816 m horizontally** (15.695919 m in 3D), reached **four of five original goals**, and stopped before a predicted body contact. **Zero completed laps.** The rejected step did not move the actor; 1,324 committed movement ticks passed the frozen body and underbody checks.

## What changed

Only vertical support following changed from stage60: immutable stage59 floor membership and nine measured support probes determine local foot height. The existing 20 mm spread/association and 25 mm total 3D motion caps remain. Each half-step additionally obeys the predeclared continuity bound of 4 mm plus tan(5°) times maximum corresponding probe displacement. All nine probe positions/order are checked. Unknown support rejects. Handoffs do not reset or snap the actor. Both actual 3D half-sweeps retain full-body and underbody checks.

This is evaluator-assisted simulated ground support, **not a phone-perception correction**. Finite probes and the retained floor residual band do not resolve every small hazard.

## Why it stopped

Reference face **5352615** lies at **1.090–1.093 m** above the original floor datum. The original phone RGB association (`diagnosis/frame_00021_seed_overlay.jpg`) places it on the rim of the round standing table beside the window. It is not a millimetre floor facet. The predicted first half-step intersects it at the body's front-left corner.

The nearest surface in the independently registered original Polycam source mesh is **23.81 cm** from the rejected reference triangle centroid (not an independently solved contact point). An exact projected triangle-versus-rectangle check finds no source upper-body overlap with the rejected half-sweep. The minimum horizontal separation of that upper-body source geometry from the rejected swept footprint is **16.46 cm**. This diagnostic covers heights 0.5–1.596 m, not the complete body or floor. The source and reference disagree locally; whether this reflects reconstruction loss, capture differences, or registration error is not established. No reference-based alignment correction or geometry deletion was applied.

Native residual clearance is **15.49 cm** at the stopped pose. The 22.5 cm native radius does not bound a 45 × 30 cm rectangle in every orientation; its circumradius is 27.04 cm, a **4.54 cm** difference. Here the residual exceeds that difference, so the native radius alone does not explain the failure. Residual navmesh clearance is not a certified raw-object distance.

## Evidence

- `run-01/result/RESULT.json`, streamed trace, compressed tick evidence and actor NPZ: exact execution.
- `INDEPENDENT_TERMINAL_REVIEW.json`: independent trace, continuity and guard recount.
- `ACTUAL_PATH.png`: committed movement versus source proposal.
- `diagnosis/CONTACT_FACE_DIAGNOSIS.json`: original triangle and rejected sweep.
- `diagnosis/SOURCE_VIEW_ASSOCIATION.json`: original RGB/depth associations.
- `diagnosis/SOURCE_REFERENCE_COMPARISON.json`, `FOOTPRINT_AUDIT.json`: bounded source/reference diagnosis.

The run used the frozen 900 CPU-second / 1,200 wall-second budget and terminated normally in 437.4 wall seconds, with about 2.27 GB peak RSS. No claim of human or device safety follows from this simulation.
