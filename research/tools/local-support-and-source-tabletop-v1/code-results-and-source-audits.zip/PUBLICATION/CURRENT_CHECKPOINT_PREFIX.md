## Current checkpoint — local support and missing tabletop geometry

**Navigation remains the priority. No complete table lap yet.** Latest published evidence: [local-support-and-source-tabletop-v1](research/tools/local-support-and-source-tabletop-v1/README.md). Earlier evidence and failed attempts below remain historical records, not overwritten claims.

- **Completed:** one [assisted entry-and-return](research/tools/verified-assisted-roundtrip-v1/README.md),8.432m, same actor, both goals within frozen0.35m tolerance. This used manually typed evaluator-world sill/floor support, a45×30×160cm zero-margin body, and retained phone uncertainty. Not autonomous phone navigation.
- **Loop progress:**59 applies one general floor-normal-conditioning rule, adding only one face.60 reaches three goals/13.262m.61 follows measured local support and reaches four goals/15.659m.63 replans each leg from actual delivered arrival and reaches four goals/15.530m. **All remain incomplete.** Rejected commands were not committed; the61/63 stop is a real elevated standing-table rim, not carpet noise or insufficient room width.
- **Source evidence:**64 original RGB/native-depth audit supports missing tabletop rim in the exported Polycam mesh.65 constructs a source-only additive exclusion candidate from observed contours and interior-depth planes; no FARO sizing, no map mutation and no movement test. ±3px is an uncalibrated stress assumption; heldout20 was already inspected, not blind validation. Unknown pose/depth bias, underside/legs and small hazards remain unresolved.
- **Next gate:** review source-derived exclusion conservatism and full-body handling, then separately freeze and evaluate movement; do not clear hazards or tune from reference contacts. Success must mean useful completed routes, not just route proposals.
- **Preserved caveats:**59 exceeded its5MiB aggregate preparation-output target; evidence retained. Finite probes/sub2mm support ambiguity remain.53/57 old3D review labels are corrected in the publication README without runtime changes.62 provides dry-run checkpoint verification and explicit missing-file restore for earlier archives.

No full lap, three-lap run,100journey suite or device/human safety validation has passed. [Previous centered-loop checkpoint](research/tools/centered-loop-and-mesh-bridge-v1/README.md).

---
