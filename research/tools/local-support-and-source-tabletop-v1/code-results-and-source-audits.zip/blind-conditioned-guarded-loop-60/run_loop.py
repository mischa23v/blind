from pathlib import Path
import json,hashlib,time,sys,numpy as np
H=Path(__file__).resolve().parent;W=H.parent
import loop_episode as e
motion=e.motion;legacy=e.legacy

def verify(expected):
 if motion.sha(H/'FROZEN.json')!=expected:raise ValueError('manifest changed')
 for p,h in json.loads((H/'FROZEN.json').read_text())['files'].items():
  if motion.sha(W/p)!=h:raise ValueError('source or input changed:'+p)
def main(expected):
 verify(expected);out=H/'run-01/result';out.mkdir(exist_ok=False);start=time.monotonic();plan=e.load_plan();runtime=motion.serial_vtk();surface,mi,reader=motion.load_surface()
 with np.load(legacy.GAME/'inputs/koivu_5cm_v2_pipeline2_out.npz')as z:meta={'R':z['R'],'t':z['t']}
 A=np.array(json.loads((W/'blind-koivu-faro-acquisition-04/selected-reference/icp_iphone.json').read_text())['gt_transformation']);T=motion.transform(meta,A);base=legacy.OrientedReferenceContainer(surface,T,legacy.BodyGeometry(width=.45,depth=.30,height=1.6,horizontal_margin=0.));grounds=[];plane=np.array(plan['floorPolicy']['fixedPlaneCoefficients']);plane.setflags(write=False);tt=np.array(T,copy=True);tt.setflags(write=False)
 for i in range(5):
  d=W/'blind-conditioned-floor-membership-59'/f'membership-leg{i}';r=json.loads((d/'RESULT.json').read_text());assert r['status']=='membershipReady'and r['referenceTransformSHA256']==hashlib.sha256(T.tobytes()).hexdigest();assert np.array_equal(r['fixedActivePlane'],plane)
  with np.load(d/'GROUND_IDS.npz')as z:ids=z['groundIDs'].copy()
  assert ids.ndim==1 and len(ids)>0 and np.all(np.diff(ids)>0)and ids.min()>=0 and ids.max()<mi['triangles'];ids.setflags(write=False);receipt={**r['groundReceipt'],'planeCoefficientsYEqualsAXPlusBZPlusC':plane.tolist(),'fixedDatumSource':'unchanged47/48redGround plane','legIndex':i,'sourceSeedsNotReachedBodyPose':True}
  grounds.append(motion.GroundSupport(ids,receipt,surface,base.mesh,int(base.mesh.GetMTime()),tt,plane))
 result=e.episode(plan,base,grounds,out);result.update(sourcePlanSHA256=e.PLAN_SHA,sourceProposalResultSHA256=plan['sourceResultSHA256'],referenceMesh=mi,runtime=runtime,wallSeconds=time.monotonic()-start,floorPolicy=plan['floorPolicy'],floorMembershipReceipts=[{'leg':i,'membershipSHA256':motion.sha(W/'blind-conditioned-floor-membership-59'/f'membership-leg{i}/GROUND_IDS.npz'),'groundCells':len(g.ground_cell_ids)}for i,g in enumerate(grounds)],worldOrReferenceNeverSelectsHorizontalRoute=True)
 verify(expected);e.save(out/'RESULT.json',result);print(json.dumps({k:result[k]for k in('status','arrival','completedLegs','completedLaps','actualDistanceMetres','actualBodyContactEvents','rejectedPredictedBodyContactEvents')}),flush=True)
if __name__=='__main__':main(sys.argv[1])
