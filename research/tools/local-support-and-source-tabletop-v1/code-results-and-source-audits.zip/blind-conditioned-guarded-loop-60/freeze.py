from pathlib import Path
import json,hashlib,numpy as np
H=Path(__file__).resolve().parent;W=H.parent;f=json.loads((W/'blind-clearance-guarded-loop-57/FROZEN.json').read_text());files=f['files'].copy();files.update(json.loads((W/'blind-conditioned-floor-membership-59/MEMBERSHIP_FROZEN.json').read_text())['files']);paths=[*H.glob('*.py'),H/'SELECTED_PLAN.json',H/'MOVEMENT_PROTOCOL.md']
for i in range(5):
 d=W/f'blind-conditioned-floor-membership-59/membership-leg{i}';r=json.loads((d/'RESULT.json').read_text());assert r['status']=='membershipReady'and r['baseline52IDsExactlyMatchedBeforeConditioning'];paths.extend([d/'RESULT.json',d/'GROUND_IDS.npz',d/'PATCH_FITS.json.gz'])
 with np.load(d/'GROUND_IDS.npz')as z:assert not np.isin(921994,z['groundIDs'])
for p in paths:files[str(p.relative_to(W))]=hashlib.sha256(p.read_bytes()).hexdigest()
for p,h in files.items():assert hashlib.sha256((W/p).read_bytes()).hexdigest()==h,p
assert (H/'SELECTED_PLAN.json').read_bytes()==(W/'blind-clearance-guarded-loop-57/SELECTED_PLAN.json').read_bytes();assert not(H/'FROZEN.json').exists();f.update(files=files,scope='60same57path/world/actor/guards; isolated59geometry-conditioned floor memberships',sourcePathOnlyChanged=False,sourcePathUnchangedFrom57=True,onlyFloorMembershipVariantChanged=True,same52MembershipsUnchangedByGuard=False,same59MembershipsUnchangedDuringMovement=True);(H/'FROZEN.json').write_text(json.dumps(f,indent=2)+'\n');print(hashlib.sha256((H/'FROZEN.json').read_bytes()).hexdigest())
