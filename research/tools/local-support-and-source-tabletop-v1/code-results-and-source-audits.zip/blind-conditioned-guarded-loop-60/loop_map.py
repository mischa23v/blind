"""Exact source-only loop path adapter; no reference-world input."""
from pathlib import Path
import hashlib,json,importlib.util,sys,numpy as np
H=Path(__file__).resolve().parent;W=H.parent;PLAN=H/'SELECTED_PLAN.json';PLAN_SHA=hashlib.sha256(PLAN.read_bytes()).hexdigest()
s=importlib.util.spec_from_file_location('loop50_frozen_map40',W/'blind-polycam-varpu-executor-40/goal_region_map.py');old=importlib.util.module_from_spec(s);sys.modules[s.name]=old;s.loader.exec_module(old)
def load_plan(path=PLAN,digest=PLAN_SHA):
 if Path(path).resolve()!=PLAN.resolve()or digest!=PLAN_SHA or hashlib.sha256(PLAN.read_bytes()).hexdigest()!=digest:raise ValueError('fixed loop plan identity')
 p=json.loads(PLAN.read_text());assert p['status']=='frozenLoopNominal45SourceProposalOnly'and p['oneLapOnly'];assert [p['geometry'][k]for k in('width','depth','height','margin')]==[.45,.30,1.60,0.];assert len(p['legs'])==5 and p['taskArrivalToleranceMetres']==.35 and p['cornerConsumptionToleranceMetres']==.01;assert p['referenceInputsUsedForSelection']is False
 return {**p,'mapRevision':PLAN_SHA,'goal':p['legs'][0]['originalTaskGoal'],'steeringGoalOriginalFrame':p['legs'][0]['originalTaskGoal'],'originalFramePath':p['legs'][0]['originalFramePath']}
class GoalRegionMap(old.GoalRegionMap):
 def route(self,start,goal):
  expected=self.plan['legs'][self.leg]['originalTaskGoal']
  if not np.array_equal(goal,expected):raise ValueError('fixed source leg goal only')
  while self.cursor<len(self.points)and np.linalg.norm((self.points[self.cursor]-start)[[0,2]])<=.01:self.cursor+=1
  return {'complete':True,'points':self.points[self.cursor:].tolist(),'projectedStart':np.asarray(start).tolist(),'projectedGoal':list(goal),'fixedCornerCursor':self.cursor,'proposalOnly':True,'referenceInputUsed':False,'fullRectangleValidated':False,'nativeRequeryPerformed':False}
 def begin_next(self,leg):
  if type(leg)is not int or leg!=self.leg+1 or leg>=len(self.plan['legs']):raise ValueError('ordered loop legs only')
  self.leg=leg;self.points=np.asarray(self.plan['legs'][leg]['originalFramePath'],float);self.cursor=0
