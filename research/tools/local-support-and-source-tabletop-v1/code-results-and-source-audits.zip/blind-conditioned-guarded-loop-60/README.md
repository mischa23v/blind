# Conditioned-floor guarded loop:13.262m, three goals, incomplete

The unchanged57source path and actor moved **13.261773m**, reached three of five original goals, and continued toward the fourth. No lap was completed.

Only the independently frozen59floor memberships differ from57: one previously ill-conditioned sliver face was added in leg1 by the general rule; all other memberships and every geometry/collision rule remain unchanged. Earlier53near-chair face remains excluded.

## Terminal result

| Measure | Result |
|---|---:|
|Original goals reached|3of5|
|Completed laps|0|
|Horizontal distance|13.261773m|
|3D distance|13.263754m|
|Guarded committed movement ticks|1110|
|Actual body contacts|0|
|Predicted body/underbody collisions|0/0|
|Wall/CPU time|310.05/313.07s|
|Peak treeRSS|2.267GB|

At tick1113 the proposed full step failed the fixed-datum support association gate. **All nine probes hit known floor**, with only2.908mm height spread; there were no missing or nonground probe faces. But the maximum distance between those floor hits and the fixed global body-height datum was20.111808mm, exceeding the frozen20mm limit by0.111808mm. The preceding half-step was19.996415mm and passed.

This isolates a **fixed-height-datum support model mismatch**, not evidence of a collision, an impassable room or insufficient corridor width. We did not increase the limit or commit the rejected candidate. Collision/underbody queries for the rejected full step were not performed because support admission failed first.

Independent recount verifies exact CSV/NPZ equality, all1110committed guarded moves, three stationary/drained goal arrivals and unchanged position on terminal rejection. Prior failures remain intact.

## Evidence

- `ACTUAL_PATH.png`: green committed movement versus blue unexecuted proposal.
- `run-01/result/RESULT.json`: full terminal and transition evidence.
- `INDEPENDENT_TERMINAL_REVIEW.json`.
- `diagnosis/FIXED_DATUM_ASSOCIATION_STOP.json`: exact saved arithmetic; no new geometry or thresholds.
- Streaming CSV, compressed tick evidence and NPZ trace under `run-01/result/`.

Final manifest: `83e87d263da4ceb7f6fae4488b4108d3b793272da4fed0c4652d90bf1a0d60fa`. Same900CPU/1200wall/2500tick and8MiBoutput limits as57; all passed. Identical generated59arrays were storage-deduplicated by hardlinks before launch; all paths and frozen byte hashes remained unchanged and immutable.

This remains evaluator-assisted offline simulation using a zero-margin45×30×160cm actor. Source sensor uncertainty persists, classified-floor contacts are unmeasured, and no autonomous phone navigation or human safety is established. No three-lap trial was run. A principled local-support height model would need a separate protocol and review, not a post-hoc threshold nudge.
