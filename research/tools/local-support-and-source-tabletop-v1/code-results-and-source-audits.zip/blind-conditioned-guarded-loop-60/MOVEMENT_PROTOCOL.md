# Frozen60: same57movement, isolated59conditioned memberships

Only the five floor membership arrays change from57to independently frozen59one-pass normal-conditioned memberships. Same source56path, start, initial heading, exact goals, full45x30x160cm body, zero margin, fixed47/48floor datum, actor/FIFO,2500ticks, collision sweeps, finite9probe support and full-footprint underbody guard. All original reference geometry remains intact; no route steering by reference or target-face removal. New labels are geometry-conditioned evaluator support, not phone sensing or semantic proof.

59requires exact baseline52ID parity before additions, quality<0.01, independent rank-valid patch<=5degrees, every vertex<=2mmresidual, and shared original edge with baseline ground. No recursive admission. Nondegenerate45degree rawguard unchanged. Real sub2mmridges remain unresolved; no small-object safety claim. Original53near-chair face must remain rejected in the post-classification regression report.

Same predeclared57resource limits:900CPU/1200wall,3.5GiBRSS,4.3GiB availableRAM,8MiB lossless output,768MiB disk reserve. CommittedCSV flushed eachtick; preserve failures/partialdistance on budgetstop. One lap only. A returned process success is not a movement success; actual fivegoal arrivals plus correct committedtrajectory winding required. No parameter changes during execution.
