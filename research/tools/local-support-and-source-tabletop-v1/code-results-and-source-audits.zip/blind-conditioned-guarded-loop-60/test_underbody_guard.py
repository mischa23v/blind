import unittest,sys,numpy as np
from pathlib import Path
H=Path(__file__).resolve().parent;W=H.parent;sys.path.insert(0,str(H));import loop_episode as e
sys.path.insert(0,str(W/'blind-split-candidate-game-03/source'));import test_oriented_container as f
from reference_geometry import ReferenceSurface

def plate(y,x=.005,z=0.):return [[[x-.003,y,z-.003],[x+.003,y,z-.003],[x,y,z+.003]]]
def scene(extra=(),plane=(0,0,.016)):
 surface=ReferenceSurface(f.mesh(f.floor()+list(extra)));T=np.eye(4);ids=np.array([0,1],np.int64);ids.setflags(write=False);g=e.motion.GroundSupport(ids,{},surface,surface.mesh,int(surface.mesh.GetMTime()),T,np.array(plane,float));b=e.legacy.BodyGeometry(width=.45,depth=.3,height=1.6,horizontal_margin=0.)
 return e.motion.GroundTiledReferenceContainer(surface,T,ground=g,body=b),g
class Tests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):e.motion.serial_vtk()
 def test_ten_mm_toy_below_floating_body_is_detected(self):
  s,g=scene(plate(.01));a=np.array([0,.016,0]);b=np.array([.02,.016,0]);self.assertFalse(s.swept_contacts(a,b,0,0)['actualBody']['contact']);r=e.underbody_guard(s,g,a,b,0,0);self.assertTrue(r['contact']);self.assertAlmostEqual(r['lowerY'],-.004)
 def test_five_mm_toy_below_body_is_detected(self):
  s,g=scene(plate(.005));self.assertTrue(e.underbody_guard(s,g,[0,.016,0],[.02,.016,0],0,0)['contact'])
 def test_known_floor_is_only_exemption(self):
  s,g=scene();self.assertFalse(e.underbody_guard(s,g,[0,.016,0],[.02,.016,0],0,0)['contact']);np.testing.assert_array_equal(g.ground_cell_ids,[0,1])
 def test_untyped_coplanar_geometry_is_not_silently_floor(self):
  s,g=scene(plate(0.));self.assertTrue(e.underbody_guard(s,g,[0,.016,0],[.02,.016,0],0,0)['contact'])
 def test_downhill_full_footprint_is_covered(self):
  s,g=scene(plate(-.01,z=-.2),plane=(0,.1,.016));r=e.underbody_guard(s,g,[0,.0385,0],[.02,.0385,0],0,0);self.assertTrue(r['contact']);self.assertLessEqual(r['lowerY'],-.0265+1e-12)
 def test_plane_unchanged(self):
  s,g=scene();before=g.plane_coefficients.copy();e.underbody_guard(s,g,[0,.016,0],[.02,.017,0],.2,.01);np.testing.assert_array_equal(g.plane_coefficients,before)
 def test_vertical_motion_top_is_not_clipped(self):
  s,g=scene(plate(.020));r=e.underbody_guard(s,g,[0,.016,0],[.02,.021,0],0,0);self.assertTrue(r['contact']);self.assertAlmostEqual(r['upperY'],.023)
 def test_rotating_tilted_plane_upper_extent_includes_intermediate_support(self):
  class Spy:
   def contact_corners(self,c):return {'contact':False}
  class G:plane_coefficients=np.array([.02,.03,.016])
  r=e.underbody_guard(Spy(),G(),[0,.016,0],[.02,.016,0],.2,.017)
  self.assertGreater(r['fullSweptFootprintPlaneMaximumY'],.016);self.assertGreaterEqual(r['upperY'],r['fullSweptFootprintPlaneMaximumY']+.002-1e-12)
 def test_yaw_swept_envelope_used(self):
  class Spy:
   def contact_corners(self,c):self.c=np.array(c);return {'contact':False}
  class G:plane_coefficients=np.array([0.,0.,.016])
  s=Spy();r=e.underbody_guard(s,G(),[0,.016,0],[.02,.016,0],0,.017);self.assertGreater(float(np.ptp(s.c[:,2])),.45);self.assertEqual(r['existingSupportAssociationEnvelopeMetres'],.02)
if __name__=='__main__':unittest.main(verbosity=2)
