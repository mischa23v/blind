# Stage67: one assisted loop with a source-only unknown tabletop exclusion

Freeze before execution. This is a separate source-planner variant of stage63, not a change to evaluator geometry or physical clearance rules.

## Unchanged physical contract

Same original start, heading, five original goal regions, 45 ×30 ×160 cm body, zero margin, immutable stage59 floor IDs, stage61 local max-nine-probe support law, stricter continuity bound, unknown-support veto, 25 mm total3D motion cap, two actual half-segment body sweeps, underbody guard, same actor/FIFO and no handoff snaps. Reference triangles and furniture remain untouched. Failed candidate motion is never committed. All five drained arrivals plus actual winding−1 and return-to-start region are required for one lap.

## Only source-planner change

Use independently reviewed stage65 unknown tabletop exclusion through the locally built stage66 Recast adapter. Raw polygon is marked null on the compact heightfield before existing native erosion, not preinflated or turned into physical geometry. The observed height hypothesis determines the affected foot-height interval; it is not certified object extent. Semantic RGB contour/ROI selection was manually assisted. Source uncertainty remains unknown.

First-leg source path and all fixed goal pairs come from the successful frozen stage66 source preflight. At each drained handoff, retain stage63 actual-delivered-pose replanning with unchanged grid, cost, LOS simplification and association limits. No old55-map fallback is allowed. Every runtime requery must verify the stage66 binary path/hash, stage65 polygon hash, actual native handle's636 marked spans and exact finite graph identity before and after querying. Record that identity in the full query receipt and controller summary. Reject missing, changed or absent exclusion. Every returned route must satisfy existing per-leg full-rotating-body-circle bounds.

The source planner now reads stage42 phone-frame metadata allowlist JSON rather than mixed evaluator NPZ archives. R/t values and all five source paths were verified bit-exact. The source runtime manifest names its12 actual source inputs; the world evaluation manifest independently retains full reference dependencies. No reference geometry, failed face, contact or support mask chooses a route.

## Budgets and evidence

One nominal lap only;2,500 ticks,900CPU seconds,1,200wall seconds,3.5GiB process-tree RSS,4.3GiB available RAM admission,768MiB disk reserve. Output cap8MiB, increased before launch from stage63's4MiB because storage was recovered by verified byte-identical deduplication. No physical tolerance changes accompany that resource change.

Full JSON tick/query evidence uses reviewed lossless XZ preset6; heartbeat gzip; exact actual CSV flushed after every committed row. On abrupt interruption, verbose compressed tails may lag; no complete-run claim is made from partial evidence. Preserve all failures and hashes.

Source-only rehearsal reports1,679 ideal follower ticks; source grid loses136 nodes/539 edges and adds none in the sampled comparison. Neither fact is physical clearance validation. This run must earn its own independent collision/support result.

## Additional source-subset gate

Before world execution, all43 segments of the five frozen source paths, including exact endpoint connectors, pass BOTH baseline and excluded native LOS/height checks. Samples are at most25mm apart with the unchanged5cm native height tolerance. Each runtime actual-start query repeats the same dual-context checks on its selected candidate, preserves it in evidence and rejects without replacement if either context fails. Baseline is only a validator, never a route fallback or alternate optimizer. This is a sampled source constraint, not physical-world clearance proof.

The graph identity also validates all directed rows for valid indices, duplicate edges, finite positive costs and exact reverse symmetry before hashing the undirected representation, so reverse-only mutations cannot evade identity checks.

The dual-context check deliberately evaluates the exact actual XYZ connector, including delivered foot height, against source-native height association. It can conservatively reject a connector whose actual foot differs by more than5cm from source height even when earlier level-only association passed. This is an additional source-validation gate, not a changed physical floor tolerance. Such failure is reported without snapping the actor or its endpoint.
