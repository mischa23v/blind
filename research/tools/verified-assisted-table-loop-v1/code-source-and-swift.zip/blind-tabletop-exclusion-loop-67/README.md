# One simulated table lap completed

**20.393912 m horizontal travel**, **20.432756 m actual3D travel**, **all five original goals reached**, **one clockwise table lap**. Independent review verified the executed trace, support/continuity checks, full-body and underbody sweeps, actual-start source queries and frozen inputs.

| Result | Measured value |
|---|---:|
| Committed motion ticks | 1,663 |
| Total ticks / saved states | 1,668 /1,669 |
| Completed drained goal arrivals | 5 |
| Actual trajectory winding | −1 |
| Non-floor body/underbody contact events | 0 |
| Predicted collision rejections | 0 |
| Final distance from original start | 0.330529 m |
| Pending/applied motion at arrival | None /zero |

The final pose is inside the **unchanged35 cm goal region**. The approximately33 cm mathematical closing segment used for winding was **not walked**. This is not an exact point-return claim.

## What made this attempt different

The prior source mesh omitted part of the round standing-table rim. Stage65 froze an **unknown, manually assisted navigation exclusion hypothesis** from original phone RGB/depth. Stage66 marked that raw polygon null in released Recast before the existing single agent-radius erosion. The source mesh and physical evaluator geometry were not repaired or replaced with invented table solids.

Stage67 uses that source exclusion with the existing clearance-weighted grid, LOS simplification and actual-arrival handoff replanning. Every runtime query verifies the native library, polygon hash,636 marked spans and graph identity. Every selected segment and exact connector must also pass BOTH baseline and excluded source-map LOS/height checks. Baseline never supplies an alternative route. All four actual-start queries and41 runtime segments passed independent recount.

## What did not change

- Body **45 ×30 ×160 cm**, **zero horizontal margin**; original start and heading.
- The five original goal regions and actual winding requirement.
- Original reference furniture/obstacles and immutable stage59 floor membership.
- Stage61 measured local support, unknown-support rejection, continuity bound and actual3D motion limits.
- Two half-segment full-body sweeps and the full-footprint nonground underbody guard.
- Same actor/FIFO across handoffs, without pose resets or endpoint snaps.

## Important limits

This is **one controlled, evaluator-assisted simulation in one static recorded room**. It uses delivered simulated poses and independently labelled/reference floor support. The tabletop ROI/contour was manually assisted; its uncertainty remains unknown. Frozen floor faces are exempted and their contact events are **unmeasured**, so zero nonground contacts is not a claim that every possible floor hazard is resolved.

This result does **not** establish phone-only perception, live tracking, moving-obstacle avoidance, robustness to jitter/delay, safe use by a person, or three completed laps. It demonstrates that the unchanged body and collision engine can execute a complete loop when the missing source tabletop extent is conservatively excluded.

## Resources and evidence

- **71 fixtures**, **537 pinned input hashes** and independent prelaunch review.
- **556.04 s wall**, **561.91 s CPU**, peak process-tree RSS **2.38 GB**.
- Approximately **3.4 MiB** run output under the predeclared8 MiB cap.
- `ACTUAL_PATH.png`: executed movement, source proposals and35 cm arrival region.
- `run-01/result/ACTUAL_TRACE_PARTIAL.csv`, `ACTOR_TRACE.npz`: exact committed state evidence.
- `TICK_EVIDENCE.jsonl.xz`, `QUERY_OPTIMIZATION.json.xz`: lossless detailed checks.
- `SOURCE_REPLAN_LEG1..4.json.gz`: actual-start routes and exclusion identity.
- `INDEPENDENT_TERMINAL_REVIEW.json`: independent numerical recount.

All earlier failures remain preserved. No physical tolerance, body size or reference obstacle was relaxed to obtain this result.
