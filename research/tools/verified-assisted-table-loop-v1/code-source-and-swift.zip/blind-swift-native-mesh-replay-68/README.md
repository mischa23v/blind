# Linux Swift → existing native Recast/Detour: candidate-only proof

**34 checks passed**, including five fixed route pairs through a Swift C-ABI
wrapper, original-vs-replayed geometry, and parity with the previous Python58
results. This closes a Linux Swift/native calling-convention feasibility gap.
It does NOT implement or verify live iPhone navigation.

## Measured

* Existing Swift6.4.1, target x86_64-unknown-linux-gnu, focused standalone swiftc.
* C imports via pinned original blind_detour.h and module map; no SwiftPM build.
* Owned packed `[Float]` positions and `[Int32]` triangles, not padded SIMD3 data.
* Real existing Polycam mesh:18,398 vertices/29,366 triangles;32 synthetic local
  anchor tiles; all triangles retained. Reconstructed Float32 triangle values
  exactly identical. Maximum Double error8.881784197001252e-16m.
* Five native original/replayed query pairs match; all five also match saved
  Python58 output with the frozen flags/count and1e-5m coordinate criteria.
* Native config:radius.225m,height1.75m,cell/cellheight/climb.025m,slope15°. This
  disc/zero-margin comparator is not a recommended safety body or swept rectangle.
* Compiler and scored-run resource figures are recorded without estimation in
  COMPILE_RECEIPT.json and EXECUTION_RECEIPT.json. Existing library not rebuilt.
* Total working folder about21MiB including17MiB cache and transient3.08MB fixture;
  publish only small source/protocol/results/receipts, not build/cache or raw fixture.

## Contract tested

Bridge.swift verifies proper rigid local→world transforms and finite indexed
geometry, applies the transform once, replaces anchor revisions, ignores stale
packets, distinguishes identical repeats from conflicting revisions, and
invalidates tickets on session/generation or geometry changes. Empty/truncated/
removed/evicted/conflicting geometry stays unknown; bad accepted-session inputs
throw and invalidate readiness via unknown status. Source completeness never
means actual-world coverage. Raw-depth detection is NOT implemented here:
rawHazardVeto remains true, actualWorldCoverageKnown false, all physical authority
false. No caller may promote a candidate path to physical guidance from this test.

Bounds:64 tiles,200,000 vertices,100,000 triangles,256 metadata IDs,128-byte
session/anchor IDs. Ledger stores prior packet payload for exact conflict checks,
so its aggregate geometry is independently capped (not just retained tile data).
Input JSON here is a trusted, deterministic test fixture capped8MiB after loading;
this is not a bounded untrusted streaming decoder. Future ARKit runtime ownership,
backpressure and capture-time association are unimplemented.

## Reproduction and provenance

FROZEN.json records source,protocol,fixture,binary and existing input/library hashes
before scoring. run.py verifies every pin, disk reserve and output budget and
executes with512MiB address-space/120CPU/180wall limits. Existing source geometry
and phone-only fixed-scale transform are reused, never FARO. Fixture creation:

```
OPENBLAS_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1 python blind-swift-native-mesh-replay-68/make_fixture.py
PYTHONDONTWRITEBYTECODE=1 python blind-swift-native-mesh-replay-68/run.py
```

`build.py` documents focused recompilation; serialize it with heavy jobs. It is
not part of the scored source change. Recompilation can change binary bytes; do
not alter FROZEN silently. Preserve the run, document a new freeze, then score.
Toolchain is existing `/workspace/shared/swift-toolchain/install/swift-6.4.1-RELEASE-debian13/usr/bin/swiftc`.

Attempt1 failed at JSON decoding because NumPy inverse indices had a nested shape
while Swift required packed indices. Failure/source/protocol preserved in
attempt1-schema. Builder now explicitly flattens those indices; hashes re-frozen
before rerun. No Swift/native/threshold changes were needed. An initial shell
attempt lacked `/usr/bin/time`; its failure log is preserved; Python resource
receipts measured the actual compile instead.

## Still missing

Actual ARMeshAnchor capture/revision replay, iOS/ARKit compilation, on-device
latency/thermal measurement, real-depth hazard integration, map registration,
route output leases, full-body movement/collision tests and safety validation.
Synthetic tiles from a fused phone mesh are not a live phone stream or proof of
small-object preservation. All movement and authority stay disabled. The app
remains untouched. Existing MuSHRoom source attribution/license remains in its
acquisition packet; no photos or raw mesh are published with this artifact.

Independent review found a bounded-memory loophole in removal packet payloads.
Revision2 source/results preserved in attempt2-removal-review; its binary is local
only. Revision3 requires empty geometry/transform arrays for removal tombstones,
adds an oversized-removal regression, recompiles and re-freezes before scoring.
All34 checks pass; native geometry/route criteria unchanged. Runtime may reject
malformed packets conservatively; no authority can arise from an adapter error.

Final independent review PASS: reviewer verified15 frozen pins and reran the final
binary, reproducing all34 checks and five route pairs exactly. Review-run peak
RSS36,900KiB; see INDEPENDENT_REVIEW.json. The main EXECUTION_RECEIPT reports the
launcher's aggregate child-process high-water mark, which can include a preceding
compiler when invoked from the same exec-replaced shell; it is a conservative
resource receipt, not a precise executable-only RSS measurement.
