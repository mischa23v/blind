from pathlib import Path
import numpy as np,json,hashlib
H=Path(__file__).resolve().parent;W=H.parent
with np.load(W/'blind-polycam-alignment-feasibility-36/POLYCAM_INTRINSIC_GEOMETRY.npz')as z:obj=z['verticesOBJ'];tri=z['triangles']
with np.load(W/'blind-polycam-rigid-registration-37/run-01/CANDIDATE_RIGID_TRANSFORM.npz')as z:level=obj@z['rotationOBJToLevel'].T+z['translationOBJToLevel'];assert z['scale']==1
v=np.c_[level[:,0],level[:,2],-level[:,1]];packets=[]
rots=[np.eye(3),np.array([[0,0,1],[0,1,0],[-1,0,0]]),np.diag([-1,1,-1]),np.array([[0,0,-1],[0,1,0],[1,0,0]])]
for i,ids in enumerate(np.array_split(np.arange(len(tri)),32)):
 unique,inverse=np.unique(tri[ids],return_inverse=True);r=rots[i%4];translation=np.array([i%5,i%3,-(i%7)],dtype=float);m=np.eye(4);m[:3,:3]=r;m[:3,3]=translation
 packets.append(dict(session='real-polycam-synthetic-anchor-replay',generation=0,anchor=f'{i:03}',revision=1,timestamp=1+i,vertices=((v[unique]-translation)@r).reshape(-1).tolist(),triangles=inverse.reshape(-1).tolist(),transform=m.reshape(-1).tolist(),complete=True,removed=False))
f=dict(vertices=v.reshape(-1).tolist(),triangles=tri.reshape(-1).tolist(),packets=packets,anchors=[x['registeredGameXYZ']for x in json.loads((W/'blind-polycam-table-loop-proposals-44/FROZEN.json').read_text())['anchors']],reference=[x['monolithic']for x in json.loads((W/'blind-native-mesh-replay-58/RESULT.json').read_text())['routes']]);data=json.dumps(f,separators=(',',':'),allow_nan=False).encode();(H/'INPUT.transient.json').write_bytes(data);print(len(data),hashlib.sha256(data).hexdigest())
