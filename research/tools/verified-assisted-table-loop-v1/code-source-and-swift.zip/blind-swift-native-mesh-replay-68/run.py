from pathlib import Path
import subprocess,resource,json,os,time,hashlib
H=Path(__file__).resolve().parent;W=H.parent
f=json.loads((H/'FROZEN.json').read_text())
for p,h in f['files'].items():assert hashlib.sha256((W/p).read_bytes()).hexdigest()==h,p
assert os.statvfs(H).f_bavail*os.statvfs(H).f_frsize>=768<<20
assert sum(p.stat().st_size for p in H.rglob('*')if p.is_file())<=25<<20
env=os.environ.copy();env['LD_LIBRARY_PATH']=str(W/'blind-split-candidate-game-03/body-margin-variants-07/native025')
def limits():
 resource.setrlimit(resource.RLIMIT_AS,(512<<20,512<<20));resource.setrlimit(resource.RLIMIT_CPU,(120,120));resource.setrlimit(resource.RLIMIT_FSIZE,(2<<20,2<<20))
start=time.monotonic()
with open(H/'EXECUTION.log','w')as out:r=subprocess.run([str(H/'build/replay'),str(H/'INPUT.transient.json'),str(H/'RESULT.json')],stdout=out,stderr=subprocess.STDOUT,env=env,timeout=180,preexec_fn=limits)
u=resource.getrusage(resource.RUSAGE_CHILDREN)
(H/'EXECUTION_RECEIPT.json').write_text(json.dumps(dict(exitCode=r.returncode,wallSeconds=time.monotonic()-start,peakRSSKiB=u.ru_maxrss,physicalAuthority=False),indent=2)+'\n')
print((H/'EXECUTION.log').read_text());print('exit',r.returncode,'peakKiB',u.ru_maxrss)
