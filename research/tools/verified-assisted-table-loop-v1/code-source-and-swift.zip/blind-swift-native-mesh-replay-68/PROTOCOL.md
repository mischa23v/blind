# Stage68 frozen Linux Swift/C-ABI candidate replay

Standalone Swift6.4.1 Linux executable calling existing pinned native025 Detour
library through original C header/modulemap. No app, ARKit, iOS or device build.
No physical guidance; no hazard detection claim. Owned packed Float/Int32 arrays,
not SIMD3 memory. Anchor transforms are proper rigid row-serialized matrices with
column-vector semantics and +Y-up metre output. All output authority false.

Before scored execution hash protocol, source, header, modulemap, fixture builder,
compiler version, library, source Polycam geometry, phone-only rigid transform,
existing stage44 frozen anchors and stage58 results. Generated local input is
transient (no published mesh copy), deterministic and hashed. Hash executable
before scoring. Compile need not count as scored execution; compiler fixes must
be recorded before refreeze. No successful fixture is called real sensor evidence.

Authored checks: once-only rigid transforms; nonrigid and NaN rejected; bad indices;
empty/truncated/removal unknown; replacement/stale/duplicate/conflict lifecycle;
session reset and invalid old ticket; explicit tile/vertex/triangle/metadata caps;
all candidate outputs authorityfalse. Invalid input withdraws readiness.

Real: unchanged Polycam source18398vertices/29366triangles,32 contiguous face batches,
quarter-turn local transforms. Reconstructed triangle coordinate error <=1e-9m,
Float32 triangles exactly equal. Build original and replayed geometry through same
native025 library with radius.225,height1.75,cell.025,cellheight.025,climb.025,slope15,
maxcells250000,maxnodes4096. Compare same5 stage44 query pairs (extent.2,.3,.2):
status/complete/errors/count equal; all point/projection coordinates<=1e-5m. Also
compare outputs to saved stage58 native queries within same criteria. No FARO.

Resource target: focused swiftc compile only, no SwiftPM/download/install; output
including fresh modulecache<=25MiB, runtime memory512MiB, CPU120s, disk reserve768MiB.
Report failures unchanged; no threshold or path tuning after results.

## Attempt1 schema failure preserved
First scored execution rejected generated tile indices: NumPy returned shaped
inverse indices while Swift correctly required packed Int32 array. No native
routes scored. Flatten generated tile indices explicitly; re-freeze fixture and
builder hashes before retry. Geometry, native config and parity thresholds remain
unchanged. Swift source/binary unchanged.

## Independent review: removal payload correction
Revision2 retained full removal packets without normal geometry validation, so an
oversized transform could enter the ledger. Preserve successful revision2 evidence
and binary locally. Require removal packets to contain empty vertex/triangle/
transform arrays (bounded tombstone metadata only); add oversized-removal fixture.
Recompile/refreeze before scoring. Native config and real parity inputs unchanged.
