"""Reproduce focused Linux compilation; do not run concurrently with heavy workers."""
from pathlib import Path
import subprocess,resource,json,time,os
H=Path(__file__).resolve().parent;W=H.parent;B=Path('/workspace/shared/swift-toolchain/install/swift-6.4.1-RELEASE-debian13/usr/bin')
assert os.statvfs(H).f_bavail*os.statvfs(H).f_frsize>=790<<20
(H/'build/cache').mkdir(parents=True,exist_ok=True)
env=os.environ.copy();env['PATH']=str(B)+':'+env['PATH']
cmd=[str(B/'swiftc'),'-j','1','-module-cache-path',str(H/'build/cache'),'-I',str(H/'cmodule'),'-L',str(W/'blind-split-candidate-game-03/body-margin-variants-07/native025'),'-lblind_detour',str(H/'Bridge.swift'),str(H/'main.swift'),'-o',str(H/'build/replay')]
t=time.monotonic()
with open(H/'COMPILE.log','w')as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=120,env=env)
(H/'COMPILE_RECEIPT.json').write_text(json.dumps(dict(command=cmd,exitCode=r.returncode,wallSeconds=time.monotonic()-t,peakRSSKiB=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss),indent=2)+'\n')
if r.returncode:raise SystemExit(r.returncode)
print('Compile only. Re-freeze resulting binary and verify source pins before scoring; do not silently overwrite evidence.')
