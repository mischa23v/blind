from pathlib import Path
import json,hashlib
H=Path(__file__).resolve().parent;W=H.parent
files=json.loads((W/'blind-clearance-los-simplification-56/FROZEN.json').read_text())['files'].copy()
for p in [*H.glob('*.py'),*H.glob('*.cpp'),H/'PROTOCOL.md',H/'libblind_detour.so',H/'License.txt',W/'blind-tabletop-exclusion-hypothesis-65/FROZEN_EXCLUSION.json',W/'blind-tabletop-exclusion-hypothesis-65/INDEPENDENT_REVIEW.json',W/'blind-actual-arrival-loop-63/SELECTED_PLAN.json']:
 files[str(p.relative_to(W))]=hashlib.sha256(p.read_bytes()).hexdigest()
for p,d in files.items():assert hashlib.sha256((W/p).read_bytes()).hexdigest()==d,p
assert not(H/'FROZEN.json').exists()
r={'scope':'66 source-only frozen unknown tabletop exclusion before native erosion','files':files,'noReferenceSelection':True,'noMovement':True,'resourceLimits':{'addressSpaceBytes':512*1024**2,'CPUSeconds':120,'wallSeconds':180,'newOutputBytes':256*1024,'diskReserveBytes':768*1024**2}}
(H/'FROZEN.json').write_text(json.dumps(r,indent=2)+'\n');print(hashlib.sha256((H/'FROZEN.json').read_bytes()).hexdigest(),len(files))
