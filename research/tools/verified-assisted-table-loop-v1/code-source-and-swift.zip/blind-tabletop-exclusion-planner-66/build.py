from pathlib import Path
import subprocess,hashlib,json,time,resource,os
H=Path(__file__).resolve().parent;N=H.parent/'blind-split-candidate-game-03/body-margin-variants-07/native025';U=N/'upstream'
assert not(H/'libblind_detour.so').exists()
resource.setrlimit(resource.RLIMIT_CPU,(120,120));resource.setrlimit(resource.RLIMIT_AS,(1024**3,1024**3));resource.setrlimit(resource.RLIMIT_FSIZE,(5<<20,5<<20));os.sched_setaffinity(0,{min(os.sched_getaffinity(0))})
files=[*sorted((U/'Recast/Source').glob('*.cpp')),*sorted((U/'Detour/Source').glob('*.cpp')),*sorted((U/'DetourCrowd/Source').glob('*.cpp')),H/'clearance_adapter.cpp'];cmd=['g++','-std=c++11','-O1','-fPIC','-shared','-fno-rtti','-fno-exceptions','-Wall','-Wextra',*[f'-I{U}/{x}/Include'for x in ['Recast','Detour','DetourCrowd']],*map(str,files),'-o',str(H/'libblind_detour.so')];start=time.monotonic()
p=subprocess.run(cmd,capture_output=True,text=True);(H/'build.stderr.log').write_text(p.stderr);(H/'BUILD_RECEIPT.json').write_text(json.dumps({'exitCode':p.returncode,'command':cmd,'wallSeconds':time.monotonic()-start,'sourceSHA256':{str(x):hashlib.sha256(x.read_bytes()).hexdigest()for x in files},'librarySHA256':hashlib.sha256((H/'libblind_detour.so').read_bytes()).hexdigest()if p.returncode==0 else None},indent=2)+'\n');p.check_returncode()
