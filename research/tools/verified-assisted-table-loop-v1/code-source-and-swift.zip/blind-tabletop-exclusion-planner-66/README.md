# Source-only tabletop exclusion: complete loop proposal

The frozen source-only exclusion produces **five connected source legs**, **20.8572 m** total proposal length and clockwise winding **−1**. All routes remain inside the pre-existing per-leg bounds expanded for the rotating body. **No physical movement was executed in this stage.**

## What changed

The independently reviewed stage65 polygon is an **unknown, manually assisted navigation exclusion hypothesis** derived from original phone RGB/depth. It is not a fabricated table solid, underside or legs, and is not certified object extent. Original Polycam triangles and all physical evaluator geometry are untouched.

A local adapter calls released `rcMarkConvexPolyArea` on the compact heightfield **before the existing single radius erosion**. The raw polygon is not preinflated. It marks **636** previously walkable compact spans as null. Candidate foot heights affected are **−0.682167 to1.104075 m**, derived from the observed top-point hypothesis range and unchanged native agent height1.75 m; those observations are not certified vertical bounds.

The source grid/cost, native body radius, exact original goals, source association limits and LOS simplification remain unchanged. A future movement test must retain the complete body and underbody guards; a source proposal alone establishes no physical clearance.

## Checks

- **9 native fixtures** pass, including exact real-Polycam dense-grid/five-route zero-exclusion parity, winding parity, no double erosion, unaffected levels outside the height interval and invalid polygon rejection.
- Sampled grid comparison: **7,502→7,366 nodes**, **28,111→27,572 edges**. **Zero newly accepted nodes or edges.** This is a sampled graph result, not proof that every continuous navmesh point is a subset.
- Source build/query: **2.89 s**, about39 MB peak RSS.
- Every original goal pair and clockwise loop survived; no geometry, endpoint or threshold was tuned after the result.

The first launch stopped before any query because unrelated inherited hash inputs were read wholesale under the memory cap. The preserved preflight failure was corrected with streaming hashes and a source-only dependency manifest; no planner or geometry rule changed.

## Evidence

`source-01/RESULT.json` and `QUERY_EVIDENCE.json.gz` contain the exact source paths, endpoint associations and simplification samples. `GRID_MONOTONICITY_AUDIT.json` compares sampled nodes/edges. `FROZEN.json` pins81 source inputs. `License.txt` accompanies the locally built adapter/library using unchanged pinned Recast/Detour upstream code.

Uncertainty remains unknown, semantic ROI selection was manually assisted, and no physical authority or human-safety claim is made.

## Portable source-only runtime inputs

`SOURCE_RUNTIME_MANIFEST.json` lists12 explicit planner inputs without FARO or mixed evaluator NPZ archives. The metadata-only adapter uses the existing stage42 phone-frame R/t allowlist; exact matrix values and all five source paths reproduce bit-for-bit (`FRAME_METADATA_PARITY.json`, `METADATA_ONLY_PATH_PARITY.json`). The completed original66 run is preserved. Its earlier mixed NPZ access decoded only R/t, not evaluator arrays; unrelated first-preflight access was hash-only and stopped before any query.
