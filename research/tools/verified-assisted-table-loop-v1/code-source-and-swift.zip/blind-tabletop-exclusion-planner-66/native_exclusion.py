"""Unknown source tabletop exclusion; no physical geometry is constructed."""
from pathlib import Path
import importlib.util,sys,threading,ctypes as C,json
import numpy as np
H=Path(__file__).resolve().parent;W=H.parent
sys.path.insert(0,str(W/'blind-clearance-centered-loop-55'))
from planner import Native as BaseNative
s=importlib.util.spec_from_file_location('exclusion66_binding',W/'blind-split-candidate-game-03/body-margin-variants-07/native025/detour_engine.py');de=importlib.util.module_from_spec(s);sys.modules[s.name]=de;s.loader.exec_module(de);de.ROOT=H
EXCLUSION=W/'blind-tabletop-exclusion-hypothesis-65/FROZEN_EXCLUSION.json'
def frozen_exclusion():
 r=json.loads(EXCLUSION.read_text())
 assert r['unknown'] and r['authority'] is False and r['bodyInflationApplied'] is False and r['noFAROOrHeldoutUsed']
 p=np.asarray(r['polygonPlannerXZ'],float);assert np.array_equal(p,np.asarray(r['polygonLevelXY'])*[1,-1])
 return np.c_[p[:,0],np.zeros(len(p)),p[:,1]],r['observedTopPointHeightRangeNotBounds'],r
class ExclusionEngine(de.Engine):
 def __init__(self,v,t,config,polygon=None,height_range=None):
  self.handle=None;self._lock=threading.RLock();self.lib=de._lib();self.config=config;self.mode='known-provided-map'
  v=de._array(v,np.float32);t=de._array(t,np.int32)
  if v.ndim!=2 or v.shape[1]!=3 or t.ndim!=2 or t.shape[1]!=3:raise ValueError('mesh arrays must be N by3')
  cfg=de.NativeConfig(**config.__dict__)
  self.lib.bn_build_excluded.argtypes=[de.F,C.c_int,de.I,C.c_int,C.POINTER(de.NativeConfig),de.F,C.c_int,C.c_float,C.c_float];self.lib.bn_build_excluded.restype=C.c_void_p
  self.lib.bn_excluded_span_count.argtypes=[C.c_void_p];self.lib.bn_excluded_span_count.restype=C.c_int
  if polygon is None:h=self.lib.bn_build(de._fp(v),len(v),t.ctypes.data_as(de.I),len(t),C.byref(cfg))
  else:
   p=de._array(polygon,np.float32)
   if p.ndim!=2 or p.shape[1]!=3 or height_range is None or len(height_range)!=2:raise ValueError('exclusion shape/range')
   h=self.lib.bn_build_excluded(de._fp(v),len(v),t.ctypes.data_as(de.I),len(t),C.byref(cfg),de._fp(p),len(p),*height_range)
  if not h:raise ValueError(self.lib.bn_last_error().decode())
  self.handle=h;self.marked_span_count=self.lib.bn_excluded_span_count(h)
class Native(BaseNative):
 def __init__(self,v,t,*,exclusion=True,polygon=None,height_range=None):
  cfg=de.Config(radius=.225,height=1.75,cell_size=.025,max_climb=.025,max_slope=15)
  if exclusion and polygon is None:polygon,height_range,_=frozen_exclusion()
  if not exclusion:polygon=None;height_range=None
  self.engine=ExclusionEngine(v,t,cfg,polygon,height_range);self.lib=self.engine.lib
  self.lib.bn_sample.argtypes=[C.c_void_p,de.F,de.F,C.c_float,de.F,de.F];self.lib.bn_sample.restype=C.c_int
  self.lib.bn_segment.argtypes=[C.c_void_p,de.F,de.F];self.lib.bn_segment.restype=C.c_int
  self.marked_span_count=self.engine.marked_span_count
  self.receipt={'unknownExclusion':exclusion,'physicalAuthority':False,'rawPolygonInflated':False,'agentRadiusAppliedOnceByNativeErosion':True,'markedCompactSpans':self.marked_span_count,'observedHeightHypothesisRange':height_range,'affectedCandidateFootHeightInterval':None if height_range is None else[height_range[0]-cfg.height,height_range[1]],'nativeHeightMetres':cfg.height,'physicalGeometryChanged':False,'sourceROIManuallyAssisted':True,'notCertifiedObstacleBounds':True}
