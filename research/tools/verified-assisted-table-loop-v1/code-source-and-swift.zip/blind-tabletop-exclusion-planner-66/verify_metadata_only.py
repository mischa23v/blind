from pathlib import Path
import json,hashlib,time
import numpy as np
H=Path(__file__).resolve().parent;W=H.parent
from source_metadata_only import ActualArrivalPlanner
p=ActualArrivalPlanner();before=json.loads((H/'source-01/RESULT.json').read_text());rows=[];start=time.monotonic()
for leg in before['legs']:
 r=p.query(leg['requestedStartXYZ'],leg['unchangedOriginalGoalXYZ'],leg['leg']);same=bool(r['complete']and np.array_equal(r['points'],leg['originalFramePath'])and np.array_equal(r['nativeXYZ'],leg['nativeXYZ']));rows.append({'leg':leg['leg'],'complete':r['complete'],'pathAndNativeXYZBitExact':same});assert same
p.close();out={'scope':'source-only metadata allowlist export substitution; saved source66 result is comparator only, never route input','checks':rows,'allFivePathsBitExact':all(r['pathAndNativeXYZBitExact']for r in rows),'wallSeconds':time.monotonic()-start,'noMixedNPZRequiredByPlanner':True,'noReferenceGeometryUsed':True};(H/'METADATA_ONLY_PATH_PARITY.json').write_text(json.dumps(out,indent=2)+'\n');print(out)
