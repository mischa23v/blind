"""Stable identity of the finite sampled source graph; not geometry certification."""
import hashlib,struct
import numpy as np

def graph_sha256(planner):
 h=hashlib.sha256(b'source-grid-identity-v1\0')
 p=np.asarray(planner.points,dtype='<f8');c=np.asarray(planner.clearance,dtype='<f8')
 h.update(struct.pack('<II',len(p),3));h.update(p.tobytes(order='C'));h.update(c.tobytes(order='C'))
 for i,row in enumerate(planner.adj):
  for j,cost in sorted(row):
   if i<j:h.update(struct.pack('<IId',i,int(j),float(cost)))
 return h.hexdigest()
if __name__=='__main__':
 from pathlib import Path
 import json
 from source_metadata_only import ActualArrivalPlanner
 h=Path(__file__).resolve().parent;p=ActualArrivalPlanner();r={'graphSHA256':graph_sha256(p),'gridNodes':len(p.points),'undirectedEdges':sum(len(x)for x in p.adj)//2,'exclusionReceipt':p.native.receipt,'nativeLibrarySHA256':hashlib.sha256((h/'libblind_detour.so').read_bytes()).hexdigest(),'frozenExclusionSHA256':hashlib.sha256((h.parent/'blind-tabletop-exclusion-hypothesis-65/FROZEN_EXCLUSION.json').read_bytes()).hexdigest(),'sourceMetadataOnly':True};p.close();(h/'GRAPH_IDENTITY.json').write_text(json.dumps(r,indent=2)+'\n');print(r)
