"""Source-only actual-arrival query. No evaluator geometry or contact input."""
from pathlib import Path
import sys, json, math
import numpy as np
H=Path(__file__).resolve().parent; W=H.parent
sys.path.insert(0,str(W/'blind-clearance-centered-loop-55'))
sys.path.insert(0,str(W/'blind-clearance-los-simplification-56'))
from planner import build_graph, dijkstra, compress_collinear, edge_cost, CONNECTOR
from simplify import simplify
from native_exclusion import Native

class ActualArrivalPlanner:
 def __init__(self):
  with np.load(W/'blind-polycam-alignment-feasibility-36/POLYCAM_INTRINSIC_GEOMETRY.npz') as z: obj=z['verticesOBJ'];tri=z['triangles']
  with np.load(W/'blind-polycam-rigid-registration-37/run-01/CANDIDATE_RIGID_TRANSFORM.npz') as z: level=obj@z['rotationOBJToLevel'].T+z['translationOBJToLevel']
  with np.load(W/'blind-split-candidate-game-03/inputs/koivu_5cm_v2_pipeline2_out.npz') as z:self.R=z['R'];self.t=z['t']
  with np.load(W/'blind-pose-experiments-review-17/upstream/pose-consistency/runs/koivu_floorfix/pipeline2_out.npz') as z:self.N=z['R'];self.nt=z['t']
  self.vertices=np.c_[level[:,0],level[:,2],-level[:,1]]
  self.native=Native(self.vertices,tri)
  fixed=json.loads((W/'blind-clearance-centered-loop-55/RESULT.json').read_text())
  anchors=[x['requestedXYZ'] for x in fixed['anchorAssociations']];anchors.append(anchors[0])
  points,clearance,adj,nodes,_=build_graph(self.native,self.vertices,anchors)
  # Exclude original query anchors from the reusable grid. Grid coordinates,
  # sampling height and neighbor rule remain source55; the exclusion may remove nodes and edges.
  count=nodes[0];self.points=points[:count];self.clearance=clearance[:count]
  self.adj=[[edge for edge in row if edge[0]<count] for row in adj[:count]]
  self.bounds=json.loads((W/'blind-polycam-table-loop-proposals-44/PROPOSED_PHYSICS_BOUNDS.json').read_text())['perLeg']
 def corrected(self,p):
  p=np.asarray(p,float);level=np.array([p[0],-p[2],p[1]])
  new=((level-self.t)@self.R)@self.N.T+self.nt
  return np.array([new[0],new[2],-new[1]])
 def original(self,p):
  p=np.asarray(p,float);level=np.c_[p[:,0],-p[:,2],p[:,1]]
  old=((level-self.nt)@self.N)@self.R.T+self.t
  return np.c_[old[:,0],old[:,2],-old[:,1]]
 def query(self,actual,goal,leg):
  actual=np.asarray(actual,float);goal=np.asarray(goal,float)
  if actual.shape!=(3,) or goal.shape!=(3,) or not np.isfinite([actual,goal]).all() or type(leg)is not int or not 0<=leg<=4:raise ValueError('finite actual pose and ordered handoff leg')
  requested=actual.copy();requested[1]=0. # Existing level-map association, not actor motion.
  rows=[];points=list(self.points);clearance=list(self.clearance);adj=[list(row) for row in self.adj];ids=[]
  for p in (requested,goal):
   corrected=self.corrected(p);hit=self.native.sample(corrected,(.2,.3,.2))
   if hit is None:return {'complete':False,'reason':'query association unavailable'}
   projected,c=hit
   if np.linalg.norm((projected-corrected)[[0,2]])>.1:return {'complete':False,'reason':'query association exceeds unchanged10cm'}
   original=self.original(np.array([projected]))[0]
   if abs(original[1])>.05:return {'complete':False,'reason':'query native height exceeds unchanged5cm'}
   u=len(points);ids.append(u);points.append(projected);clearance.append(c);adj.append([])
   for v in np.flatnonzero(np.linalg.norm((self.points-projected)[:,[0,2]],axis=1)<=CONNECTOR):
    v=int(v)
    if self.native.segment(projected,points[v]) and self.native.segment(points[v],projected):
     cost=edge_cost(projected,points[v],c,clearance[v]);adj[u].append((v,cost));adj[v].append((u,cost))
   rows.append({'requestedOriginalXYZ':p.tolist(),'projectedCorrectedXYZ':projected.tolist(),'projectedOriginalXYZ':original.tolist(),'horizontalAssociationMetres':float(np.linalg.norm((projected-corrected)[[0,2]]))})
  indices,cost=dijkstra(adj,*ids)
  if indices is None:return {'complete':False,'reason':'no source grid route','associations':rows}
  raw=compress_collinear(np.asarray(points)[indices]);simple=simplify(self.native,raw)
  if not simple['complete']:return {'complete':False,'reason':'source simplification rejected','simplification':simple}
  native=np.array(simple['nativeXYZ']);original=self.original(native)
  # Exact delivered XYZ connector retained. The controller may flatten its
  # steering copy only; physics retains the measured foot height.
  exact=np.vstack([actual,original,goal]);bounds=np.array(self.bounds[leg]['floorCandidateXZBounds']);radius=math.hypot(.225,.15)
  covered=bool(np.all(exact[:,[0,2]].min(0)-radius>=bounds[0]) and np.all(exact[:,[0,2]].max(0)+radius<=bounds[1]))
  return {'complete':covered,'reason':'sourceRouteReady' if covered else 'sourceRouteOutsideFrozenLegBounds','actualDeliveredXYZ':actual.tolist(),'unchangedOriginalGoalXYZ':goal.tolist(),'leg':leg,'points':exact.tolist(),'nativeXYZ':native.tolist(),'associations':rows,'weightedGridCost':cost,'simplification':simple,'fullRotatingBodyCircleWithinFrozenBounds':covered,'unknownExclusionReceipt':self.native.receipt,'referenceInputUsed':False,'actorSnapped':False,'gridSamplingHeightUnchanged':True}
 def close(self):self.native.close()
