from pathlib import Path
import json,gzip,numpy as np
from PIL import Image,ImageDraw,ImageFont
H=Path(__file__).resolve().parent;W=H.parent;r=json.loads((H/'source-01/RESULT.json').read_text());plan=json.loads((W/'blind-actual-arrival-loop-63/SELECTED_PLAN.json').read_text())
with np.load(W/'blind-polycam-alignment-feasibility-36/POLYCAM_INTRINSIC_GEOMETRY.npz')as z:v=z['verticesOBJ'];tri=z['triangles']
with np.load(W/'blind-polycam-rigid-registration-37/run-01/CANDIDATE_RIGID_TRANSFORM.npz')as z:lev=v@z['rotationOBJToLevel'].T+z['translationOBJToLevel']
with np.load(W/'blind-split-candidate-game-03/inputs/koivu_5cm_v2_pipeline2_out.npz')as z:R=z['R'];t=z['t']
with np.load(W/'blind-pose-experiments-review-17/upstream/pose-consistency/runs/koivu_floorfix/pipeline2_out.npz')as z:N=z['R'];nt=z['t']
old=((lev-nt)@N)@R.T+t;v=np.c_[old[:,0],old[:,2],-old[:,1]];xyz=v[tri];keep=(xyz.mean(1)[:,1]>.15)&(xyz.mean(1)[:,1]<1.8)
lo=v[:,[0,2]].min(0);hi=v[:,[0,2]].max(0);im=Image.new('RGB',(1100,1300),'white');d=ImageDraw.Draw(im);font='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf';big=ImageFont.truetype(font,25);sm=ImageFont.truetype(font,17);scale=min(950/(hi[0]-lo[0]),1020/(hi[1]-lo[1]))
def p(q):return(65+(q[0]-lo[0])*scale,160+(q[2]-lo[1])*scale)
d.text((35,20),'Source-only 20.857 m loop proposal; NO movement executed',font=big,fill='black');d.text((35,58),'Unchanged native parameters; manually assisted unknown tabletop exclusion before one erosion.',font=sm,fill='black')
for q in xyz[keep]:d.line([p(x)for x in q]+[p(q[0])],fill='#dddddd',width=1)
for leg in r['legs']:d.line([p(q)for q in leg['originalFramePath']],fill='#1679ae',width=4)
poly=json.loads((W/'blind-tabletop-exclusion-hypothesis-65/FROZEN_EXCLUSION.json').read_text())['polygonPlannerXZ'];poly=np.array(poly);new=np.c_[poly[:,0],-poly[:,1],np.zeros(len(poly))];oldpoly=((new-nt)@N)@R.T+t;gamepoly=np.c_[oldpoly[:,0],oldpoly[:,2],-oldpoly[:,1]];d.polygon([p(q)for q in gamepoly],fill='#ffc37a',outline='#a55300');d.text(p(gamepoly.mean(0)),'UNKNOWN',font=sm,fill='#843600')
for j,q in enumerate([plan['start'],*[x['originalTaskGoal']for x in plan['legs']]]):
 
 if j==5:continue
 x,y=p(q);d.ellipse((x-5,y-5,x+5,y+5),fill='#222222');d.text((x+8,y),('0 / 5' if j==0 else str(j)),font=sm,fill='black')
d.text((35,1215),'Blue = source proposal only. Orange = unknown tabletop exclusion, not a physical solid.',font=sm,fill='black');d.text((35,1245),'All five fixed source legs connect; clockwise winding -1; zero newly accepted sampled nodes/edges.',font=sm,fill='black');d.text((35,1270),'Original source mesh unchanged. No collision or movement validation in this stage.',font=sm,fill='black');im.save(H/'SOURCE_PROPOSAL.png')
