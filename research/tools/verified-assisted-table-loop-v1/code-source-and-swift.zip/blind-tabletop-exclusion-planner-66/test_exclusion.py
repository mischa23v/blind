import unittest,json
from pathlib import Path
import numpy as np
from native_exclusion import Native,frozen_exclusion
from planner import Native as Baseline

def floor(y=0.):
 return np.array([[-3,y,-3],[-3,y,3],[3,y,3],[3,y,-3]],float),np.array([[0,1,2],[0,2,3]],int)
def square():return np.array([[-.4,0,-.4],[.4,0,-.4],[.4,0,.4],[-.4,0,.4]])
class Tests(unittest.TestCase):
 def test_zero_exclusion_parity(self):
  v,t=floor();a=Baseline(v,t);b=Native(v,t,exclusion=False)
  try:
   self.assertEqual(b.marked_span_count,0)
   for x in[-2.,-1.,0.,1.,2.]:
    aa=a.sample([x,0,0]);bb=b.sample([x,0,0]);np.testing.assert_array_equal(aa[0],bb[0]);self.assertEqual(aa[1],bb[1])
   self.assertEqual(vars(a.engine.route([-2,0,0],[2,0,0])),vars(b.engine.route([-2,0,0],[2,0,0])))
  finally:a.close();b.close()
 def test_null_before_one_erosion(self):
  v,t=floor();n=Native(v,t,polygon=square(),height_range=[1.,1.1])
  try:
   self.assertGreater(n.marked_span_count,0);self.assertIsNone(n.sample([0,0,0]));self.assertIsNone(n.sample([.5,0,0]));self.assertIsNotNone(n.sample([.75,0,0]));self.assertTrue(n.engine.route([-2,0,0],[2,0,0]).complete)
  finally:n.close()
 def test_winding_parity(self):
  v,t=floor();a=Native(v,t,polygon=square(),height_range=[1,1.1]);b=Native(v,t,polygon=square()[::-1],height_range=[1,1.1])
  try:self.assertEqual(a.marked_span_count,b.marked_span_count);self.assertEqual(vars(a.engine.route([-2,0,0],[2,0,0])),vars(b.engine.route([-2,0,0],[2,0,0])))
  finally:a.close();b.close()
 def test_levels_above_and_below_unaffected(self):
  for y in [-2.,2.]:
   v,t=floor(y);n=Native(v,t,polygon=square(),height_range=[1.,1.1])
   try:self.assertEqual(n.marked_span_count,0);self.assertIsNotNone(n.sample([0,y,0]))
   finally:n.close()
 def test_overhead_beyond_native_height_unaffected(self):
  v,t=floor();n=Native(v,t,polygon=square(),height_range=[3.,3.1])
  try:self.assertEqual(n.marked_span_count,0);self.assertIsNotNone(n.sample([0,0,0]))
  finally:n.close()
 def test_invalid_polygon_rejected(self):
  v,t=floor();bad=[np.vstack([square(),square()]),np.zeros((3,3)),np.array([[0,0,0],[1,0,1],[0,0,1],[1,0,0]]),square()*float('nan')]
  for p in bad:
   with self.assertRaises(ValueError):Native(v,t,polygon=p,height_range=[1,1.1])
 def test_invalid_height_rejected(self):
  v,t=floor()
  for interval in [[2,1],[float('nan'),1]]:
   with self.assertRaises(ValueError):Native(v,t,polygon=square(),height_range=interval)
 def test_frozen65_frame_and_provenance(self):
  p,y,r=frozen_exclusion();self.assertEqual(len(p),19);self.assertEqual(p.shape,(19,3));np.testing.assert_array_equal(p[:,[0,2]],r['polygonPlannerXZ']);self.assertTrue(r['unknown']);self.assertFalse(r['bodyInflationApplied']);self.assertEqual(y,[1.0678330948175452,1.1040746892673932])
 def test_real_polycam_zero_exclusion_dense_parity(self):
  w=Path(__file__).resolve().parent.parent
  with np.load(w/'blind-polycam-alignment-feasibility-36/POLYCAM_INTRINSIC_GEOMETRY.npz')as z:v=z['verticesOBJ'];t=z['triangles']
  with np.load(w/'blind-polycam-rigid-registration-37/run-01/CANDIDATE_RIGID_TRANSFORM.npz')as z:v=v@z['rotationOBJToLevel'].T+z['translationOBJToLevel']
  v=np.c_[v[:,0],v[:,2],-v[:,1]];a=Baseline(v,t);b=Native(v,t,exclusion=False)
  try:
   lo=np.floor(v[:,[0,2]].min(0)/.05).astype(int);hi=np.ceil(v[:,[0,2]].max(0)/.05).astype(int);checks=0
   for x in range(lo[0],hi[0]+1):
    for z in range(lo[1],hi[1]+1):
     pa=a.sample([x*.05,0,z*.05]);pb=b.sample([x*.05,0,z*.05]);checks+=1
     self.assertEqual(pa is None,pb is None)
     if pa is not None:np.testing.assert_array_equal(pa[0],pb[0]);self.assertEqual(pa[1],pb[1])
   anchors=[q['requestedXYZ']for q in json.loads((w/'blind-clearance-centered-loop-55/RESULT.json').read_text())['anchorAssociations']]
   for x,y in zip(anchors,anchors[1:]+anchors[:1]):self.assertEqual(vars(a.engine.route(x,y)),vars(b.engine.route(x,y)))
   self.assertGreater(checks,1000);self.assertEqual(b.marked_span_count,0)
  finally:a.close();b.close()
if __name__=='__main__':unittest.main()
