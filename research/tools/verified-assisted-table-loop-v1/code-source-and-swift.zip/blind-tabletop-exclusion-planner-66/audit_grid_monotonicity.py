"""Post-build source-only audit, never input to candidate selection."""
from pathlib import Path
import json,hashlib,time,resource
import numpy as np
H=Path(__file__).resolve().parent;W=H.parent
def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb')as f:
  while b:=f.read(65536):h.update(b)
 return h.hexdigest()
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2));resource.setrlimit(resource.RLIMIT_CPU,(120,120))
from source_replan import ActualArrivalPlanner
from planner import Native as Baseline,build_graph
f=json.loads((H/'FROZEN.json').read_text())
for p,d in f['files'].items():assert sha(W/p)==d,p
start=time.monotonic();new=ActualArrivalPlanner()
with np.load(W/'blind-polycam-alignment-feasibility-36/POLYCAM_INTRINSIC_GEOMETRY.npz')as z:tri=z['triangles']
old=Baseline(new.vertices,tri);anchors=[a['requestedXYZ']for a in json.loads((W/'blind-clearance-centered-loop-55/RESULT.json').read_text())['anchorAssociations']];anchors.append(anchors[0])
op,oc,oa,on,_=build_graph(old,new.vertices,anchors);count=on[0];op=op[:count];oa=[[e for e in x if e[0]<count]for x in oa[:count]]
def sets(points,adj):
 keys=[tuple(np.rint(p[[0,2]]/.05).astype(int).tolist())for p in points];edges=set()
 for i,rows in enumerate(adj):
  for j,_ in rows:
   if i<j:edges.add(tuple(sorted((keys[i],keys[j]))))
 return set(keys),edges
ok,oe=sets(op,oa);nk,ne=sets(new.points,new.adj);added=nk-ok;addededges=ne-oe
r={'scope':'source-only monotonicity audit; no route or polygon changes','oldGridNodes':len(ok),'newGridNodes':len(nk),'removedGridNodes':len(ok-nk),'newlyAcceptedGridNodes':len(added),'newlyAcceptedKeys':sorted(added),'oldUndirectedGridEdges':len(oe),'newUndirectedGridEdges':len(ne),'newlyAcceptedGridEdges':len(addededges),'newlyAcceptedEdgeKeys':sorted(addededges),'noNewGridNodesOrEdges':not added and not addededges,'limits':'Only fixed5cm sampled grid and native-raycast edges; not proof of continuous navmesh subset or physical free space.','wallSeconds':time.monotonic()-start,'auditScriptSHA256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
new.close();old.close();(H/'GRID_MONOTONICITY_AUDIT.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items()if k not in ['newlyAcceptedKeys','newlyAcceptedEdgeKeys']}))
