from pathlib import Path
import json,hashlib,gzip,time,resource,signal,os,math
H=Path(__file__).resolve().parent;W=H.parent
def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb')as f:
  while b:=f.read(65536):h.update(b)
 return h.hexdigest()
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2));resource.setrlimit(resource.RLIMIT_CPU,(120,120));resource.setrlimit(resource.RLIMIT_FSIZE,(256*1024,256*1024));signal.alarm(180)
import numpy as np
from source_replan import ActualArrivalPlanner
manifest=json.loads((H/'FROZEN.json').read_text())
for p,d in manifest['files'].items():assert sha(W/p)==d,p
assert os.statvfs(H).f_bavail*os.statvfs(H).f_frsize>(768*1024**2+256*1024)
out=H/'source-01';out.mkdir(exist_ok=False);start=time.monotonic();planner=ActualArrivalPlanner();plan=json.loads((W/'blind-actual-arrival-loop-63/SELECTED_PLAN.json').read_text());rows=[];details=[];joined=[]
for i,leg in enumerate(plan['legs']):
 a=leg['sourceStartOriginalXYZ'];b=leg['originalTaskGoal'];r=planner.query(a,b,i);details.append(r)
 row={'leg':i,'requestedStartXYZ':a,'unchangedOriginalGoalXYZ':b,'complete':r['complete'],'reason':r['reason']}
 if r['complete']:
  path=np.array(r['points']);row.update(originalFramePath=path.tolist(),nativeXYZ=r['nativeXYZ'],horizontalLengthMetres=float(np.linalg.norm(np.diff(path[:,[0,2]],axis=0),axis=1).sum()),fullRotatingBodyCircleWithinFrozenBounds=r['fullRotatingBodyCircleWithinFrozenBounds']);joined.extend(path.tolist()if not joined else path[1:].tolist())
 rows.append(row)
receipt=planner.native.receipt;planner.close();winding=None;complete=all(x['complete']for x in rows)
if complete:
 p=np.array(joined)[:,[0,2]]-np.array(plan['tableWindingPointOriginalXYZ'])[[0,2]];winding=float(np.arctan2(p[:-1,0]*p[1:,1]-p[:-1,1]*p[1:,0],(p[:-1]*p[1:]).sum(1)).sum()/(2*np.pi))
with gzip.open(out/'QUERY_EVIDENCE.json.gz','wt')as f:json.dump(details,f,separators=(',',':'))
r={'scope':'source-only unknown tabletop exclusion candidate; no physical movement','completeFiveLegTour':complete,'oneLoopProposal':bool(complete and abs(winding+1)<1e-5),'winding':winding,'legs':rows,'exclusionReceipt':receipt,'frozenExclusionSHA256':hashlib.sha256((W/'blind-tabletop-exclusion-hypothesis-65/FROZEN_EXCLUSION.json').read_bytes()).hexdigest(),'referenceUsed':False,'movementExecuted':False,'semanticROIManuallyAssisted':True,'uncertaintyRemainsUnknown':True,'runtime':{'wallSeconds':time.monotonic()-start,'CPUSeconds':time.process_time(),'peakRSSKiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}}
(out/'RESULT.json').write_text(json.dumps(r,indent=2)+'\n')
assert sum(p.stat().st_size for p in out.iterdir()if p.is_file())<=256*1024
for p,d in manifest['files'].items():assert sha(W/p)==d,p
print(json.dumps({k:v for k,v in r.items()if k!='legs'}));print([(x['leg'],x['complete'],x.get('horizontalLengthMetres'),x['reason'])for x in rows])
