# Stage66: source-only tabletop exclusion in released Recast

Use the independently reviewed, frozen stage65 **unknown navigation exclusion hypothesis**. Original Polycam vertices/triangles, source registration, body dimensions, native parameters, source grid/cost, fixed goals and LOS simplification remain unchanged. The exclusion is based on manually assisted source RGB contour/ROI selection and phone depth; it is not an automatic detector, certified obstacle bound, physical solid, table-leg model or free-space proof.

The19-vertex convex polygon is in corrected planner XZ=(levelX,−levelY). Pass the raw, uninflated polygon to released `rcMarkConvexPolyArea` on the compact heightfield **before** the existing single `rcErodeWalkableArea` call. Mark `RC_NULL_AREA`; never add walkable spans. Recast raster/height quantization remains unchanged.

Observed top-point hypothesis heights are1.0678330948175452–1.1040746892673932m, explicitly not certified bounds. With unchanged native agent height1.75m, affected candidate foot heights are[−0.6821669051824548,1.1040746892673932]m: an interval where foot-to-foot+height intersects that observed height hypothesis. No extra body inflation, vertical fill, floor flattening or physical mesh modification is performed.

Local adapter changes: explicit exclusion build arguments, finite/convex/unique-vertex checks, count newly null spans, and defensive nonempty native raycast-path check. No frozen55 binary or released upstream source is modified. The zero-exclusion wrapper retains prior build behavior and must pass parity fixtures. Above/below floor levels outside the hypothesis interval must remain unaffected.

## Frozen source-only evaluation

Build the unchanged world-origin5cm source grid and eight-neighbor native-raycast edges. Use the unchanged wall-distance cap2m and cost length×(1+(0.30/(residualClearance+0.05))²). Native radius0.225m is applied only by the existing erosion, not again by custom logic.

Query the five original stage44 start/goal pairs in order using the stage63 actual-start query algorithm (source-only fixed original anchors for this preflight). Preserve exact endpoints, native height associations,10cm XZ association,15cm grid connectors and stage56 LOS simplification (≤25mm samples, no minimum-clearance degradation or integrated-cost increase beyond1e-6). Source-only rotated-body-circle checks must remain inside the existing per-leg extraction bounds. Record every failure and the actual concatenated source winding; do not tune to success or select routes using reference geometry.

Source run bounds:512MiB address space,120CPU seconds,180wall seconds,256KiB new result output,768MiB disk reserve. No world collision or movement run in this stage. Expected total preparation package about1MiB; all inputs and candidate polygon hash pinned before source queries.

A later movement variant, only after independent review, may use this source-only planner with the same stage63 actual-arrival controller and unchanged reference-world/body/support/underbody policies. No polygon enlargement after reference scoring is authorized.
