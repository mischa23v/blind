# Development stress pilot — proposal, not a navigation result

## Purpose and stopping condition
Test whether the existing frozen controller/actor interface behaves predictably
under five **synthetic timing/motion conditions** while keeping all physical
collision and support gates intact. First implement and independently review a
small five-episode pilot, one unchanged first-leg journey per condition. Stop the
pilot after those five scheduled outcomes, retaining invalid starts, stops and
budget failures. Do not tune the geometry, body, floor policy, route cost or
impairment magnitudes against outcomes. No heavy physics was run for this packet.

The successful stage69 three laps are nominal deterministic simulation, not
sensor robustness. This proposal does not claim otherwise.

## What is actually implemented already

| Capability | Existing code | Status for current stage69 loop |
|---|---|---|
| Nominal actor FIFO | `ActorFIFO`, `ActorProfile` | Wired and tested |
| Delayed command application, including delayed stop | `reaction_delay_ticks` | Utility exists; loop hardcodes nominal profile |
| Extra translation, with unchanged 25 mm cap | `translation_scale` up to 1.25 | Utility exists; not enabled in loop |
| Timed wrong-turn pulses | `wrong_turn_*` | Utility exists; deliberately not part of five-condition pilot |
| Seeded packet delay, temporal jitter, random drops | `SensorFIFO`, `SensorProfile` | Utility exists; current loop bypasses it |
| Missing/stale delivered-pose stop | Controller accepts `None`; 0.5 s age gate | Exists, but loop currently delivers exact current pose every tick |
| Fixed tracking interruption interval | No interval field in SensorProfile | Requires explicit submit-withholding adapter |
| Position/yaw estimation noise, drift or relocalization jumps | Not in these utilities | Not covered; requires new model and review |
| Raw camera/LiDAR/IMU corruption, dynamic obstacles | Not modeled here | Not covered |

Source: `blind-authored-navigation-pilot/source/impairments.py`. The older
`blind-koivu-game-07/run_game.py` shows pose queue integration, but its historical
world/collision logic must NOT replace the current stage61/69 physics.

## Five predeclared synthetic conditions

Machine-readable values and seeds are in `CONDITIONS.json`; simulation frequency
remains 15 Hz. Vary one axis at a time:

1. **Nominal:** zero pose/command delay, no drop, translation scale 1.
2. **Command delay:** actor reaction delay 3 ticks = 200 ms. Pose delivery nominal.
   A stop is queued; it cannot erase three commands already in flight.
3. **Temporal delivery jitter:** sensor queue base delay 2 ticks, seeded jitter
   ±2 ticks, no random drops. FIFO ordering is retained by the existing utility.
   This is timing jitter, NOT noisy estimated coordinates.
4. **Extra translation:** scale forward command by 1.15, retaining the existing
   25 mm per-tick cap. Yaw unchanged. No human-response distribution is claimed.
5. **Tracking interruption:** withhold pose captures during ticks [60,90),
   exactly two simulated seconds. Resume with a newly captured current simulated
   pose at tick90, not an old packet relabeled fresh. This does NOT simulate
   genuine ARKit relocalization or guarantee physical recovery.

The proposed pose adapter records capture/source tick, scheduled delivery tick,
all released packets and the selected newest released packet. If none is newly
released, pass `None`, not a fabricated fresh pose; do not silently hold/re-date
an old estimate. Record coalesced packets rather than pretend they were random
loss. Existing 0.5 s stale-pose rejection remains unchanged.

All world motion follows the true simulated state, never the delayed pose. Every
applied command, including motion after issued stop, still gets both full-body
half-sweeps, local support/continuity checks and underbody guards. A predicted
contact or support failure stops the episode before committing that motion.
Do not purge the FIFO, teleport the actor or move the reference map to rescue it.

## Small pilot before any 100-episode batch

Use the **unchanged original stage67 start, initial yaw and first original goal**,
with exactly the same source exclusion, body, reference geometry and membership0.
One fresh actor/pose FIFO per independent pilot episode is appropriate; never
reset within an episode. This pilot covers only the short first leg, not a lap
or all parts of the room. Conditions run in listed order with seed72000.

Required implementation before freezing/executing:
- Parameterize ActorProfile rather than alter its queue implementation.
- Integrate SensorFIFO for simulation-only pose delivery, preserving capture time.
- Add the explicit capture-withholding interval with independent audit rows.
- Preserve current controller/source planner and all physical/support guards.
- Add per-tick true/delivered poses, their errors/ages, issued/applied commands,
  capture disposition, queue contents/counts and source query evidence.
- Keep ordinary goal arrival contingent on the true original35 cm region,
  zero applied motion and drained nonzero FIFO, not only a delayed arrival cue.
- Freeze files, profiles and seeds; independent review before any physics run.

Required fixtures: nominal byte-value parity against unchanged first-leg baseline;
delayed-stop commands persist; stale timestamp never freshened; same-seed
jitter replay and FIFO order; interruption exact bounds; no-delivery sendsNone;
resumption uses newcapture; extra translation cap; all support/body/underbody
checks still run during delayed motion; no reference route steering; no goal
arrival with pending motion; rejected proposal not committed.

`probe_queues.py` has already exercised 600 cheap synthetic queue ticks. Its
receipt proves queue semantics only: delayed stops retain three moving ticks,
extra20 mm commands become23 mm, the interruption yields30 missing deliveries,
and temporal jitter coalesces packets deterministically. **It is not a movement,
collision or real-sensor test.** No heavy mesh was loaded.

## Metrics and honest outcomes

Publish all five scheduled records, not just runs that moved. Separate:
- invalid initial support/body state, source-query failure, physical support veto;
- predicted body or underbody contact veto (include exact face and proposed pose);
- no-delivery/stale-pose/controller stop, queue drain, deadlock and budget stop;
- successful original-goal arrival with drained FIFO;
- committed contacts (should remain zero because the evaluator vetoes them).

Report actual/attempted distance, elapsed simulated time, CPU/wall/RSS, stop count,
first stop reason, latest pose age, maximum true-versus-delivered position/yaw
error, issued-versus-applied command lag, motion after issued stop, resume latency,
queue high-water mark, source queries and identity hashes. Preserve full traces
and every failed proposal. Count command-delay exposure and interruption exposure
explicitly: if an episode ends before tick60, that interruption was NOT tested.

**Zero committed collisions alone is not success:** the reference evaluator is an
oracle that rejects unsafe simulated moves. A predicted collision veto is a
navigation failure/assisted stop, not evidence that a phone sensed the obstacle.
Ground contacts remain unmeasured. There is no human-safety inference.

## Eventual 100 episodes, without pretending to have 20 rooms

After the five-episode pilot and any separately declared implementation fixes,
freeze **20 replicate indices × five conditions = 100 one-lap episodes**, using
the same five-goal original loop. Seed =72000+replicateIndex, shared across paired
conditions. These are20 replicates of one route, NOT20 distinct journeys/rooms.
Only temporal-jitter cases vary by seed; nominal/delay/extra/interruption repeats
can be deterministic duplicates and must not be treated as independent evidence.

Full-lap stress integration needs an additional handoff audit: source replanning
must use the *delivered estimate*, without secretly substituting true evaluator
position. Its exact query-start identity must match the delivered packet; report
its difference from the physical stationary pose separately. Under delay, the
old nominal assertion “query start equals true arrival position” may no longer
hold. Do not fix that by sending reference truth to the controller. Retain true
physical handoff support/collision and drained-arrival checks. Test all four
handoffs before claiming100 episodes are ready.

Nominal and each stress condition must report success/stop/invalid counts and
uncensored denominators. This is a development matrix, not a held-out statistical
safety validation. Do not tune against it and then describe it as a holdout.

## Resource feasibility

Proposed pilot caps per episode:450ticks,180CPU seconds,240wall seconds,3.5GiB RSS,
2MiB output,768MiB reserve and fresh4.3GiB available-memory admission. Sequential
five-episode maximum15CPU minutes/20wall minutes/10MiB output. Short nominal
first-leg geometry suggests considerably less work, but no successful finish is
guaranteed; budget failure remains a published result. Current disk snapshot786MiB
leaves18MiB above reserve; fresh admission is mandatory and concurrent writes
must be accounted for. Do not launch until implementation/review are complete.

The eventual100 full laps are expensive: stage67≈562CPU seconds and3.4MiB per
nominal lap implies≈15.6CPU hours and340MiB before stress overhead. A conservative
900CPU-second per-episode cap would permit25CPU hours, plus wall and artifact
headroom. Current local storage is insufficient for that full evidence set.
Require a separately frozen batch/storage/publication plan; never delete raw
archives or omit evidence to make the estimate fit. Do not launch100 now.
