"""Tiny queue semantics probe only: no map, reference geometry or collision test."""
from pathlib import Path
import json,sys,hashlib
from dataclasses import asdict
H=Path(__file__).resolve().parent;W=H.parent;P=W/'blind-authored-navigation-pilot/source/impairments.py';sys.path.insert(0,str(P.parent))
from impairments import ActorFIFO,ActorProfile,ActorCommand,SensorFIFO,SensorProfile
config=json.loads((H/'CONDITIONS.json').read_text())
def probe(c,seed):
 actor=ActorFIFO(ActorProfile(**c['actor']));sensor=SensorFIFO(SensorProfile(seed=seed,**c['poseDelivery']));rows=[]
 for tick in range(120):
  now=100+tick/15;withheld=c['withholdCaptureTicks']is not None and c['withholdCaptureTicks'][0]<=tick<c['withholdCaptureTicks'][1]
  disposition=None
  if not withheld:disposition=asdict(sensor.submit(tick,{'tick':tick,'receivedAt':now,'command':'continue','pose':{'capturedAt':now,'position':[tick*.01,0.,0.],'yaw':0.}}))
  delivered=sensor.release(tick,now);pose=delivered[-1].packet['pose']if delivered else None
  # Synthetic queue probe: a zero command during no delivery, and a scheduled
  # zero after tick100. This is not the actual path follower or a motion run.
  forward=.02 if pose is not None and tick<100 else 0.
  applied=actor.step(tick,ActorCommand(forward,0.,tick,pose['capturedAt']if pose else None,'queue fixture'))
  rows.append({'tick':tick,'withheld':withheld,'disposition':disposition,'releasedSourceTicks':[d.source_tick for d in delivered],'coalesced':max(0,len(delivered)-1),'deliveredCapturedAt':pose['capturedAt']if pose else None,'issuedForward':forward,'applied':asdict(applied)})
 return rows
out=[]
for c in config['conditions']:
 a=probe(c,config['baseSeed']);assert a==probe(c,config['baseSeed'])
 released=[t for r in a for t in r['releasedSourceTicks']];assert released==sorted(released)
 assert all(abs(r['applied']['forward_metres'])<=.025 and abs(r['applied']['yaw_radians'])<=.01745329252 for r in a)
 if c['id']=='command_delay':assert a[100]['applied']['forward_metres']>0 and a[102]['applied']['forward_metres']>0 and a[103]['applied']['forward_metres']==0
 if c['id']=='extra_translation':assert abs(a[0]['applied']['forward_metres']-.023)<1e-12
 if c['id']=='tracking_interruption':assert all(not r['releasedSourceTicks']and r['deliveredCapturedAt']is None for r in a[60:90]);assert a[90]['releasedSourceTicks']==[90]
 out.append({'condition':c['id'],'deterministicSameSeed':True,'missingDeliveryTicks':sum(not r['releasedSourceTicks']for r in a),'coalescedPackets':sum(r['coalesced']for r in a),'motionAfterIssuedZeroTicks':sum(r['issuedForward']==0 and r['applied']['forward_metres']!=0 for r in a),'rows':a})
receipt={'scope':'600 synthetic queue-only ticks, not navigation, sensors, obstacle avoidance or physics','physicsExecuted':False,'impairmentsSourceSHA256':hashlib.sha256(P.read_bytes()).hexdigest(),'conditionsSHA256':hashlib.sha256((H/'CONDITIONS.json').read_bytes()).hexdigest(),'results':out}
(H/'QUEUE_SEMANTICS_RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps([{k:v for k,v in r.items()if k!='rows'}for r in out],indent=2))
