from pathlib import Path
import json,hashlib
H=Path(__file__).resolve().parent;W=H.parent

def sha(p):
 h=hashlib.sha256()
 with p.open('rb')as f:
  while b:=f.read(65536):h.update(b)
 return h.hexdigest()
f=json.loads((W/'blind-tabletop-exclusion-loop-67/FROZEN.json').read_text());files=f['files'].copy()
for p in [*H.glob('*.py'),H/'SELECTED_PLAN.json',H/'CONDITIONS.json',H/'MOVEMENT_PROTOCOL.md',H/'EVIDENCE_CODEC.json',H/'DUAL_SOURCE_FIXED_PATH_AUDIT.json',H/'DUAL_SOURCE_FIXED_SEGMENTS.json.gz',W/'blind-tabletop-exclusion-loop-67/run-01/result/ACTOR_TRACE.npz',W/'blind-tabletop-exclusion-loop-67/run-01/result/TICK_EVIDENCE.jsonl.xz']:
 files[str(p.relative_to(W))]=sha(p)
for p,d in files.items():assert sha(W/p)==d,p
for n in ['local_support.py','loop_map.py','source_runtime.py','evidence_codec.py','SELECTED_PLAN.json']:
 assert(H/n).read_bytes()==(W/'blind-tabletop-exclusion-loop-67'/n).read_bytes(),n
assert not(H/'FROZEN.json').exists()
f.update(scope='73 five first-leg synthetic stress episodes; unchanged67 physical gates and source route',files=files,maximumTicksPerEpisode=450,aggregatePilotOutputCapBytes=5*1024**2,scheduledConditions=['nominal','command_delay','temporal_jitter','extra_translation','tracking_interruption'],syntheticOnly=True,sourceRequeriesExecuted=0,resourceLimits={'CPUSeconds':180,'wallSeconds':240,'RSSBytes':int(3.5*1024**3),'outputBytes':2*1024**2,'diskReserveBytes':768*1024**2},outputDirectory='pilot-<condition>',outputCapBytes=2*1024**2)
(H/'FROZEN.json').write_text(json.dumps(f,indent=2)+'\n');print(sha(H/'FROZEN.json'),len(files))
