# Five synthetic first-leg stress pilots

**All five scheduled short journeys reached the unchanged original goal, with
the actuator queue drained and no predicted body/underbody collision or support
veto.** This is a small development result in one assisted recorded room—not a
100-episode test, live sensor validation or human-safety proof.

| Synthetic condition | Distance | Ticks at 15 Hz | Notable behavior |
|---|---:|---:|---|
| Nominal | 2.775841 m | 172 | Exact first-leg command/distance parity with stage67 |
| Command delay, 200 ms | 2.839975 m | 197 | Three moving ticks after issued stop; FIFO then drained |
| Temporal delivery jitter, 2 ± 2 ticks | 2.800000 m | 370 | **193 no-new-pose stop ticks**, 191 coalesced packets |
| Extra forward translation, +15% | 2.783000 m | 154 | No applied-increment clipping |
| Capture interruption, 2 seconds | 2.775841 m | 202 | All30 withheld captures exposed; stopped and resumed without reset |

The temporal-jitter case took over twice the nominal tick count. Its maximum
delivered-pose age was267 ms and its maximum actual-versus-delivered position
difference was6.0004 cm. **Arrival does not imply smooth or pleasant navigation.**
The stop count comes from the deliberately frozen policy “no newly released
packet means stop,” not an intrinsic failure of a real sensor. Retaining an
unexpired last observation would be a separate policy requiring new tests; it was
not substituted after seeing these results.

## What was actually stressed

These are simulation-only pose transport and actuator increments. No camera,
LiDAR or IMU recording was corrupted, and no realistic sensor error distribution
was estimated. Jitter is temporal, not noisy coordinates. The interruption is a
missing-capture interval, not ARKit relocalization. On resume the new current
simulated pose is captured normally; the actor is never teleported.

The controller receives only the selected delivered packet with its original
capture timestamp, generation and source tick. Current evaluator truth is not
substituted for a delayed pose. Invalid, duplicate, future, stale or wrong-generation
observations stop the controller. An old goal cue cannot authorize arrival after
subsequent motion: the accepted observation must postdate the last committed
motion, and true original-goal proximity plus a drained queue are independently
required by the evaluator.

Every applied motion—including queued motion after a stop command—retained the
same local floor support/continuity test, full3D body sweeps and underbody guards.
The body remained45×30×160 cm with zero horizontal margin. Source exclusion,
source route, physical geometry and stage59 membership0 did not change. No failed
proposal or scheduled condition was discarded.

**A reference-world veto would count as a failed/assisted stop, not successful
phone obstacle detection.** Zero committed contacts is partly guaranteed by that
veto and is not sufficient evidence of robust navigation. Here no predicted
contact or support veto occurred either, but only this short first leg was tested.
Floor contact events remain unmeasured, with evaluator-assisted floor IDs/support
and manually assisted source ROI unchanged.

## Evidence and reproducibility

- `SUMMARY.json`: all five scheduled outcomes, distances, counts and receipt hashes.
- `CONDITIONS.json`: exact profiles, seed72000 and the proposed future matrix.
- `MOVEMENT_PROTOCOL.md`: predeclared first-leg method and budget.
- `FROZEN.json`:562 pinned inputs; SHA-256
  `33ebe269afdc54b28bb9b4d5940eaa7be100fc4a0129044b99d0622797b6d46d`.
- `INDEPENDENT_PRELAUNCH_REVIEW.json`:83 independently passing fixtures.
- Each `pilot-<condition>/RUN_RECEIPT.json` records its successful bounded run.
- Each result directory retains exact CSV/NPZ traces, full XZ tick/geometry evidence,
  transport capture/release records, applied commands and terminal result.
- Independent terminal replay/recount verifies transport queues, commands and
  recorded physical evidence without rerunning the heavy reference world.

The frozen budgets were180CPU/240wall seconds,3.5GiB RSS and2MiB per episode,
with a5MiB aggregate pilot-output cap and768MiB disk reserve. All five completed
within those limits; run artifacts total approximately2.1MiB. Each was run once,
sequentially. Exact CSV is flushed per row; verbose XZ is lossless on normal close
but may lose a recent tail under abrupt termination.

## Next milestone is not yet completed

The corrected future matrix is **20 distinct ordered source-anchor pairs × five
conditions =100 episodes**, in one room—not100 repeats of the same lap and not20
rooms. `../blind-synthetic-stress-protocol-72/TWENTY_SOURCE_PAIRS.json` declares the
pairs before scoring. Source paths and their own expanded-body bounds must be
prepared before reference evaluation; invalid starts/routes stay in the denominator.
Neither those100 episodes nor delayed-pose handoffs between multiple goals were
executed here. Storage and compute forecasts remain provisional.
