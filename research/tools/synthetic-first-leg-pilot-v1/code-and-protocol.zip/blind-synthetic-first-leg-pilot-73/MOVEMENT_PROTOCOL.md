# 73 — Five short synthetic stress episodes (implementation before execution)

This packet implements the five conditions in `CONDITIONS.json`. No physical
world run has been executed at preparation. It preserves stage69 and uses the
identical stage67 first source leg, source65 uncertainty-labeled exclusion,
source66 native validation, stage59 membership0 and stage61 physical support
law/body/underbody guards. No obstacle, dimension, margin or tolerance changes.

## Frozen intent
Five independent episodes in condition order: nominal,200ms command delay,
temporal packet jitter(2±2ticks),15% extra forward translation, and two-second
withheld captures[tick60,tick90). Seed72000. One original first-leg goal, not a lap.
Fresh actor and sensor queues at episode start; no reset or purge inside an
active episode. Original nominal start/heading and goal remain unchanged.

At15Hz, every non-withheld capture records the simulated true pose at that capture
time. SensorFIFO delays it and returns released packets without changing source
capture time. The controller receives ONLY the newest released pose, never the
current physical pose substituted for a delayed capture. Coalesced packets are
all logged. If no packet is newly released, the controller receivesNone and issues
a stop. **This is a deliberately frozen stop-on-no-new-packet policy, not evidence
of intrinsic sensor failure.** A production implementation could retain an
unexpired observation with its original timestamp, but that is NOT this pilot
and cannot be switched after seeing results. Jitter-induced stops are reported.

Observation generation, revision, capture tick and timestamp must match the
expected simulation contract. Duplicate, out-of-order, future, wrong-generation,
malformed or older-than0.5s observations produce zero commands. The source route
uses delivered coordinates only; evaluator truth is never supplied as corrective
controller/planner feedback. The evaluator separately records true-versus-delivered
error. The known evaluator floor assistance is unchanged and explicitly retained.

Every command goes through ActorFIFO. Delayed stops cannot erase in-flight motion.
All applied motion still receives the original local support/continuity checks,
two actual3D body sweeps and two underbody sweeps before any commit. Any predicted
contact is a failed/assisted stop, not a successful phone avoidance. Committed
contacts are zero by evaluator veto, not proof of sensing. No floor contacts are
measured. Underbody and body geometry remain45×30×160cm with zero margin.

Arrival additionally requires an accepted goal cue from the same delivered packet
and generation, captured strictly after the last committed motion tick. The true
original35cm goal region, positive travel, zero currently applied motion and
nonzero FIFO drain remain required. A delayed old goal observation cannot authorize
arrival after later physical motion. This check is evaluator acceptance only,
not a true pose passed back to the controller.

## Scope and exposure
The saved stage67 nominal first-leg arrival was tick171 (172ticks), after the
proposed60–89 interruption interval. That is a useful exposure preflight, not a
guarantee any stressed episode reaches it. Record all30 withheld ticks or mark
interruption exposure incomplete if the episode stops early. Retain every failure
and every condition in the scheduled denominator. No condition is rerun with
retuned parameters. No handoffs or delayed-pose replan claims arise from this
single-leg pilot; future20pair×5 matrix requires its own source-only paths/bounds.

The current nominal controller has a saved172-tick command replay fixture against
stage67: forward/yaw commands, reasons and goal cues must match exactly. This is
not a heavy physics rerun. Queue, malformed/stale packet, arrival causality and
all existing local floor/low-object fixtures run before independent review.

## Evidence and resource contract
Per episode:450ticks,180CPU seconds,240wall seconds,3.5GiB RSS,2MiB output;
768MiB disk reserve, fresh4.3GiB available RAM, unchanged6M candidate-face cap.
The aggregate five-episode output cap is5MiB, additionally enforced during every
run; per-episode cap remains2MiB. A new episode requires at least512KiB aggregate
headroom, a forecast not a promise. Any per-run or aggregate cap stops explicitly
and retains evidence; no truncation or silent precision reduction. Fresh disk gate for
EACH episode; no concurrent heavy physics. Resource forecast is provisional.
Exact CSV flushed each tick, full XZ evidence on normal close, capture dispositions,
all released packets, cue/applied commands, support/contacts, true/delivered errors,
stop reasons, delayed-motion counts and clipping counts retained. XZ may lose a
recent tail on abrupt kill; never claim fully flushed verbose evidence.

Existing stage67 files are not edited. `FROZEN.json` pins all new runtime inputs
before an independently approved run. Wrapper fails if any input changes and
refuses to overwrite `pilot-<condition>` output directories. Run commands must
not be issued before the independent gate and parent run authorization.
