"""Synthetic observation transport, not a perception system or world authority."""
from pathlib import Path
import json,math,sys
from dataclasses import asdict
import numpy as np
H=Path(__file__).resolve().parent;W=H.parent
sys.path.insert(0,str(W/'blind-authored-navigation-pilot/source'))
from impairments import SensorFIFO,SensorProfile

def condition_by_id(name):
 matches=[x for x in json.loads((H/'CONDITIONS.json').read_text())['conditions']if x['id']==name]
 if len(matches)!=1:raise ValueError('unknown unique frozen condition')
 return matches[0]

class PoseDelivery:
 def __init__(self,condition,seed):self.condition=condition;self.queue=SensorFIFO(SensorProfile(seed=seed,**condition['poseDelivery']))
 def capture_and_release(self,tick,now,state,yaw,revision,generation):
  interval=self.condition['withholdCaptureTicks'];withheld=interval is not None and interval[0]<=tick<interval[1];disposition=None;capture=None
  if not withheld:
   capture={'kind':'simulated-physics-body-pose','position':np.asarray(state).tolist(),'yaw':float(yaw),'capturedAt':now,'capturedTick':tick,'generation':generation,'mapRevision':revision}
   disposition=asdict(self.queue.submit(tick,{'tick':tick,'receivedAt':now,'command':'continue','pose':capture}))
  released=self.queue.release(tick,now);delivered=released[-1].packet['pose']if released else None
  return delivered,{'capture':capture,'captureWithheld':withheld,'disposition':disposition,'released':[asdict(r)for r in released],'selectedSourceTick':released[-1].source_tick if released else None,'coalescedPackets':max(0,len(released)-1),'pendingPackets':len(self.queue.pending),'syntheticOnly':True,'truePosePassedDirectlyToController':False}

def validate_delivered_pose(p,revision,generation,tick,now,last_tick,last_time):
 keys={'kind','position','yaw','capturedAt','capturedTick','generation','mapRevision'}
 if not isinstance(p,dict) or set(p)!=keys or p['kind']!='simulated-physics-body-pose' or p['mapRevision']!=revision:return False,'wrongSimulatedPoseSchemaOrRevision'
 if type(p['generation'])is not int or p['generation']!=generation:return False,'wrongObservationGeneration'
 t=p['capturedTick'];time=p['capturedAt']
 if type(t)is not int or not 0<=t<=tick or t<=last_tick:return False,'nonmonotonicOrFutureCaptureTick'
 if isinstance(time,bool) or not isinstance(time,(int,float)) or not math.isfinite(time) or time<=last_time or abs(time-(100+t/15))>1e-9:return False,'nonmonotonicOrWrongCaptureTimestamp'
 try:pos=np.asarray(p['position'],float)
 except (TypeError,ValueError):return False,'malformedDeliveredPosition'
 if pos.shape!=(3,)or not np.isfinite(pos).all()or isinstance(p['yaw'],bool)or not isinstance(p['yaw'],(int,float))or not math.isfinite(p['yaw']):return False,'nonfiniteDeliveredPose'
 if not 0<=now-time<=.5:return False,'staleOrInvalidSimulatedPose'
 return True,'acceptedSimulatedObservation'

def goal_observation_current(cue,delivered,generation,last_motion_tick):
 return bool(delivered is not None and cue.get('goalReached') and cue.get('sourceGeneration')==generation==delivered.get('generation') and cue.get('sourceCapturedTick')==delivered.get('capturedTick') and type(delivered.get('capturedTick'))is int and delivered['capturedTick']>last_motion_tick)
