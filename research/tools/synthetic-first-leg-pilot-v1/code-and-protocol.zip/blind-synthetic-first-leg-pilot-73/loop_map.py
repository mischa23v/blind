"""Exact source-only loop path adapter; no reference-world input."""
from pathlib import Path
import hashlib,json,importlib.util,sys,gzip,numpy as np
from source_runtime import ActualArrivalPlanner,verify_initial_source_plan
H=Path(__file__).resolve().parent;W=H.parent;PLAN=H/'SELECTED_PLAN.json';PLAN_SHA=hashlib.sha256(PLAN.read_bytes()).hexdigest()
s=importlib.util.spec_from_file_location('loop50_frozen_map40',W/'blind-polycam-varpu-executor-40/goal_region_map.py');old=importlib.util.module_from_spec(s);sys.modules[s.name]=old;s.loader.exec_module(old)
def load_plan(path=PLAN,digest=PLAN_SHA):
 if Path(path).resolve()!=PLAN.resolve()or digest!=PLAN_SHA or hashlib.sha256(PLAN.read_bytes()).hexdigest()!=digest:raise ValueError('fixed loop plan identity')
 p=json.loads(PLAN.read_text());assert p['status']=='frozenLoopNominal45SourceProposalOnly'and p['oneLapOnly'];assert [p['geometry'][k]for k in('width','depth','height','margin')]==[.45,.30,1.60,0.];assert len(p['legs'])==5 and p['taskArrivalToleranceMetres']==.35 and p['cornerConsumptionToleranceMetres']==.01;assert p['referenceInputsUsedForSelection']is False
 verify_initial_source_plan(p)
 return {**p,'mapRevision':PLAN_SHA,'goal':p['legs'][0]['originalTaskGoal'],'steeringGoalOriginalFrame':p['legs'][0]['originalTaskGoal'],'originalFramePath':p['legs'][0]['originalFramePath']}
class GoalRegionMap(old.GoalRegionMap):
 def __init__(self,plan):
  super().__init__(plan);self.replanner=None;self.pending_replan=False;self.replan_failure=None;self.query_receipt=None
 def close(self):
  if self.replanner:self.replanner.close();self.replanner=None
  super().close()
 def route(self,start,goal):
  expected=self.plan['legs'][self.leg]['originalTaskGoal']
  if not np.array_equal(goal,expected):raise ValueError('fixed source leg goal only')
  if self.pending_replan:
   if self.replanner is None:self.replanner=ActualArrivalPlanner()
   query=self.replanner.query(start,goal,self.leg);self.pending_replan=False
   out=H/'run-01/result'/f'SOURCE_REPLAN_LEG{self.leg}.json.gz'
   with gzip.open(out,'wt')as fp:json.dump(query,fp,separators=(',',':'))
   self.query_receipt={'path':str(out.relative_to(H)),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'complete':query['complete'],'actualDeliveredXYZ':np.asarray(start).tolist(),'unchangedGoalXYZ':list(goal),'referenceInputUsed':False,'runtimeExclusionIdentity':query['runtimeExclusionIdentity']}
   if query['complete']:self.points=np.asarray(query['points'],float);self.cursor=0
   else:self.replan_failure=query['reason']
  if self.replan_failure:return {'complete':False,'points':[],'reason':self.replan_failure,'sourceReplanReceipt':self.query_receipt}
  while self.cursor<len(self.points)and np.linalg.norm((self.points[self.cursor]-start)[[0,2]])<=.01:self.cursor+=1
  return {'complete':True,'points':self.points[self.cursor:].tolist(),'projectedStart':[float(start[0]),0.,float(start[2])],'projectedGoal':list(goal),'fixedCornerCursor':self.cursor,'proposalOnly':True,'referenceInputUsed':False,'fullRectangleValidated':False,'nativeRequeryPerformed':self.leg>0,'sourceReplanReceipt':self.query_receipt}
 def begin_next(self,leg):
  if type(leg)is not int or leg!=self.leg+1 or leg>=len(self.plan['legs']):raise ValueError('ordered loop legs only')
  self.leg=leg;self.pending_replan=True;self.replan_failure=None;self.points=np.empty((0,3));self.cursor=0
