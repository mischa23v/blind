"""Fail-closed runtime identity for the reviewed unknown-exclusion source planner."""
from pathlib import Path
import sys,json,hashlib
import numpy as np
H=Path(__file__).resolve().parent;W=H.parent;SOURCE=W/'blind-tabletop-exclusion-planner-66'
sys.path.insert(0,str(SOURCE))
from source_metadata_only import ActualArrivalPlanner as SourcePlanner
from graph_identity import graph_sha256
from native_exclusion import Native as ExclusionNative
from simplify import segment_measure
EXPECTED=json.loads((SOURCE/'GRAPH_IDENTITY.json').read_text())

def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb')as f:
  while b:=f.read(65536):h.update(b)
 return h.hexdigest()
def validate_receipt(receipt,graph):
 required={'unknownExclusion':True,'physicalAuthority':False,'rawPolygonInflated':False,'agentRadiusAppliedOnceByNativeErosion':True,'physicalGeometryChanged':False,'sourceROIManuallyAssisted':True,'notCertifiedObstacleBounds':True}
 for k,v in required.items():
  if receipt.get(k) is not v:raise ValueError('missing/invalid exclusion provenance: '+k)
 if receipt.get('markedCompactSpans')!=EXPECTED['exclusionReceipt']['markedCompactSpans'] or receipt['markedCompactSpans']<=0:raise ValueError('exclusion absent or different marked spans')
 if graph!=EXPECTED['graphSHA256']:raise ValueError('unexpected source graph identity')
 if receipt.get('affectedCandidateFootHeightInterval')!=EXPECTED['exclusionReceipt']['affectedCandidateFootHeightInterval']:raise ValueError('exclusion height interval changed')

def validate_undirected_graph(adj,count):
 if len(adj)!=count:raise ValueError('graph row count mismatch')
 rows=[]
 for i,row in enumerate(adj):
  d={}
  for j,cost in row:
   if isinstance(j,bool) or not isinstance(j,(int,np.integer)) or not 0<=j<count or j==i or j in d or not np.isfinite(cost) or cost<=0:raise ValueError('invalid/duplicate source graph edge')
   d[int(j)]=float(cost)
  rows.append(d)
 for i,row in enumerate(rows):
  for j,cost in row.items():
   if rows[j].get(i)!=cost:raise ValueError('source graph reverse adjacency differs')

def verify_source_files():
 inputs=json.loads((SOURCE/'SOURCE_RUNTIME_MANIFEST.json').read_text())['runtimeFiles']
 for p,d in inputs.items():
  if sha(W/p)!=d:raise ValueError('source runtime input changed: '+p)
 if sha(W/'blind-tabletop-exclusion-hypothesis-65/FROZEN_EXCLUSION.json')!=EXPECTED['frozenExclusionSHA256']:raise ValueError('exclusion hash changed')
 if sha(SOURCE/'libblind_detour.so')!=EXPECTED['nativeLibrarySHA256']:raise ValueError('native adapter hash changed')

def verify_initial_source_plan(plan):
 verify_source_files();r=json.loads((SOURCE/'source-01/RESULT.json').read_text())
 if plan['sourceResultSHA256']!=sha(SOURCE/'source-01/RESULT.json') or not r['oneLoopProposal']:raise ValueError('wrong frozen initial source candidate')
 validate_receipt(r['exclusionReceipt'],EXPECTED['graphSHA256'])
 audit=json.loads((H/'DUAL_SOURCE_FIXED_PATH_AUDIT.json').read_text())
 if not audit['allSegmentsAccepted'] or len(audit['legs'])!=5 or audit['sourceResultSHA256']!=plan['sourceResultSHA256'] or audit['runtimeSourceSHA256']!=sha(H/'source_runtime.py'):raise ValueError('initial dual-context source audit missing or stale')
 if plan.get('sourceExclusion',{}).get('frozenExclusionSHA256')!=EXPECTED['frozenExclusionSHA256']:raise ValueError('initial route missing frozen exclusion')
 if len(plan['legs'])!=5 or len(r['legs'])!=5:raise ValueError('five source legs required')
 for a,b in zip(plan['legs'],r['legs']):
  if not np.array_equal(a['originalFramePath'],b['originalFramePath']) or not np.array_equal(a['originalTaskGoal'],b['unchangedOriginalGoalXYZ']):raise ValueError('initial candidate or original goal changed')

class ActualArrivalPlanner(SourcePlanner):
 def __init__(self):
  self.baseline=None
  verify_source_files();super().__init__()
  try:
   with np.load(W/'blind-polycam-alignment-feasibility-36/POLYCAM_INTRINSIC_GEOMETRY.npz')as z:tri=z['triangles']
   self.baseline=ExclusionNative(self.vertices,tri,exclusion=False);self.verify_runtime()
  except BaseException:self.close();raise
 def verify_runtime(self):
  verify_source_files();validate_undirected_graph(self.adj,len(self.points));graph=graph_sha256(self);validate_receipt(self.native.receipt,graph)
  count=self.native.lib.bn_excluded_span_count(self.native.engine.handle)
  if count!=EXPECTED['exclusionReceipt']['markedCompactSpans']:raise ValueError('native handle exclusion is absent or changed')
  if Path(self.native.lib._name).resolve()!=(SOURCE/'libblind_detour.so').resolve():raise ValueError('wrong native adapter loaded')
  basecount=self.baseline.lib.bn_excluded_span_count(self.baseline.engine.handle)
  if basecount!=0 or Path(self.baseline.lib._name).resolve()!=(SOURCE/'libblind_detour.so').resolve():raise ValueError('baseline validator is not unchanged no-exclusion native map')
  return {'baselineValidatorMarkedSpans':basecount,'dualSourceSegmentChecksRequired':True,'graphSHA256':graph,'nativeLibrarySHA256':EXPECTED['nativeLibrarySHA256'],'frozenExclusionSHA256':EXPECTED['frozenExclusionSHA256'],'markedCompactSpans':count,'unknownExclusion':True,'semanticROIManuallyAssisted':True,'physicalAuthority':False,'referenceGeometryInput':False,'sourceMetadataOnly':True}
 def validate_segments(self,original_path):
  original=np.asarray(original_path,float)
  if original.ndim!=2 or original.shape[1]!=3 or len(original)<2 or not np.isfinite(original).all():raise ValueError('finite fullXYZ source path required')
  corrected=np.array([self.corrected(p)for p in original]);rows=[]
  for i,(a,b)in enumerate(zip(corrected[:-1],corrected[1:])):
   excluded=segment_measure(self.native,a,b);baseline=segment_measure(self.baseline,a,b)
   accepted=bool(excluded['valid']and baseline['valid']);rows.append({'segment':i,'exactOriginalStartXYZ':original[i].tolist(),'exactOriginalEndXYZ':original[i+1].tolist(),'excluded':excluded,'baseline':baseline,'accepted':accepted})
  return {'accepted':all(r['accepted']for r in rows),'segments':rows,'sourceOnly':True,'maximumSampleSpacingMetres':.025,'includesExactEndpointConnectors':True,'noPathReplacement':True}
 def close(self):
  if self.baseline is not None:self.baseline.close();self.baseline=None
  if getattr(self,'native',None)is not None:self.native.close()
 def query(self,actual,goal,leg):
  if type(leg)is not int or not 1<=leg<=4:raise ValueError('only drained handoff legs1to4')
  before=self.verify_runtime();r=super().query(actual,goal,leg)
  if r['complete']:
   checked=self.validate_segments(r['points']);r['dualSourceSegmentValidation']=checked
   if not checked['accepted']:r['complete']=False;r['reason']='baselineOrExcludedSourceSegmentRejected'
  after=self.verify_runtime()
  if before!=after:raise ValueError('source graph mutated during query')
  r['runtimeExclusionIdentity']=after
  return r
