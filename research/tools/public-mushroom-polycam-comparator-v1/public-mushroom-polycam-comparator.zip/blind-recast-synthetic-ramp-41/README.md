# Synthetic shallow-ramp regression

Separate authored geometry only, no sensor or room inputs. A4m-long×2m-wide continuous ramp rises5cm (0.716°), below the unchanged5° slope limit. It has no discontinuous physical step. Test the same nominal45cm proposal radius/.025m raster/1.75m native height with climb0 and one-cell climb.025m; also test a flat control. All four cases fixed before querying, same native library.

This isolates a raster-transition setting issue on known continuous geometry. It does not establish that any observed room height difference is noise, does not permit crossing a real small object, and does not alter any prior scene, map, result or physical contract. Exact vertices, triangles, config and native outcomes are retained in RESULT.json.
