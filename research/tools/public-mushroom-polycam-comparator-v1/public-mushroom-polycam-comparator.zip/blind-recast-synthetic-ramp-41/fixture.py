import os
os.environ['OPENBLAS_NUM_THREADS']='1'
import resource
resource.setrlimit(resource.RLIMIT_AS,(512<<20,512<<20));resource.setrlimit(resource.RLIMIT_CPU,(10,10))
from pathlib import Path
import json,numpy as np,hashlib,importlib.util,sys,dataclasses
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent;f=json.loads((HERE/'FROZEN.json').read_text())
for p,h in f['files'].items():assert hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==h
p=ROOT/'blind-split-candidate-game-03/body-margin-variants-07/native025/detour_engine.py';s=importlib.util.spec_from_file_location('synthetic_ramp41',p);de=importlib.util.module_from_spec(s);sys.modules[s.name]=de;s.loader.exec_module(de);rows=[]
for rise in [0.,.05]:
 v=np.array([[0,0,-1],[4,rise,-1],[4,rise,1],[0,0,1]],np.float32);t=np.array([[0,3,2],[0,2,1]],np.int32);a=[.5,rise*.5/4,0];b=[3.5,rise*3.5/4,0]
 for climb in [0.,.025]:
  cfg=de.Config(radius=.225,height=1.75,cell_size=.025,cell_height=.025,max_climb=climb,max_slope=5.)
  try:
   with de.Engine(v,t,cfg,mode='known-provided-map')as e:r=dataclasses.asdict(e.route(a,b));err=None
  except Exception as ex:r=None;err=str(ex)
  rows.append({'continuousSurface':'flat control'if rise==0 else'authored continuous shallow ramp','width':2.,'length':4.,'rise':rise,'slopeDegrees':float(np.rad2deg(np.arctan2(rise,4))),'physicalDiscontinuousStepPresent':False,'sourceVertices':v.tolist(),'sourceTriangles':t.tolist(),'requestedStart':a,'requestedGoal':b,'config':dataclasses.asdict(cfg),'native':r,'buildError':err})
for p,h in f['files'].items():assert hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==h
out={'scope':'synthetic raster quantization regression, not source sensor validation or real step permission','rows':rows,'roomInputsUsed':False,'sourceMapEdited':False,'physicalAuthority':False,'CPUSeconds':resource.getrusage(resource.RUSAGE_SELF).ru_utime+resource.getrusage(resource.RUSAGE_SELF).ru_stime}
(HERE/'RESULT.json').write_text(json.dumps(out,indent=2));print([(r['rise'],r['config']['max_climb'],r['native']['complete']if r['native']else r['buildError'])for r in rows])
