# Fixed reverse VARPU proposals

All six queries pass native completeness and the existing10cm horizontal association gate under the same registered Polycam15°/.025m setting: three body profiles ×two explicitly distinguished return starts. Nominal45cm exact original physical inside160→outside130 is4.73632m; exact accepted entryrank0target→outside130 is4.848912m.

The original floor-height physical anchor160 was transformed from original level coordinates, not replaced by corrected camera height/position. Both definitions, all exact requested/projectedXYZ and native corners are retained. Frozen before independent movement outcomes. No reference/scorer/controller here; native circles do not validate full body. An entry-and-return execution must use actual actor state and validated connection, never teleport to either assumed start.
