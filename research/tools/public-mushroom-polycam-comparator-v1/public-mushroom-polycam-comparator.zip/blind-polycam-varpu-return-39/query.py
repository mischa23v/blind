import os
os.environ['OPENBLAS_NUM_THREADS']='1'
import resource,signal,time
resource.setrlimit(resource.RLIMIT_AS,(1<<30,1<<30));resource.setrlimit(resource.RLIMIT_CPU,(30,30));signal.alarm(60)
from pathlib import Path
import json,numpy as np,hashlib,importlib.util,sys,dataclasses
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent;START=time.monotonic();frozen=json.loads((HERE/'FROZEN.json').read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for p,h in frozen['files'].items():assert sha(ROOT/p)==h
spec=importlib.util.spec_from_file_location('polycam_return39',ROOT/'blind-split-candidate-game-03/body-margin-variants-07/native025/detour_engine.py');de=importlib.util.module_from_spec(spec);sys.modules[spec.name]=de;spec.loader.exec_module(de)
with np.load(ROOT/'blind-polycam-alignment-feasibility-36/POLYCAM_INTRINSIC_GEOMETRY.npz')as z:obj=z['verticesOBJ'];tri=z['triangles']
with np.load(ROOT/'blind-polycam-rigid-registration-37/run-01/CANDIDATE_RIGID_TRANSFORM.npz')as z:level=obj@z['rotationOBJToLevel'].T+z['translationOBJToLevel'];assert z['scale']==1
v=np.c_[level[:,0],level[:,2],-level[:,1]];rows=[]
def association(a,b):
 a=np.array(a);b=np.array(b);ok=np.isfinite(b).all();return {'horizontalMetres':float(np.linalg.norm((b-a)[[0,2]]))if ok else None,'verticalMetres':float(b[1]-a[1])if ok else None,'passesExisting10cmHorizontal':bool(ok and np.linalg.norm((b-a)[[0,2]])<=.1)}
for profile,radius in [('body45cmMargin0',.225),('body45cmMargin5cm',.275),('abstract28cmProfile',.15)]:
 cfg=de.Config(radius=radius,height=1.75,cell_size=.025,max_climb=.025,max_slope=15.)
 with de.Engine(v,tri,cfg,mode='known-provided-map')as engine:
  for task in frozen['tasks']:
   a=task['requestedStartXYZ'];b=task['requestedGoalXYZ'];r=engine.route(a,b,query_half_extents=(.2,.3,.2),max_points=256);aa=association(a,r.projected_start);bb=association(b,r.projected_goal);points=np.array(r.points);rows.append({'profile':profile,'task':task,'nativeConfig':dataclasses.asdict(cfg),'native':dataclasses.asdict(r),'startAssociation':aa,'goalAssociation':bb,'geometryProposalCompleteAndAssociated':bool(r.complete and aa['passesExisting10cmHorizontal']and bb['passesExisting10cmHorizontal']),'nativeHorizontalLength':float(np.linalg.norm(np.diff(points[:,[0,2]],axis=0),axis=1).sum())if len(points)>1 else None,'rectangleOrPhysicalClearanceValidated':False})
for p,h in frozen['files'].items():assert sha(ROOT/p)==h
out={'scope':'reverse original physical VARPU objectives under fixed Polycam15deg/2.5cm config; frozen before independent movement outcome','attempts':rows,'referenceInputsUsed':False,'movementExecuted':False,'physicalAuthority':False,'runtime':{'CPUSeconds':resource.getrusage(resource.RUSAGE_SELF).ru_utime+resource.getrusage(resource.RUSAGE_SELF).ru_stime,'peakRSSKiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'wallSeconds':time.monotonic()-START}}
def safe(x):
 if isinstance(x,float)and not np.isfinite(x):return None
 if isinstance(x,dict):return {k:safe(v)for k,v in x.items()}
 if isinstance(x,(tuple,list)):return [safe(v)for v in x]
 return x
(HERE/'RESULT.json').write_text(json.dumps(safe(out),indent=2));print(json.dumps(safe(out)))
