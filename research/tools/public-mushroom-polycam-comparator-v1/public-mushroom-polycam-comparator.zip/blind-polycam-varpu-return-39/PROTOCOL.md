# Frozen reverse VARPU native queries

Parent requested reverse inside160→outside130 before any independent physics outcome. Query BOTH: the exact original physical floor-height anchor160 mapped rigidly from originallevel to correctedlevel, and the alreadyfrozen entryrank0 target [4.625,0,.225], each to unchanged originaloutside130 physical anchor. This distinguishes an anchorquery from a returnfollowing chosenentrytarget; no camera-height actorposition or pose-correction displacement substituted.

Exact accepted rigid Polycam37 geometry and fixedS15_C25mm configuration; same3profiles, .025m voxels,1.75m nativeheight, .10m endpointassociation, no newtuning. Preserve allsix results. Nativecircles are proposals, not fullrectangle/body/contact/support/coverage proof. The oldcustommask is NOT a veto for this externalgeometrycomparison. Any continuous entryreturn must use actual actor state and validated connector, never teleport to this assumed start. No FARO/reference, physics or controller here.

Budget30CPU/60wall/1GiB/<5MiB.
