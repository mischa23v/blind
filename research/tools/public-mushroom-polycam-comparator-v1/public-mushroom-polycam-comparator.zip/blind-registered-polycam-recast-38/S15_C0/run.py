import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
import resource,signal,time
resource.setrlimit(resource.RLIMIT_AS,(1<<30,1<<30));resource.setrlimit(resource.RLIMIT_CPU,(60,60));resource.setrlimit(resource.RLIMIT_FSIZE,(20<<20,20<<20));signal.alarm(120)
from pathlib import Path
import numpy as np,json,hashlib,importlib.util,sys,dataclasses
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent.parent;OUT=HERE/'run-01';START=time.monotonic()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
frozen=json.loads((HERE/'FROZEN.json').read_text());pins=frozen['files']
def verify():
 for p,h in pins.items():
  if sha(ROOT/p)!=h:raise ValueError('changed source '+p)
 if os.statvfs(HERE).f_bavail*os.statvfs(HERE).f_frsize<(768<<20):raise ValueError('disk reserve')
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
def safe(v):
 if isinstance(v,(np.ndarray,)):return safe(v.tolist())
 if isinstance(v,np.generic):return safe(v.item())
 if isinstance(v,float)and not np.isfinite(v):return None
 if isinstance(v,dict):return {k:safe(x)for k,x in v.items()}
 if isinstance(v,(list,tuple)):return [safe(x)for x in v]
 return v
def write(p,x):p.write_text(json.dumps(safe(x),indent=2))
verify();OUT.mkdir(exist_ok=False)
mesh=ROOT/'blind-mushroom-koivu-acquisition-01/selected/room_datasets/koivu/iphone/long_capture/polycam_mesh/textured.obj'
with np.load(ROOT/'blind-polycam-alignment-feasibility-36/POLYCAM_INTRINSIC_GEOMETRY.npz')as z:obj=z['verticesOBJ'].copy();tri=np.ascontiguousarray(z['triangles'],np.int32)
registration=json.loads((ROOT/'blind-polycam-rigid-registration-37/run-01/RESULT.json').read_text());assert registration['acceptedForComparator']and registration['scale']==1.
with np.load(ROOT/'blind-polycam-rigid-registration-37/run-01/CANDIDATE_RIGID_TRANSFORM.npz')as z:Q=z['rotationOBJToLevel'];translation=z['translationOBJToLevel'];assert float(z['scale'])==1.
level=obj@Q.T+translation
META=ROOT/'blind-pose-experiments-review-17/upstream/pose-consistency/runs/koivu_floorfix/pipeline2_out.npz'
with np.load(META,allow_pickle=False)as z:R=z['R'].copy();t=z['t'].copy();lo=z['lo'].copy();res=float(z['res'])
assert abs(np.linalg.det(R)-1)<1e-8 and np.allclose(R@R.T,np.eye(3),atol=1e-8)and res==.05
phone=(level-t)@R;game=np.ascontiguousarray(np.c_[level[:,0],level[:,2],-level[:,1]],np.float32)
assert np.max(abs((level-t)@R-phone))<1e-10
# Rotation is proper: neither geometry nor triangle winding is changed.
M=np.array([[1,0,0],[0,0,1],[0,-1,0]],float);assert np.linalg.det(M)==1
norm=np.cross(game[tri[:,1]]-game[tri[:,0]],game[tri[:,2]]-game[tri[:,0]]);mag=np.linalg.norm(norm,axis=1);normalY=np.divide(norm[:,1],mag,out=np.zeros(len(mag)),where=mag>0);cent=game[tri].mean(1);floor=np.abs(cent[:,1])<.1
bounds=np.array([game.min(0),game.max(0)]);widths=np.floor((bounds[1,[0,2]]-bounds[0,[0,2]])/.025+.5).astype(int)
originalPose=json.loads((ROOT/'blind-mushroom-koivu-acquisition-01/selected/room_datasets/koivu/iphone/long_capture/transformations.json').read_text())['frames'];correctedPose=json.loads((ROOT/'blind-pose-experiments-review-17/upstream/pose-consistency/poses/koivu_floorfix_transformations.json').read_text())['frames'];poseChanges=[i for i,(a,b)in enumerate(zip(originalPose,correctedPose))if not np.array_equal(a['transform_matrix'],b['transform_matrix'])]
write(OUT/'MESH_INPUT_RECEIPT.json',{'originalMeshSHA':sha(mesh),'vertexCount':len(game),'triangleCount':len(tri),'transformedFloat32VertexBytesSHA':hashlib.sha256(game.tobytes()).hexdigest(),'triangleBytesSHA':hashlib.sha256(tri.tobytes()).hexdigest(),'gameBounds':bounds,'gridWidthDepthCells':widths,'gridCellCount':int(np.prod(widths)),'properRotationDeterminant':float(np.linalg.det(M@R)),'windingChanged':False,'floorBandTriangleCount':int(floor.sum()),'floorBandUpwardSlopeAtMost5degTriangles':int((floor&(normalY>np.cos(np.deg2rad(5)))).sum()),'floorBandDownwardTriangles':int((floor&(normalY<0)).sum()),'meshSource':'author-distributed Polycam exact original triangles, registered by frozen phone-only rigid fit37; fixed scale1; no new fusion or cleanup','correctedOccupancyPoseIndicesDifferentFromOriginalMesh':poseChanges,'poseFrameWasRelocated':False,'originalToCorrectedIsNotOneRigidPoseFix':True,'registrationTransform':registration,'polycamSourceFrameSubsetOrOptimizedPosesNotSupplied':True,'fullTSDFWeightCoverageAvailable':False})
with np.load(ROOT/'blind-pose-experiments-review-17/upstream/pose-consistency/runs/koivu_floorfix/occthres_split0.7.npz',allow_pickle=False)as z:flags={k:z[k].copy()for k in z.files}
with np.load(ROOT/'blind-measured-ray-repair-27/run-01/CANDIDATE_NATIVE_STATES.npz',allow_pickle=False)as z:joint=(z['all07'][:,:,5]==0)&(z['near07'][:,:,5]==0)
patchcells=set()
for p in sorted((ROOT/'blind-assisted-structural-comparator-31/run-01').glob('frame_*-floor*.npz')):
 with np.load(p,allow_pickle=False)as z:patchcells.update(map(tuple,z['sourceCells'].tolist()))
def coverage(path):
 if len(path)<1:return None
 path=np.array(path,float);samples=[path[0]]
 for a,b in zip(path[:-1],path[1:]):
  n=max(1,int(np.ceil(np.linalg.norm((b-a)[[0,2]])/.025)));samples.extend(a+(b-a)*(np.arange(1,n+1)/n)[:,None])
 samples=np.array(samples);q=np.floor(np.c_[samples[:,0],-samples[:,2]]/.05+1e-7).astype(int)-lo[:2];inside=np.all((q>=0)&(q<flags['walk'].shape),1);keys=np.unique(q[inside],axis=0)
 return {'scope':'diagnostic centreline columns only; NOT full rectangle/body clearance; Polycam internal optimized frame subset unknown; registered residuals separate','sampleSpacingMetres':.025,'sampleCount':len(samples),'outsideMaskSamples':int((~inside).sum()),'uniqueMaskCells':keys,'originalFlagCountsOverlapping':{k:int(v[keys[:,0],keys[:,1]].sum())for k,v in flags.items()},'measuredJointLowUnknownColumns':int(joint[keys[:,0],keys[:,1]].sum()),'manualSourceSamplePatchColumns':sum(tuple(k)in patchcells for k in keys),'manualPatchColumnsAreNotContinuousCoverage':True,'meshMissingImpliesFree':False,'full3DVolumeObservationCoverageProven':False}
def assoc(a,b):
 a=np.array(a);b=np.array(b);valid=bool(np.isfinite(b).all());d=b-a
 return {'requestedXYZ':a,'projectedXYZ':b,'finite':valid,'horizontalDisplacementMetres':float(np.linalg.norm(d[[0,2]]))if valid else None,'verticalDisplacementMetres':float(d[1])if valid else None,'withinExisting0p10mHorizontalBound':bool(valid and np.linalg.norm(d[[0,2]])<=.1),'actorSnapped':False}
base=ROOT/'blind-split-candidate-game-03/body-margin-variants-07';de=load('direct_tsdf_detour33',base/'native025/detour_engine.py');variants=load('direct_tsdf_variants33',base/'margin_variants.py');rows=[]
for profile in frozen['profiles']:
 g=variants.geometry(profile);cfg=de.Config(radius=g['nativeRadiusIntended'],height=1.75,cell_size=.025,max_climb=0.0,max_slope=15.0);buildStart=time.monotonic()
 try:engine=de.Engine(game,tri,cfg,mode='known-provided-map');buildError=None
 except Exception as e:engine=None;buildError=str(e)
 buildWall=time.monotonic()-buildStart
 try:
  for task in frozen['tasks']:
   source=json.loads((ROOT/task['path'].format(profile=profile)).read_text());oldqueries=source['legs'][task['legIndex']]['attempts'];attempts=[]
   for q in oldqueries:
    a=q['requestedStartXYZ'];b=q['requestedGoalXYZ'];r=engine.route(a,b,query_half_extents=(.20,.30,.20),max_points=256)if engine else None
    row={'requestedStartXYZ':a,'requestedGoalXYZ':b,'sourceCandidateRank':q.get('candidateRank'),'buildError':buildError,'native':dataclasses.asdict(r)if r else None,'startAssociation':assoc(a,r.projected_start)if r else None,'goalAssociation':assoc(b,r.projected_goal)if r else None,'movementExecuted':False,'physicalAuthority':False,'fullRectangleValidated':False}
    row['geometryProposalCompleteAndAssociated']=bool(r and r.complete and row['startAssociation']['withinExisting0p10mHorizontalBound']and row['goalAssociation']['withinExisting0p10mHorizontalBound']and len(r.points)>=2)
    row['providedOccupancyCoverageDiagnostic']=coverage([a,*r.points,b]if r and r.complete else(r.points if r else []))
    attempts.append(row)
   write(OUT/(task['name']+'-'+profile+'.json'),{'task':task,'profile':profile,'geometry':g,'nativeConfig':dataclasses.asdict(cfg),'queryExtentsXYZ':[.2,.3,.2],'meshWasUnmodified':True,'attempts':attempts})
   reasons={}
   for a in attempts:
    r=a['native'];reason=a['buildError']or(r['error']if r else None)or('complete'if r['complete']else'partial');reasons[reason]=reasons.get(reason,0)+1
   rows.append({'profile':profile,'task':task['name'],'queries':len(attempts),'buildWallSeconds':buildWall,'nativeComplete':sum(bool(a['native']and a['native']['complete'])for a in attempts),'geometryProposalCompleteAndAssociated':sum(a['geometryProposalCompleteAndAssociated']for a in attempts),'reasons':reasons})
   print(json.dumps(rows[-1]),flush=True)
 finally:
  if engine:engine.close()
verify();size=sum(p.stat().st_size for p in HERE.rglob('*')if p.is_file());assert size<(20<<20),'aggregate output budget'
result={'scope':'registered exact Polycam mesh native proposal '+'S15_C0'+'; no physical clearance or stepping authority','results':rows,'referenceInputsUsed':False,'newFusionOrCleanup':False,'fullRectangleValidated':False,'movementExecuted':False,'physicalAuthority':False,'sourcePinsVerifiedBeforeAfter':True,'runtime':{'cpuSeconds':resource.getrusage(resource.RUSAGE_SELF).ru_utime+resource.getrusage(resource.RUSAGE_SELF).ru_stime,'peakRSSKiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'wallSeconds':time.monotonic()-START,'artifactBytesBeforeResult':size}}
write(OUT/'RESULT.json',result);print(json.dumps(result),flush=True)
