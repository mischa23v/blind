# Frozen exact registered Polycam native geometry comparator

User explicitly asked to try moving through the released Polycam room. Registration37 passed its prespecified fixed-scale rigid comparator gates using floor/high walls and reserved33 doorway/table/backrest landmarks; pooledreservedp906.05cm is NOT precise clearance certification. Every original OBJ vertex/triangle is kept; only the accepted proper rigid transform is applied, then proper level→game rotation. No cleaning, fill, fusion, mesh scaling, texture-derived geometry, route-based alignment or physical actor snapping.

Before any native outcome, freeze the SAME four configurations used in35:5°/15° slopes×0/2.5cm climb, unchanged .025m voxels,1.75m nativeheight, three original body proposal radii, same192 original physical objective pairs each (768total). The baseline5°/0 is primary; other rows are explicit reconstruction-noise sensitivities, not permission to cross actual steps. Report every row, no tuning. Same native library and association bounds.

A complete nativecircle route is only a candidate. Independent oriented-body swept collision, support/coverage, connector and movement checks are not supplied here. Missing mesh is not free; the registered comparator does not silently replace old uncertainty. Occupancy comparisons are diagnostic only because Polycam internal pose optimization/frame subset are unavailable. Keep the original VARPUfar-inside goal distinct from doorway-only traversal. No FARO/reference planning or physical/controller execution.

Resource≤60CPU/120wall/1GiB,20MiB total,≥768MiB diskreserve. All input/registration/native/objective pins verified before and after.
