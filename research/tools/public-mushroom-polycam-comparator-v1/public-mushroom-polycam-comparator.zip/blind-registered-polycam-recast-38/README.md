# Exact registered Polycam: fixed physical route proposals

**Full native route proposals now exist on this released reconstruction.** Original OBJ18,398vertices/29,366triangles are unchanged; accepted fixed-scale rigid transform37 is the only spatial operation. Same original physical objectives, body profiles and native library. All four settings were frozen before querying; no route-driven tuning.

| Native slope / climb | South→east, native complete / association-valid | VARPU far-inside, native complete / association-valid |
|---|---|---|
|5° /0 |0 /0 for all profiles |0 /0 for all profiles|
|15° /0 |0 /0 for all profiles |0 /0 for all profiles|
|5° /2.5cm |32 /32 for each profile |45cm:31 /17;55×40cm:29 /0;28cm:32 /32|
|15° /2.5cm |32 /32 for each profile |45cm:32 /32;55×40cm:29 /21;28cm:32 /32|

Each task/profile has32 original requested goal candidates;768 queries overall. Some native-complete routes project an endpoint more than the existing10cm association allowance and are separately rejected as physical-objective proposals. In15°/2.5cm55×40VARPU,3queries are partial. Zero-climb rows are overwhelmingly partial, not complete. The task's original far-insideVARPU goal is not silently replaced by a doorway-only objective.

First original-rank0 nominal45cm south proposal:4.3852m,11nativecorners,5°/2.5cm; endpoint XY projection shifts below0.1micrometre. First original-rank0 nominal45cm VARPU proposal:4.8489m,9corners,15°/2.5cm; similarly negligible horizontal shifts. `FIRST_FIXED_PROPOSALS.json` retains exact fullXYZ, original indices, height ranges and diagnostics. Choosing the lowest original rank is not optimization against a physical scorer.

**These are proposals, not executed movement or full oriented-body clearance.** The2.5cm setting tolerates one native vertical raster step; it is not permission to step on real objects. The1.75m native height interacts with the actual mesh, but circular erosion does not certify rectangle corners, turns, connectors, or missing-volume coverage. Native floor coordinates contain raster quantization. Registration reserved landmarks have6.05cm p90 residual, not safety-margin precision.

The nominal main centerline intersects6 old blocked occupancy columns (overlapping3low1/5highObstacle); VARPU14 (8deepBelow/4low1/2highObstacle). That disagreement must be resolved by independent body/contact/support evaluation, not silently clearing old flags. Zero highUnknown centerline columns does not prove full-body observed coverage. No FARO/reference inputs entered alignment/planning, and no scorer/controller ran here.

`FACTORIAL_FROZEN.json` pins four independently frozen configurations. `RESULT.json` aggregates all outcomes. `SELF_RECOUNT.json` verifies all768 exact requested XYZ pairs, all pins, exact rawOBJ→NPZ equality, transformed native vertex/triangle hashes, determinant+1, inverse error1.2e−14m; it is self-check, not independent review. Total4.24CPU seconds. Original model/maps/failures remain unchanged. Parent owns any independent movement evaluation.
