# Phone-only fixed-scale Polycam registration

**Accepted for a geometric comparator under the frozen gates. Not a clearance certificate.** All24 yaw seeds were evaluated; no route was queried or ranked during registration. Only proper rotation+translation was fitted; scale is exactly1. The author OBJ remains unchanged.

High-wall bidirectional residual median8.37mm,p90=29.35mm,99.0%within20cm. Best90%-trimmed RMS11.07mm; best distinct competitor773.94mm. Reserved source-depth/manual-boundary landmarks were evaluated only after selecting the wall-fit transform:

| Reserved family | Points | Median distance to exact mesh |
|---|---:|---:|
| Backrests |13|26.9mm|
| Visible table end |2|47.4mm|
| Doorway nominal boundaries |18|27.7mm|

Pooledp90=60.5mm. These are same-capture excluded-fit landmarks, not independent physical truth; some boundaries are plane/ray-derived and nearest surface alone does not prove semantic correspondence. The6cm tail is too large to certify a5cm safety margin. The successful fit establishes a usable comparator transform, not that every reconstructed object is accurate or missing geometry is free.

`FROZEN.json` and `PROTOCOL.md` precede optimization and specify masks,24yaw seeds, fit iterations, residual/ambiguity/reserved acceptance thresholds. `FIT_CANDIDATES.json` records every candidate; `FIT_SURFACES.npz` records sampled triangle IDs; `RESERVED_LANDMARKS.json` retains every check and original Polycam face IDs. Exact OBJ→leveled-phone transformation is in `CANDIDATE_RIGID_TRANSFORM.npz`; column convention is `level = OBJ @ Q.T + translation`. Game coordinates are `[levelX,levelZ,-levelY]`.

53.27CPU seconds,52.86wall seconds,213,016KiB peakRSS,~1.27MB artifacts;120CPU cap enforced. No FARO, reference registration, scaling, surface cleanup, geometry completion, pose correction or movement. Source data CC BY4.0 MuSHRoom, exact attribution in original acquisition packet. The original unaligned model and stage36 remain intact. Stage38 separately freezes native paths on these exact transformed triangles.
