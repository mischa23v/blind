import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
import resource,signal,time
resource.setrlimit(resource.RLIMIT_AS,(1<<30,1<<30));resource.setrlimit(resource.RLIMIT_CPU,(120,120));resource.setrlimit(resource.RLIMIT_FSIZE,(20<<20,20<<20));signal.alarm(180)
from pathlib import Path
import numpy as np,json,hashlib
from scipy.spatial import cKDTree
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent;OUT=HERE/'run-01';START=time.monotonic();rng=np.random.default_rng(37001)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
frozen=json.loads((HERE/'FROZEN.json').read_text())
def verify():
 for p,h in frozen['files'].items():assert sha(ROOT/p)==h,p
 assert os.statvfs(HERE).f_bavail*os.statvfs(HERE).f_frsize>768*(1<<20)
def safe(x):
 if isinstance(x,np.ndarray):return x.tolist()
 if isinstance(x,np.generic):return x.item()
 raise TypeError(type(x))
def write(p,x):p.write_text(json.dumps(x,default=safe,indent=2))
verify();OUT.mkdir(exist_ok=False)
with np.load(ROOT/'blind-polycam-alignment-feasibility-36/POLYCAM_INTRINSIC_GEOMETRY.npz')as z:sv=z['verticesOBJ'];sf=z['triangles']
with (ROOT/'blind-open3d-author-baseline-10/koivu/unfiltered-tsdf-mesh.ply').open('rb')as f:
 while f.readline()!=b'end_header\n':pass
 tv=np.fromfile(f,np.dtype([('xyz','<f8',(3,)),('rgb','u1',(3,))]),242293)['xyz'].copy();tf=np.fromfile(f,np.dtype([('n','u1'),('v','<u4',(3,))]),461256)['v'].copy()
with np.load(ROOT/'blind-pose-experiments-review-17/upstream/pose-consistency/runs/koivu_floorfix/pipeline2_out.npz')as z:tv=tv@z['R'].T+z['t']
def features(v,f):
 tri=v[f];n=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]);a=np.linalg.norm(n,axis=1)/2;return tri.mean(1),n/np.maximum(a[:,None]*2,1e-30),a
sc,sn,sa=features(sv,sf);tc,tn,ta=features(tv,tf)
def plane(c,n,a,axis,mask):
 keep=mask&(abs(n[:,axis])>.98)&(a>1e-8);p=c[keep];w=a[keep];ids=np.where(keep)[0];use=np.ones(len(p),bool)
 for iteration in range(5):
  mean=np.average(p[use],axis=0,weights=w[use]);x=p[use]-mean;cov=(x*w[use,None]).T@x/w[use].sum();normal=np.linalg.eigh(cov)[1][:,0]
  if normal[axis]<0:normal=-normal
  offset=float(mean@normal);dist=abs(p@normal-offset);use=dist<=min(.03,float(np.quantile(dist,.85)))
 assert use.sum()>100 and w[use].sum()>5
 return normal,offset,{'triangleIDs':ids[use],'area':float(w[use].sum()),'pointCount':int(use.sum()),'normal':normal,'offset':offset,'residualP95':float(np.quantile(abs(p[use]@normal-offset),.95))}
# Fit excludes all reserved doorway spatial region; furniture landmarks are outside floor/high-wall height bands.
def excluded_level(p):return (p[:,0]>=1.4)&(p[:,0]<=3.3)&(p[:,1]>=-3.)&(p[:,1]<=.3)
ns,ds,ps=plane(sc,sn,sa,1,(sc[:,1]>=-1.5)&(sc[:,1]<=-1.25))
nt,dt,pt=plane(tc,tn,ta,2,(tc[:,2]>=-.08)&(tc[:,2]<=.08)&~excluded_level(tc))
def align(a,b):
 v=np.cross(a,b);c=float(a@b);s=np.linalg.norm(v);K=np.array([[0,-v[2],v[1]],[v[2],0,-v[0]],[-v[1],v[0],0]])
 return np.eye(3)+K+K@K*((1-c)/(s*s)) if s>1e-12 else np.eye(3)
Q0=align(ns,nt);shift=nt*(dt-ds);assert abs(np.linalg.det(Q0)-1)<1e-8
b0=np.array([1.,0,0]);b0-=nt*(b0@nt);b0/=np.linalg.norm(b0);b1=np.cross(nt,b0);B=np.column_stack((b0,b1,nt));assert np.linalg.det(B)>.999999
slev=sv@Q0.T+shift;scent=sc@Q0.T+shift;snlev=sn@Q0.T
# Uniform area sampling, deterministic fixed seed; selected points themselves must lie in high-wall band.
def sample(v,f,c,n,a,normal,offset,exclude=False):
 height=c@normal-offset;mask=(height>=1.65)&(height<=2.45)&(abs(n@normal)<np.sin(np.deg2rad(10)))&(a>1e-8)
 ids=np.where(mask)[0];chosen=rng.choice(ids,size=60000,replace=True,p=a[ids]/a[ids].sum());uv=rng.random((len(chosen),2));uv=np.where((uv.sum(1)>1)[:,None],1-uv,uv);tri=v[f[chosen]];p=tri[:,0]+(tri[:,1]-tri[:,0])*uv[:,0,None]+(tri[:,2]-tri[:,0])*uv[:,1,None];norm=n[chosen];h=p@normal-offset;good=(h>=1.75)&(h<=2.35)
 if exclude:good&=~excluded_level(p)
 sel=np.where(good)[0];sel=sel[np.linspace(0,len(sel)-1,min(12000,len(sel))).astype(int)];assert len(sel)>1000
 return p[sel],norm[sel],chosen[sel]
sp,snorm,sids=sample(slev,sf,scent,snlev,sa,nt,dt);tp,tnorm,tids=sample(tv,tf,tc,tn,ta,nt,dt,True)
S=(sp@B)[:,:2];T=(tp@B)[:,:2];SN=(snorm@B)[:,:2];TN=(tnorm@B)[:,:2];tree=cKDTree(T)
np.savez_compressed(OUT/'FIT_SURFACES.npz',sourceOBJTriangleIDs=sids,sourcePreYawLevelXYZ=sp,targetTSDFTriangleIDs=tids,targetLevelXYZ=tp,sourceFloorTriangleIDs=ps['triangleIDs'],targetFloorTriangleIDs=pt['triangleIDs'])
def rot(th):return np.array([[np.cos(th),-np.sin(th)],[np.sin(th),np.cos(th)]])
def current_good(P):
 floor=np.c_[P,np.full(len(P),dt)];world=floor@B.T;return ~excluded_level(world)
def rms90(d):return float(np.sqrt(np.mean(np.sort(d)[:max(1,int(len(d)*.9))]**2)))
rows=[]
for seed in frozen['yawDegrees']:
 A=rot(np.deg2rad(seed));tr=np.median(T,axis=0)-np.median(S@A.T,axis=0)
 # Fixed15 point-to-point iterations for coarse capture; no scaling/reflections.
 for it in range(15):
  P=S@A.T+tr;d,idx=tree.query(P,workers=1);keep=current_good(P)&(d<=min(2.,float(np.quantile(d,.8))))
  if keep.sum()<100:break
  x=P[keep];y=T[idx[keep]];xm=x.mean(0);ym=y.mean(0);U,_,Vt=np.linalg.svd((x-xm).T@(y-ym));J=np.eye(2);J[-1,-1]=np.linalg.det(Vt.T@U.T);D=Vt.T@J@U.T;delta=ym-xm@D.T;A=D@A;tr=tr@D.T+delta
 # Fixed25 robust point-to-line iterations. Source/target normal agreement prevents perpendicular-wall pairing.
 for it in range(25):
  P=S@A.T+tr;d,idx=tree.query(P,workers=1);N=TN[idx];norms=SN@A.T;agreement=abs(np.einsum('ij,ij->i',N,norms))
  keep=current_good(P)&(d<=min(.4,float(np.quantile(d,.85))))&(agreement>=np.cos(np.deg2rad(20)))
  if keep.sum()<100:break
  x=P[keep];n=N[keep];y=T[idx[keep]];H=np.c_[np.sum(n*np.c_[-x[:,1],x[:,0]],1),n];err=np.sum(n*(x-y),1);step=np.linalg.lstsq(H,-err,rcond=None)[0];step[0]=np.clip(step[0],-.05,.05);step[1:]=np.clip(step[1:],-.15,.15);D=rot(step[0]);A=D@A;tr=tr@D.T+step[1:]
 P=S@A.T+tr;keep=current_good(P);d,_=tree.query(P[keep],workers=1);rev,_=cKDTree(P[keep]).query(T,workers=1);dist=np.r_[d,rev];yaw=float(np.rad2deg(np.arctan2(A[1,0],A[0,0]))%360)
 rows.append({'seedYawDegrees':seed,'yawDegrees':yaw,'rotation2D':A,'translation2D':tr,'trimmed90RMS':rms90(dist),'bidirectionalMedian':float(np.median(dist)),'bidirectionalP90':float(np.quantile(dist,.9)),'fractionWithin20cm':float(np.mean(dist<=.2)),'sourceFitCountAfterExclusion':int(keep.sum())})
 print(seed,rows[-1]['trimmed90RMS'],yaw,flush=True)
rows.sort(key=lambda r:r['trimmed90RMS']);best=rows[0]
def angle_diff(a,b):return abs((a-b+180)%360-180)
competitors=[r for r in rows[1:]if angle_diff(r['yawDegrees'],best['yawDegrees'])>5 or np.linalg.norm(r['translation2D']-best['translation2D'])>.15]
second=competitors[0]if competitors else None
ambiguity=(second is None)or(second['trimmed90RMS']>=best['trimmed90RMS']+.03 and second['trimmed90RMS']>=1.25*best['trimmed90RMS'])
G=np.eye(3);G[:2,:2]=best['rotation2D'];translation=np.r_[best['translation2D'],0.];Q=B@G@B.T@Q0;trans=B@(G@(B.T@shift)+translation);aligned=sv@Q.T+trans
assert abs(np.linalg.det(Q)-1)<1e-8 and np.max(abs(Q@Q.T-np.eye(3)))<1e-8
write(OUT/'FIT_CANDIDATES.json',{'floorSource':ps,'floorTarget':pt,'fitCandidatesRankedWithoutReservedLandmarks':rows,'selectedByWallResidualOnly':best,'distinctRunnerUp':second,'ambiguityCheck':ambiguity})
# Reserved geometry evaluation happens only AFTER one fit candidate is selected.
import vtk
from vtk.util.numpy_support import numpy_to_vtk,numpy_to_vtkIdTypeArray
points=vtk.vtkPoints();points.SetData(numpy_to_vtk(aligned,deep=True));cells=vtk.vtkCellArray();cells.SetCells(len(sf),numpy_to_vtkIdTypeArray(np.c_[np.full(len(sf),3),sf].ravel().astype(np.int64),deep=True));poly=vtk.vtkPolyData();poly.SetPoints(points);poly.SetPolys(cells);loc=vtk.vtkStaticCellLocator();loc.SetDataSet(poly);loc.BuildLocator()
furniture=json.loads((ROOT/'blind-furniture-gap-measurement-32/MEASUREMENTS.json').read_text());door=json.loads((ROOT/'blind-varpu-doorway-width-diagnostic-26/WIDTH_MEASUREMENTS.json').read_text());landmarks=[]
for row in furniture['backrestMeasurements']:
 for k,p in enumerate(row['boundaryLevelXYZ']):landmarks.append({'family':'backrest','name':row['name']+':'+str(k),'sourceFrame':row['plane']['frameID'],'point':p})
for k,p in enumerate(furniture['mainTableVisibleEnd']['visibleEndBoundaryLevelXYZ']):landmarks.append({'family':'tableEnd','name':'visibleTableEnd:'+str(k),'sourceFrame':furniture['mainTableVisibleEnd']['sourceFrame'],'point':p})
for row in door['results']:
 for fit in row['fits']:
  if abs(fit['residualThresholdMetres']-.02)>1e-9:continue
  for line in fit['measurements']:
   for k,p in enumerate(line['nominalLevelEndpoints']):landmarks.append({'family':'doorway','name':row['frameID']+':v'+str(line['rowV'])+':'+str(k),'sourceFrame':row['frameID'],'point':p,'caveat':'plane-projected nominal boundary, not certified physical jamb'})
for l in landmarks:
 q=[0.,0.,0.];cid=vtk.reference(0);sub=vtk.reference(0);dist=vtk.reference(0.);loc.FindClosestPoint(l['point'],q,cid,sub,dist);l.update(distanceToMeshMetres=float(dist)**.5,closestMeshLevelXYZ=q,originalPolycamTriangleID=int(cid))
families={k:[r['distanceToMeshMetres']for r in landmarks if r['family']==k]for k in ['backrest','tableEnd','doorway']};metrics={k:{'count':len(v),'median':float(np.median(v)),'p90':float(np.quantile(v,.9)),'max':float(np.max(v))}for k,v in families.items()};pooled=[r['distanceToMeshMetres']for r in landmarks];reservedGood=all(r['median']<=.08 for r in metrics.values())and np.quantile(pooled,.9)<=.15
fitGood=best['bidirectionalMedian']<=.05 and best['bidirectionalP90']<=.12 and best['fractionWithin20cm']>=.8
# Pair-length diagnostics do not estimate/apply a scale.
pairs=[]
for family in families:
 group=[r for r in landmarks if r['family']==family]
 for a,b in zip(group[::2],group[1::2]):
  source=np.linalg.norm(np.array(a['point'])-b['point']);recon=np.linalg.norm(np.array(a['closestMeshLevelXYZ'])-b['closestMeshLevelXYZ']);pairs.append({'family':family,'names':[a['name'],b['name']],'sourceDistance':float(source),'closestMeshDistance':float(recon),'scaleEstimatedOrApplied':False})
write(OUT/'RESERVED_LANDMARKS.json',{'excludedFromFit':True,'notIndependentCaptureTruth':True,'points':landmarks,'families':metrics,'pooledP90':float(np.quantile(pooled,.9)),'passesFrozenGate':bool(reservedGood),'pairDistanceDiagnostics':pairs,'nearestSurfaceDoesNotEstablishSemanticCorrespondence':True})
np.savez_compressed(OUT/'CANDIDATE_RIGID_TRANSFORM.npz',rotationOBJToLevel=Q,translationOBJToLevel=trans,scale=np.array(1.))
verify();size=sum(p.stat().st_size for p in HERE.rglob('*')if p.is_file());assert size<20*(1<<20)
out={'scope':'fixed-scale phone-only Polycam rigid registration; no reference or route-based fit','acceptedForComparator':bool(fitGood and ambiguity and reservedGood),'gates':{'fitResidual':bool(fitGood),'distinctHypothesisSeparation':bool(ambiguity),'reservedLandmarkResidual':bool(reservedGood)},'rotationOBJToLevel':Q,'translationOBJToLevel':trans,'scale':1.,'bestWallFit':best,'reservedFamilyResiduals':metrics,'reservedP90':float(np.quantile(pooled,.9)),'sourceOriginalMeshUnchanged':True,'physicalClearanceCertified':False,'movementExecuted':False,'referenceUsed':False,'runtime':{'CPUSeconds':resource.getrusage(resource.RUSAGE_SELF).ru_utime+resource.getrusage(resource.RUSAGE_SELF).ru_stime,'peakRSSKiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'wallSeconds':time.monotonic()-START,'bytesBeforeResult':size}}
write(OUT/'RESULT.json',out);print(json.dumps(out,default=safe),flush=True)
