from pathlib import Path
import hashlib,json,time,sys
import numpy as np
H=Path(__file__).resolve().parent;W=H.parent
import step_world as sw
motion=sw.motion;legacy=sw.legacy

def verify(expected):
 if motion.sha(H/'FROZEN.json')!=expected:raise ValueError('manifest changed')
 for p,h in json.loads((H/'FROZEN.json').read_text())['files'].items():
  if motion.sha(W/p)!=h:raise ValueError('source changed: '+p)
def main(expected):
 verify(expected);out=H/json.loads((H/'FROZEN.json').read_text())['outputDirectory']/'result';out.mkdir(exist_ok=False);start=time.monotonic();plan=legacy.load_plan();runtime=motion.serial_vtk();surface,mesh_info,reader=motion.load_surface()
 with np.load(legacy.GAME/'inputs/koivu_5cm_v2_pipeline2_out.npz')as z:meta={'R':z['R'],'t':z['t']}
 A=np.array(json.loads((W/'blind-koivu-faro-acquisition-04/selected-reference/icp_iphone.json').read_text())['gt_transformation']);T=motion.transform(meta,A)
 base=legacy.OrientedReferenceContainer(surface,T,legacy.BodyGeometry(width=.45,depth=.30,height=1.6,horizontal_margin=0.))
 floors=json.loads((H/'floor-gate-01/RESULT.json').read_text());typing=json.loads((H/'complete-manual-sill/TYPED_SILL_DEFINITION.json').read_text());validation=json.loads((H/'complete-manual-sill/VALIDATION.json').read_text());assert validation['status']=='PASS_COMPLETE_CROSS_SECTION_MANUAL_ASSISTANCE_ONLY';assert validation['npzSHA256']==motion.sha(H/'complete-manual-sill/TYPED_SILL_FACE_IDS.npz');assert floors['status']=='twoIndependentFloorComponentsReady'
 assert hashlib.sha256(T.tobytes()).hexdigest()==floors['redGround']['referenceTransformSHA256']==floors['grayGround']['referenceTransformSHA256']
 with np.load(H/'floor-gate-01/FROZEN_FLOOR_MEMBERSHIP.npz')as z:red=z['redGroundIDs'].copy();gray=z['grayGroundIDs'].copy()
 with np.load(H/'complete-manual-sill/TYPED_SILL_FACE_IDS.npz')as z:top=z['topReferenceCellIDs'].copy();risers=z['transitionReferenceCellIDs'].copy();ramps=z['rampSupportReferenceCellIDs'].copy();steep=z['steepRiserReferenceCellIDs'].copy()
 for ids in(red,gray,top,risers,ramps,steep):
  assert ids.ndim==1 and len(ids)>0 and np.all(np.diff(ids)>0) and ids.min()>=0 and ids.max()<mesh_info['triangles'];ids.setflags(write=False)
 assert not len(np.setdiff1d(ramps,risers)) and not len(np.intersect1d(ramps,steep)) and np.array_equal(np.union1d(ramps,steep),risers)
 assert not len(np.intersect1d(red,gray)) and not len(np.intersect1d(np.union1d(red,gray),np.union1d(top,risers)))
 prior=json.loads((legacy.GAME/'camera-approach-executor-14/run-01/result/SUMMARY.json').read_text())['sharedGround'];rp=prior['planeCoefficientsYEqualsAXPlusBZPlusC'];gp=floors['grayGround']['planeCoefficientsYEqualsAXPlusBZPlusC']
 world=sw.AssistedWorld(base,red,gray,top,risers,rp,gp,ramps=ramps)
 result=sw.episode(plan,world,out)
 result.update(sourcePlanSHA256=legacy.PLAN_SHA,sourcePlanPath=str(legacy.PLAN.relative_to(W)),sourceSelectionUsesReference=False,physicsFrame='original supplied gameXYZ',floorMembership={'redCells':len(red),'grayCells':len(gray),'redActivePlane':rp,'grayActivePlane':gp,'redActivePlaneUnchangedFrom40':True,'grayPlaneNewIndependentPreflightFit':True,'sourceFileSHA256':motion.sha(H/'floor-gate-01/FROZEN_FLOOR_MEMBERSHIP.npz')},manualSillAnnotation={'topFaces':len(top),'transitionFaces':len(risers),'sourceFileSHA256':motion.sha(H/'complete-manual-sill/TYPED_SILL_FACE_IDS.npz'),'partialRegion':False,'completeCrossSectionWithinManuallyBoundedWidth':True,'fullDoorwayWidthClaimed':False,'grayFacingDescentTyped':True,'rampSupportFaces':len(ramps),'steepNonSupportRiserFaces':len(steep),'sourceOnlyPerception':False,'referenceWorldManualAssistance':True,'fullBodyColliderExemption':False,'extraUnderbodyExemptionOnly':True},referenceMesh=mesh_info,runtime=runtime,wallSeconds=time.monotonic()-start,firstFailureTerminates=True)
 verify(expected);motion.dump(out/'RESULT.json',result);print(json.dumps({'phase':'terminal','status':result['status'],'arrival':result['arrival'],'entryArrival':result['entryArrival'],'returnArrival':result['returnArrival'],'distance':result['actualDistanceMetres'],'bodyContacts':result['actualBodyContactEvents'],'underbodyContacts':result['nonSillUnderbodyContactEvents']}),flush=True)
if __name__=='__main__':main(sys.argv[1])
