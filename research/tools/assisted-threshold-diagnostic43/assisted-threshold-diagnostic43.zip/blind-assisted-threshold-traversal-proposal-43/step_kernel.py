"""Explicit assisted UP/SIDE/DOWN macro, source-inspired; not native PhysX/Jolt.
No scene queries here. Caller supplies frozen typing/support and immutable-world
collision callbacks. Full macro validates before any actor state is committed.
"""
from dataclasses import dataclass
import math
import numpy as np
STEP_CAP=.025
TICK_3D_CAP=.025
YAW_CAP=math.radians(1)
STEP_TRIGGER=.002
@dataclass(frozen=True)
class Phase:
 start: tuple
 end: tuple
 start_yaw: float
 yaw_delta: float
 kind: str
 source_tick: int
 @property
 def length(self):return float(np.linalg.norm(np.asarray(self.end)-self.start))
class StepRejected(RuntimeError):
 def __init__(self,reason,details=None):super().__init__(reason);self.reason=reason;self.details=details

def build_macro(state,proposed,yaw,dyaw,support_mid,support_end,source_tick,current_sill=False):
 a=np.asarray(state,float);b=np.asarray(proposed,float).copy()
 if a.shape!=(3,)or b.shape!=(3,)or not np.isfinite([*a,*b,yaw,dyaw]).all():raise StepRejected('invalid_state')
 if abs(dyaw)>YAW_CAP+1e-10 or np.linalg.norm((b-a)[[0,2]])>.025000001:raise StepRejected('horizontal_or_yaw_cap')
 for name,q in [('mid',support_mid),('end',support_end)]:
  if not q['accepted']or q['hitCount']!=9 or q['missingCount']!=0:raise StepRejected('unknown_'+name+'_support',q)
 b[1]=support_end['footHeight'];delta=b[1]-a[1]
 required_rise=max(support_mid['footHeight'],support_end['footHeight'])-a[1]
 if abs(delta)>STEP_CAP+1e-10 or required_rise>STEP_CAP+1e-10:raise StepRejected('structural_rise_or_drop_exceeds25mm',{'deltaY':delta,'requiredRise':required_rise})
 typed=bool(current_sill or support_mid['typedSill']or support_end['typedSill'])
 transition=bool(abs(delta)>STEP_TRIGGER or required_rise>STEP_TRIGGER)
 if transition and not typed:raise StepRejected('untyped_vertical_transition',{'deltaY':delta})
 way=[];last=a.copy();ly=float(yaw)
 if transition and required_rise>STEP_TRIGGER:
  up=a.copy();up[1]+=STEP_CAP;way.append((up,ly,'UP'))
  side=b.copy();side[1]=up[1];way.append((side,ly+dyaw,'SIDE'))
  if abs(b[1]-side[1])>1e-12:way.append((b,ly+dyaw,'DOWN'))
 elif transition:
  side=b.copy();side[1]=a[1];way.extend([(side,ly+dyaw,'SIDE'),(b,ly+dyaw,'DOWN')])
 else:way.append((b,ly+dyaw,'FOLLOW'))
 phases=[]
 for end,ey,kind in way:
  length=float(np.linalg.norm(end-last));n=max(1,int(math.ceil(length/TICK_3D_CAP-1e-12)),int(math.ceil(abs(ey-ly)/YAW_CAP-1e-12)))
  first=last.copy();fy=ly
  for i in range(n):
   x=first+(end-first)*((i+1)/n);ny=fy+(ey-fy)*((i+1)/n)
   ph=Phase(tuple(last),tuple(x),ly,ny-ly,kind,int(source_tick))
   if ph.length>TICK_3D_CAP+1e-10 or abs(ph.yaw_delta)>YAW_CAP+1e-10:raise StepRejected('phase_cap')
   if ph.length>1e-12 or abs(ph.yaw_delta)>1e-12:phases.append(ph)
   last=x;ly=ny
 return phases,{'typedStructuralTransition':transition,'typedSillInSupport':typed,'verticalRiseMetres':delta,'maximumRequiredRiseMetres':required_rise,'phaseCount':len(phases),'sourceTick':source_tick,'macroPathLengthMetres':sum(x.length for x in phases),'originalHorizontalEndpoint':b[[0,2]].tolist(),'footHeight':b[1]}

def validate_macro(phases,body_collision,underbody_collision):
 receipts=[]
 for phase in phases:
  body=body_collision(phase);receipts.append({'phase':phase.kind,'body':body})
  if body.get('contact'):raise StepRejected('body_or_head_or_side_collision',{'phase':phase.kind,'collision':body,'receipts':receipts})
  under=underbody_collision(phase);receipts[-1]['underbody']=under
  if under.get('contact'):raise StepRejected('non_sill_underbody_collision',{'phase':phase.kind,'collision':under,'receipts':receipts})
 return receipts
