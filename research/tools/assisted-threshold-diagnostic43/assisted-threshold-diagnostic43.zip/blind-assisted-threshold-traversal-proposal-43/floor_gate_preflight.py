"""No motion: predeclared red/gray source anchors and unchanged floor classifier."""
from pathlib import Path
import os,resource,signal,time,json,importlib.util,sys,math,hashlib
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
resource.setrlimit(resource.RLIMIT_AS,(int(3.5*1024**3),int(3.5*1024**3)));resource.setrlimit(resource.RLIMIT_CPU,(180,180));signal.alarm(240)
import numpy as np
H=Path(__file__).resolve().parent;W=H.parent;S=W/'blind-polycam-varpu-executor-40';START=time.monotonic()
sys.path.insert(0,str(S))
s=importlib.util.spec_from_file_location('fixed40_driver_for43_floor_gate',S/'run_north.py');d=importlib.util.module_from_spec(s);sys.modules[s.name]=d;s.loader.exec_module(d)
p=d.load_plan();paths=[np.asarray(p['originalFramePath']),np.asarray(p['returnOriginalFramePath'])]
# Floor anchors are original source-camera floor projections, never reached actor positions.
gray=np.asarray(p['goal']);path=np.asarray(p['originalFramePath']);delta=next(path[i]-path[i-1]for i in range(len(path)-1,0,-1)if np.linalg.norm((path[i]-path[i-1])[[0,2]])>.01);gyaw=math.atan2(delta[2],delta[0]);red=json.loads((S/'preflight-01/PREFLIGHT.json').read_text())
config={'scope':'Assisted floor-support association gate only; no movement or horizontal path selection','sourcePlanSHA256':hashlib.sha256((S/'SELECTED_PLAN.json').read_bytes()).hexdigest(),'redSeedIDs':red['seedIDs'],'redSeedPoints':red['seedPoints'],'grayAnchorOriginalGameXYZ':gray.tolist(),'grayYawRadians':gyaw,'grayAnchorSource':'original frame00175/pose160 floor anchor already frozen in24; not an actual reached pose','bounds':red['gameBounds'],'classification':'exact stage40 unchanged 5deg training/2mm local recovery/45deg raw guard with two separately fixed seed sets','grayPlanePolicy':'own seeded component broad plane, not active until separately frozen/reviewed executor','motionExecuted':False}
(H/'FLOOR_GATE_CONFIG.json').write_text(json.dumps(config,indent=2)+'\n')
out=H/'floor-gate-01';out.mkdir(exist_ok=False);motion=d.motion;motion.serial_vtk();surface,info,reader=motion.load_surface()
with np.load(d.GAME/'inputs/koivu_5cm_v2_pipeline2_out.npz',allow_pickle=False)as z:meta={'R':z['R'],'t':z['t']}
A=np.asarray(json.loads((W/'blind-koivu-faro-acquisition-04/selected-reference/icp_iphone.json').read_text())['gt_transformation']);base=d.OrientedReferenceContainer(surface,motion.transform(meta,A),d.BodyGeometry(width=.45,depth=.30,height=1.6,horizontal_margin=0.))
probe=base.support_probes(gray,gyaw);check=motion.support_check(probe);receipt={'scope':config['scope'],'configuration':config,'graySupportProbes':probe,'grayNumericSupportCheck':check,'motionExecuted':False,'physicalAuthority':False}
if not check['acceptedFiniteSupportModel']:
 receipt.update(status='grayAnchorSupportGateRejected')
else:
 grayids=[int(x['referenceCellID'])for x in probe['probes']];graypoints=[[x['modelXZ'][0],x['modelHeightY'],x['modelXZ'][1]]for x in probe['probes']];receipt.update(graySeedIDs=grayids,graySeedPoints=graypoints)
 try:
  def progress(row):print(json.dumps({'phase':'floor_candidate_count',**row}),flush=True)
  redg=d.shared_ground(base,paths,red['seedIDs'],red['seedPoints'],progress)
  grayg=d.shared_ground(base,paths,grayids,graypoints,progress)
  np.savez_compressed(out/'FROZEN_FLOOR_MEMBERSHIP.npz',redGroundIDs=redg.ground_cell_ids,grayGroundIDs=grayg.ground_cell_ids)
  receipt.update(status='twoIndependentFloorComponentsReady',redGround=redg.receipt,grayGround=grayg.receipt,redGroundCells=len(redg.ground_cell_ids),grayGroundCells=len(grayg.ground_cell_ids),intersectionCells=int(len(np.intersect1d(redg.ground_cell_ids,grayg.ground_cell_ids))),membershipSHA256=hashlib.sha256((out/'FROZEN_FLOOR_MEMBERSHIP.npz').read_bytes()).hexdigest())
 except(ValueError,RuntimeError)as e:receipt.update(status='independentFloorMembershipGateRejected',reason=str(e),details=getattr(e,'details',{}))
receipt['runtime']={'wallSeconds':time.monotonic()-START,'CPUSeconds':resource.getrusage(resource.RUSAGE_SELF).ru_utime+resource.getrusage(resource.RUSAGE_SELF).ru_stime,'peakRSSBytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024};(out/'RESULT.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:receipt[k]for k in ['status','runtime']}),flush=True)
