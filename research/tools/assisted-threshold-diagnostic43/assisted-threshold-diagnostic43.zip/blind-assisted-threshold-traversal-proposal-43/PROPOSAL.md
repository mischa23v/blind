# Proposed assisted structural-sill traversal v43 — NOT EXECUTED

## Why this is a new model, not a floor correction

Frozen stage40 failed at a real threshold-associated raised band, not missing rays or demonstrated flat carpet. Keep40 and all earlier failures unchanged. Globally raising ground residual/normal tolerances, clearing the old map, or skipping the strip while the body remains at its old foot height would be invalid: it would erase/tunnel through geometry. A new explicit locomotion/support assumption is needed.

The same exact nominal45×30×160cm zero-margin body, original start/inside/return goals, frozen Polycam S15_C25mm rank0 corners, and existing goal-stop/FIFO rules must remain. No horizontal route reselection from evaluator geometry. Source geometry remains native-proposal-only, not a fully validated source body path.

## Required source-only semantic input (pending final packet)

Original195 observed interior wood-strip polygon UV[(350,862.35),(640,904.4),(640,930.4),(350,888.35)] was selected from visible material boundaries/pre-existing source bands, excluding jamb ends. It is approximately0.724–0.763m along the strip,0.101–0.108m across. It is NOT the whole threshold footprint. Adjacent red/gray bands, upper/lower wood, and narrow ridge must retain separate measurements. Initial source evidence gives upper wood~1.8mm above red/~8.3mm above gray; interframe differences~7–9mm and evaluator/source discrepancies15–39mm remain. Therefore25mm is NOT a certified measured physical rise.

Freeze the final packet's exact source pixels, source hashes, coordinate/pose convention, visibility and uncertainty before implementation. A typed reference region may be associated by projection into this observed semantic strip plus explicitly bounded depth association; no ad-hoc dilation chosen to include the failed face. An unresolved association must reject, not grow the region. The depth-association bound is currently **not established**. If the parent instead authorizes an explicitly manually associated evaluator structural strip, label that extra assistance separately; do not call it phone-only automatic recognition.

## Proposed scope and geometry constraints

1. Keep original ground membership, active plane and all non-sill geometry unchanged. Add a separate `observedStructuralSill` type, not a blanket ground relabel.
2. Only geometry wholly associated with the observed strip and a coherent transverse structural band can receive the type. All complete original faces remain available; no geometry is flattened, translated, removed or capped to fit.
3. Freeze a25mm maximum structural rise as an **assumed kinematic capability**, motivated by the already-declared source-native climb25mm, not an inferred child/human capability or certified source height. Measure rise relative to adjacent observed/reference floor support, not just arbitrary modelY.
4. Coherence/extent gates must reject isolated small objects, elevated loose blocks, a short bump on the strip, and side/jamb/door-leaf geometry. A fixed long structural strip observed in imagery is the only proposed exception. Top surfaces may use the unchanged2mm local planar residual per coherent stratum; multiple observed strata stay explicit. Protrusions, unobserved depth layers, and geometry extending above the25mm bound remain obstacles.
5. Source association and geometry typing must be frozen before the new episode; no expansion from later failure or successful-path feedback. Any unresolved boundary/object identity yields unknown/stop. The source interior polygon must not be promoted to full doorway width or complete support.

## Vertical transition semantics: two honest implementation choices

### A. Typed-height follower (smaller change, limited capability)

The existing world already computes actorY from support; thus an explicit typed-surface extension could retain the same forward/yaw command interface while changing only the vertical support law. When support transitions among old floor and the verified sill, set the whole rigid body's footY from the bounded top support envelope, retain full3D swept body tests, and use a source-region-only smaller forward command (e.g.5mm) before entering the band. The exact original25mm total3D motion-per-tick cap remains. If rise/drop plus horizontal travel exceeds it, or finite support/clearance fails, stop. No clipping/relocation of XZ and no invented ramp. Mixed-height support limits would be explicitly local to the typed structural transition, not raised globally.

This is NOT a leg/foot gait model. Raising one rigid upright box on a high corner leaves other bottom corners above lower ground. It is a declared kinematic structural-step abstraction; finite probe support is not continuous contact or a human-safety result. Merely replacing oldplaneY with a newplaneY without collision testing the vertical transition is forbidden.

### B. Explicit up/forward/down character-step state machine (stronger behavioral change)

Use bounded swept upward clearance, fixed requested horizontal displacement, then downward/landing support tests; keep exact original geometry and same body. Every actual subsegment and time/state transition must be recorded; total3D travel≤25mm/tick; vertical phases may consume additional ticks while horizontal progress waits. Do not use set-position/teleport or reset the actor. Head/side contacts, unknown landing support, edge fall, rise>25mm, or unrelated low objects terminate. Do not silently assume the original actuator already had this capability: it is a new declared simulation behavior requiring parent authorization and independent fixture review.

A foot/underbody guard must continue checking non-floor/non-sill geometry below a temporarily raised body, so lifting the box does not magically make arbitrary small objects disappear. Only the explicitly typed structural sill can be crossed as support. The scope is ordinary assisted doorway transition, not proof that loose objects are safe.

## Required authored fixtures before any movement rerun

- Identical flat floor: original and new behavior/trace match outside the typed region.
- Tagged continuous structural strip at0,5,15,25mm: expected bounded support/transition behavior;26mm and higher reject.
- Same geometry untagged: retains baseline stop. Small loose block both inside/outside region remains obstacle; connected raised protrusion remains obstacle; tiny gaps/unobserved support reject.
- Door jamb, table/coatstand base, side wall, ceiling during lift, and overhead obstruction all retain full-body collisions.
- Unknown/missing first-hit probe, mixed front/back depth layer, depth-association failure, ROI end or unobserved material rejects rather than inferred support.
- Full45×30×160 body and zero margin unchanged; no disc substitution; rotation sweeps retained.
- Up/down transition cannot tunnel through a thin face; Y changes recorded; XZ never snaps/clips to a different route; total3D25mm/tick and yaw1° caps enforced.
- Source-region speed control uses source geometry only, never evaluator collision outcomes.
- Original full3D35cm arrival, zero motion/drained queue, same-actor entry→return, frozen return connector and no pose reset retained.
- Same closed exterior door/beyond-scan prohibition and all low/blocked phone exposures remain.

## Resources and stopping condition

No run has occurred. Source association/depth bound and choiceA/B remain decisions, not silently selected. Any implemented variant needs a fresh source manifest, fixtures and independent review. Preserve stage40 failure and publish the additional assistance/behavior change. Use the same serial≤3.5GiB/6Mface/600CPU/900wall budgets and exact same fixed horizontal path; recheck disk (currently~824MiB free,768MiB reserve), possibly smaller declared output cap rather than deleting evidence.
