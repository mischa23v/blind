# Complete manual sill cross-section, assisted simulation only

This separate pre-movement annotation extends the earlier partial4310-face image-interior annotation across the same wooden threshold to its gray-floor join. It is explicitly manual reference-world assistance, not phone-only perception or a validated sensor algorithm. Source frame195 identifies the wooden strip. Reference geometry supplies exact face identities and support connections.

## Result

- 3,146 top faces; 2,661 <=45-degree structural ramp candidates; 1,078 steep riser faces. Total6,885 manually typed original faces.
- The top is exactly edge-connected through separate transition components to both independently frozen red and gray ground components. No proximity bridging.
- Maximum tagged vertex height over the lower adjacent broad floor plane:20.582mm. The25mm kinematic cap remains an assumption, not a human capability certificate.
- All old4,310 manually tagged face IDs are retained. Their original NPZ and definition are unchanged.
- Full lateral ends/jamb margins remain unknown. The bounded interior is about75.5cm wide; this is NOT a whole-door certified clearance.

## Executor contract

Use topReferenceCellIDs for candidate landing-support identity. Use rampSupportReferenceCellIDs only under independent local normal/rise/extent checks; these are sloping surfaces, NOT a flat top plane. steepRiserReferenceCellIDs must NEVER authorize landing support. manualSillReferenceCellIDs may be exempted only from the additional underbody-loose-object guard. ALL original faces remain full-body colliders. Existing ground IDs remain unchanged. No geometry is removed, no map cells are cleared, and no horizontal route is selected or changed by this annotation.

The helper filename FIXED_IMAGE_ROI_REFERENCE_FACES.npz is retained for interface compatibility, but its contents here are a manually bounded REFERENCE-WORLD inspection envelope, not the old fixed image ROI. The frozen config and extraction receipt say this explicitly.

## Reproduction

Run extract_manual_reference_envelope.py, classify_complete_sill.py, then validate_complete_sill.py. The validation script writes sourceOverlayVisuallyInspected=false until a human/model actually views the resulting overlay. The saved validation records that completed inspection separately. No movement is performed by these scripts.

## Provenance and limits

Public MuSHRoom Koivu FARO reference mesh with previously published fixed transform, and original source195 RGB. Dataset attribution remains in the enclosing project records. This is evaluator-assisted simulator development and cannot count as autonomous phone navigation, unknown-obstacle clearance, or physical safety evidence.

## Overlay legend

Yellow: top. Orange: <=45-degree structural ramp candidates. Magenta: >45-degree steep risers (never support). Blue: pre-existing floor membership, not newly cleared space. The overlay is a qualitative object-identity check, not millimetre geometry or passage-clearance verification. See VISUAL_REVIEW.json.
