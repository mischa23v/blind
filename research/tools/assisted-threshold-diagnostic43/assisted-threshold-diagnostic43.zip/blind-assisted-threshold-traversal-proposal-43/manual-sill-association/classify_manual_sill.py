"""Explicit manual fixed-ROI evaluator association; exact face IDs, no movement."""
import os,resource,json,hashlib,time
os.environ['OPENBLAS_NUM_THREADS']='1';resource.setrlimit(resource.RLIMIT_AS,(1024**3,1024**3));resource.setrlimit(resource.RLIMIT_CPU,(120,120))
from pathlib import Path
import numpy as np
ROOT=Path('/workspace/scratch/90f3f6703064');OUT=Path(__file__).resolve().parent;start=time.monotonic();cfg=json.loads((OUT/'FROZEN_ALTERNATIVE_CONFIG.json').read_text());initial=json.loads((OUT/'FROZEN_MANUAL_SILL_CONFIG.json').read_text());ex=json.loads((OUT/'EXTRACTION_RECEIPT.json').read_text());floor=json.loads((ROOT/cfg['floorResultPath']).read_text())
with np.load(OUT/'FIXED_IMAGE_ROI_REFERENCE_FACES.npz')as z:verts=z['verticesOriginalGameXYZ'];vids=z['vertexIDs'];tri=z['localTriangles'];ids=z['referenceCellIDs'];globaltri=z['trianglesOriginalVertexIDs'];slope=z['slopeDegrees'];uv=z['vertexProjectedUV195']
q=verts[tri];cent=q.mean(1);N=len(tri);L=np.array(cfg['alongDirectionOriginalGameXZ']);L/=np.linalg.norm(L);U=np.array([L[1],-L[0]]);adj=[[]for _ in range(N)];edges={}
for i,t in enumerate(globaltri):
 for a,b in [(t[0],t[1]),(t[1],t[2]),(t[2],t[0])]:
  key=(min(int(a),int(b)),max(int(a),int(b)))
  if key in edges:
   for j in edges[key]:adj[i].append(j);adj[j].append(i)
   edges[key].append(i)
  else:edges[key]=[i]
def components(mask):
 seen=np.zeros(N,bool);out=[]
 for i in np.flatnonzero(mask):
  if seen[i]:continue
  seen[i]=True;stack=[int(i)];part=[]
  while stack:
   j=stack.pop();part.append(j)
   for k in adj[j]:
    if mask[k]and not seen[k]:seen[k]=True;stack.append(k)
  out.append(np.array(part,dtype=int))
 return out

def extent(part):
 p=verts[np.unique(tri[part])];xz=p[:,[0,2]];return {'alongExtentMetres':float(np.ptp(xz@L)),'acrossExtentMetres':float(np.ptp(xz@U)),'boundsOriginalGameXYZ':np.column_stack((p.min(0),p.max(0))).tolist(),'vertexCount':len(p)}

def fit(window):
 lo,hi=window;training=(slope<=cfg['seedNormalAtMostDegrees'])&(q[:,:,1]>=lo).all(1)&(q[:,:,1]<=hi).all(1);v=np.unique(tri[training]);hist=[]
 if len(v)<3:return None,training,{'seedWindowMetres':window,'seedFaces':int(training.sum()),'status':'FAIL_NO_TRAINING_VERTICES'}
 p=verts[v];A=np.column_stack((p[:,0],p[:,2],np.ones(len(p))));use=np.ones(len(p),bool)
 for _ in range(3):
  if use.sum()<3:return None,training,{'seedWindowMetres':window,'seedFaces':int(training.sum()),'status':'FAIL_REFIT_TOO_FEW_VERTICES'}
  co=np.linalg.lstsq(A[use],p[use,1],rcond=None)[0];err=abs(p[:,1]-A@co);use=err<=cfg['topFitMaximumVertexResidualMetres'];hist.append(int(use.sum()))
 return co,training,{'seedWindowMetres':window,'seedFaces':int(training.sum()),'seedVertices':len(v),'fixedRefitInlierCounts':hist,'planeYEqualsAXPlusBZPlusC':co.tolist(),'planeSlopeDegrees':float(np.degrees(np.arctan(np.linalg.norm(co[:2])))),'seedPlaneResidualP50P95Metres':np.quantile(abs(p[:,1]-A@co),[.5,.95]).tolist(),'status':'FIT'}
failed=[]
for win in initial['manualReferenceTopStrataSeedWindowsMetres']:
 co,tr,rec=fit(win);failed.append(rec)
(OUT/'RETAINED_TWO_STRATUM_GATE_RESULT.json').write_text(json.dumps({'scope':'Previously frozen two-stratum proposal retained; not implemented by silently inventing a9mm plane.','initialConfigFile':'FROZEN_MANUAL_SILL_CONFIG.json','strata':failed,'localPriorCropObservation':'9mm window had0 <=5deg training faces in49,918-face saved crop; same unchanged image ROI now loaded completely.','status':'FAIL_TWO_STRATUM_MODEL'if any(x['status']!='FIT'for x in failed)else'RETAINED_NOT_USED_NEW_ALTERNATIVE_EXPLICIT'},indent=2)+'\n')
co,training,fitrec=fit(cfg['manualReferenceTopStrataSeedWindowsMetres'][0]);assert co is not None;pred=co[0]*q[:,:,0]+co[1]*q[:,:,2]+co[2];resid=np.max(abs(q[:,:,1]-pred),axis=1);cand=(resid<=cfg['topFitMaximumVertexResidualMetres'])&(slope<=cfg['topRawNormalAtMostDegrees']);top=np.zeros(N,bool);comps=[]
for part in components(cand):
 info=extent(part);accept=info['alongExtentMetres']>=cfg['topConnectedComponentMinimumAlongExtentMetres']and info['acrossExtentMetres']>=cfg['topConnectedComponentMinimumAcrossExtentMetres'];comps.append({'faceCount':len(part),'accepted':bool(accept),**info});top[part]=accept
with np.load(ROOT/cfg['floorMembershipPath'])as z:redids=z['redGroundIDs'];grayids=z['grayGroundIDs']
red=np.isin(ids,redids);gray=np.isin(ids,grayids);ground=red|gray;planes=[np.array(floor[k]['broadPlaneCoefficientsYEqualsAXPlusBZPlusC'])for k in ['redGround','grayGround']];lower=np.minimum(*[p[0]*q[:,:,0]+p[1]*q[:,:,2]+p[2]for p in planes]);between=(q[:,:,1]>=lower-.002).all(1)&(q[:,:,1]<=pred+.002).all(1);riser_cand=between&~top&~ground;transition=np.zeros(N,bool);rcomps=[]
for part in components(riser_cand):
 neighbors=set(k for j in part for k in adj[j]if k not in set(part));neighbors=np.array(sorted(neighbors),dtype=int);touchTop=bool(top[neighbors].any())if len(neighbors)else False;touchRed=bool(red[neighbors].any())if len(neighbors)else False;touchGray=bool(gray[neighbors].any())if len(neighbors)else False;info=extent(part);accept=touchTop and(touchRed or touchGray)and info['alongExtentMetres']>=cfg['riserConnectedComponentMinimumAlongExtentMetres'];transition[part]=accept;rcomps.append({'faceCount':len(part),'accepted':bool(accept),'touchesTopExactEdge':touchTop,'touchesRedGroundExactEdge':touchRed,'touchesGrayGroundExactEdge':touchGray,**info})
manual=top|transition;unclassified=~manual&~ground
np.savez_compressed(OUT/'TYPED_SILL_FACE_IDS.npz',topReferenceCellIDs=ids[top],transitionReferenceCellIDs=ids[transition],manualSillReferenceCellIDs=ids[manual],unclassifiedROIReferenceCellIDs=ids[unclassified],alreadyFloorROIReferenceCellIDs=ids[ground],allROIReferenceCellIDs=ids)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();summ={'scope':'EXPLICIT MANUAL source-informed evaluator sill annotation; not phone-only perception, source geometry repair, floor relabel or horizontal route input.','status':'WHITELIST_FROZEN'if top.any()and transition.any()else'PARTIAL_WHITELIST_OR_GATE_BLOCKER','executorInterface':{'NPZ':'TYPED_SILL_FACE_IDS.npz','topReferenceCellIDs':'Exact original face IDs, usable only as additional landing support identity if independent executor gates pass.','transitionReferenceCellIDs':'Exact ramp/riser IDs; not planar landing support.','manualSillReferenceCellIDs':'Union top+transition; excluded ONLY from extra underbody hazard guard, NEVER from fullbody colliders.','unclassifiedROIReferenceCellIDs':'Remain untyped original obstacles/unknown; no expansion.'},'frozenAlternativeConfig':'FROZEN_ALTERNATIVE_CONFIG.json','topFit':fitrec,'topComponentAudit':comps,'transitionComponentAudit':rcomps,'counts':{'wholeImageROIFaces':N,'topCandidateFaces':int(cand.sum()),'topAcceptedFaces':int(top.sum()),'transitionCandidateFaces':int(riser_cand.sum()),'transitionAcceptedFaces':int(transition.sum()),'alreadyRedGroundROI':int(red.sum()),'alreadyGrayGroundROI':int(gray.sum()),'alreadyGroundROIUnion':int(ground.sum()),'unclassifiedROI':int(unclassified.sum())},'redFloorPlane':planes[0].tolist(),'grayFloorPlane':planes[1].tolist(),'topRiseAgainstMinIndependentFloorP0P50P100Metres':np.quantile((pred-lower)[top],[0,.5,1]).tolist()if top.any()else None,'allOriginalFacesRemainColliders':True,'originalGeometryChanged':False,'movementExecuted':False,'unknownBoundaries':'Whole-face image ROI boundary/jamb margins remain untyped. Original photo semantic observation does not infer missing full sill ends. Failed two-stratum proposal retained separately. Face whitelist cannot absorb future/added loose objects or unmatched original geometry.','coordinateAudit':'Original-game evaluator vertices inverted using ORIGINAL pipelineR,t before source195 camera projection. Earlier postrun source association used correctedR,t; small leveling-frame difference is not a registration fit or a region dilation.','referenceMeshSHA256':ex['meshSHA256'],'pins':{str(p.relative_to(ROOT)):sha(p)for p in [OUT/'FROZEN_ALTERNATIVE_CONFIG.json',OUT/'FROZEN_MANUAL_SILL_CONFIG.json',OUT/'FIXED_IMAGE_ROI_REFERENCE_FACES.npz',OUT/'EXTRACTION_RECEIPT.json',ROOT/cfg['floorMembershipPath'],ROOT/cfg['floorResultPath'],Path(__file__)]},'runtime':{'wallSeconds':time.monotonic()-start,'peakRSSBytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024}};(OUT/'TYPED_SILL_DEFINITION.json').write_text(json.dumps(summ,indent=2)+'\n');print(json.dumps(summ,indent=2))
