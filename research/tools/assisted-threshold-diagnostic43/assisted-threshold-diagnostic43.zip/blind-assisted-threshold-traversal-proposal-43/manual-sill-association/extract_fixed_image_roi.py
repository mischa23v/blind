"""Bounded direct-PLY extraction of unchanged manually associated source image ROI."""
import os,resource,time,json,hashlib
os.environ['OPENBLAS_NUM_THREADS']='1';resource.setrlimit(resource.RLIMIT_AS,(1024**3,1024**3));resource.setrlimit(resource.RLIMIT_CPU,(120,120))
from pathlib import Path
import numpy as np
ROOT=Path('/workspace/scratch/90f3f6703064');OUT=Path(__file__).resolve().parent;start=time.monotonic();cfg=json.loads((OUT/'FROZEN_MANUAL_SILL_CONFIG.json').read_text());mesh=ROOT/'blind-koivu-faro-acquisition-04/selected-reference/gt_mesh.ply';meta=ROOT/'blind-split-candidate-game-03/inputs/koivu_5cm_v2_pipeline2_out.npz';icp=ROOT/'blind-koivu-faro-acquisition-04/selected-reference/icp_iphone.json';pose=ROOT/'blind-mushroom-koivu-acquisition-01/selected/room_datasets/koivu/iphone/long_capture/transformations.json'
with np.load(meta)as z:R=z['R'];t=z['t']
A=np.array(json.loads(icp.read_text())['gt_transformation']);B=np.array([[1.,0,0],[0,0,-1],[0,1,0]]);M=np.eye(4);M[:3,:3]=R.T@B;M[:3,3]=-R.T@t;I=np.linalg.inv(A@M);f=next(x for x in json.loads(pose.read_text())['frames']if '00195'in x['file_path']);T=np.array(f['transform_matrix'])
N=8940320;F=17801112;within=np.zeros(N,bool);vids=[];verts=[];uvs=[];localfaces=[];faceids=[];hashmesh=hashlib.sha256()
with mesh.open('rb')as handle:
 header=b''
 while not header.endswith(b'end_header\n'):header+=handle.readline()
 assert b'element vertex 8940320\n'in header and b'element face 17801112\n'in header;hashmesh.update(header);offset=len(header)
 for st in range(0,N,65536):
  n=min(65536,N-st);raw=handle.read(n*48);hashmesh.update(raw);a=np.frombuffer(raw,'<f8').reshape(n,6)[:,:3].astype(np.float32).astype(float);q=a@I[:3,:3].T+I[:3,3];level=q[:,[0,2,1]]*np.array([1,-1,1]);phone=(level-t)@R;c=(phone-T[:3,3])@T[:3,:3];z=-c[:,2];u=c[:,0]/z*f['fl_x']+f['cx']-.5;v=-c[:,1]/z*f['fl_y']+f['cy']-.5;delta=v-(855+(u-320)*.145);keep=(z>0)&(u>=350)&(u<=640)&(delta>=3)&(delta<=29)&(q[:,1]>=-.03)&(q[:,1]<=.12);within[st:st+n]=keep;vids.extend((np.flatnonzero(keep)+st).tolist());verts.extend(q[keep].tolist());uvs.extend(np.column_stack((u[keep],v[keep])).tolist())
 dtype=np.dtype([('n','u1'),('v','<u4',(3,))]);assert handle.tell()==offset+N*48
 for st in range(0,F,65536):
  n=min(65536,F-st);raw=handle.read(n*13);hashmesh.update(raw);a=np.frombuffer(raw,dtype);assert np.all(a['n']==3);tri=a['v'];keep=np.all(within[tri],axis=1);localfaces.extend(tri[keep].tolist());faceids.extend((np.flatnonzero(keep)+st).tolist())
 assert handle.read(1)==b''
vids=np.asarray(vids);verts=np.asarray(verts);uvs=np.asarray(uvs);tri=np.asarray(localfaces);faceids=np.asarray(faceids);local=np.searchsorted(vids,tri);q=verts[local];cent=q.mean(1);normals=np.cross(q[:,1]-q[:,0],q[:,2]-q[:,0]);norm=np.linalg.norm(normals,axis=1);slope=np.degrees(np.arccos(np.clip(np.divide(abs(normals[:,1]),norm,out=np.ones(len(norm)),where=norm>0),0,1)));np.savez_compressed(OUT/'FIXED_IMAGE_ROI_REFERENCE_FACES.npz',vertexIDs=vids,verticesOriginalGameXYZ=verts,vertexProjectedUV195=uvs,referenceCellIDs=faceids,trianglesOriginalVertexIDs=tri,localTriangles=local,centroidsOriginalGameXYZ=cent,slopeDegrees=slope)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();receipt={'scope':'Manual evaluator annotation only: full unchanged source image ROI loaded, no semantic dilation/route input/movement.','vertexCount':len(verts),'faceCount':len(tri),'boundsOriginalGameXYZ':np.column_stack((verts.min(0),verts.max(0))).tolist(),'meshSHA256':hashmesh.hexdigest(),'originalGameToPhone_R':R.tolist(),'originalGameToPhone_t':t.tolist(),'FAROToOriginalGameMatrix':I.tolist(),'source195CameraToPhone':T.tolist(),'source195Intrinsics':{k:f[k]for k in ['fl_x','fl_y','cx','cy']},'sourceROIUnchanged':True,'priorCropTruncationResolvedByExtractionOnly':True,'pins':{str(p.relative_to(ROOT)):sha(p)for p in [meta,icp,pose,OUT/'FROZEN_MANUAL_SILL_CONFIG.json',Path(__file__)]},'runtime':{'wallSeconds':time.monotonic()-start,'peakRSSBytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024}};(OUT/'EXTRACTION_RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
