# Frozen manual evaluator sill annotation — stage43

**Usable interface:** `TYPED_SILL_FACE_IDS.npz`, exact ORIGINAL reference face IDs:

| Array | Count | Permitted role |
|---|---:|---|
| `topReferenceCellIDs` | 2,973 | Additional landing-support identity, only if independent executor gates pass |
| `transitionReferenceCellIDs` | 1,337 | Known red-facing structural transition, not planar landing support |
| `manualSillReferenceCellIDs` | 4,310 | Union; exclude only from the **additional underbody hazard guard** |
| `alreadyFloorROIReferenceCellIDs` | 2,731 | Existing frozen red-ground membership, unchanged |
| `unclassifiedROIReferenceCellIDs` | 0 | No unclassified face wholly inside this limited ROI |
| `allROIReferenceCellIDs` | 7,041 | Whole original triangles fully inside frozen image region |

**Every original face remains a full-body collider.** This whitelist must not clear or flatten geometry. It applies only to the exact reference mesh hash below; added/loose objects or renumbered/changed meshes cannot inherit it.

## Important incomplete boundary

The frozen source image interior includes the coherent high top and its **red-facing** transition. It contains **no gray-ground face or gray-facing descent**. Jamb margins, the outer wood/gray edge and any geometry outside the unchanged image ROI remain untyped—not silently absorbed. This is a **partial structural whitelist**, not complete step authorization or a successful crossing. Do not enlarge it in response to a later episode failure.

## Explicit assistance and frozen gates

The parent explicitly authorized **manual source-informed evaluator-world annotation**. Original195 visibly shows wood in the pre-existing source-only interior polygon. Reference geometry was used only to associate and type the real top/connecting transition, not to select the horizontal route, repair a phone map or infer new phone perception. No movement occurred.

`FROZEN_MANUAL_SILL_CONFIG.json` records the initial9/20mm proposal. In the saved49,918-face local crop, the lower window[5,13]mm had zero ≤5° training faces. That failed local-crop gate is retained in `RETAINED_TWO_STRATUM_GATE_RESULT.json`. A bounded stream then loaded the **whole unchanged source-image ROI**, revealing47 low-window training faces at the far end; their fit is retained, **not adopted as a flat9mm sill stratum**.

The parent separately authorized `FROZEN_ALTERNATIVE_CONFIG.json` **before classification**: one coherent20mm top plus transition faces connected to independently frozen red/gray floor memberships. Same image ROI,2mm residual,5° seed normals and45° top raw-normal guard; no tuning of these thresholds. Exact shared-edge components require ≥0.35m along-strip extent; accepted top also requires ≥8mm across extent. Transition components must touch accepted top and a frozen floor component, remain between the floor/top bounds±2mm, and meet the same long-strip extent. No proximity bridging, triangle clipping, object completion or region dilation.

## Measured evaluator geometry

Top plane, original-game coordinates, metres:

`Y = −0.004691584995 X −0.000703632578 Z +0.032245982023`

- Plane slope: **0.272°**; training residual P95 **0.609mm**.
- One accepted top component: **0.736m along ×0.070m across**.
- One accepted transition component: **0.737m along ×0.018m across**; exact-edge attachment to top and existing red ground, not gray.
- Top fitted rise above the smaller of the independently frozen broad red/gray floor planes: **18.4–19.4mm**. This is evaluator geometry, not certified source perception.
- The **25mm cap is an assumed kinematic capability**, not a measured human capability or certified phone-derived rise. Local support, descent, full-body collisions, arrival rules and cap enforcement remain executor-owned.

## Exact provenance and independent anchors

`FLOOR_ANCHOR_PROVENANCE_AUDIT.json` audits, without regenerating membership:
- Red anchor: original frame00131, pose index130; its floor-anchor XZ exactly equals the source camera XZ. Existing stage40 red seed face IDs retained.
- Gray anchor: original frame00175, pose index160; its floor-anchor XZ exactly equals the independently frozen source camera XZ. Existing stage43 gray first-hit seed IDs retained.
- These are camera-projected horizontal anchors plus evaluator floor-hit annotations, **not RGB-derived floor surface pixels**. No new floor seeds, route changes or ground-classifier thresholds.

`EXTRACTION_RECEIPT.json` records the complete unchanged ROI extraction:7,041 faces,2s,66MB peak RSS. Direct PLY chunks only; no full VTK/full-reference transformed copy. Whole original face vertices project inside u350–640 and delta3–29 relative to v=855+(u−320)×0.145. Original-game vertices are inverted using ORIGINAL pipelineR,t before original195 camera projection. This avoids silently confusing original and corrected leveling frames.

Reference mesh SHA256:
`e18db651c694046de7994237e276d88138ecef9071351281a418de9c9a279b5e`

`TYPED_SILL_DEFINITION.json` pins source region, original geometry, configs, floor membership and scripts. `MANUAL_EVALUATOR_TYPES_SOURCE195.png` shows the manually associated classes projected into the public original: yellow=top, orange=transition, blue=existing red ground, green=fixed image ROI. No route or private UI is shown. Source-height uncertainties and unobserved jamb/outer margins remain as recorded in the source-only packet.
