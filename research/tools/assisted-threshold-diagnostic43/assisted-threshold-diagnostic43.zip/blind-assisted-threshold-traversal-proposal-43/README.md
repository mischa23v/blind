# Assisted threshold diagnostic43

Read RESULT_REPORT.md first. The actor moved1.616166m but entry and return did not complete. This is a failed assisted simulator support rule, not a validated navigation system.

- CURRENT_PROTOCOL.md describes the explicit reference-world assistance and frozen behavior.
- FROZEN.json pins437 original inputs plus the serialization regression log. Original run01 frozen sources are retained in run-01/frozen-source/.
- run-02/result/RESULT.json and postrun/RECOUNT.json contain terminal evidence; ACTUAL_TRACE.csv contains actual positions only.
- complete-manual-sill/ defines the manual physical-object association; manual-sill-association/ preserves the earlier incomplete annotation.
- Historical PROPOSAL.md and STATUS.json intentionally remain unchanged and describe the earlier state, not current completion.

Reproduction needs prior full repository research inputs listed by exact path/hash in FROZEN.json, the published Polycam comparator archive (master4211356), earlier room-test/query-performance assets, and the public660550085-byte FARO reference mesh from the navigation-test-data-20261026 release. This compact packet is not standalone and contains no replacement raw scan.

Stage45 is a separate mathematical support-envelope correction. No stage45 result is claimed here.
