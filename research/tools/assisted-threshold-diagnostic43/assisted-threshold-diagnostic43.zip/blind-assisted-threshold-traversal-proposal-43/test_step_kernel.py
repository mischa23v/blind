import unittest,math,sys,json
from pathlib import Path
import numpy as np
from step_kernel import *
H=Path(__file__).resolve().parent;W=H.parent
sys.path.insert(0,str(W/'blind-polycam-varpu-executor-40'));import run_north as d
sys.path.insert(0,str(W/'blind-split-candidate-game-03/source'));import test_oriented_container as f
from oriented_container import sweep_enclosure
from reference_geometry import ReferenceSurface

def support(y,typed=True,accepted=True,hits=9):return {'accepted':accepted,'hitCount':hits,'missingCount':9-hits,'footHeight':y,'typedSill':typed}
def make_macro(y,typed=True):return build_macro([-.16,0,0],[-.14,0,0],0,0,support(y,typed),support(y,typed),0)
def plate(x0,x1,z0,z1,y):return [[[x0,y,z0],[x1,y,z0],[x1,y,z1]],[[x0,y,z0],[x1,y,z1],[x0,y,z1]]]
def collision_scene(extras=(),sill=.02):
 tris=f.floor()+plate(0,.1,-.5,.5,sill)+list(extras);surface=ReferenceSurface(f.mesh(tris));T=np.eye(4)
 def ground(ids):
  ids=np.array(ids,np.int64);ids.setflags(write=False);return d.motion.GroundSupport(ids,{},surface,surface.mesh,int(surface.mesh.GetMTime()),T,np.zeros(3))
 body=d.motion.GroundTiledReferenceContainer(surface,T,ground=ground([0,1]),body=d.BodyGeometry(width=.45,depth=.30,height=1.6,horizontal_margin=0))
 guard=d.motion.GroundTiledReferenceContainer(surface,T,ground=ground([0,1,2,3]),body=d.BodyGeometry(width=.45,depth=.30,height=1.6,horizontal_margin=0))
 def bc(p):
  x=body.swept_contacts(p.start,p.end,p.start_yaw,p.yaw_delta);return {'contact':bool(x['actualBody']['contact']or x['horizontalMargin']['contact']),'raw':x}
 def uc(p):
  a=np.array(p.start);b=np.array(p.end);top=max(a[1],b[1])+.002;a[1]=b[1]=0.;corners,_=sweep_enclosure(a,b,p.start_yaw,p.yaw_delta,half_forward=.15,half_lateral=.225,height=max(.002,top),floor_contact_exclusion=0.);q=guard.contact_corners(corners);return {'contact':q['contact'],'raw':q}
 return bc,uc
class Tests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):d.motion.serial_vtk()
 def test_flat_identity(self):
  p,r=make_macro(0,False);self.assertEqual(len(p),1);self.assertEqual(p[0].kind,'FOLLOW');np.testing.assert_allclose(p[0].end,[-.14,0,0])
 def test_declared_rise_boundary(self):
  for h in [0,.005,.015,.025]:
   p,r=make_macro(h);self.assertTrue(all(x.length<=.025000001 for x in p));self.assertAlmostEqual(p[-1].end[1],h);self.assertEqual(p[-1].end[0],-.14)
  with self.assertRaisesRegex(StepRejected,'exceeds25mm'):make_macro(.026)
 def test_untyped_step_rejects(self):
  with self.assertRaisesRegex(StepRejected,'untyped'):make_macro(.015,False)
 def test_missing_landing_rejects(self):
  with self.assertRaisesRegex(StepRejected,'unknown_end'):build_macro([0,0,0],[.02,0,0],0,0,support(.01),support(.01,hits=8),0)
 def test_unknown_mid_support_rejects(self):
  with self.assertRaisesRegex(StepRejected,'unknown_mid'):build_macro([0,0,0],[.02,0,0],0,0,support(.01,accepted=False),support(.01),0)
 def test_full25mm_step_sweeps_clear_authored_strip(self):
  p,_=make_macro(.025);a,b=collision_scene(sill=.025);self.assertEqual(len(validate_macro(p,a,b)),len(p))
 def test_missing_knownfloor_not_inferred_from_collisionfree(self):
  with self.assertRaises(StepRejected):build_macro([0,0,0],[.02,0,0],0,0,support(0,hits=0),support(0,hits=0),0)
 def test_low_loose_block_on_sill_retained(self):
  # A1mm protrusion above the sill, distinct non-sill face: not silently exempted.
  extra=[[[.001,.021,-.01],[.009,.021,-.01],[.005,.021,.01]]];a,b=collision_scene(extra);p,_=make_macro(.02)
  with self.assertRaises(StepRejected):validate_macro(p,a,b)
 def test_unrelated_small_object_below_raised_body_retained(self):
  extra=[[[.001,.01,-.01],[.009,.01,-.01],[.005,.01,.01]]];a,b=collision_scene(extra);p,_=make_macro(.02)
  with self.assertRaisesRegex(StepRejected,'underbody'):validate_macro(p,a,b)
 def test_ceiling_blocks_upward_sweep(self):
  a,b=collision_scene(plate(-.5,.5,-.5,.5,1.615));p,_=make_macro(.02)
  with self.assertRaisesRegex(StepRejected,'head_or_side'):validate_macro(p,a,b)
 def test_jamb_or_side_obstacle_retained(self):
  a,b=collision_scene([[[0,0,-.1],[0,2,-.1],[0,1,.1]]]);p,_=make_macro(.02)
  with self.assertRaisesRegex(StepRejected,'head_or_side'):validate_macro(p,a,b)
 def test_failed_trial_does_not_commit_position(self):
  st=np.array([-.16,0,0]);before=st.copy();p,_=build_macro(st,[-.14,0,0],0,0,support(.02),support(.02),0)
  with self.assertRaises(StepRejected):validate_macro(p,lambda p:{'contact':True},lambda p:{'contact':False})
  np.testing.assert_array_equal(st,before)
 def test_yaw_and_body_not_shrunk(self):
  p,r=build_macro([-.16,0,0],[-.14,0,0],0,math.radians(1),support(.02),support(.02),0);self.assertAlmostEqual(sum(x.yaw_delta for x in p),math.radians(1));self.assertTrue(all(abs(x.yaw_delta)<=math.radians(1)+1e-12 for x in p))
 def test_down_step_explicit_y(self):
  p,r=build_macro([0,.02,0],[.02,.02,0],0,0,support(0),support(0),1,current_sill=True);self.assertEqual([x.kind for x in p],['SIDE','DOWN']);self.assertAlmostEqual(p[-1].end[1],0)
 def test_numpy_inputs_macro_policy_json_serializable(self):
  phases,policy=build_macro(np.array([-.16,0.,0.]),np.array([-.14,0.,0.]),0.,0.,support(.02),support(.02),0)
  json.dumps(policy,allow_nan=False)
 def test_command_caps_not_relaxed(self):
  with self.assertRaises(StepRejected):build_macro([0,0,0],[.026,0,0],0,0,support(0),support(0),0)
if __name__=='__main__':unittest.main(verbosity=2)
