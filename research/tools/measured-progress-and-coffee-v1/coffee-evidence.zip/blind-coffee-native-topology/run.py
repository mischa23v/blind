from pathlib import Path
import json,numpy as np,hashlib,sys,resource,time,dataclasses,os
os.environ['OPENBLAS_NUM_THREADS']='1';resource.setrlimit(resource.RLIMIT_CPU,(120,120));sys.dont_write_bytecode=True
H=Path(__file__).resolve().parent;W=H.parent;S=W/'blind-coffee-source-readiness';P=json.loads((H/'PROTOCOL.json').read_text());M=S/'selected/room_datasets/coffee_room/iphone/long_capture/polycam_mesh/textured.obj';A=S/'ORIENTATION_AUDIT.json';a=json.loads(A.read_text());bounds=np.array(a['candidateFloor']['observedTriangleXZBounds']);y=a['candidateFloor']['weightedCentroidOBJ'][1];end=[]
for fx in [.15,.5,.85]:
 for fz in [.15,.5,.85]:
  x,z=bounds[0]+np.array([fx,fz])*(bounds[1]-bounds[0]);end.append([float(x),float(y),float(z)])
pins=[M,A,H/'PROTOCOL.json',Path(__file__),W/'blind-tabletop-exclusion-planner-66/libblind_detour.so',W/'blind-tabletop-exclusion-planner-66/native_exclusion.py',W/'blind-tabletop-exclusion-planner-66/blind_detour_exclusion.cpp',W/'blind-tabletop-exclusion-planner-66/clearance_adapter.cpp',W/'blind-tabletop-exclusion-planner-66/BUILD_RECEIPT.json',W/'blind-clearance-centered-loop-55/planner.py',W/'blind-split-candidate-game-03/body-margin-variants-07/native025/detour_engine.py']
manifest={'requestedEndpoints':end,'config':P['nativeConfig'],'sourceSHA256':{str(p.relative_to(W)):hashlib.sha256(p.read_bytes()).hexdigest()for p in pins},'recastUpstreamCommit':'9f4ce64458dfae86e1239c525ddc219c4e9e06f1','nativeCapsUnchanged':{'maxVertices':250000,'maxFaces':500000,'maxCells':250000},'frozenBeforeNativeBuild':True};(H/'FROZEN.json').write_text(json.dumps(manifest,indent=2)+'\n');v=[];f=[]
for line in M.open():
 q=line.split()
 if not q:continue
 if q[0]=='v':v.append(list(map(float,q[1:4])))
 elif q[0]=='f':
  assert len(q)==4;f.append([int(x.split('/')[0])-1 for x in q[1:]])
v=np.array(v);f=np.array(f);assert len(v)<=250000 and len(f)<=500000;assert f.min()>=0 and f.max()<len(v)
sys.path.insert(0,str(W/'blind-tabletop-exclusion-planner-66'));from native_exclusion import Native
start=time.monotonic();native=Native(v,f,exclusion=False);assert dataclasses.asdict(native.engine.config)==P['nativeConfig'];assert native.marked_span_count==0
samples=[]
for i,p in enumerate(end):
 s=native.sample(p,tuple(P['endpointAssociation']['queryHalfExtents']));shift=None if s is None else float(np.linalg.norm((s[0]-p)[[0,2]]));samples.append({'id':i,'requestedXYZ':p,'projectedXYZ':None if s is None else s[0].tolist(),'horizontalShiftMetres':shift,'validAssociation':s is not None and shift<=.1,'residualNativeWallDistance':None if s is None else s[1]})
rows=[]
for i,p in enumerate(end):
 for j,q in enumerate(end):
  if i==j:continue
  r=native.engine.route(p,q,query_half_extents=(.2,.3,.2));points=np.array(r.points);length=float(np.linalg.norm(np.diff(points,axis=0),axis=1).sum())if len(points)>1 else 0;rows.append({'start':i,'goal':j,'native':dataclasses.asdict(r),'endpointAssociationsValid':samples[i]['validAssociation']and samples[j]['validAssociation'],'acceptedNativeProposal':r.complete and samples[i]['validAssociation']and samples[j]['validAssociation'],'pathLengthMetres':length})
native.close();accepted=[r for r in rows if r['acceptedNativeProposal']];out={'scope':P['scope'],'frozenSHA256':hashlib.sha256((H/'FROZEN.json').read_bytes()).hexdigest(),'nativeMarkedExclusionSpans':0,'meshCounts':[len(v),len(f)],'endpoints':samples,'queries':rows,'summary':{'queries':len(rows),'validEndpoints':sum(x['validAssociation']for x in samples),'completeNativeQueries':sum(r['native']['complete']for r in rows),'acceptedNativeProposals':len(accepted),'longestAcceptedMetres':max([r['pathLengthMetres']for r in accepted],default=0),'movementEpisodes':0,'elapsedWallSeconds':time.monotonic()-start,'processMaxRSSKiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss},'knownMeshOnlyNotObservedFreeSpace':True,'physicalAuthority':False};
def strict(x):
 if isinstance(x,dict):return {k:strict(v)for k,v in x.items()}
 if isinstance(x,(list,tuple)):return [strict(v)for v in x]
 if isinstance(x,float)and not np.isfinite(x):return None
 return x
(H/'RESULT.json').write_text(json.dumps(strict(out),indent=2,allow_nan=False)+'\n');print(json.dumps(out['summary'],indent=2))
