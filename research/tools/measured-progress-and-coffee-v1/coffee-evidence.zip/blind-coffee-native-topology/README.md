# Coffee: unchanged native Recast source-geometry topology

**20complete native proposals across5valid predeclared endpoints; longest6.1895m. Zero movement episodes.** These are not simulated arrivals, swept-body passes, physical clearance, or a fresh blind holdout.

## Frozen setup
Nine source-only points were frozen before building/querying: Cartesian fractions[.15,.50,.85]of the previous source candidate-floor XZbounds; commonY=weighted candidatefloorheight. All72directednonselfpairs retained. No endpoint replacement, map correction, registered camera position, reference data, or Koivu transform.

Original51,965vertices/87,370triangles feed the same released Recast/Detour engine at upstream commit`9f4ce64458dfae86e1239c525ddc219c4e9e06f1` through existing66adapter with **exclusion disabled**. Radius.225m,height1.75m,cellsize/cellheight.025m,slope15degrees,climb.025m,maxcells250,000,maxnodes4096. Agent radius is applied once; no new enlargement/shrinkage. Native mesh caps250,000vertices/500,000faces already accommodate Coffee; no limits increased.

These are circular native proposals, not an oriented45×30cm fullbody sweep. Complete geometry is assumed by the planner; missing mesh is not observed free space.

## Retained outcomes
-5/9requested endpoints meet unchanged horizontal association≤.10m within native query halfextents[.2,.3,.2]m.
-Endpoint3projects14.19cm and is rejected; endpoints2,4,5have no sample. No substitute points chosen. Their physical cause was not diagnosed.
-Endpoints0,1,6,7,8all connect to one another:20/20directed native proposals. Endpoint6has9.26cm projection, endpoint7has1.41cm; these shifts are explicitly retained and are not actual actor motion.
-Native reports30complete queries overall;10are rejected by endpoint association.42other nativequeries are incomplete/invalid. Full status, projected endpoints, error strings, partial points and lengths remain in RESULT.json.
-Longest accepted native proposal6.189526m. Figure shows source proposals, not executed trajectories. Green/red endpoint markers are requested positions; native path vertices start/end at projected positions.
-Native-section walltime~.098seconds, processpeakRSS53,884KiB; imposed120CPUsecondcap. No heavy physics. The2MiB output budget is checked by measured folder size, not an actively enforced filesystem quota; the120CPUsecondlimit is enforced.

`FROZEN.json` pins sourceOBJ, orientationinput, endpoint protocol, nativebinary, bindings, adapter sources and buildreceipt. `RECOUNT.json` comes from a separate arithmetic/output verifier: checks allpins,72unique directedpairs, every path-length recomputation, association filtering and all-pairs connectivity. This is a separate verifier, not a new independent real-world test.

One exact rerun only corrected serialization of invalid native projectionNaNs to JSONnull; no geometry, endpoint, threshold or planner changes. Counts and lengths were identical. Native source metadata/configuration hashes are published. Original mesh/poses unchanged.

## Next boundary
These results show the current released engine can propose multi-metre routes through this second recorded phone mesh without the older custom floor-mask policy. They do not show correctness against real obstacles, safety, or that all physically possible routes are found. Coffee-specific camera/mesh registration, coverage/hazard evidence, independent evaluation and fullbody movement remain untested. No reference geometry used for planning or this recount.

Run:
```
OPENBLAS_NUM_THREADS=1 python blind-coffee-native-topology/run.py
OPENBLAS_NUM_THREADS=1 python blind-coffee-native-topology/review_and_draw.py
```
The original source archive provenance/CC-BY4.0 attribution, source member hashes, acquisition verification, orientation diagnostic and remote/local inventory are in sibling`blind-coffee-source-readiness/`.
