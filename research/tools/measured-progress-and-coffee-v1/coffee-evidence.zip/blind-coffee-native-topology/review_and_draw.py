from pathlib import Path
import os,json,hashlib,numpy as np
os.environ['MPLCONFIGDIR']='/tmp/coffee-mpl-config';os.environ['XDG_CACHE_HOME']='/tmp/coffee-font-cache'
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
H=Path(__file__).resolve().parent;W=H.parent;r=json.loads((H/'RESULT.json').read_text());f=json.loads((H/'FROZEN.json').read_text());assert r['frozenSHA256']==hashlib.sha256((H/'FROZEN.json').read_bytes()).hexdigest()
for p,sha in f['sourceSHA256'].items():assert hashlib.sha256((W/p).read_bytes()).hexdigest()==sha
assert len(r['queries'])==72 and len({(x['start'],x['goal'])for x in r['queries']})==72;accepted=[]
for x in r['queries']:
 p=np.array(x['native']['points']);length=float(np.linalg.norm(np.diff(p,axis=0),axis=1).sum())if len(p)>1 else 0;assert abs(length-x['pathLengthMetres'])<1e-10
 expect=x['native']['complete']and r['endpoints'][x['start']]['validAssociation']and r['endpoints'][x['goal']]['validAssociation'];assert x['acceptedNativeProposal']==expect
 if expect:accepted.append(x)
valid=[x['id']for x in r['endpoints']if x['validAssociation']];assert len(accepted)==len(valid)*(len(valid)-1)
summary={'allChecksPassed':True,'validEndpointIDs':valid,'allValidEndpointsMutuallyConnectedNativeOnly':True,'acceptedDirectedProposals':len(accepted),'endpointOutcomes':r['endpoints'],'longestRoute':max(accepted,key=lambda x:x['pathLengthMetres']),'noMovementOrSafetyClaim':True};(H/'RECOUNT.json').write_text(json.dumps(summary,indent=2)+'\n')
v=[]
for line in (W/'blind-coffee-source-readiness/selected/room_datasets/coffee_room/iphone/long_capture/polycam_mesh/textured.obj').open():
 if line.startswith('v '):v.append(list(map(float,line.split()[1:4])))
v=np.array(v);floor=f['requestedEndpoints'][0][1];m=(v[:,1]>floor+.05)&(v[:,1]<floor+1.6);fig,ax=plt.subplots(figsize=(9,8));ax.scatter(v[m,0],v[m,2],s=.7,c='gray',alpha=.5)
for x in accepted:
 if x['start']>x['goal']:continue
 p=np.array(x['native']['points']);ax.plot(p[:,0],p[:,2],color='#0089b5',lw=1,alpha=.6)
long=summary['longestRoute'];p=np.array(long['native']['points']);ax.plot(p[:,0],p[:,2],color='#b500a3',lw=2,label=f"Longest accepted native proposal {long['pathLengthMetres']:.2f}m (not movement)")
for x in r['endpoints']:
 p=x['requestedXYZ'];ok=x['validAssociation'];ax.scatter([p[0]],[p[2]],c='green'if ok else'red',marker='o'if ok else'x',s=45);ax.annotate(str(x['id']),(p[0],p[2]),xytext=(5,5),textcoords='offset points',fontsize=10)
ax.set_aspect('equal');ax.set_xlabel('Original source OBJ X (m)');ax.set_ylabel('Original source OBJ Z (m)');ax.set_title('Coffee: unchanged native Recast proposals on original mesh\nDots = requested endpoints (green valid / red invalid); paths use projections\nNo body movement tested');ax.grid(alpha=.2);ax.legend(fontsize=8);fig.tight_layout();fig.savefig(H/'NATIVE_PROPOSALS.png',dpi=110);plt.close(fig);print([(x['id'],x['validAssociation'],x['horizontalShiftMetres'])for x in r['endpoints']])
