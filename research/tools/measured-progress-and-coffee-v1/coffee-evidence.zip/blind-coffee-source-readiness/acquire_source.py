from pathlib import Path,PurePosixPath
import urllib.request,tarfile,hashlib,json,time,signal,shutil
H=Path(__file__).resolve().parent;OUT=H/'selected';OUT.mkdir(exist_ok=True)
URL='https://zenodo.org/api/records/10230733/files/coffee_room_iphone.tar.gz/content';LIMIT=190*1024**2;OUTMAX=12*1024**2;RESERVE=768*1024**2;start=time.monotonic();signal.alarm(295)
class Reader:
 def __init__(self,r):self.r=r;self.n=0;self.md5=hashlib.md5();self.sha=hashlib.sha256()
 def read(self,n=-1):
  if n<0:n=65536
  b=self.r.read(min(n,65536));self.n+=len(b)
  if self.n>LIMIT:raise ValueError('network cap')
  self.md5.update(b);self.sha.update(b);return b
rows=[];saved=[];total=0;rawtotal=0
try:
 with urllib.request.urlopen(URL,timeout=30)as resp:
  r=Reader(resp)
  with tarfile.open(fileobj=r,mode='r|gz')as tar:
   for m in tar:
    rawtotal+=m.size
    if len(rows)>10000 or rawtotal>2*1024**3:raise ValueError('inventory cap')
    name=m.name;pp=PurePosixPath(name)
    if pp.is_absolute()or '..'in pp.parts:raise ValueError('unsafe member')
    wanted=m.isfile()and '/coffee_room/iphone/long_capture/'in '/'+name and (name.endswith('/polycam_mesh/textured.obj')or name.endswith('/long_capture/transformations.json'))
    rows.append({'name':name,'size':m.size,'type':m.type.decode('ascii','replace'),'selected':wanted})
    if not wanted:continue
    if total+m.size>OUTMAX or shutil.disk_usage(H).free-m.size<RESERVE:raise ValueError('output/reserve cap')
    target=OUT/pp;target.parent.mkdir(parents=True,exist_ok=True)
    if target.exists():raise ValueError('no overwrite')
    digest=hashlib.sha256();n=0
    with tar.extractfile(m)as src,target.open('xb')as dst:
     while True:
      b=src.read(65536)
      if not b:break
      dst.write(b);digest.update(b);n+=len(b)
    if n!=m.size:raise ValueError('member size')
    total+=n;saved.append({'path':str(target.relative_to(H)),'bytes':n,'sha256':digest.hexdigest()});print(json.dumps(saved[-1]),flush=True)
  while r.read(65536):pass
  complete=r.n==183080957 and r.md5.hexdigest()=='cb467b3ad18d8f2c83dbf97a486d378b'
  receipt={'url':URL,'networkBytes':r.n,'wholeArchiveMD5':r.md5.hexdigest(),'wholeArchiveSHA256':r.sha.hexdigest(),'officialSizeAndMD5Match':complete,'saved':saved,'outputBytes':total,'members':rows,'elapsedSeconds':time.monotonic()-start,'archiveSaved':False,'referenceAcquired':False,'license':'CC-BY-4.0 per official record10230733'}
  (H/'ACQUISITION.json').write_text(json.dumps(receipt,indent=2)+'\n');assert complete
except Exception as e:
 (H/'ACQUISITION_FAILURE.json').write_text(json.dumps({'error':str(e),'saved':saved,'members':rows,'elapsed':time.monotonic()-start},indent=2));raise
print('COMPLETE',total,flush=True)
