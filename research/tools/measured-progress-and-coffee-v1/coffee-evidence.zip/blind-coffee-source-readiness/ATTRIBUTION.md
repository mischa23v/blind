# Public MuSHRoom Coffee source attribution

Dataset: MuSHRoom, Xuqian Ren, Wenjia Wang, Dingding Cai, Tuuli Tuominen, Juho Kannala and Esa Rahtu, WACV2024. Official repository: https://github.com/TUTvision/MuSHRoom .

Source: Xuqian Ren, **iPhone dataset (Basic Data)**, https://zenodo.org/records/10230733 , DOI https://doi.org/10.5281/zenodo.10230733 . Official metadata declares **Creative Commons Attribution4.0International**: https://creativecommons.org/licenses/by/4.0/ . Full legalcode: https://creativecommons.org/licenses/by/4.0/legalcode.en .

`coffee_room_iphone.tar.gz`,183,080,957bytes, officialMD5`cb467b3ad18d8f2c83dbf97a486d378b`verified oncomplete streamed archive. Retained originalOBJ andtransformations members are byte-unmodified; exactmemberSHA256s andcompletearchiveSHA256 are inACQUISITION.json. Noarchivecopy retained. Hashmatch is identity checking, not an independent authenticity guarantee; provenance comes from officialHTTPS record.

Derived outputs: source-only mesh inventory, candidateorientation statistics, top-down renders and nativeRecast path proposals. These derivatives are labelled and do not imply endorsement byauthors, physical safety, reliablecompletegeometry, sourcecameraalignment or liveiPhonetracking. NoFAROreferencegeometry included. Dataset source is phone reconstruction, not groundtruth.

Recast/Detour code is separately licensed under its originalzlib-style permissive terms, copyrightMikkoMononen. See the included`blind-tabletop-exclusion-planner-66/License.txt`; the datasetlicense does not replace third-partycodelicenses.
