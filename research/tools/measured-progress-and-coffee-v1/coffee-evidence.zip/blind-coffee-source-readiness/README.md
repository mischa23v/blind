# Coffee room: independent-room source readiness

## Ready now, without FARO planning
We now have the official original Coffee iPhone Polycam triangle mesh and original388camera poses/intrinsics. A bounded **source-mesh-only released Recast/Detour baseline** can run after checking mesh floor/up-axis and face/index integrity. It must keep the same planner/body rules, not tune against Coffee outcomes. No route query, movement, reconstruction scoring, or heavy reference-world load was performed in this audit.

Coffee is **not a pristine holdout**: earlier sessions analyzed its noise, masks and reference proxies. Dataset name does not establish that this is a commercial cafe/customer route.

## Verified selective acquisition
Official source: https://zenodo.org/records/10230733 , *iPhone dataset (Basic Data)*, Xuqian Ren; **CC BY4.0**. Live metadata is preserved in OFFICIAL_SOURCE.json.

Streamed `coffee_room_iphone.tar.gz` once, keeping **no archive**, deleting no existing files. Whole stream183,080,957bytes completed in276.77seconds, below190MiB/295second caps. Official size/MD5 match:
- MD5 `cb467b3ad18d8f2c83dbf97a486d378b`
- SHA256 `591672a1c4afa50e5109fc78ff08d8f608d05756a9181cfdd7cef38a57a1623d`

Selected outputs total10,814,582bytes (<12MiB);768MiB reserve retained. No reference archive acquired. ACQUISITION.json contains the full1066member inventory and selected-file SHA256s.

Under `selected/room_datasets/coffee_room/iphone/long_capture/`:

| File | Bytes | SHA256 |
|---|---:|---|
| `polycam_mesh/textured.obj` |10,497,144|`f10de085426143ad095fefc713b4966d22fdf08beda9ff9ead759019a0a8306a`|
| `transformations.json` |317,438|`46c8d1fc5188d38179e88eff98fd42f99956fb93b570bd9483e6e92764ae7010`|

Mesh51,965vertices/87,370faces; bounds[-2.672565,-1.786106,-3.404962]to[2.672565,1.786106,3.404962]. These are **mesh coordinate bounds**, not a measured room floorplan or proven up-axis. Material189bytes and texture2,614,072bytes are listed in the archive but not extracted. Recast geometry does not require a texture. Raw RGB/depth are inventoried, **not local**.

## Existing local derived evidence
`blind-pose-experiments-review-17/upstream/pose-consistency/` contains older externally supplied b0be8628 Coffee floor-fixed poses and masks:
- `poses/coffee_floorfix_transformations.json`:388poses; SHA256 `00da30738be10e341c5c8642eb48f67507f3ff985300fa4480b91f1aa87f5501`.
- `runs/coffee_floorfix/occthres_split0.7.npz`:218,252bytes; SHA256 `8cf54a1d2e9f4e6a01f212975cc985a9bcbb88ffb243b36106db78be58006efa`.
- `runs/coffee_floorfix/pipeline2_out.npz`:3,547,969bytes; SHA256 `57c8552dbd98c966f26625dc1440bd77ff4cfb4257966b4cf6af76bfcd95963b`.

The metadata NPZ also contains `refWalk/ref_*` evaluator arrays. Existing planner key allowlist must remain: phone flags and lo/res/R/t only; never pass reference arrays into planning. The old24 Coffee run tested planar mask paths, not this original triangle mesh, and executed zero movement episodes. It is not a result for the current Polycam pipeline.

## Published Fable branch inventory
Live read-only listing of `claude/affectionate-curie-bolib1`, `research/mapping-audit-opus-20261026/`, is saved in REMOTE_LISTING.json with exact Git blob SHAs/sizes (not SHA256 byte verification).
- `v3/maps/coffee_coloricp` and `coffee_floorfix`: masks218,252bytes, pipeline arrays3,547,969bytes, support-layer arrays1,380,993bytes.
- `v3/poses/coffee_coloricp_transformations.json`:200,087bytes, Git blob `d6f5f7da1cbd5308fda82e3529a580fafbc15679`.
- `derived/pipeline-outputs/coffee_5cm_v2_fused_clouds.npz`:4,133,510bytes, Git blob `aa8e98818e671530f3c615ec3046d43f65f13cd9`.

Published README describes fused clouds as occupied/free OctoMap leaf centres, **not triangle mesh**. No original Polycam mesh appeared in the inspected audit directories. These remote binary assets were not downloaded or verified; do not silently substitute newer v3 classifications for unchanged rules.

## Concrete next bounded step
1. Validate OBJ triangle indices, finite coordinates and mesh-derived dominant floor/up direction without FARO. Freeze this preprocessing and the unchanged native Recast settings before querying routes.
2. Run one source-mesh-coordinate topology/route availability diagnostic with released Recast. Report as geometry-only proposal, no camera association, body-safe movement or reference pass. Original mesh must remain untouched.
3. For source-camera-goal or recorded-image interpretation, obtain a small preregistered RGB/depth subset using this archive inventory, then run **Coffee-specific source-only registration** and independent heldout reprojection. Official MuSHRoom layout warns Polycam mesh is not aligned with poses. Original poses alone cannot solve that transform; do not reuse Koivu registration or align using reference geometry.
4. Only later acquire separate Coffee reference mesh/registration for evaluator-only full-body testing. Its official archive288,148,502bytes is absent; saved vertex-column proxies cannot replace triangle collision geometry. Do not claim completed room movement before those gates.

Recast code already local: `blind-tabletop-exclusion-planner-66/License.txt` (zlib-style permissive terms, Mikko Mononen), SHA256 `ffad87821cce7cfd3be00b63ffadd01b04e83a4c6a0bcc68f06362ffd42d705e`; source/version pins remain in existing planner manifests. Dataset attribution/licence must remain with derived assets. Do not assume third-party code licenses from the dataset license.

## Added source-only orientation diagnostic (no routes)
`ORIENTATION_AUDIT.json` and `SOURCE_TOP_VIEW.png` inspect the original mesh, without reference data. All87,370faces are triangles with valid indices; no zero-area triangles found. Candidate Y-up has a strong lowest-half near-horizontal layer: area-ranked2cm bin[-1.64,-1.62]m,4,247triangles, summedarea23.819m². Weighted floor centroidY−1.630163m, normal[0.000228,0.9999998,−0.000580], centroid residualmedian1.17mm/p957.50mm. Observed floor-triangle XZ bounds span5.20×6.37m. Summed triangle area can include overlap; not a measured walkable area.

The figure shows vertices0.05–1.60m above that candidate floor and observed floor-triangle centres/bounds. **This is not an occupancy or walkability map**; no object, drop, or noise was removed. Candidate vertical-surface bins cluster nearX±2.58m andZ−3.12/+3.28m. Furniture can contribute; closed walls, entrances and physical room dimensions are not inferred.

Y-up/sign and physical scale remain candidate assumptions pending source RGB/depth cross-check. A mesh-derived floor normalization permits a geometry-only native planner proposal, but it is not a mesh-to-camera transform. Camera correspondence requires a Coffee-specific registration: source depth/colour anchors, original camera intrinsics/poses, mesh correspondences and reserved view reprojections, not copied Koivu matrices or FARO fitting. Existing original388poses alone do not determine this association.
