from pathlib import Path
import json,numpy as np
import os
os.environ['MPLCONFIGDIR']='/tmp/coffee-mpl-config'
os.environ['XDG_CACHE_HOME']='/tmp/coffee-font-cache'
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
H=Path(__file__).resolve().parent;p=H/'selected/room_datasets/coffee_room/iphone/long_capture/polycam_mesh/textured.obj';v=[];faces=[];nontri=0
for line in p.open():
 a=line.split()
 if not a:continue
 if a[0]=='v':v.append(list(map(float,a[1:4])))
 if a[0]=='f':
  if len(a)!=4:nontri+=1;continue
  faces.append([int(q.split('/')[0])-1 for q in a[1:]])
v=np.asarray(v);f=np.asarray(faces);assert nontri==0 and f.min()>=0 and f.max()<len(v)
t=v[f];c=t.mean(1);cross=np.cross(t[:,1]-t[:,0],t[:,2]-t[:,0]);area=np.linalg.norm(cross,axis=1)/2;normal=cross/np.maximum(2*area[:,None],1e-30)
axisareas=[float(area[abs(normal[:,i])>=np.cos(np.deg2rad(10))].sum())for i in range(3)]
# Fixed diagnostic: candidate Y-up only, lowest half near-horizontal triangles;2cm height bins, choose largest area.
mask=(abs(normal[:,1])>=np.cos(np.deg2rad(10)))&(c[:,1]<(v[:,1].min()+v[:,1].max())/2)&(area>1e-10);bins=np.floor(c[:,1]/.02).astype(int);keys=np.unique(bins[mask]);hist={int(k):float(area[mask&(bins==k)].sum())for k in keys};winner=max(hist,key=hist.get);sel=mask&(bins==winner);center=np.average(c[sel],axis=0,weights=area[sel]);n=(normal[sel]*np.sign(normal[sel,1])[:,None]*area[sel,None]).sum(0);n/=np.linalg.norm(n);off=n@center;res=c[sel]@n-off
# Neighbouring-bin report reveals floor thickness/ripple without threshold tuning.
peaks=sorted(hist.items(),key=lambda x:-x[1])[:8];floorY=float(center[1]);bounds=t[sel][:,:,[0,2]].reshape(-1,2);foot=[bounds.min(0).tolist(),bounds.max(0).tolist()]
wall=[]
for axis in [0,2]:
 m=(abs(normal[:,axis])>=np.cos(np.deg2rad(10)))&(c[:,1]>floorY+.2)&(c[:,1]<floorY+2.2);bb=np.floor(c[:,axis]/.05).astype(int);hh={int(k):float(area[m&(bb==k)].sum())for k in np.unique(bb[m])};top=sorted(hh.items(),key=lambda x:-x[1])[:4];wall.append({'normalAxis':'XYZ'[axis],'candidate5cmBins':[{'interval':[k*.05,(k+1)*.05],'triangleArea':a}for k,a in top],'notGuaranteedWalls':'Furniture/doors/other surfaces can contribute; no RGB semantics or room closure inferred.'})
report={'sourceMeshCoordinateFrameOnly':True,'sourceUnmodified':True,'triangleValidation':{'faces':len(f),'nonTriangles':nontri,'indicesInRange':True,'zeroAreaTriangles':int((area<=1e-10).sum())},'areaWithin10DegreesOfAxisNormalSquareMetres':dict(zip('XYZ',axisareas)),'orientation':'Y-up is a candidate supported by low broad near-horizontal layer; sign/semantic floor not independently confirmed by RGB. Not a mesh-to-camera registration.','candidateFloor':{'selection':'centroids in lowest-halfY,absnormalY>=cos10deg;highest-area2cmheightbin,predeclareddiagnostic','chosenBin':[winner*.02,(winner+1)*.02],'triangleCount':int(sel.sum()),'summedTriangleAreaSquareMetres':float(area[sel].sum()),'weightedCentroidOBJ':center.tolist(),'weightedNormalTowardPositiveY':n.tolist(),'planeOffset':float(off),'centroidResidualP50P95Metres':np.quantile(abs(res),[.5,.95]).tolist(),'observedTriangleXZBounds':foot,'areaRanked2cmYBins':[{'interval':[k*.02,(k+1)*.02],'area':a}for k,a in peaks]},'candidateVerticalSurfaceBands':wall,'registrationMissing':['PolycamOBJ-to-originalcamera rigid transform','independentview reprojection / scale andgravity checks','sourceRGB/depthsubsets for floor/wall anchors andheldout observations'],'noFAROOrRoutesUsed':True}
(H/'ORIENTATION_AUDIT.json').write_text(json.dumps(report,indent=2)+'\n')
fig,ax=plt.subplots(figsize=(9,8));m=(v[:,1]>=floorY+.05)&(v[:,1]<=floorY+1.6);scatter=ax.scatter(v[m,0],v[m,2],c=v[m,1]-floorY,s=1,cmap='viridis',vmin=0,vmax=1.6,rasterized=True);ax.scatter(c[sel,0],c[sel,2],s=1,c='lightgray',alpha=.5,label='Candidate floor triangle centroids');ax.plot([foot[0][0],foot[1][0],foot[1][0],foot[0][0],foot[0][0]],[foot[0][1],foot[0][1],foot[1][1],foot[1][1],foot[0][1]],'r--',lw=1,label='Observed candidate floor XZ bounds (not walls)');ax.set_aspect('equal');ax.set_xlabel('Source OBJ X (metres assumed from export; not independently measured)');ax.set_ylabel('Source OBJ Z (m)');ax.set_title('Coffee source mesh only: candidate Y-up top view\nColoured vertices +0.05 to +1.60m above candidate floor; NOT walkability');ax.text(.02,.02,'Dominant candidate vertical-surface bands:\nX≈−2.58,+2.58m; Z≈−3.12,+3.28m\nFurniture can contribute; not verified walls.',transform=ax.transAxes,fontsize=7,bbox={'facecolor':'white','alpha':.85,'edgecolor':'gray'});ax.grid(alpha=.25);ax.legend(loc='upper right',fontsize=7);fig.colorbar(scatter,ax=ax,label='Height above candidate floor (m)');fig.tight_layout();fig.savefig(H/'SOURCE_TOP_VIEW.png',dpi=110);plt.close(fig);print(json.dumps(report,indent=2))
