from pathlib import Path
import json,lzma,numpy as np
from PIL import Image,ImageDraw,ImageFont
H=Path(__file__).resolve().parent;W=H.parent;paths=[W/'blind-synthetic-first-leg-pilot-73',W/'blind-retained-pose-jitter-pilot-74',H];labels=['73: stop without new packet','74: retain, discard history','76: retain + measured progress'];colors=['#246ca8','#b14242','#257548'];rows=[];traces=[]
for folder in paths:
 p=folder/'pilot-temporal_jitter/result';r=json.loads((p/'RESULT.json').read_text());a=np.load(p/'ACTOR_TRACE.npz')['trace'];traces.append(a);ev=[json.loads(x)for x in lzma.open(p/'TICK_EVIDENCE.jsonl.xz','rt')];stops=[e['cue']['forwardMetres']==0 and e['cue']['yawRadians']==0 for e in ev];entries=sum(x and (i==0 or not stops[i-1])for i,x in enumerate(stops));rows.append({'stage':folder.name,'arrival':r['arrival'],'ticks':r['ticks'],'horizontalDistanceMetres':r['actualDistanceMetres'],'noUsablePoseStopTicks':r['stressCounts'].get('controllerReason:noDeliveredPose',0),'allZeroCommandTicksIncludingGoal':sum(stops),'zeroCommandEpisodeEntriesIncludingGoal':entries,'maxPoseErrorMetres':r['maximumDeliveredPoseErrorMetres'],'maxYawErrorRadians':r['maximumDeliveredYawErrorRadians'],'bodyVetoes':r['rejectedPredictedBodyContactEvents'],'underbodyVetoes':r['rejectedPredictedUnderbodyContactEvents'],'finalGoalErrorMetres':r['terminal']['actualFull3DGoalError']})
progress=[]
for e in ev:
 for q in e['cue'].get('releasedObservationProgress',[]):
  if q['cursorAfter']>q['cursorBefore']:progress.append({'deliveryTick':e['tick'],**q})
out={'scope':'paired development comparison, same synthetic jitter seed/route/physical gates; not independent held-out validation','rows':rows,'stage76ProgressAdvances':progress};(H/'PAIRED_COMPARISON.json').write_text(json.dumps(out,indent=2)+'\n')
plan=json.loads((H/'SELECTED_PLAN.json').read_text());im=Image.new('RGB',(1400,880),'white');d=ImageDraw.Draw(im);font='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf';big=ImageFont.truetype(font,23);sm=ImageFont.truetype(font,17);d.text((25,20),'Same short jitter journey: measured progress fixes the lost waypoint',font=big,fill='black');d.text((25,58),'Actual committed trajectories. Same source path, body and physical guards; no geometry or radius relaxation.',font=sm,fill='black')
for k,a in enumerate(traces):
 def xy(q):return(45+k*450+(q[0]+2.5)*195,740-(q[2]-.8)*180)
 d.text((25+k*450,105),labels[k],font=big,fill=colors[k]);d.text((25+k*450,140),f"{'ARRIVED'if rows[k]['arrival']else'FAILED'} | {rows[k]['ticks']} ticks | {rows[k]['horizontalDistanceMetres']:.3f} m",font=sm,fill=colors[k])
 for q in [plan['start'],plan['legs'][0]['originalTaskGoal']]:
  x,y=xy(q);d.ellipse((x-4,y-4,x+4,y+4),fill='#333333')
 x,y=xy(plan['legs'][0]['originalTaskGoal']);d.ellipse((x-.35*195,y-.35*180,x+.35*195,y+.35*180),outline='#999999',width=2)
 d.line([xy(q)for q in plan['legs'][0]['originalFramePath']],fill='#c0c0c0',width=2);d.line([xy(q)for q in a[:,2:5]],fill=colors[k],width=4)
 d.text((25+k*450,790),f"No-usable-pose stop ticks: {rows[k]['noUsablePoseStopTicks']}",font=sm,fill='black')
d.text((25,840),'Static assisted simulation. Evaluator-vetoed collisions are not phone sensing; floor contacts unmeasured.',font=sm,fill='black');im.save(H/'PAIRED_JITTER_PATHS.png')
