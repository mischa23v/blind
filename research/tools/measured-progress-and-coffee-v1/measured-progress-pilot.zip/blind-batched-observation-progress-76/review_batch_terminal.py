from pathlib import Path
import sys,json,lzma,hashlib,numpy as np
H=Path('blind-batched-observation-progress-76');sys.path.insert(0,str(H.resolve()))
import loop_controller as lc
from test_loop_contract import FakeModel
import loop_map as lm
p=H/'pilot-temporal_jitter/result';ev=[json.loads(s) for s in lzma.open(p/'TICK_EVIDENCE.jsonl.xz','rt')];plan=lm.load_plan();c=lc.Controller();c.plan=plan;c.model=FakeModel(plan);c.revision=plan['mapRevision'];c.goal=np.array(plan['legs'][0]['originalTaskGoal']);c.route_goal=c.goal.copy()
progress=[];observations=0
for row in ev:
 tick=row['tick'];batch=[dict(x['packet']['pose'],deliveryMode='new') for x in row['poseDelivery']['released']]
 out=c.consume(dict(command='tick',tick=tick,now=100+tick/15,deliveredPose=row['deliveredPose'],releasedPoses=batch));actual=row['cue']
 for key in ['forwardMetres','yawRadians','goalReached','reason','sourceCapturedAt','sourceCapturedTick','sourceDeliveryMode','releasedObservationProgress','nativeCandidatePoints']:
  assert out.get(key)==actual.get(key),(tick,key)
 for entry,observation in zip(actual.get('releasedObservationProgress',[]),batch):
  observations+=1;assert entry['capturedTick']==observation['capturedTick'];assert entry['positionXYZ']==observation['position'];assert entry['unchangedRadiusMetres']==.01
  before,after=entry['cursorBefore'],entry['cursorAfter'];assert after>=before
  for k in range(before,after):assert np.linalg.norm((np.array(plan['legs'][0]['originalFramePath'][k])-observation['position'])[[0,2]])<=.01
  if after>before:progress.append(dict(deliveryTick=tick,captureTick=observation['capturedTick'],cursorBefore=before,cursorAfter=after))
 if row['deliveredPose'] is not None:
  selected=row['deliveredPose'];assert actual['sourceCapturedTick']==selected['capturedTick'];assert actual['sourceCapturedAt']==selected['capturedAt']
last=ev[-1];assert last['deliveredPose']['deliveryMode']=='new' and last['goalObservationCurrent'];assert last['deliveredPose']['capturedTick']>last['lastCommittedMotionTick'];assert not last['pendingMotion'];assert not(last['appliedCommand']['forward_metres'] or last['appliedCommand']['yaw_radians'])
f=json.loads((H/'FROZEN.json').read_text())
for name,expected in f['files'].items():
 d=hashlib.sha256()
 with open(name,'rb') as z:
  for b in iter(lambda:z.read(1<<20),b''):d.update(b)
 assert d.hexdigest()==expected,name
report=json.loads((H/'INDEPENDENT_TERMINAL_RECOUNT.json').read_text());report['batchReview']=dict(controllerCommandsExactlyReplayed=len(ev),progressObservationsChecked=observations,allProgressUsesOriginalMeasuredPositions=True,unchangedRadiusMetres=.01,progressEvents=progress,newestOnlySteering=True,arrivalCaptureTick=last['deliveredPose']['capturedTick'],lastMotionTick=last['lastCommittedMotionTick'],full3DGoalErrorMetres=last['actualFull3DGoalError'],all613FrozenPinsUnchanged=True,physicalAuthority=False)
report['priorCandidates']=[]
for name in ['blind-synthetic-first-leg-pilot-73','blind-retained-pose-jitter-pilot-74']:
 r=json.loads((Path(name)/'pilot-temporal_jitter/result/RESULT.json').read_text());report['priorCandidates'].append(dict(stage=name,status=r['status'],ticks=r['ticks'],horizontalMetres=r['actualDistanceMetres']))
report['resourceReceipt']=json.loads((H/'pilot-temporal_jitter/RUN_RECEIPT.json').read_text());(H/'INDEPENDENT_TERMINAL_RECOUNT.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report['batchReview'],indent=2))
