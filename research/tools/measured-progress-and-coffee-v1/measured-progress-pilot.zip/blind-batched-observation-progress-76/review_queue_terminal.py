from pathlib import Path
import sys,json,lzma,numpy as np,math,hashlib
from dataclasses import asdict
H=Path('blind-batched-observation-progress-76');sys.path.insert(0,str(H.resolve()))
from pose_delivery import PoseDelivery,condition_by_id
from impairments import ActorFIFO,ActorProfile,ActorCommand
plan=json.loads((H/'SELECTED_PLAN.json').read_text());revision=hashlib.sha256((H/'SELECTED_PLAN.json').read_bytes()).hexdigest()
results=[]
for name in [x['id'] for x in json.loads((H/'CONDITIONS.json').read_text())['conditions']]:
 p=H/f'pilot-{name}'/'result'
 if not (p/'RESULT.json').exists():continue
 r=json.loads((p/'RESULT.json').read_text());a=np.load(p/'ACTOR_TRACE.npz')['trace'];assert np.array_equal(a,np.loadtxt(p/'ACTUAL_TRACE_PARTIAL.csv',delimiter=',',skiprows=1));ev=[json.loads(s) for s in lzma.open(p/'TICK_EVIDENCE.jsonl.xz','rt')];assert len(a)==len(ev)+1 and len(ev)==r['ticks'];assert np.array_equal(a[:,0],np.arange(-1,len(ev)))
 condition=condition_by_id(name);delivery=PoseDelivery(condition,r['seed']);actor=ActorFIFO(ActorProfile(**condition['actor']));dist3d=0.;maxerr=0.;maxyaw=0.;maxage=0.;missing=0;withheld=0;coalesced=0;afterzero=0;delayexposure=0;scaled=0;clipped=0;firststop=None;reasons={};lastmotion=-1;motionticks=[];stop_entries=0;previous_stop=False;scheduled_delays=[]
 for i,x in enumerate(ev):
  state=a[i,2:5];yaw=a[i,5];now=100+i/15
  delivered,row=delivery.capture_and_release(i,now,state,yaw,revision,0);assert delivered==x['deliveredPose'] and row==x['poseDelivery']
  
  if row['disposition']:scheduled_delays.append(row['disposition']['scheduled_tick']-i)
  missing+=int(delivered is None);withheld+=int(row['captureWithheld']);coalesced+=row['coalescedPackets']
  if delivered:
   maxerr=max(maxerr,float(np.linalg.norm(state-delivered['position'])));maxyaw=max(maxyaw,abs(math.atan2(math.sin(yaw-delivered['yaw']),math.cos(yaw-delivered['yaw']))));maxage=max(maxage,now-delivered['capturedAt'])
  cue=x['cue'];reasons[cue['reason']]=reasons.get(cue['reason'],0)+1
  issued=ActorCommand(cue['forwardMetres'],cue['yawRadians'],i,cue['sourceCapturedAt'],cue['reason']);applied=actor.step(i,issued);assert asdict(applied)==x['appliedCommand'];pending=any(c.forward_metres or c.yaw_radians for _,c in actor.pending);assert pending==x['pendingMotion']
  moving=bool(applied.forward_metres or applied.yaw_radians);zero=not(cue['forwardMetres'] or cue['yawRadians']);afterzero+=int(moving and zero);delayexposure+=int(moving and applied.issued_tick<i);clipped+=int(applied.translation_clipped)
  if applied.issued_tick is not None and applied.forward_metres:
   raw=ev[applied.issued_tick]['cue']['forwardMetres'];scaled+=int(abs(applied.forward_metres-raw)>1e-12)
  if zero and not previous_stop:stop_entries+=1
  previous_stop=zero
  if zero and firststop is None:firststop={'tick':i,'reason':cue['reason']}
  actualmoved=bool(np.linalg.norm(a[i+1,2:5]-state)>1e-12 or abs(a[i+1,5]-yaw)>1e-12)
  if actualmoved:lastmotion=i;motionticks.append(i)
  assert lastmotion==x['lastCommittedMotionTick']
  if actualmoved:
   assert x['candidateStateCommitted'] and len(x['contacts'])==2 and all(not c['actualBody']['contact'] and not c['horizontalMargin']['contact'] for c in x['contacts']);assert not x['underbodyGuard']['contact'] and len(x['underbodyGuard']['halfSegments'])==2
   m=x['movement'];mid=(state+a[i+1,2:5])/2;mid[1]=max(q['modelHeightY'] for q in m['supportRows'][1]['probes']);d=float(np.linalg.norm(mid-state)+np.linalg.norm(a[i+1,2:5]-mid));assert abs(d-m['attempted3DDistanceMetres'])<1e-12 and d<=.025000001;dist3d+=d
  if not x['candidateStateCommitted']:assert np.array_equal(a[i+1,2:6],a[i,2:6])
 distance=float(np.linalg.norm(np.diff(a[:,[2,4]],axis=0),axis=1).sum());assert abs(distance-r['actualDistanceMetres'])<1e-10 and abs(dist3d-r['actual3DDistanceMetres'])<1e-10
 assert abs(maxerr-r['maximumDeliveredPoseErrorMetres'])<1e-12 and abs(maxyaw-r['maximumDeliveredYawErrorRadians'])<1e-12 and abs(maxage-r['maximumDeliveredPoseAgeSeconds'])<1e-12
 for key,val in [('captureWithheldTicks',withheld),('ticksWithoutUsableObservation',missing),('coalescedPackets',coalesced),('motionAfterIssuedZeroTicks',afterzero),('translationClippedTicks',clipped)]:assert r['stressCounts'].get(key,0)==val
 retained=0;no_new=0;last_new=None
 for x in ev:
  observation=x['deliveredPose'];no_new+=int(not x['poseDelivery']['newPacketSelected'])
  if observation is not None:
   assert 0<=100+x['tick']/15-observation['capturedAt']<=.5
   if observation['deliveryMode']=='new': last_new=observation.copy()
   else:
    retained+=1;assert last_new is not None
    assert all(observation[k]==last_new[k] for k in observation if k!='deliveryMode')
    assert not x['goalObservationCurrent']
  else: assert x['cue']['forwardMetres']==0 and x['cue']['yawRadians']==0
 assert r['stressCounts'].get('retainedObservationTicks',0)==retained
 assert r['stressCounts'].get('ticksWithoutNewPacket',0)==no_new
 if r['arrival']:
  x=ev[-1];assert x['deliveredPose']['deliveryMode']=='new';assert not x['pendingMotion'] and not(x['appliedCommand']['forward_metres'] or x['appliedCommand']['yaw_radians']);assert x['goalObservationCurrent'] and x['cue']['goalReached'];assert x['deliveredPose']['capturedTick']>lastmotion and x['cue']['sourceCapturedTick']==x['deliveredPose']['capturedTick'];assert np.linalg.norm(a[-1,2:5]-plan['legs'][0]['originalTaskGoal'])<=.35
 if name=='tracking_interruption' and len(ev)>90:
  assert all(ev[i]['poseDelivery']['captureWithheld'] and ev[i]['deliveredPose'] is None for i in range(60,90))
  assert ev[90]['deliveredPose']['capturedTick']==90
 resume=next((i for i in motionticks if i>=90),None) if name=='tracking_interruption' else None
 result={'condition':name,'status':r['status'],'arrival':r['arrival'],'ticks':len(ev),'horizontalMetres':distance,'actual3DMetres':dist3d,'queueReplayExact':True,'CSVEqualsNPZ':True,'maximumPositionErrorMetres':maxerr,'maximumYawErrorRadians':maxyaw,'maximumAgeSeconds':maxage,'retainedObservationTicks':retained,'ticksWithoutNewPacket':no_new,'missingDeliveryTicks':missing,'withheldCaptureTicks':withheld,'coalescedPackets':coalesced,'movingDelayedCommandTicks':delayexposure,'motionAfterIssuedZeroTicks':afterzero,'scaledTranslationTicks':scaled,'translationClippedTicks':clipped,'firstIssuedStop':firststop,'issuedStopEpisodeEntries':stop_entries,'scheduledCaptureDelaysTicks':sorted(set(scheduled_delays)),'reasons':reasons,'firstMovingTickAtOrAfterResume90':resume,'finalPendingMotion':r['finalPendingMotion'],'terminalGoalObservationCurrent':ev[-1]['goalObservationCurrent'],'predictedBodyContacts':r['rejectedPredictedBodyContactEvents'],'predictedUnderbodyContacts':r['rejectedPredictedUnderbodyContactEvents'],'committedBodyContacts':r['actualBodyContactsCommitted'],'resultSHA256':hashlib.sha256((p/'RESULT.json').read_bytes()).hexdigest()};results.append(result)
print(json.dumps(results,indent=2))
(H/'INDEPENDENT_TERMINAL_RECOUNT.json').write_text(json.dumps({'scope':'Recorded evidence recount and deterministic queue replay; no world rerun, no sensor or human safety proof','scheduledConditions':1,'terminalRecordsReviewed':len(results),'results':results},indent=2)+'\n')
