import unittest,math,hashlib,json,sys
from types import SimpleNamespace
from pathlib import Path
import numpy as np
H=Path(__file__).resolve().parent;sys.path.insert(0,str(H));import loop_map as lm;import loop_controller as lc;import loop_episode as le
class FakeModel:
 def __init__(self,p):self.plan=p;self.leg=0;self.revision=p['mapRevision'];self.points=np.array(p['legs'][0]['originalFramePath']);self.cursor=0;self.pending_replan=False;self.replan_failure=None;self.query_receipt=None;self.replanner=None
 def begin_next(self,leg):return lm.GoalRegionMap.begin_next(self,leg)
 def route(self,start,goal):return lm.GoalRegionMap.route(self,start,goal)
 def observe_progress(self,p):return lm.GoalRegionMap.observe_progress(self,p)
 def flag_receipt(self,p,y):return {'lowUnresolvedCells':3,'diagnosticOnly':True}
 def close(self):pass
class Tests(unittest.TestCase):
 def setUp(self):self.p=lm.load_plan()
 def test_fixed45_dimensions(self):self.assertEqual([self.p['geometry'][k]for k in('width','depth','height','margin')],[.45,.3,1.6,0.])
 def test_five_unchanged_original_goals(self):
  f=json.loads((H.parent/'blind-polycam-table-loop-proposals-44/FROZEN.json').read_text());self.assertEqual([x['originalTaskGoal']for x in self.p['legs']],[x['originalGameXYZ']for x in f['anchors'][1:]])
 def test_return_is_original_start(self):np.testing.assert_array_equal(self.p['legs'][-1]['originalTaskGoal'],self.p['start'])
 def test_fixed_native_corners_retained(self):
  for x in self.p['legs']:np.testing.assert_array_equal(x['originalFramePath'][1:-1],x['sourceNativeOriginalFramePath'])
 def test_no_leg_skip(self):
  m=FakeModel(self.p)
  with self.assertRaises(ValueError):m.begin_next(2)
 def test_leg_switch_has_no_actor_state(self):
  m=FakeModel(self.p);m.begin_next(1);self.assertEqual(m.leg,1);self.assertFalse(hasattr(m,'actor'));self.assertTrue(m.pending_replan);self.assertEqual(m.points.shape,(0,3))
 def test_only_exact_goal(self):
  m=FakeModel(self.p)
  with self.assertRaises(ValueError):m.route(np.zeros(3),np.ones(3))
 def test_full3d_arrival_required(self):self.assertFalse(le.arrived({'goalReached':True},False,False,np.array([0.,.36,0.]),np.zeros(3),1.,np.array([1.,0.,0.])))
 def test_motion_blocks_arrival(self):self.assertFalse(le.arrived({'goalReached':True},True,False,np.zeros(3),np.zeros(3),1.,np.array([1.,0.,0.])))
 def test_fifo_blocks_arrival(self):self.assertFalse(le.arrived({'goalReached':True},False,True,np.zeros(3),np.zeros(3),1.,np.array([1.,0.,0.])))
 def test_zero_motion_is_not_arrival(self):self.assertFalse(le.arrived({'goalReached':True},False,False,np.zeros(3),np.zeros(3),0.,np.array([1.,0.,0.])))
 def test_valid_arrival(self):self.assertTrue(le.arrived({'goalReached':True},False,False,np.zeros(3),np.zeros(3),1.,np.array([1.,0.,0.])))
 def test_western_task_exclusion_removed(self):
  c=lc.Controller();c.plan=self.p;c.model=FakeModel(self.p);c.revision=self.p['mapRevision'];c.goal=np.array(self.p['legs'][0]['originalTaskGoal']);c.route_goal=c.goal.copy()
  pos=np.array([-3.1,0.,-2.]);c.model.route=lambda a,b:{'complete':True,'points':[a.tolist(),(a+np.array([.3,0.,0.])).tolist()],'projectedStart':a.tolist(),'projectedGoal':b.tolist()}
  obs={'kind':'simulated-physics-body-pose','position':pos.tolist(),'yaw':0.,'capturedAt':100.,'capturedTick':0,'generation':0,'sessionID':'stage76-temporal-jitter-seed72000','deliveryMode':'new','mapRevision':c.revision};r=c.consume({'command':'tick','tick':0,'now':100.,'deliveredPose':obs,'releasedPoses':[obs]})
  self.assertTrue(r['historicalWesternTaskExclusionRemoved']);self.assertNotEqual(r['reason'],'excludedWesternROISweepWithheld');self.assertGreater(r['forwardMetres'],0.);self.assertEqual(r['phoneFlagReceipt']['lowUnresolvedCells'],3)
 def test_changed_plan_rejects(self):
  with self.assertRaises(ValueError):lm.load_plan(lm.PLAN,'0'*64)
 def test_global_plane_provenance_unchanged(self):
  f=self.p['floorPolicy'];self.assertTrue(f['oneFixedPlaneAllLegs']);self.assertFalse(f['newPlaneRefit']);self.assertTrue(f['noSillExceptions'])
 def test_next_leg_requires_matching_goal(self):
  c=lc.Controller();c.plan=self.p;c.model=FakeModel(self.p);c.goal=np.array(self.p['goal'])
  with self.assertRaises(ValueError):c.consume({'command':'beginNextLeg','leg':1,'goal':[0,0,0]})
 def test_actual_winding_distinguishes_backtracking(self):
  centre=np.zeros(3);loop=np.array([[1,0,0],[0,0,-1],[-1,0,0],[0,0,1],[1,0,0.]])
  self.assertAlmostEqual(le.actual_winding(loop,centre)['winding'],-1.)
  back=np.vstack([loop[:3],loop[1::-1]]);self.assertAlmostEqual(le.actual_winding(back,centre)['winding'],0.)
 def test_winding_closure_not_counted_as_motion(self):
  p=np.array([[1,0,0],[0,0,-1],[-1,0,0],[0,0,1],[.9,0,.1]])
  r=le.actual_winding(p,np.zeros(3));self.assertTrue(r['closingSegmentWasNotExecuted']);self.assertAlmostEqual(r['mathematicalClosingGapHorizontalMetres'],math.sqrt(.02));self.assertEqual(r['actualTraceSamples'],5)
 def overlap_fakes(self,old_known=True,new_known=True,new_plane=None):
  from test_local_support import row
  raw=row()
  base=SimpleNamespace(support_probes=lambda p,y:raw)
  old=SimpleNamespace(is_ground=lambda i:old_known,plane_coefficients=np.zeros(3))
  new=SimpleNamespace(is_ground=lambda i:new_known,plane_coefficients=np.zeros(3)if new_plane is None else np.array(new_plane))
  return le.overlap_admission(base,old,new,np.zeros(3),0.)
 def test_overlap_known_same_plane_accepts(self):self.assertTrue(self.overlap_fakes()['accepted'])
 def test_overlap_old_unknown_rejects(self):self.assertFalse(self.overlap_fakes(False,True)['accepted'])
 def test_overlap_new_unknown_rejects(self):self.assertFalse(self.overlap_fakes(True,False)['accepted'])
 def test_overlap_provenance_plane_change_is_not_physical_veto(self):self.assertTrue(self.overlap_fakes(new_plane=[0,0,.001])['accepted'])
 def test_winding_through_point_is_undefined(self):
  r=le.actual_winding(np.array([[1.,0,0],[-1,0,0],[1,0,0]]),np.zeros(3));self.assertFalse(r['defined']);self.assertIsNone(r['winding'])
 def test_winding_nonfinite_rejects(self):
  with self.assertRaises(ValueError):le.actual_winding([[1,0,0],[float('nan'),0,0]],np.zeros(3))
 def test_table_point_full_xyz_conversion(self):
  w=H.parent;r=json.loads((w/'blind-polycam-table-loop-proposals-44/RESULT.json').read_text());q=np.array(r['tabletopDiagnostic']['centroidGameXYZ'])
  with np.load(w/'blind-split-candidate-game-03/inputs/koivu_5cm_v2_pipeline2_out.npz')as z:oldR=z['R'];oldt=z['t']
  with np.load(w/'blind-pose-experiments-review-17/upstream/pose-consistency/runs/koivu_floorfix/pipeline2_out.npz')as z:newR=z['R'];newt=z['t']
  old=((np.array([q[0],-q[2],q[1]])-newt)@newR)@oldR.T+oldt
  np.testing.assert_allclose(self.p['tableWindingPointOriginalXYZ'],[old[0],old[2],-old[1]],atol=1e-12,rtol=0)
 def test_all_preserved_native_heights_fit_existing_controller_contract(self):
  self.assertTrue(all(abs(q[1])<=.05 for l in self.p['legs']for q in l['originalFramePath']))
 def test_next_leg_ipc_ack_has_explicit_no_physical_authority(self):
  c=lc.Controller();c.plan=self.p;c.model=FakeModel(self.p);c.goal=np.array(self.p['goal'])
  r=c.consume({'command':'beginNextLeg','leg':1,'goal':self.p['legs'][1]['originalTaskGoal']});self.assertIs(r.get('physicalAuthority'),False);self.assertEqual(c.model.leg,1)
 def test_json_numpy_bool(self):self.assertIs(le.jsonable(np.bool_(True)),True)
if __name__=='__main__':unittest.main()
