# 76 — Preserve released measurements for waypoint progress

Stage74 is a preserved failed candidate. It retained old poses but discarded
coalesced observations from controller input. In its saved failure, capture61 was
within the unchanged1cm corner-consumption radius; it was released alongside
59,60,62 and discarded in favor of62. The cursor therefore never advanced.

This separate development candidate changes only progress accounting. It does
not widen a radius, move a waypoint, change the map/body/floor or feed evaluator
truth into the controller. It retains74's original-timestamp unexpired-pose policy,
same jitter2±2ticks/seed72000, first source leg and all physical gates. The current
session ID is a distinct fixed76 episode identity; prior queues are not reused.

## Batch contract
Each controller tick receives the complete released observation batch in the
transport's original order, plus the selected steering observation. Historical
observations retain original source ticks/timestamps and are marked `new` when
first released. No sorting, interpolation or inferred crossings are performed.

Validate the ENTIRE batch before any cursor mutation: list size≤64, strict
increasing capture tick/time newer than last accepted capture, finite fields,
matching session/map revision/generation, no future samples and age≤existing0.5s.
An invalid/stale/out-of-order batch fails closed with zero command and no partial
progress update. For a nonempty valid batch, the steering pose must be exactly its
newest member. For an empty batch, only74's exact previously accepted retained
pose (unexpired original timestamp) orNone is legal.

After validation, process each released measurement in capture order for source
cursor advancement using exactly the original horizontal distance≤1cm criterion.
Each observation can consume only the currently next waypoint(s) actually within
that radius; it cannot skip an unobserved waypoint. Then issue ONE steering command
from the newest selected pose, never one command per historical sample. Retained
packets do not invent new history. Cursor changes and capture IDs are logged.

The goal cue is calculated only from the newest selected observation. Historical
or coalesced goal observations cannot authorize arrival. The evaluator still
requires a NEW accepted post-last-motion capture, original35cm true-goal region,
positive travel, zero applied motion and no pending nonzero commands. Physical
world truth remains evaluator-only; support assistance is explicitly unchanged.

## Scope and failure handling
The exact74 capture61 fixture must advance the next corner without enlarging its
radius. Other fixtures cover stale/out-of-order/wrong-generation batches, atomic
rejection, multiple measured waypoints, no skipping unobserved corners, newest-only
steering and prohibition of historical-goal arrival. Original nominal first-leg
command parity and all physical/low-object tests remain.

This addresses lost measured progress, not every old-yaw/overshoot problem.
Retained stale coordinates can still issue imperfect commands. Any predicted
collision, support rejection, non-arrival or budget failure is preserved and not
reinterpreted as a sensing success. The reference oracle veto is not a phone
obstacle detector. Ground contacts remain unmeasured.

One temporal-jitter pilot only, after independent gate and parent authorization:
450ticks,180CPU/240wall seconds,3.5GiB RSS,2MiB output,768MiB reserve and fresh
4.3GiB available RAM. Same exact CSV/XZ evidence and no overwrite. No tuning after
outcome. The20distinctpair×5 matrix is still separate and unexecuted.
