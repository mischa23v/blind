# Keeping measured progress restored the short jitter journey

**The candidate arrived after201ticks and2.840m**, with the actuator queue drained
and no predicted body/underbody contacts or support veto. The unchanged stage74
candidate failed at450ticks after1.240m; the conservative stage73 jitter baseline
arrived after370ticks with193 no-new-pose stop ticks.

![Recorded trajectories for the same short route](PAIRED_JITTER_PATHS.png)

| Same jitter seed and route | Stage73 | Stage74 | Stage76 |
|---|---:|---:|---:|
| Policy | Stop without new packet | Retain pose, discard history | Retain pose, preserve measured progress |
| Arrival | Yes | No | **Yes** |
| Ticks | 370 | 450 (limit) | **201** |
| Horizontal distance | 2.800m | 1.240m | 2.840m |
| No-usable-pose stop ticks | 193 | 2 | 2 |
| All zero-command ticks, including goal stop | 195 | 2 | 5 |
| Zero-command episode entries, including goal | 115 | 1 | 2 |
| Maximum delivered position error | 6cm | 8cm | 8cm |
| Maximum delivered yaw error | 3° | 4° | 4° |
| Predicted body/underbody contacts | 0 | 0 | 0 |

Stop **ticks** and stop **episodes** are different counts. This is a development
comparison on one short route/seed, not independent held-out robustness evidence.

## The actual correction

The transport already retained all released observations in evidence. Stage74
passed only the newest to the controller. At delivery tick63, capture61 had been
within the original1cm waypoint-consumption radius, but was coalesced away when
capture62 arrived in the same batch. The cursor never moved past that corner.

Stage76 validates the whole released batch in its original strict capture order,
before mutating progress. It uses each valid measured position for the unchanged
source cursor criterion, then issues **one steering command from the newest pose**.
It does not interpolate a crossing, predict a pose or widen the radius.

The executed record shows:
- Tick2: measured capture0 consumes the two coincident source-start entries.
- **Tick63: measured capture61 advances cursor2→3**, resolving the identified loss.
- Tick128: measured capture124 advances cursor3→4 at the next source corner.
- Final arrival uses a new accepted post-motion observation and drained FIFO;
  a historical/coalesced goal observation cannot authorize completion.

Coordinates, timestamps, source ticks and generation/session identity are preserved.
An invalid, stale or out-of-order batch is rejected atomically, without partial
progress. Steering does not replay one command per historical packet. Retained
packets remain subject to the original0.5s freshness rule and exact cached identity.
The physical evaluator never supplies a correcting pose to the controller.

## Physical rules and outcome

The same45×30×160cm zero-margin body, source path/exclusion, immutable floor IDs,
local measured support law, full3D body sweeps and underbody guards were retained.
No obstacle, floor band, clearance margin or waypoint was modified. Actual3D travel
was2.841876m; final original-goal error was29.1019cm, inside the unchanged35cm region.
Maximum capture age stayed266.7ms;106 ticks used an unexpired retained observation.

The bounded process took75.89CPU/75.00wall seconds, within450ticks/180CPU/240wall,
3.5GiB RSS and2MiB output. This was one attempt. Failed stage74 and all stage73
outcomes remain preserved; no parameters were changed after this result.

Zero committed contacts alone would not establish success: the reference evaluator
vetoes predicted hazards. Here no predicted body/underbody contact or support veto
occurred, but that is still only one short assisted simulation. Floor contact
events are unmeasured. Source ROI and reference-floor assistance remain explicit.

## Evidence

- `FROZEN.json`:613 input hashes, SHA-256
  `0cdabfc606692b9fb3bdaaf921cb51e51b5e620bd9abb19a09d47890046a2695`.
- `INDEPENDENT_PRELAUNCH_REVIEW.json`:101 passing fixtures, including the exact
  dropped-capture61 case, invalid-batch atomic rejection and historical-goal veto.
- `pilot-temporal_jitter/RUN_RECEIPT.json`: bounded process record.
- `pilot-temporal_jitter/result/RESULT.json`: terminal outcome and counters.
- Exact CSV/NPZ traces and full XZ tick/geometry evidence retain every batch and
  cursor update, selected steering observation and applied command.
- `PAIRED_COMPARISON.json`, `compare_saved_pilots.py` and `PAIRED_JITTER_PATHS.png`
  derive the comparison solely from preserved executed evidence.
- Independent terminal review checks the batch/actor replay, recorded physics
  and newest-only causal arrival without a second heavy world run.

This fixes the demonstrated lost-progress defect for this pilot. It does not
establish live iPhone navigation, general delayed-control stability, child safety,
100 episodes or the20distinct route-pair matrix. Those remain separate work.
