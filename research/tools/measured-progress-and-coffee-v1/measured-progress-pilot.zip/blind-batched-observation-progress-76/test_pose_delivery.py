import unittest,math,copy
from unittest.mock import patch
import numpy as np
from pose_delivery import *
from impairments import ActorFIFO,ActorProfile,ActorCommand
import loop_controller as lc
from test_loop_contract import FakeModel
import loop_map as lm
class Tests(unittest.TestCase):
 def packet(self,tick=0,generation=0):return {'kind':'simulated-physics-body-pose','position':[0.,0.,0.],'yaw':0.,'capturedAt':100+tick/15,'capturedTick':tick,'generation':generation,'sessionID':'stage76-temporal-jitter-seed72000','deliveryMode':'new','mapRevision':'r'}
 def test_nominal_exact_capture_parity(self):
  q=PoseDelivery(condition_by_id('nominal'),72000)
  for i in range(10):
   state=np.array([i*.02,.003,1]);p,r=q.capture_and_release(i,100+i/15,state,.2,'r',0);np.testing.assert_array_equal(p['position'],state);self.assertEqual(p['capturedTick'],i);self.assertEqual(p['capturedAt'],100+i/15);self.assertEqual(r['coalescedPackets'],0)
 def test_delayed_pose_not_current_truth(self):
  c=condition_by_id('nominal');c['poseDelivery']['delay_ticks']=3;q=PoseDelivery(c,72000)
  for i in range(4):p,r=q.capture_and_release(i,100+i/15,[i,0,0],0,'r',0)
  self.assertEqual(p['position'],[0,0,0]);self.assertEqual(p['capturedAt'],100);self.assertEqual(p['capturedTick'],0);self.assertEqual(r['capture']['position'],[3,0,0])
 def test_no_delivery_means_none_not_held_pose(self):
  q=PoseDelivery(condition_by_id('tracking_interruption'),72000)
  for i in range(91):
   p,r=q.capture_and_release(i,100+i/15,[i,0,0],0,'r',0)
   if 67<=i<90:self.assertIsNone(p);self.assertTrue(r['captureWithheld'])
  self.assertEqual(p['capturedTick'],90);self.assertEqual(p['position'],[90,0,0])
 def test_seed_jitter_reproducible_no_reordering(self):
  def run():
   q=PoseDelivery(condition_by_id('temporal_jitter'),72000);return[q.capture_and_release(i,100+i/15,[i,0,0],0,'r',0)for i in range(100)]
  a=run();self.assertEqual(a,run());ticks=[x[0]['capturedTick']for x in a if x[0]];self.assertEqual(ticks,sorted(ticks))
 def test_wrong_generation_revision_future_and_duplicate_rejected(self):
  p=self.packet(3)
  for kwargs in [('r',1,3,100.2,-1,-math.inf),('bad',0,3,100.2,-1,-math.inf),('r',0,2,100.2,-1,-math.inf),('r',0,3,100.2,3,100.2)]:self.assertFalse(validate_delivered_pose(p,*kwargs)[0])
 def test_timestamp_cannot_be_freshened(self):
  p=self.packet(0);p['capturedAt']=100.2;self.assertFalse(validate_delivered_pose(p,'r',0,3,100.2,-1,-math.inf)[0]);p=self.packet(0);self.assertFalse(validate_delivered_pose(p,'r',0,10,100+10/15,-1,-math.inf)[0])
 def test_wrong_delivery_arrival_rejected(self):
  p=self.packet(4);cue={'goalReached':True,'sourceGeneration':0,'sourceCapturedTick':4,'sourceDeliveryMode':'new'}
  self.assertTrue(goal_observation_current(cue,p,0,3));self.assertFalse(goal_observation_current(cue,p,0,4));self.assertFalse(goal_observation_current(cue,p,1,3));self.assertFalse(goal_observation_current(cue,None,0,3));cue['sourceCapturedTick']=3;self.assertFalse(goal_observation_current(cue,p,0,3))
 def test_queued_motion_not_purged_by_stop(self):
  actor=ActorFIFO(ActorProfile(reaction_delay_ticks=3));out=[]
  for i in range(7):out.append(actor.step(i,ActorCommand(.02 if i<3 else 0.,0.,i)))
  self.assertEqual([x.forward_metres for x in out],[0.,0.,0.,.02,.02,.02,0.])
 def test_extra_motion_retains_cap(self):
  actor=ActorFIFO(ActorProfile(translation_scale=1.15));self.assertAlmostEqual(actor.step(0,ActorCommand(.02,0,0)).forward_metres,.023);a=actor.step(1,ActorCommand(.025,0,1));self.assertEqual(a.forward_metres,.025);self.assertTrue(a.translation_clipped)
 def test_controller_stale_stop_and_generation_guard(self):
  p=lm.load_plan();c=lc.Controller();c.plan=p;c.model=FakeModel(p);c.revision=p['mapRevision'];c.goal=np.array(p['goal']);c.route_goal=c.goal.copy()
  obs=self.packet(0);obs['mapRevision']=c.revision;obs['generation']=1
  r=c.consume({'command':'tick','tick':0,'now':100.,'deliveredPose':obs,'releasedPoses':[obs]});self.assertEqual(r['reason'],'wrongObservationGeneration');self.assertEqual(r['forwardMetres'],0.);self.assertEqual(c.last_capture_tick,-1)
  obs['generation']=0
  r=c.consume({'command':'tick','tick':1,'now':101.,'deliveredPose':obs,'releasedPoses':[obs]});self.assertEqual(r['reason'],'staleOrInvalidSimulatedPose');self.assertEqual(r['forwardMetres'],0.)
 def test_malformed_position_fails_closed_without_exception(self):
  for value in [None,[],['bad',0,0],[0,float('nan'),0]]:
   p=self.packet();p['position']=value;self.assertFalse(validate_delivered_pose(p,'r',0,0,100.,-1,-math.inf)[0])
 def test_nominal_controller_replays_saved_first_leg_commands(self):
  import lzma,json
  from pathlib import Path
  p=lm.load_plan();c=lc.Controller();c.consume({'command':'initialize','planPath':str(lm.PLAN),'planSHA256':lm.PLAN_SHA});c.consume({'command':'beginRun','goal':p['goal']})
  base=Path(__file__).resolve().parent.parent/'blind-tabletop-exclusion-loop-67/run-01/result'
  with np.load(base/'ACTOR_TRACE.npz')as z:trace=z['trace']
  try:
   with lzma.open(base/'TICK_EVIDENCE.jsonl.xz','rt')as f:
    for tick,line in enumerate(f):
     if tick>171:break
     old=json.loads(line)['cue'];a=trace[tick];obs={'kind':'simulated-physics-body-pose','position':a[2:5].tolist(),'yaw':float(a[5]),'capturedAt':100+tick/15,'capturedTick':tick,'generation':0,'sessionID':'stage76-temporal-jitter-seed72000','deliveryMode':'new','mapRevision':p['mapRevision']}
     new=c.consume({'command':'tick','tick':tick,'now':100+tick/15,'deliveredPose':obs,'releasedPoses':[obs]})
     for key in ['forwardMetres','yawRadians','goalReached','reason']:self.assertEqual(new[key],old[key],(tick,key))
  finally:c.close()
if __name__=='__main__':unittest.main()
