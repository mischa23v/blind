import unittest,json,lzma,copy,math
from pathlib import Path
import numpy as np
from observation_batch import validate_batch
from pose_delivery import SESSION_ID,goal_observation_current
import loop_map as lm
import loop_controller as lc
from test_loop_contract import FakeModel

def observation(t,p=(0.,0.,0.),revision='r',generation=0):return {'kind':'simulated-physics-body-pose','position':list(p),'yaw':0.,'capturedTick':t,'capturedAt':100+t/15,'generation':generation,'mapRevision':revision,'sessionID':SESSION_ID,'deliveryMode':'new'}
class Tests(unittest.TestCase):
 def test_exact_capture61_reproducer_advances_unchanged_radius(self):
  h=Path(__file__).resolve().parent.parent/'blind-retained-pose-jitter-pilot-74/pilot-temporal_jitter/result'
  with lzma.open(h/'TICK_EVIDENCE.jsonl.xz','rt')as f:
   for line in f:
    e=json.loads(line)
    if e['tick']==63:break
  batch=[dict(r['packet']['pose'],deliveryMode='new',sessionID=SESSION_ID)for r in e['poseDelivery']['released']];self.assertEqual([q['capturedTick']for q in batch],[59,60,61,62]);selected=batch[-1]
  valid,reason,checked=validate_batch(batch,selected,selected['mapRevision'],0,63,100+63/15,58,100+58/15,None);self.assertTrue(valid)
  plan=lm.load_plan();m=FakeModel(plan);m.points=np.array(e['cue']['nativeCandidatePoints']);m.cursor=0
  old=m.cursor;self.assertGreater(np.linalg.norm((m.points[0]-selected['position'])[[0,2]]),.01)
  receipts=[m.observe_progress(p['position'])for p in checked];self.assertEqual(m.cursor,old+1);self.assertEqual(receipts[2]['cursorAfter'],1);self.assertEqual(receipts[1]['cursorAfter'],0)
 def test_stale_out_of_order_wrong_generation_reject_entire_batch(self):
  good=[observation(2),observation(3)]
  for bad in [[good[1],good[0]],[good[0],observation(3,generation=1)],[observation(0),good[1]],[good[0],good[0]]]:
   now=100+10/15 if bad[0]['capturedTick']==0 else 100+3/15
   ok,_,rows=validate_batch(bad,bad[-1],'r',0,10 if bad[0]['capturedTick']==0 else 3,now,-1,-math.inf,None);self.assertFalse(ok);self.assertEqual(rows,[])
 def test_only_newest_batch_item_may_steer(self):
  b=[observation(1),observation(2)];self.assertFalse(validate_batch(b,b[0],'r',0,2,100+2/15,-1,-math.inf,None)[0])
 def test_multiple_waypoints_consumed_in_measured_order(self):
  m=FakeModel(lm.load_plan());m.points=np.array([[0,0,0],[.1,0,0],[.2,0,0],[.3,0,0]]);m.cursor=0
  b=[observation(i,[i*.1,0,0])for i in range(3)];ok,_,rows=validate_batch(b,b[-1],'r',0,2,100+2/15,-1,-math.inf,None);self.assertTrue(ok)
  for p in rows:m.observe_progress(p['position'])
  self.assertEqual(m.cursor,3)
 def test_path_cannot_skip_unobserved_waypoint(self):
  m=FakeModel(lm.load_plan());m.points=np.array([[0,0,0],[.1,0,0],[.2,0,0]]);m.cursor=0;m.observe_progress([.2,0,0]);self.assertEqual(m.cursor,0)
 def test_no_radius_expansion_at_just_outside(self):
  m=FakeModel(lm.load_plan());m.points=np.array([[0,0,0]]);m.cursor=0;m.observe_progress([.010001,0,0]);self.assertEqual(m.cursor,0)
 def test_historical_goal_observation_cannot_authorize_arrival(self):
  p=lm.load_plan();c=lc.Controller();c.plan=p;c.model=FakeModel(p);c.revision=p['mapRevision'];c.goal=np.array(p['goal']);c.route_goal=c.goal.copy();c.tick=1
  old=observation(1,c.goal,revision=c.revision);new=observation(2,c.goal+np.array([1.,0,0]),revision=c.revision)
  r=c.consume({'command':'tick','tick':2,'now':100+2/15,'deliveredPose':new,'releasedPoses':[old,new]});self.assertFalse(r['goalReached']);self.assertFalse(goal_observation_current(r,new,0,0));self.assertEqual(r['sourceCapturedTick'],2)
 def test_invalid_batch_does_not_partially_mutate_cursor(self):
  p=lm.load_plan();c=lc.Controller();c.plan=p;c.model=FakeModel(p);c.revision=p['mapRevision'];c.goal=np.array(p['goal']);c.route_goal=c.goal.copy();c.tick=1
  b=[observation(1,c.model.points[0],c.revision),observation(2,c.model.points[0],c.revision,generation=1)];before=c.model.cursor
  r=c.consume({'command':'tick','tick':2,'now':100+2/15,'deliveredPose':b[-1],'releasedPoses':b});self.assertEqual(c.model.cursor,before);self.assertEqual(r['forwardMetres'],0.);self.assertEqual(c.last_capture_tick,-1)
 def test_retained_cannot_be_inserted_in_history(self):
  p=observation(0);p['deliveryMode']='retained';self.assertFalse(validate_batch([p],p,'r',0,0,100.,-1,-math.inf,None)[0])
 def test_new_packet_without_history_or_oversized_batch_rejects(self):
  p=observation(0);self.assertFalse(validate_batch([],p,'r',0,0,100.,-1,-math.inf,None)[0]);self.assertFalse(validate_batch([p]*65,p,'r',0,0,100.,-1,-math.inf,None)[0])
if __name__=='__main__':unittest.main()
