import os,sys,time,json,hashlib,resource
os.environ['OPENBLAS_NUM_THREADS']='1'
sys.path.insert(0,'/workspace/shared/blind-perception-private-replay/runtime')
import cv2,numpy as np
from pathlib import Path
cv2.setNumThreads(1);cv2.setRNGSeed(77)
resource.setrlimit(resource.RLIMIT_CPU,(120,120))
OUT=Path(__file__).resolve().parent; W=OUT.parent.parent
P=json.loads((OUT/'PROTOCOL.json').read_text()); start=time.process_time()
def budget():
 assert resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024 < 1024**3
 s=os.statvfs(OUT);assert s.f_bavail*s.f_frsize >= 768*1024**2
 assert sum(x.stat().st_size for x in OUT.iterdir() if x.is_file()) < 3*1024**2
budget()
metadata=W/'blind-mushroom-koivu-acquisition-01/selected/room_datasets/koivu/iphone/long_capture/transformations.json'
frames=json.load(open(metadata))['frames']
F={int(Path(f['file_path']).stem.split('_')[-1]):f for f in frames}
queries=P['query_frames']; train=[i for i in range(1,295,8) if i in F and not any(a-5<=i<=b+5 for a,b in P['query_blocks_1based'])]
# Query metadata stripped of recorded pose before estimator enters.
Q={i:{k:F[i][k] for k in ['fl_x','fl_y','cx','cy','w','h']} for i in queries}
T={i:F[i] for i in train};del F,frames
rgb=W/'blind-open3d-author-baseline-10/author-inputs/selected/images'; dep=W/'blind-koivu-game-07/map/depths'
sift=cv2.SIFT_create(nfeatures=1000); matcher=cv2.BFMatcher(cv2.NORM_L2)
def rgbpath(i):
 p=rgb/f'frame_{i:05d}.jpg'
 return p if p.exists() else W/'koivu-room-photo-catalog/missing-rgb'/p.name
def features(i):
 image=cv2.imread(str(rgbpath(i)),cv2.IMREAD_GRAYSCALE);assert image is not None
 im=cv2.resize(image,None,fx=.5,fy=.5,interpolation=cv2.INTER_AREA)
 k,d=sift.detectAndCompute(im,None);return k,d,im.shape
refs=[];inputs={str(metadata.relative_to(W)):hashlib.sha256(metadata.read_bytes()).hexdigest()}
for i in train:
 budget();f=T[i];k,d,shape=features(i); depth=cv2.imread(str(dep/f'frame_{i:05d}.png'),cv2.IMREAD_UNCHANGED)
 assert depth.shape==(f['h'],f['w'])
 p=[];desc=[];pose=np.array(f['transform_matrix'])
 for j,kp in enumerate(k):
  u,v=np.array(kp.pt)*2; x,y=int(round(u)),int(round(v))
  if not (2<=x<f['w']-2 and 2<=y<f['h']-2):continue
  patch=depth[y-2:y+3,x-2:x+3].astype(float)/1000;z=depth[y,x]/1000
  if not (.3<=z<=5 and patch.min()>0 and np.ptp(patch)<=.1):continue
  # OpenGL camera right/up/back, vs CV right/down/forward.
  cam=np.array([(u-f['cx'])/f['fl_x']*z,-(v-f['cy'])/f['fl_y']*z,-z])
  p.append(pose[:3,:3]@cam+pose[:3,3]);desc.append(d[j])
 if p: refs.append((i,np.array(p,np.float32),np.array(desc,np.float32)))
 for path in [rgbpath(i),dep/f'frame_{i:05d}.png']: inputs[str(path.relative_to(W))]=hashlib.sha256(path.read_bytes()).hexdigest()
results=[]
for i in queries:
 budget();k,d,shape=features(i);candidates=[]
 for ti,points,descriptors in refs:
  good=[pair[0] for pair in matcher.knnMatch(d,descriptors,k=2) if len(pair)==2 and pair[0].distance<.7*pair[1].distance]
  candidates.append((len(good),ti,points,good))
 candidates.sort(key=lambda a:-a[0]);attempts=[];f=Q[i]
 for count,ti,points,good in candidates[:3]:
  row={'reference_frame':ti,'matches':count,'accepted':False,'inliers':0}
  if count>=6:
   obj=np.array([points[m.trainIdx] for m in good],np.float32);img=np.array([k[m.queryIdx].pt for m in good],np.float32)
   K=np.array([[f['fl_x']/2,0,f['cx']/2],[0,f['fl_y']/2,f['cy']/2],[0,0,1.]])
   ok,rv,tv,idx=cv2.solvePnPRansac(obj,img,K,None,iterationsCount=1000,reprojectionError=3,confidence=.999,flags=cv2.SOLVEPNP_EPNP)
   if ok and idx is not None:
    ix=idx.ravel();span=np.ptp(img[ix],axis=0)/np.array([shape[1],shape[0]])
    R=cv2.Rodrigues(rv)[0];C=-R.T@tv.ravel();Rc=R.T@np.diag([1,-1,-1]);proj=cv2.projectPoints(obj[ix],rv,tv,K,None)[0][:,0,:]
    row.update(inliers=len(ix),inlier_fraction=len(ix)/count,span=span.tolist(),median_reprojection_px=float(np.median(np.linalg.norm(proj-img[ix],axis=1))),camera_position=C.tolist(),camera_rotation_gl=Rc.tolist(),accepted=bool(len(ix)>=20 and len(ix)/count>=.35 and min(span)>=.2))
  attempts.append(row)
 chosen=max(attempts,key=lambda a:a['inliers']);row=dict(chosen);row.update(frame=i,keypoints=len(k),ambiguous=False)
 for alt in attempts:
  if row['accepted'] and alt['accepted']:
   distance=np.linalg.norm(np.array(row['camera_position'])-alt['camera_position']);angle=np.degrees(np.arccos(np.clip((np.trace(np.array(row['camera_rotation_gl']).T@np.array(alt['camera_rotation_gl']))-1)/2,-1,1)))
   if distance>.5 or angle>15:row['ambiguous']=True
 if row['ambiguous']:row['accepted']=False
 row['candidates']=attempts;results.append(row)
 path=rgbpath(i);inputs[str(path.relative_to(W))]=hashlib.sha256(path.read_bytes()).hexdigest()
 print(json.dumps(row),flush=True)
# Save estimates before loading withheld scoring poses.
(OUT/'ESTIMATES.json').write_text(json.dumps(results,indent=2))
G={int(Path(f['file_path']).stem.split('_')[-1]):np.array(f['transform_matrix']) for f in json.load(open(metadata))['frames']}
for r in results:
 if 'camera_position' not in r:continue
 g=G[r['frame']];R=np.array(r['camera_rotation_gl']);r['position_error_m']=float(np.linalg.norm(np.array(r['camera_position'])-g[:3,3]))
 r['rotation_error_deg']=float(np.degrees(np.arccos(np.clip((np.trace(R.T@g[:3,:3])-1)/2,-1,1))))
 # Heading around exported Z-up world, optical forward -camera Z.
 h=np.arctan2(-R[1,2],-R[0,2]);gt=np.arctan2(-g[1,2],-g[0,2]);r['heading_error_deg']=float(abs(np.degrees(np.arctan2(np.sin(h-gt),np.cos(h-gt)))))
 r['false_accepted']=bool(r['accepted'] and (r['position_error_m']>.25 or r['rotation_error_deg']>10))
result={'protocol_sha256':hashlib.sha256((OUT/'PROTOCOL.json').read_bytes()).hexdigest(),'opencv':cv2.__version__,'train_frames':train,'train_landmarks':sum(len(x[1]) for x in refs),'queries':results,'cpu_seconds':time.process_time()-start,'max_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,'input_sha256':inputs}
(OUT/'RESULTS.json').write_text(json.dumps(result,indent=2));print('DONE',result['cpu_seconds'],result['max_rss_bytes'])
