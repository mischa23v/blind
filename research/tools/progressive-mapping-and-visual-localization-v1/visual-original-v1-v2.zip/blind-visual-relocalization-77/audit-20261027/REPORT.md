# Koivu RGB-only query relocalization: verified development result

## Result

The supplied RGB-D map can localize one of these eight query photos, but this is not yet a dependable localization system. The combined-landmark baseline accepted **0/8**; selecting among separate reference-image PnP candidates accepted **1/8**. The accepted frame 50 differs from its withheld exported camera pose by **0.01974 m / 0.2525° full rotation / 0.1881° optical heading**. The other seven were rejected. No false acceptance occurred in this tiny sample; that does not establish a false-acceptance rate or safety.

| Frame | Candidate-v2 accepted | Inliers | Position error (m) | Rotation error (°) |
|---|---:|---:|---:|---:|
|50|yes|25|0.01974|0.2525|
|58|no|13|0.3193|3.7948|
|120|no|10|0.1497|0.4049|
|128|no|0|no pose|no pose|
|190|no|6|6.5800|152.4390|
|198|no|0|no pose|no pose|
|260|no|13|0.1170|2.4033|
|268|no|0|no pose|no pose|

Rejected poses must never become route inputs. Some are close; others are catastrophically wrong. In the combined variant frame 198 is approximately 350 m wrong. Do not relax the gates to rescue these examples.

## What was actually tested

- 20 reference frames, 5,287 depth-backed SIFT landmarks; eight fixed query frames from four guarded blocks of the same processed recording.
- Query estimator uses RGB and intrinsics; reference-map construction uses reference RGB, depth, and supplied reference camera poses. No query depth, all-frame mesh, or FARO data is used.
- Half-resolution SIFT (at most 1,000 features), BF L2 ratio 0.7, OpenCV 4.14.0 EPNP RANSAC (1,000 iterations, 3 px, confidence 0.999, seed 77).
- Acceptance unchanged: at least 20 inliers, fraction at least 0.35, and inlier bounding box spanning at least 20% of image width and height. V2 evaluates top-three reference images by match count, selects highest inlier count, rejects conflicting accepted candidates beyond 0.5 m or 15°.
- Fixed frames are NOT evidenced as a random sample. V2 is development on the same eight frames, NOT a new holdout.
- Poses were removed from query dictionaries and estimates saved before scoring reload. However the combined metadata file was initially parsed in the estimator process. This is code-level information separation, not a separately isolated blind input package. Reference poses may themselves include globally optimized information from the full recording.
- Full camera rotation and optical heading are not body heading. Phone-to-body orientation, floor registration, traversable connector and continuous deviation remain untested here.

## Reproducibility verification

On 2026-10-27 all 49 input hashes in EACH original result matched the current local files; frozen protocol hashes matched; saved estimates matched the pre-scoring fields in results. Both variants were rerun without changing algorithms, parameters, inputs, or seed. Only output/workspace paths changed to preserve original files. **Estimates matched byte-for-byte and all result fields except CPU/RSS matched exactly.** See `VERIFICATION.json` and rerun folders. Original runtimes: 2.31 / 3.39 CPU seconds, approximately 97.8 MB peak RSS. Reruns: 2.57 / 2.96 CPU seconds, approximately 97.9 MB. No download, model installation, external push, or original-file overwrite occurred.

Commands from workspace root:

```sh
python blind-visual-relocalization-77/audit-20261027/combined/run.py
python blind-visual-relocalization-77/audit-20261027/candidate/run.py
```

These overwrite only the audit rerun outputs. Source depends on `/workspace/shared/blind-perception-private-replay/runtime` and source image/depth/metadata paths recorded in each RESULTS.json. `MANIFEST.json` hashes original and audited artifacts plus runtime implementation; original RESULTS.json contains input hashes. There is no applicable AGENTS.md in the task directory or its workspace ancestry (checked).

## Next: predeclared two-view test, not more threshold tuning

Use released OpenCV pyramidal Lucas–Kanade tracking plus the existing PnP estimator. Preserve all map, feature, pose, and acceptance settings. Make an explicit map-only/reference-pose package and query-RGB/intrinsics-only package first; estimator must not open the combined transformations file. Keep scoring in a separate invocation after estimates are sealed.

1. Freeze pairs `(50,58), (120,128), (190,198), (260,268)` as a development-only pairing. The naive 'any independent accepted view' result is already only **1/4 pairs**, and says nothing about the second camera's current location.
2. Independently localize both frames using unchanged v2. Separately track every mapped correspondence from the first frame into the second with OpenCV `calcOpticalFlowPyrLK` using its documented defaults; retain successful finite in-bounds tracks and enforce unique source/target assignment. Freeze exact parameters and selection rules before execution.
3. Estimate the second frame's pose from tracked **map 3D ↔ second RGB 2D** correspondences with unchanged PnP and acceptance rules. This supplies metric scale from the map rather than pretending RGB essential-matrix translation has metric scale. No pose averaging across moving cameras; no query poses or query depth.
4. Record independent-only vs tracked candidates separately. Recompute projection residuals and positive depth for audit, not a post-hoc tuned rescue rule. Existing PnP returned-inlier sets sometimes have final median residuals greater than 3 px; report this instead of assuming returned inliers prove the final fit.
5. Score both frames only after output sealing. Report accepted count, wrong accepts, pose/heading errors, failure reasons and resources. A current-pose result requires the second frame to pass, not merely a good first frame. Do not choose track parameters from these error scores.
6. A short-sequence extension should be frozen in advance and retain per-frame tracking rejection/relocalization. Validate on a newly reserved block or independent recording for generalization; present current frames as development only.

Released stronger comparator once downloads/storage are authorized: official hloc retrieval + local matching + localization, with an explicitly training-only map and official fixed model/config. Do not claim hloc/SuperPoint/LightGlue was run here or assume it fits 1 GiB RAM. Under the current no-download cap, OpenCV tracking is the practical next experiment, not evidence that two photos suffice.

Primary references: [OpenCV optical-flow API](https://docs.opencv.org/4.x/dc/d6b/group__video__track.html), [OpenCV camera calibration and pose API](https://docs.opencv.org/4.x/d9/d0c/group__calib3d.html), [official hloc release repository](https://github.com/cvg/Hierarchical-Localization). Online calibration docs redirected to version 4.13.0; the installed runtime reports 4.14.0, so record installed defaults explicitly in any next frozen protocol.

## Navigation gate

Only an accepted, frame-consistent camera pose can enter a connector experiment. First establish map-frame alignment and camera-to-body heading observability; then plan a collision-checked connector to a traversable path rather than Euclidean snapping across furniture/walls. Test tracking loss, wrong/rejected pose, turns, lateral deviation, re-entry and reacquisition. Never present this offline camera-pose result as blind pedestrian safety evidence.
