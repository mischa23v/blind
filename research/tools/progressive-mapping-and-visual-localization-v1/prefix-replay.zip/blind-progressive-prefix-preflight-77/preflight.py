"""Two-frame provided-pose prefix preflight. No navigation authority."""
import os
os.environ.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
from pathlib import Path
import sys,json,hashlib,shutil,resource,signal,time
ROOT=Path(__file__).resolve().parent; BASE=ROOT.parent
sys.dont_write_bytecode=True
sys.path.insert(0,str(BASE/'blind-octomap-fullray-10'))
import numpy as np
from PIL import Image
from octomap_engine import OctoMap

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def reserve():
 if shutil.disk_usage(ROOT).free<768*1024**2+3*1024**2:raise RuntimeError('768 MiB reserve plus 3 MiB output budget unavailable')

def main():
 reserve();resource.setrlimit(resource.RLIMIT_CPU,(90,90));resource.setrlimit(resource.RLIMIT_FSIZE,(3*1024**2,3*1024**2));signal.alarm(120)
 posepath=BASE/'blind-mushroom-koivu-acquisition-01/selected/room_datasets/koivu/iphone/long_capture/transformations.json'
 # Reading metadata is unavoidable; only the first two rows are used for fusion.
 frames=json.loads(posepath.read_text())['frames'][:2]
 pins={str(posepath.relative_to(BASE)):sha(posepath)};results=[];start=time.monotonic()
 with OctoMap(.05) as tree:
  defaults=tree.defaults()
  for index,f in enumerate(frames):
   reserve();name=Path(f['depth_file_path']).name;p=BASE/'blind-koivu-game-07/map/depths'/name
   pins[str(p.relative_to(BASE))]=sha(p)
   d=np.asarray(Image.open(p));assert d.shape==(f['h'],f['w']) and d.dtype==np.uint16
   # Cropped 4x nearest-neighbour raster: complete native blocks start at (1,1).
   h=(d.shape[0]-1)//4;w=(d.shape[1]-1)//4;blocks=d[1:1+4*h,1:1+4*w].reshape(h,4,w,4)
   values=blocks[:,0,:,0];assert np.all(blocks==values[:,None,:,None])
   # Optical coordinate is the block centre, not sixteen duplicated observations.
   v,u=np.meshgrid(2.5+4*np.arange(h),2.5+4*np.arange(w),indexing='ij');z=values.astype(float)*.001
   valid=(z>0)&(z<=4.)
   cv=np.stack(((u-f['cx'])*z/f['fl_x'],(v-f['cy'])*z/f['fl_y'],z),axis=-1)[valid]
   T=np.asarray(f['transform_matrix'],float)@np.diag([1,-1,-1,1]);assert np.allclose(T[3],[0,0,0,1])
   assert np.allclose(T[:3,:3].T@T[:3,:3],np.eye(3),atol=1e-5)
   points=np.asarray(cv@T[:3,:3].T+T[:3,3],dtype=np.float32)
   stats=tree.insert_fullray(index,points,np.asarray(T[:3,3],dtype=np.float32),maxrange=-1)
   leaves=tree.leaves()['xyzSizeProbability'];known=float(np.sum(leaves[:,3]**3));free=float(np.sum(leaves[leaves[:,4]<defaults['occupancy'],3]**3))
   results.append(dict(prefixFrames=index+1,frameID=Path(name).stem,nativeCompleteBlocks=int(values.size),submittedRays=len(points),discardedZeroOrOver4m=int(values.size-len(points)),nativeStats=stats,knownVolumeM3=known,freeVolumeM3=free,leafCount=len(leaves)))
 result=dict(scope='Two-frame progressive OctoMap fusion preflight with supplied exported poses, not live SLAM or navigation',defaults=defaults,checkpoints=results,inputSHA256=pins,sourceSHA256=sha(Path(__file__)),wallSeconds=time.monotonic()-start,originalConfidenceAvailable=False,originalTimestampsAvailable=False,poseOptimizationMayUseFuture=True,finalMeshRead=False,FARORead=False,floorFitUsed=False,bodyConnectivityEvaluated=False,physicalAuthority=False)
 data=(json.dumps(result,indent=2)+'\n').encode();reserve();out=ROOT/'PREFLIGHT_RESULT.json'
 with out.open('xb') as f:f.write(data)
 print(json.dumps(result,indent=2))
if __name__=='__main__':main()
