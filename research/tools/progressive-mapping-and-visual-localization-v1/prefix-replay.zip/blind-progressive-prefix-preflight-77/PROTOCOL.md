# Progressive recorded-observation replay: frozen first experiment

## What already ran

`preflight.py` fed only the first two Koivu depth frames and their exported poses to the existing pinned OctoMap full-ray adapter. Native known volume increased from 5.7135 to 7.048375 m³; native free volume from 5.029875 to 6.06775 m³. These are fused sensor-ray occupancy volumes, **not walkable floor area, physical accuracy, or successful movement**. No route was attempted.

All 294 pose-matched depth PNGs are local. Exported frame IDs increase monotonically. Default Python does not expose Open3D, but the existing isolated `blind-open3d-author-baseline-10/environment/target` contains Open3D 0.19.0 and an already-run official TSDF implementation. No install or download is necessary for the first depth-only replay.

The first execution rejected float64 endpoints and the second rejected float64 origin at the strict existing adapter boundary; both ran no integration. The executable now explicitly converts exported-coordinate points and origin to float32 before insertion. These are converted processed observations, not a claim of native ARKit float buffers.

## Scope and evidence limits

This is **progressive observation fusion with supplied Polycam poses**. Exported poses may have been globally optimized using later observations. Therefore even a strict prefix-frame experiment does not establish causal live SLAM. No original timestamps, confidence images, tracking states, IMU, or body-to-phone extrinsics exist in the audited recording. No synthetic timestamps/confidence will be supplied. Runtime measurements describe the test host, not iPhone latency.

Only original RGB/depth, intrinsics and provided poses may enter reconstruction. The completed Polycam mesh, FARO, whole-recording floor models, source-only global registrations, manual table ROI and pre-carved camera corridor are prohibited mapping inputs. FARO may be a separately isolated evaluator later, never a planner input.

## Frozen first full replay, pending root review

- Input order: all 294 original pose rows, monotonic original frame IDs; never sort by a geometric or evaluator-derived preference.
- Checkpoints after **1, 2, 16, 32, 64, 128, 192, 256, 294** supplied observations. No future image/depth loading in the checkpoint loop. A mapper receives only one frame at a time; full metadata is a loader artifact, not permitted floor/geometry evidence.
- One persistent OctoMap instance; no restarting with the final map at checkpoints. Released upstream commit `007a0b5b6e4d3bb6c54f2c65a12234e03adcd72f`, existing `blind-octomap-fullray-10` adapter/build receipt. Existing wrapper verifies source/library checksums before loading.
- Native resolution 0.05 m, default hit0.7/miss0.4/occupancy0.5, default clamps; `insert_fullray`, upstream full original-ray computeUpdate (no endpoint dedup), unpruned probabilistic state retained between frames.
- The 738×994 depth exports repeat each sample in 4×4 blocks. Cropping leaves complete blocks starting at pixel(1,1). Verify exact repetition for each frame. Sample each complete block once and unproject at its centre(2.5+4k). Exclude partial edge blocks rather than claim independent measurements. Intrinsics remain exported raster intrinsics. Keep finite positive depth≤4m; discard farther samples entirely, do not reinterpret them as free-to-4m. Zero/invalid means unobserved.
- OpenGL camera-to-world transforms converted by diag(1,-1,-1,1); units remain metres. No unit-box normalization or world registration.
- No custom floor-vs-object classifier in this baseline.

## Metrics and connectivity: separate meanings

At every checkpoint record processed frame IDs/hashes, original/used ray counts, native occupied/free/conflict counts, leaf count, observed/free/occupied volume and bounds. Volume sums use native variable leaf sizes, not leaf count × fixed size.

For a bounded fixed grid **centred on the first camera**, freeze a 12×12×6m, 0.10m diagnostic grid before loading later frames. Query native state at centres and report known/free/occupied/unknown counts and six-neighbour connected components of native free samples. Report unknown boundary contact and fraction of known-free samples in the largest component. This grid is a diagnostic sampling of native occupancy, not a body-sized passage model. It does not fill unsampled volume and does not imply that a person can stand or walk there. Record out-of-grid observations; do not expand bounds using future data.

**Human-route connectivity remains a separate, unfinished stage.** It requires observed support, foot/body/head obstacle evidence, and actual body sweep checks. Do not label air-voxel connectivity or a smooth TSDF opening as a walkable route. The next released-component comparator should use prefix Open3D TSDF surface integration and existing Recast code, with independent observed-coverage gating; lack of a triangle cannot mean clear. Do not reuse the broken permanent-residual floor classifier simply to produce a route number. An explicit reviewed support policy is required before claiming body connectivity.

## Revisit and return

A metadata-only diagnostic found exported path length56.955m and final-to-initial separation3.617m. Among pose indices200 onward, posed frame214 (source frame229) is0.362m from the initial pose. This supports a **candidate recorded revisit**, not a verified complete physical return. Select and freeze visit intervals using only pose-distance criteria before scoring mapping; then inspect their actual RGB overlap. Later recorded frames are new observations; replaying existing frames backwards is not.

Because exported poses may be optimized, these distances are dataset-coordinate diagnostics rather than independent measurements. Do not copy the camera track into a body path or use it to force free cells. An alternative instructed route needs actual closed-loop sensing; offline replay cannot synthesize its unseen observations.

## Bounds / stop conditions

Parent review required before the294-frame run. No new downloads; no full mesh/reference reads. Maintain768MiB free plus3MiB planned outputs, output only compact JSON/summary figures, no dense grids or new mesh copies. Two-frame preflight has90sCPU/120swall, ≤3MiB per-file cap and reserve checks. A full run additionally needs sampled process memory/CPU watchdog and total-output accounting; preflight limits are not a full-run resource approval. Abort on input mismatch, nonmonotonic frame IDs, failed4×4 repetition check, resource bound, or unavailable source. Preserve failed receipts, never delete evidence.

## Reproduce the completed preflight

From the shared workspace:

```
PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 \
python blind-progressive-prefix-preflight-77/preflight.py
```

The command refuses to overwrite `PREFLIGHT_RESULT.json`. For an independent rerun use a separately reviewed output location or compare a new stdout receipt; do not mutate the completed result. No external push was performed by this worker.
