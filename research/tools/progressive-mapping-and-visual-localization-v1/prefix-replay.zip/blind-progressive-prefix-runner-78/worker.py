"""Recorded prefix occupancy experiment, not body navigability or live SLAM."""
import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
from pathlib import Path
import sys,json,time,hashlib,resource
sys.dont_write_bytecode=True
import numpy as np
from PIL import Image
from scipy.ndimage import label,generate_binary_structure
ROOT=Path(__file__).resolve().parent;BASE=ROOT.parent
sys.path.insert(0,str(BASE/'blind-octomap-fullray-10'))
from octomap_engine import OctoMap

def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 spec=json.loads((ROOT/'FROZEN.json').read_text());out=Path(sys.argv[1]);rows=spec['frames'];start=time.monotonic();cpu=time.process_time()
 frames=json.loads((BASE/spec['posePath']).read_text())['frames'];assert len(frames)==294
 centre=np.asarray(frames[0]['transform_matrix'],float)[:3,3]
 lo=centre-np.array([6.,6.,3.]);shape=(120,120,60)
 axes=[lo[i]+(.5+np.arange(shape[i]))*.1 for i in range(3)]
 grid=np.stack(np.meshgrid(*axes,indexing='ij'),axis=-1).reshape(-1,3).astype(np.float32)
 lastID=-1;results=[];outside=0
 with OctoMap(.05) as tree:
  defaults=tree.defaults()
  for i,row in enumerate(rows):
   f=frames[i];fid=Path(f['depth_file_path']).stem;assert fid==row['frameID'];number=int(fid.split('_')[-1]);assert number>lastID;lastID=number
   p=BASE/row['depthPath'];assert digest(p)==row['sha256']
   d=np.asarray(Image.open(p));assert d.shape==(f['h'],f['w']) and d.dtype==np.uint16
   h=(d.shape[0]-1)//4;w=(d.shape[1]-1)//4;b=d[1:1+4*h,1:1+4*w].reshape(h,4,w,4);z0=b[:,0,:,0];assert np.all(b==z0[:,None,:,None])
   v,u=np.meshgrid(2.5+4*np.arange(h),2.5+4*np.arange(w),indexing='ij');z=z0.astype(float)*.001;valid=(z>0)&(z<=4)
   cv=np.stack(((u-f['cx'])*z/f['fl_x'],(v-f['cy'])*z/f['fl_y'],z),axis=-1)[valid]
   T=np.asarray(f['transform_matrix'],float)@np.diag([1,-1,-1,1]);assert np.isfinite(T).all() and np.allclose(T[3],[0,0,0,1]) and np.allclose(T[:3,:3].T@T[:3,:3],np.eye(3),atol=1e-5)
   points=np.asarray(cv@T[:3,:3].T+T[:3,3],dtype=np.float32);origin=np.asarray(T[:3,3],dtype=np.float32)
   outside+=int(np.any((points<lo)|(points>=lo+np.array([12.,12.,6.])),axis=1).sum())
   scan=tree.insert_fullray(i,points,origin,maxrange=-1)
   if i+1 in spec['checkpoints']:
    leaves=tree.leaves()['xyzSizeProbability'];vol=leaves[:,3]**3;free=leaves[:,4]<defaults['occupancy']
    bounds=tree.metric_bounds();bounds={k:v.tolist() for k,v in bounds.items()} if bounds else None
    native=dict(bounds=bounds,knownVolumeM3=float(vol.sum()),freeVolumeM3=float(vol[free].sum()),occupiedVolumeM3=float(vol[~free].sum()),leafCount=len(leaves));del leaves,vol,free
    # Diagnostic sample connectivity only: never used to admit a body route.
    states=np.zeros(len(grid),np.uint8)
    for k in range(0,len(grid),100000):
     q=tree.query(grid[k:k+100000]);states[k:k+len(q['known'])]=np.where(q['known']==0,0,np.where(q['occupied']!=0,2,1))
    freegrid=(states.reshape(shape)==1);components,n=label(freegrid,generate_binary_structure(3,1));sizes=np.bincount(components.ravel());sizes[0]=0
    boundary=freegrid[0].sum()+freegrid[-1].sum()+freegrid[:,0].sum()+freegrid[:,-1].sum()+freegrid[:,:,0].sum()+freegrid[:,:,-1].sum()
    unknown=(states.reshape(shape)==0)
    unknown_boundary=sum(int(x.sum()) for x in [unknown[0],unknown[-1],unknown[:,0],unknown[:,-1],unknown[:,:,0],unknown[:,:,-1]])
    counts=np.bincount(states,minlength=3)
    results.append(dict(prefixFrames=i+1,lastFrameID=fid,nativeCompleteBlocks=int(z0.size),discardedZeroOrOver4m=int(z0.size-valid.sum()),native=native,lastScan=scan,diagnosticGrid=dict(shape=shape,spacingM=.1,lowerCorner=lo.tolist(),unknownSamples=int(counts[0]),freeSamples=int(counts[1]),occupiedSamples=int(counts[2]),sixConnectedFreeComponents=int(n),largestFreeComponentSamples=int(sizes.max()),largestFreeFraction=float(sizes.max()/max(1,counts[1])),freeBoundaryFaceSamplesWithCornerDuplicates=int(boundary),unknownBoundaryFaceSamplesWithCornerDuplicates=unknown_boundary),cumulativeEndpointsOutsideGrid=outside,cpuSeconds=time.process_time()-cpu,wallSeconds=time.monotonic()-start))
    del states,freegrid,components,sizes,unknown
    print(json.dumps(results[-1]),flush=True)
 result=dict(scope=spec['scope'],checkpoints=results,defaults=defaults,processedFrames=len(rows),poseOptimizationMayUseFuture=True,missingNativeConfidenceAndTime=True,finalMeshRead=False,FARORead=False,floorClassificationImplemented=False,bodyRouteConnectivityImplemented=False,liveSLAMTested=False,physicalAuthority=False,workerPeakRSSKiB=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,cpuSeconds=time.process_time()-cpu,wallSeconds=time.monotonic()-start)
 (out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
if __name__=='__main__':main()
