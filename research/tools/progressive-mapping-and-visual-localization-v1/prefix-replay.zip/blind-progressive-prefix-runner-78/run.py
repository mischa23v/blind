"""Bounded parent watchdog. Root launch only after independent review."""
from pathlib import Path
import sys,os,json,hashlib,time,signal,subprocess,resource,shutil,argparse
ROOT=Path(__file__).resolve().parent;BASE=ROOT.parent
LIMITS=dict(cpuSeconds=180,wallSeconds=240,rssBytes=1288490188,outputBytes=3145728,reserveBytes=805306368)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def usage(pid):
 entries={};page=os.sysconf('SC_PAGE_SIZE');hz=os.sysconf('SC_CLK_TCK')
 for p in Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:
   s=(p/'stat').read_text().rsplit(')',1)[1].split();entries[int(p.name)]=(int(s[1]),int(s[21])*page,(int(s[11])+int(s[12]))/hz)
  except (OSError,ValueError,IndexError):pass
 if pid not in entries:raise RuntimeError('parent /proc missing')
 selected={pid}
 while True:
  more={p for p,e in entries.items() if e[0] in selected}
  if more<=selected:break
  selected|=more
 return sum(entries[p][1] for p in selected),sum(entries[p][2] for p in selected)
def allocated(p):return sum(q.lstat().st_blocks*512 for q in [p,*p.rglob('*')])
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--frozen-sha',required=True);a=ap.parse_args();f=ROOT/'FROZEN.json'
 if digest(f)!=a.frozen_sha:raise RuntimeError('frozen digest mismatch')
 spec=json.loads(f.read_text());assert spec['limits']==LIMITS
 for p,h in spec['sourcePins'].items():
  if digest(BASE/p)!=h:raise RuntimeError('source mismatch '+p)
 if digest(BASE/spec['posePath'])!=spec['poseSHA256']:raise RuntimeError('pose mismatch')
 if shutil.disk_usage(ROOT).free<LIMITS['reserveBytes']+LIMITS['outputBytes']:raise RuntimeError('reserve + output budget unavailable')
 out=ROOT/'run-01';out.mkdir();started=time.monotonic();cpu0=usage(os.getpid())[1];peak=0;child=None;status='failed';error=None
 env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1');env.pop('LD_PRELOAD',None);env.pop('LD_AUDIT',None)
 def limits():
  resource.setrlimit(resource.RLIMIT_CPU,(180,180));resource.setrlimit(resource.RLIMIT_FSIZE,(3*1024**2,3*1024**2))
 def stop(*_):raise TimeoutError('parent wall alarm')
 signal.signal(signal.SIGALRM,stop);signal.alarm(240)
 try:
  with (out/'stdout.jsonl').open('xb') as log,(out/'stderr.log').open('xb') as err:
   child=subprocess.Popen([sys.executable,str(ROOT/'worker.py'),str(out)],cwd=BASE,env=env,stdout=log,stderr=err,start_new_session=True,preexec_fn=limits)
   while child.poll() is None:
    rss,cpu=usage(os.getpid());peak=max(peak,rss)
    if rss>LIMITS['rssBytes']:raise RuntimeError('tree RSS cap')
    if cpu-cpu0>LIMITS['cpuSeconds']:raise RuntimeError('tree CPU cap')
    if time.monotonic()-started>240:raise RuntimeError('wall cap')
    if allocated(ROOT)>LIMITS['outputBytes']-65536:raise RuntimeError('total stage output cap minus receipt reserve')
    if shutil.disk_usage(ROOT).free<LIMITS['reserveBytes']+65536:raise RuntimeError('disk reserve')
    time.sleep(.1)
   if child.returncode:raise RuntimeError('worker exit '+str(child.returncode))
  r=json.loads((out/'RESULT.json').read_text());assert r['processedFrames']==294 and [x['prefixFrames'] for x in r['checkpoints']]==spec['checkpoints']
  for p,h in spec['sourcePins'].items():assert digest(BASE/p)==h
  assert digest(f)==a.frozen_sha and digest(BASE/spec['posePath'])==spec['poseSHA256']
  status='completed'
 except BaseException as e:error=repr(e)
 finally:
  if child is not None:
   if child.poll() is None:
    os.killpg(child.pid,signal.SIGKILL)
   child.wait()
  signal.alarm(0)
  receipt=dict(status=status,error=error,wallSeconds=time.monotonic()-started,peakSampledTreeRSSBytes=peak,childCPUSeconds=resource.getrusage(resource.RUSAGE_CHILDREN).ru_utime+resource.getrusage(resource.RUSAGE_CHILDREN).ru_stime,limits=LIMITS,frozenSHA256=a.frozen_sha,measurement='sampled /proc RSS + CPU with hard child CPU and parent wall alarm, not cgroup guarantee',physicalAuthority=False)
  if allocated(ROOT)+65536>LIMITS['outputBytes'] or shutil.disk_usage(ROOT).free<LIMITS['reserveBytes']+65536:print(json.dumps(receipt),file=sys.stderr)
  else:(out/'RUN_RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
  print(json.dumps(receipt))
 if status!='completed':raise SystemExit(1)
if __name__=='__main__':main()
