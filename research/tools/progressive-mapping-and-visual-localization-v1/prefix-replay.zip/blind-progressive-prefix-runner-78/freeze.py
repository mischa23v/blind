from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parent;BASE=ROOT.parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 pose=BASE/'blind-mushroom-koivu-acquisition-01/selected/room_datasets/koivu/iphone/long_capture/transformations.json';frames=json.loads(pose.read_text())['frames'];rows=[]
 for f in frames:
  p=BASE/'blind-koivu-game-07/map/depths'/Path(f['depth_file_path']).name
  rows.append(dict(frameID=p.stem,depthPath=str(p.relative_to(BASE)),sha256=sha(p)))
 source=[ROOT/'run.py',ROOT/'worker.py',ROOT/'freeze.py',BASE/'blind-octomap-fullray-10/octomap_engine.py',BASE/'blind-octomap-fullray-10/octomap_adapter.cpp',BASE/'blind-octomap-fullray-10/build-01/libblind_octomap.so',BASE/'blind-octomap-fullray-10/build-01/BUILD_RECEIPT.json']
 spec=dict(scope='Progressive provided-pose native occupancy growth/connectivity only, not walkability or live SLAM',checkpoints=[1,2,16,32,64,128,192,214,256,294],posePath=str(pose.relative_to(BASE)),poseSHA256=sha(pose),frames=rows,sourcePins={str(p.relative_to(BASE)):sha(p) for p in source},limits=dict(cpuSeconds=180,wallSeconds=240,rssBytes=1288490188,outputBytes=3145728,reserveBytes=805306368),upstreamOctoMap='007a0b5b6e4d3bb6c54f2c65a12234e03adcd72f',mapperFutureGeometryAllowed=False)
 out=ROOT/'FROZEN.json'
 with out.open('x') as f:json.dump(spec,f,indent=2);f.write('\n')
 print('python '+str((ROOT/'run.py').relative_to(BASE))+' --frozen-sha '+sha(out))
if __name__=='__main__':main()
