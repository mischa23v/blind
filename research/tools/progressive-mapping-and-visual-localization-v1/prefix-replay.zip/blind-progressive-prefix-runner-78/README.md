# Bounded provided-pose prefix occupancy replay — completed

Independently reviewed and executed once under root authorization; stage77 evidence is untouched. Frozen checkpoints: **1,2,16,32,64,128,192,214,256,294**. Frame214 is included because the original supplied-pose sequence has a candidate revisit near the initial camera position. No results are selected by checkpoint tuning.

This tests the user's incremental-observation idea using all294 depth frames in original order. It reuses the already pinned released OctoMap full-ray update implementation. At each checkpoint it reports native occupied/free/observed volume and six-neighbour connectivity of a frozen0.10m sample grid centred on the first camera. **This is air-occupancy connectivity, not observed floor support, body clearance, a navigable route or a live guidance demonstration.** No new floor classifier has been introduced. The route-connectivity stage is explicitly unimplemented rather than silently filled using the final scan.

## Input isolation

Only the current prefix of depth observations is fused. The loader reads exported poses metadata; geometry code uses the first pose for fixed grid extent and each current pose for that frame, never later poses for a floor fit, registration or ROI. Exported Polycam poses may themselves be globally optimized, so this is not causal-pose SLAM. Final mesh, FARO, global floor models and manual tabletop exclusions are not inputs. Native confidence, capture timing and mounting extrinsics remain unavailable. Camera positions are not carved free or called body paths.

Every complete4×4 repeated sample block is verified, then represented once at its centre. Finite positive depth≤4m is used; farther/zero values are discarded rather than converted to clearance. Partial edge blocks are discarded. Existing native probability defaults and0.05m voxel size are unchanged. Continuous probability state is retained; no binary finalization between checkpoints.

## Resource forecast and bounds

Measured two-frame rerun (stage77 algorithm, separate output here): **0.334CPU seconds**, **0.311wall seconds**, **39,740KiB peakRSS** (process includes imports; small wall/CPU discrepancy from measurement boundaries). Naively multiplying CPU by147 gives49.0CPU seconds. That is only a planning estimate: growing-tree updates and ten864,000-point diagnostic queries add cost. A reasonable unvalidated scheduling allowance is50–150CPU seconds; the180CPU limit is the decision boundary, not an assurance it will finish. Memory cannot be extrapolated from two frames; larger trees/leaf exports will grow. The1.2GiB sampled process-tree cap stops the run rather than assuming the whole room fits.

Parent watchdog enforces180CPU seconds,240wall seconds,1.2GiB sampledRSS,3MiB total stage output and768MiB free reserve. Child CPU/file caps and parent wall alarm supplement sampled accounting; no cgroup hard-RSS guarantee is claimed. Checkpoints are compactJSON, no large mesh/grid export. The raw source arrays and evidence are not mutated. A failure stops and retains the failure receipt.

**Do not run concurrently with the image-localization worker:** its SIFT/PnP task has priority. Independent source review must clear first; root owns launch.

Initial frozen command (review fixes may produce a new SHA):

```
PYTHONDONTWRITEBYTECODE=1 python blind-progressive-prefix-runner-78/run.py \
 --frozen-sha fd863a6f1abdc8f053306c398b79b8e5eed91db7df7f6ab08b1287a68030e078
```

No external push performed. No movement trial performed.

## Verified full-run result

All 294 supplied observations completed in recorded order at all 10 checkpoints. `run-01/RESULT.json` contains the metrics; `run-01/RUN_RECEIPT.json` records completed status with 63.189 s wall, 63.066 s child CPU, and 198,270,976-byte sampled process-tree peak RSS. `INDEPENDENT_REVIEW.json` records post-run input/source verification and checkpoint invariants. The first two checkpoints exactly reproduce stage77.

Known/free native volumes were 5.7135/5.029875 m³ after observation 1; 145.449375/120.0565 m³ at observation 214 (source frame_00229); and 148.788875/122.1925 m³ after observation 294. These are occupancy volumes, not walkable area. Seventeen cumulative endpoints fell outside the fixed diagnostic sampling grid, so sampled connectivity does not describe the whole native map. No full return, causal live SLAM, floor support, or human navigability has been established.

The original preparation is preserved in `*.prepared`. Review restored the original nine checkpoints plus revisit 214 before the single run and added native bounds/unknown-boundary diagnostics. No failed run was overwritten and no repeat run was launched.
