#ifndef BLIND_OCTOMAP_FULLRAY_ADAPTER_H
#define BLIND_OCTOMAP_FULLRAY_ADAPTER_H
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif
typedef struct FullScanStats {
 uint64_t frame, originalPoints, raysSubmitted, rangeClippedRays;
 uint64_t occupiedKeys, freeKeys, treeNodes, conflictKeys;
} FullScanStats;
const char* om_last_error(void);
void* om_create(double resolution);
void om_destroy(void* handle);
int om_insert_fullray(void* handle,uint64_t frame,const float* xyz,uint64_t count,
 const float* origin,double maxrange,uint8_t lazy_eval,FullScanStats* output);
int om_query_keys(void* handle,const uint16_t* keys,uint64_t count,uint8_t* known,
 uint8_t* occupied,double* probability,float* log_odds,uint32_t* hits,uint32_t* frees);
int om_metric_bounds(void* handle,double* min_xyz_max_xyz,uint8_t* has_tree);
int om_finalize_binary_state(void* handle);
#ifdef __cplusplus
}
#endif
#endif
