// Simulation-only adapter. Upstream OctoMap owns occupancy updates and ray traversal.
#include <octomap/octomap.h>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <memory>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <vector>
#include "octomap_adapter.h"
struct Counts { uint32_t hits=0, frees=0; };
struct Handle { octomap::OcTree tree; std::unordered_map<uint64_t,Counts> evidence; uint64_t next=0; bool healthy=true; bool finalized=false; explicit Handle(double r):tree(r){} };
struct ScanStats { uint64_t frame, originalPoints, occupiedKeys, representativeRays, freeKeys, treeNodes, conflictKeys; };
static thread_local std::string error;
static uint64_t packed(const octomap::OcTreeKey& k){return (uint64_t(k[0])<<32)|(uint64_t(k[1])<<16)|uint64_t(k[2]);}
static bool finite3(const float*p){return p&&std::isfinite(p[0])&&std::isfinite(p[1])&&std::isfinite(p[2]);}
static Handle& checked(void*p){if(!p)throw std::runtime_error("null handle");Handle&h=*static_cast<Handle*>(p);if(!h.healthy)throw std::runtime_error("retired handle");return h;}
extern "C" {
const char* om_last_error(){return error.c_str();}
void* om_create(double resolution){try{if(!std::isfinite(resolution)||resolution<.01||resolution>1)throw std::runtime_error("invalid resolution");error.clear();return new Handle(resolution);}catch(const std::exception&e){error=e.what();return nullptr;}}
void om_destroy(void*p){delete static_cast<Handle*>(p);}
int om_defaults(void*p,double*out){try{auto&h=checked(p);if(!out)throw std::runtime_error("null output");out[0]=h.tree.getResolution();out[1]=h.tree.getProbHit();out[2]=h.tree.getProbMiss();out[3]=h.tree.getOccupancyThres();out[4]=h.tree.getClampingThresMin();out[5]=h.tree.getClampingThresMax();return 1;}catch(const std::exception&e){error=e.what();return 0;}}
int om_insert(void*p,uint64_t frame,const float*xyz,uint64_t count,const float*origin,ScanStats*out){
 try{auto&h=checked(p);if(h.finalized||frame!=h.next||frame>=8192||!finite3(origin)||!xyz||count==0||count>2000000||!out)throw std::runtime_error("invalid scan/owner");
  octomap::point3d sensor(origin[0],origin[1],origin[2]);octomap::OcTreeKey originKey;if(!h.tree.coordToKeyChecked(sensor,originKey))throw std::runtime_error("origin out of native bounds");
  const size_t rayCapacity=octomap::KeyRay().sizeMax();
  octomap::KeySet allKeys;octomap::Pointcloud representatives;representatives.reserve(count);
  for(uint64_t i=0;i<count;++i){const float*q=xyz+3*i;if(!finite3(q))throw std::runtime_error("nonfinite endpoint");octomap::point3d endpoint(q[0],q[1],q[2]);octomap::OcTreeKey key;if(!h.tree.coordToKeyChecked(endpoint,key))throw std::runtime_error("endpoint out of native bounds");uint64_t maximumSteps=2;for(int axis=0;axis<3;++axis)maximumSteps+=uint64_t(std::abs(int(key[axis])-int(originKey[axis])));if(maximumSteps>=rayCapacity)throw std::runtime_error("native ray capacity bound");if(allKeys.insert(key).second)representatives.push_back(endpoint);}
  octomap::KeySet freeKeys,occupiedKeys;
  // Exact upstream computeUpdate; no discretize=true synthetic voxel-centre rays.
  h.tree.computeUpdate(representatives,sensor,freeKeys,occupiedKeys,-1.0);
  if(occupiedKeys.size()!=allKeys.size())throw std::runtime_error("occupied-set equivalence failed");
  for(const auto&k:allKeys)if(occupiedKeys.find(k)==occupiedKeys.end())throw std::runtime_error("lost occupied endpoint key");
  for(const auto&k:freeKeys)if(occupiedKeys.find(k)!=occupiedKeys.end())throw std::runtime_error("upstream occupied-wins contract violated");
  // Same upstream insertion order/updateNode operations, with a copied evidence counter.
  for(const auto&k:freeKeys){h.tree.updateNode(k,false,true);++h.evidence[packed(k)].frees;}
  for(const auto&k:occupiedKeys){h.tree.updateNode(k,true,true);++h.evidence[packed(k)].hits;}
  h.tree.updateInnerOccupancy();++h.next;uint64_t conflicts=0;for(const auto&e:h.evidence)if(e.second.hits&&e.second.frees)++conflicts;
  *out={frame,count,uint64_t(occupiedKeys.size()),uint64_t(representatives.size()),uint64_t(freeKeys.size()),uint64_t(h.tree.size()),conflicts};error.clear();return 1;
 }catch(const std::exception&e){if(p)static_cast<Handle*>(p)->healthy=false;error=e.what();return 0;}
}
int om_query(void*p,const float*xyz,uint64_t count,uint8_t*known,double*probability,float*logOdds,uint32_t*hits,uint32_t*frees){try{auto&h=checked(p);if(!xyz||count>5000000||!known||!probability||!logOdds||!hits||!frees)throw std::runtime_error("invalid query buffers");for(uint64_t i=0;i<count;++i){const float*q=xyz+3*i;if(!finite3(q))throw std::runtime_error("nonfinite query");octomap::point3d point(q[0],q[1],q[2]);octomap::OcTreeKey key;if(!h.tree.coordToKeyChecked(point,key))throw std::runtime_error("query out of bounds");auto*n=h.tree.search(key,h.tree.getTreeDepth());known[i]=n?1:0;probability[i]=n?n->getOccupancy():NAN;logOdds[i]=n?n->getLogOdds():NAN;auto e=h.evidence.find(packed(key));hits[i]=e==h.evidence.end()?0:e->second.hits;frees[i]=e==h.evidence.end()?0:e->second.frees;}return 1;}catch(const std::exception&e){error=e.what();return 0;}}
uint64_t om_leaf_count(void*p){try{return checked(p).tree.getNumLeafNodes();}catch(const std::exception&e){error=e.what();return UINT64_MAX;}}
int om_export(void*p,uint64_t capacity,double*xyzSizeProbability,float*logOdds,uint32_t*hits,uint32_t*frees){try{auto&h=checked(p);if(capacity!=h.tree.getNumLeafNodes()||!xyzSizeProbability||!logOdds||!hits||!frees)throw std::runtime_error("export size mismatch");uint64_t i=0;for(auto it=h.tree.begin_leafs(),end=h.tree.end_leafs();it!=end;++it,++i){xyzSizeProbability[5*i]=it.getX();xyzSizeProbability[5*i+1]=it.getY();xyzSizeProbability[5*i+2]=it.getZ();xyzSizeProbability[5*i+3]=it.getSize();xyzSizeProbability[5*i+4]=it->getOccupancy();logOdds[i]=it->getLogOdds();auto e=h.evidence.find(packed(it.getKey()));hits[i]=e==h.evidence.end()?0:e->second.hits;frees[i]=e==h.evidence.end()?0:e->second.frees;}return i==capacity?1:0;}catch(const std::exception&e){error=e.what();return 0;}}
}
// Keep the threshold decision inside the upstream implementation.
extern "C" int om_query_occupied(void*p,const float*xyz,uint64_t count,uint8_t*known,uint8_t*occupied){try{auto&h=checked(p);if(!xyz||count>5000000||!known||!occupied)throw std::runtime_error("invalid occupancy buffers");for(uint64_t i=0;i<count;++i){const float*q=xyz+3*i;if(!finite3(q))throw std::runtime_error("nonfinite occupancy query");octomap::OcTreeKey key;if(!h.tree.coordToKeyChecked(octomap::point3d(q[0],q[1],q[2]),key))throw std::runtime_error("occupancy query out of bounds");auto*n=h.tree.search(key,h.tree.getTreeDepth());known[i]=n?1:0;occupied[i]=n&&h.tree.isNodeOccupied(n)?1:0;}return 1;}catch(const std::exception&e){error=e.what();return 0;}}
extern "C" int om_keys(void*p,const float*xyz,uint64_t count,uint16_t*keys){try{auto&h=checked(p);if(!xyz||count>2000000||!keys)throw std::runtime_error("invalid key buffers");for(uint64_t i=0;i<count;++i){const float*q=xyz+3*i;if(!finite3(q))throw std::runtime_error("nonfinite key query");octomap::OcTreeKey key;if(!h.tree.coordToKeyChecked(octomap::point3d(q[0],q[1],q[2]),key))throw std::runtime_error("key query out of bounds");for(int a=0;a<3;++a)keys[3*i+a]=key[a];}return 1;}catch(const std::exception&e){error=e.what();return 0;}}
extern "C" int om_query_keys(void*p,const uint16_t*keys,uint64_t count,uint8_t*known,uint8_t*occupied,double*probability,float*logOdds,uint32_t*hits,uint32_t*frees){try{auto&h=checked(p);if(!keys||count>5000000||!known||!occupied||!probability||!logOdds||!hits||!frees)throw std::runtime_error("invalid keyed query buffers");for(uint64_t i=0;i<count;++i){octomap::OcTreeKey key(keys[3*i],keys[3*i+1],keys[3*i+2]);auto*n=h.tree.search(key,h.tree.getTreeDepth());known[i]=n?1:0;occupied[i]=n&&h.tree.isNodeOccupied(n)?1:0;probability[i]=n?n->getOccupancy():NAN;logOdds[i]=n?n->getLogOdds():NAN;auto e=h.evidence.find(packed(key));hits[i]=e==h.evidence.end()?0:e->second.hits;frees[i]=e==h.evidence.end()?0:e->second.frees;}return 1;}catch(const std::exception&e){error=e.what();return 0;}}

// Additive full-ray ABI. Every original Float32 endpoint is passed to upstream.
extern "C" int om_insert_fullray(void*p,uint64_t frame,const float*xyz,uint64_t count,
 const float*origin,double maxrange,uint8_t lazy_eval,FullScanStats*out){
 try {
  auto&h=checked(p);
  if(h.finalized||frame!=h.next||frame>=8192||!finite3(origin)||!xyz||count==0||
     count>2000000||!out||lazy_eval>1||!std::isfinite(maxrange)||
     !(maxrange==-1.0||maxrange>=0.0))throw std::runtime_error("invalid full-ray scan/owner/range");
  const octomap::point3d sensor(origin[0],origin[1],origin[2]);
  octomap::OcTreeKey originKey;
  if(!h.tree.coordToKeyChecked(sensor,originKey))throw std::runtime_error("origin out of native bounds");
  const size_t rayCapacity=octomap::KeyRay().sizeMax();
  octomap::Pointcloud cloud;cloud.reserve(count);
  octomap::KeySet expectedOccupied;uint64_t clipped=0;
  // Validate native traversal capacity before any updates. Range arithmetic here
  // mirrors upstream only for bounds checks; computeUpdate still owns all rays.
  for(uint64_t i=0;i<count;++i){
   const float*q=xyz+3*i;if(!finite3(q))throw std::runtime_error("nonfinite endpoint");
   const octomap::point3d endpoint(q[0],q[1],q[2]);
   const octomap::point3d delta=endpoint-sensor;
   const double distance=delta.norm();
   if(!std::isfinite(distance))throw std::runtime_error("nonfinite native ray length");
   const bool hit=maxrange<0.0||distance<=maxrange;
   const octomap::point3d rayEnd=hit?endpoint:sensor+delta.normalized()*(float)maxrange;
   if(!std::isfinite(rayEnd.x())||!std::isfinite(rayEnd.y())||!std::isfinite(rayEnd.z()))
    throw std::runtime_error("nonfinite range endpoint");
   octomap::OcTreeKey rayEndKey;
   if(!h.tree.coordToKeyChecked(rayEnd,rayEndKey))throw std::runtime_error("effective endpoint out of native bounds");
   uint64_t maximumSteps=2;
   for(int axis=0;axis<3;++axis)maximumSteps+=uint64_t(std::abs(int(rayEndKey[axis])-int(originKey[axis])));
   if(maximumSteps>=rayCapacity)throw std::runtime_error("native ray capacity bound");
   if(hit)expectedOccupied.insert(rayEndKey);else ++clipped;
   cloud.push_back(endpoint); // No endpoint representative or discretization.
  }
  octomap::KeySet freeKeys,occupiedKeys;
  h.tree.computeUpdate(cloud,sensor,freeKeys,occupiedKeys,maxrange);
  if(occupiedKeys.size()!=expectedOccupied.size())throw std::runtime_error("full-ray occupied-set mismatch");
  for(const auto&k:expectedOccupied)if(occupiedKeys.find(k)==occupiedKeys.end())throw std::runtime_error("lost in-range endpoint key");
  for(const auto&k:freeKeys)if(occupiedKeys.find(k)!=occupiedKeys.end())throw std::runtime_error("upstream occupied-wins contract violated");
  // Same implementation/order/options as upstream insertPointCloud(...,
  // maxrange, lazy_eval, discretize=false), with separate per-scan counters.
  for(const auto&k:freeKeys){h.tree.updateNode(k,false,lazy_eval!=0);++h.evidence[packed(k)].frees;}
  for(const auto&k:occupiedKeys){h.tree.updateNode(k,true,lazy_eval!=0);++h.evidence[packed(k)].hits;}
  if(lazy_eval)h.tree.updateInnerOccupancy();
  ++h.next;uint64_t conflicts=0;for(const auto&e:h.evidence)if(e.second.hits&&e.second.frees)++conflicts;
  *out={frame,count,uint64_t(cloud.size()),clipped,uint64_t(occupiedKeys.size()),
        uint64_t(freeKeys.size()),uint64_t(h.tree.size()),conflicts};
  error.clear();return 1;
 }catch(const std::exception&e){if(p)static_cast<Handle*>(p)->healthy=false;error=e.what();return 0;}
}

// Full-depth search above resolves pruned ancestors without enumerating leaves.
extern "C" int om_metric_bounds(void*p,double*out,uint8_t*hasTree){
 try{auto&h=checked(p);if(!out||!hasTree)throw std::runtime_error("invalid bounds buffers");
  *hasTree=h.tree.size()?1:0;
  if(*hasTree){h.tree.getMetricMin(out[0],out[1],out[2]);h.tree.getMetricMax(out[3],out[4],out[5]);}
  else for(int i=0;i<6;++i)out[i]=NAN;
  error.clear();return 1;
 }catch(const std::exception&e){error=e.what();return 0;}
}

// Exactly the two destructive preparation operations in upstream writeBinary.
// No file is written; later insertions are forbidden. Known/occupied queries
// remain valid, but probabilities/log odds become clamped model values.
extern "C" int om_finalize_binary_state(void*p){
 try{auto&h=checked(p);if(!h.finalized){h.tree.toMaxLikelihood();h.tree.prune();h.finalized=true;}
  error.clear();return 1;
 }catch(const std::exception&e){if(p)static_cast<Handle*>(p)->healthy=false;error=e.what();return 0;}
}
