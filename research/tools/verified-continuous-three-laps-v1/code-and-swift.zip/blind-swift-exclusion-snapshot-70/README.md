# Swift static unknown-exclusion snapshot → native planner (70)

**55 checks passed.** This isolated Linux Swift/C-ABI prototype sends the frozen
stage65 tabletop exclusion hypothesis to the existing stage66 native planner.
It does not modify the app, enable guidance or construct new physical geometry.

## Results

* Five unchanged real-Polycam native route pairs with the exclusion match the
  Python66 same-API reference (flags/count/errors and coordinates within1e-5m).
* **636 compact spans marked**, exactly matching Python66.
* Zero-exclusion native routes match original/replayed mesh and saved Python58
  baseline for all five pairs.
* 32 synthetic mesh-anchor tiles preserve all29,366 source triangles; Float32
  triangle coordinates remain identical, Double error8.88e-16m.
* Authored tests cover convexity, winding, duplicate/bowtie/concave/nonfinite
  polygons, collapsed Float32 topology, wrong frame, disjoint heights, disabled
  updates/removal, and inherited68 mesh/metadata/lifecycle bounds.
* Compile2.55s, sampled compiler-tree RSS256.37MiB, minimum available RAM2.20GiB.
  CPU8/nice10; world69 retained CPU0/priority. Replay0.65s, receipt37,268KiB
  child high-water mark. These are loaded-workspace measurements, not phone
  performance. Existing Swift6.4.1/toolchain/cache/library reused, no downloads.

## Exact height/coordinate contract

The polygon and heights refer to the canonical corrected phone-source frame,
+Y up, horizontal XZ. The fixture validates65's stored XY→XZ sign conversion and
pins the metadata/source hashes. Swift requires matching mesh/polygon/height
frame IDs, unknown=true, authority=false and bodyInflationApplied=false. Labels
alone do not prove registration; this test uses the existing fixed source frame.

Raw observed height hypothesis: [1.0678330948175452,1.1040746892673932]m.
Native Float32 inputs: [1.0678330659866333,1.1040747165679932]m.
These are observed points, NOT certified physical tabletop bounds.

The wrapper passes those raw heights unchanged except mandatory Float32 packing.
Only native66 subtracts its configured1.75m body height, once, to determine affected
candidate foot heights. The report's raw diagnostic interval is
[-0.6821669051824548,1.1040746892673932]m; it is not resubmitted to native or applied
as another expansion. Radius.225m is applied by the same native erosion once.
The source65 scenario1.6m is not silently substituted for this frozen66 comparator
configuration1.75m. Float quantization matches66; it is not a new conservative
uncertainty bound. Both raw/native heights are retained in RESULT.json.

Convex geometry is validated in Double AND after Float32 packing. Double-only
validation would accept a1m polygon at1e8m whose packed vertices collapse. Early
independent review caught that case before compilation; the first precompile
source/protocol/reference is preserved in precompile-review-v1. Packed topology
revalidation and regression were frozen before scoring. No route thresholds tuned.

## Scope and authority

This is an immutable **static exclusion snapshot**. Updates/removal are explicitly
unsupported; an attempted update retires the snapshot owner and prevents further
native creation. It cannot silently clear known exclusions. No dynamic exclusion
lifecycle or live scene-update capability is claimed.

The existing mesh replay guards remain from68: session/generation/revision fences,
proper rigid transforms, exact-once projection, owned packed arrays, explicit
incomplete geometry and metadata/triangle/vertex caps. No padded SIMD3 C pointers.
Raw-depth detection remains unimplemented/veto, actual-world coverage unknown,
and physical authority alwaysfalse. An exclusion is conservative unknown space,
not an invented obstacle or source of new free space.

These queries are native66 candidate route parity, **not** a Swift reimplementation
of66's clearance-weighted graph, line-of-sight simplifier or movement controller.
No physical movement, FARO/reference evaluator or device data was used by70.
Synthetic tiling of a fused real phone mesh is not live ARMeshAnchor capture.

## Reproduce

PREEXEC_FROZEN.json pins source/protocol/library/inputs before Python reference
generation. FROZEN.json also pins the compiled executable and generated fixture
before Swift scoring. make_fixture.py verifies the earlier pins and creates a
transient local fixture plus Python66 reference receipts. run.py verifies every
final pin and uses CPU8/nice10/512MiB address-space/120CPU/180wall constraints.
compile_bounded.py adds sampled512MiB treeRSS and1.5GiB available-RAM watchdogs.

```
OPENBLAS_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1 python blind-swift-exclusion-snapshot-70/make_fixture.py
PYTHONDONTWRITEBYTECODE=1 python blind-swift-exclusion-snapshot-70/run.py
```

Rebuild only in an approved resource window and create a new documented freeze;
do not overwrite frozen results silently. Cache reuse may create unpublished
module-cache entries but no68 source, binary or input was changed.

Publication: include files listed in MANIFEST.json only; exclude build/ and
INPUT.transient.json. No rawmesh/photos published. MuSHRoom provenance/license
remain in the existing source acquisition packet. All code is isolated research,
not an iOS/ARKit build, installed feature or safe navigation claim.

Independent final review PASS:18 frozen pins verified; existing executable rerun
on CPU8/nice10 reproduced all55 checks,636 marked spans and saved routes exactly
(reviewRSS37,272KiB). See INDEPENDENT_REVIEW.json. Owner retirement blocks future
Native creation; already-created immutable Native handles are not dynamically
revoked. They retain their original exclusion, never a cleared version. This is
another reason the API is static snapshot only, not a live update/removal system.
