# Stage70: frozen static unknown tabletop exclusion through Swift/C ABI

Candidate-only immutable snapshot, no app or physical authority. Reuse68 packed
arrays, mesh-anchor transforms and revision/unknown guards. Integrate65 frozen
raw polygon/height via66 existing bn_build_excluded. Validate exact canonical
frame identity, XY→XZ conversion, unknown=true, authority=false, no previous body
inflation. Pass raw observed heights; only native66 subtracts bodyheight once.
Footinterval in receipt is diagnostic, never sent as already-expanded input.

Convexity includes all vertices against every edge (not just local turn signs),
finite/duplicate/height/winding checks. Native config remains.225radius,1.75height,
.025cell/climb,15slope. Static owner explicitly retires on unsupported update or
removal; never silently remove an exclusion. No dynamic exclusion lifecycle claim.

Freeze source/header/scripts/protocol/native66binary/input65+68hashes before
Python reference generation or Swift scoring. Python66 sameAPI gives5 unchanged
stage44query pairs and marked spans. Swift zero-exclusion must match58baseline
and Swift original/replayed. Swift exclusion must matchPython66 markedspans,
flags/count/errors and coordinate1e-5m. Original mesh triangles remain unchanged.
Test authored square/winding/duplicates/bowtie/concave/nonfinite/frame mismatch,
height-disjoint/zero-exclusion and unsupportedupdate retirement. NoFARO.

This compares raw native candidate paths, not66's clearance-weighted graph/LOS
controller path as a whole. Does not establish safe body movement or live hazard
coverage. Compile serialized after69heavy worker ends. Reuse68toolchain/cache,
no newtoolchain/librarybuild. Source/publication small; no rawmesh publication.
