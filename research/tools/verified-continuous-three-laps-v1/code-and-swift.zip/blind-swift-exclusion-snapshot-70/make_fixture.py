from pathlib import Path
import json,sys,dataclasses,hashlib
import numpy as np
H=Path(__file__).resolve().parent;W=H.parent
for p,h in json.loads((H/'PREEXEC_FROZEN.json').read_text())['files'].items():assert hashlib.sha256((W/p).read_bytes()).hexdigest()==h,p
base=json.loads((W/'blind-swift-native-mesh-replay-68/INPUT.transient.json').read_text());r=json.loads((W/'blind-tabletop-exclusion-hypothesis-65/FROZEN_EXCLUSION.json').read_text())
assert r['coordinateFrame']=='corrected source-level XY horizontal, Z up; existing planner game=(X,Z,-Y)'
assert r['unknown'] and not r['authority'] and not r['bodyInflationApplied'] and r['noFAROOrHeldoutUsed']
p=np.array(r['polygonPlannerXZ']);assert np.array_equal(p,np.array(r['polygonLevelXY'])*[1,-1])
frame='phone-corrected-level-game-yup-v1'
base['exclusion']=dict(id='frozen65-tabletop-unknown',revision=1,meshFrameID=frame,polygonFrameID=frame,heightFrameID=frame,polygonLevelXY=np.array(r['polygonLevelXY']).reshape(-1).tolist(),polygonPlannerXZ=p.reshape(-1).tolist(),observedTopHeightRange=r['observedTopPointHeightRangeNotBounds'],unknown=True,authority=False,bodyInflationApplied=False)
sys.path.insert(0,str(W/'blind-tabletop-exclusion-planner-66'));from native_exclusion import Native
n=Native(np.array(base['vertices']).reshape(-1,3),np.array(base['triangles']).reshape(-1,3))
try:
 base['exclusionReference']=[dataclasses.asdict(n.engine.route(a,b))for a,b in zip(base['anchors'][:-1],base['anchors'][1:])];base['expectedMarkedSpans']=n.marked_span_count
finally:n.close()
(H/'INPUT.transient.json').write_text(json.dumps(base,separators=(',',':'),allow_nan=False))
(H/'PYTHON66_REFERENCE_RECEIPT.json').write_text(json.dumps(dict(markedSpans=base['expectedMarkedSpans'],routes=base['exclusionReference'],physicalAuthority=False),indent=2)+'\n')
