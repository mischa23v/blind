from pathlib import Path
import os,time,subprocess,psutil,json,signal,resource
H=Path(__file__).resolve().parent;W=H.parent
assert psutil.virtual_memory().available>=1536<<20
assert 8 in os.sched_getaffinity(0)
B=Path('/workspace/shared/swift-toolchain/install/swift-6.4.1-RELEASE-debian13/usr/bin');(H/'build').mkdir(exist_ok=True)
cmd=[str(B/'swiftc'),'-j','1','-module-cache-path',str(W/'blind-swift-native-mesh-replay-68/build/cache'),'-I',str(H/'cmodule'),'-L',str(W/'blind-tabletop-exclusion-planner-66'),'-lblind_detour',str(H/'Bridge.swift'),str(H/'Exclusion.swift'),str(H/'main.swift'),'-o',str(H/'build/replay')]
env=os.environ.copy();env['PATH']=str(B)+':'+env['PATH']
def setup():
 os.setsid();os.nice(10);os.sched_setaffinity(0,{8});resource.setrlimit(resource.RLIMIT_CPU,(120,120))
start=time.monotonic();peak=0;minavailable=psutil.virtual_memory().available;maxcpu=0;reason=None
with open(H/'COMPILE.log','w')as log:
 p=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,env=env,preexec_fn=setup);root=psutil.Process(p.pid)
 while p.poll() is None:
  try:procs=[root]+root.children(recursive=True)
  except psutil.Error:procs=[]
  rss=cpu=0
  for child in procs:
   try:rss+=child.memory_info().rss;t=child.cpu_times();cpu+=t.user+t.system
   except psutil.Error:pass
  peak=max(peak,rss);maxcpu=max(maxcpu,cpu);available=psutil.virtual_memory().available;minavailable=min(minavailable,available)
  if rss>512<<20 or available<1536<<20 or cpu>120 or time.monotonic()-start>120:
   reason='resource-watchdog';os.killpg(p.pid,signal.SIGKILL);break
  time.sleep(.05)
 rc=p.wait()
r=dict(command=cmd,exitCode=rc,abortReason=reason,wallSeconds=time.monotonic()-start,sampledPeakTreeRSSBytes=peak,sampledMaxTreeCPUSeconds=maxcpu,minimumMemAvailableBytes=minavailable,CPU=8,nice=10,concurrentWorldRun69=True,phoneBenchmark=False)
(H/'COMPILE_RECEIPT.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r));raise SystemExit(rc)
