# 69 — Three continuous laps, pre-run protocol

Repeat the five unchanged original source goals three times with one actor, one
FIFO, one monotonically increasing tick/time stream and exactly one initial
settlement. No reset, teleport or lap-boundary heading/height snap. This is a new
run, not an extension or reinterpretation of successful stage67.

## Unchanged physical and source inputs
The stage67 source65 tabletop unknown exclusion, source66 native map, 5 cm
clearance-weighted grid, cost and LOS simplification remain fixed. Stage63
actual-delivered-pose source replanning is performed at every drained handoff,
including global legs4→5 and9→10; source bounds and original goal use leg modulo5.
Every query verifies the same native library, polygon,636 marked compact spans,
graph identity, and both baseline/excluded native segment/height validity.
There is no fallback to old anchors, no reference route choice, and no path tuning.

The same45×30×160 cm zero-margin body, immutable stage59 floor memberships,
stage61 local max-nine measured support and continuity law, full3D body sweeps,
underbody guards, unknown support veto and actual movement caps remain unchanged.
Five scorer objects are reused by membership index, rather than fifteen duplicated
objects. Each call recomputes its geometric query; every handoff performs fresh
old/new membership, static-body and underbody checks at the unchanged actual pose.
Optimization logs are grouped by five memberships and include every call, not
fifteen separately duplicated caches. No cached support observations are reused.

## Arrival and topology
Each of15 goals requires the original35 cm full3D arrival region, positive leg
travel, zero applied motion and drained FIFO. At goals5,10,15, score that lap's
actual trace from the exact prior lap-end state (initial settled state for lap1).
Require winding−1 about the same original source table point and return inside
the ORIGINAL start's35 cm full3D region. Require−3 total actual winding and all
15 drained goals for three-lap success. Report every lap's trace row/tick indices,
start/end coordinates and3D/horizontal closing gap. Mathematical closing chords
are NEVER executed or added to distance. Two points within the original35 cm
region can have a lap-boundary gap approaching70 cm; that gap is reported, not
silently constrained to35 cm or fabricated as movement. Partial runs retain
completed lap counts, exact committed CSV and all failed proposals.

## Predeclared budgets and evidence
Maximum7,500 ticks,2,100 process-tree CPU seconds,2,700 wall seconds,3.5 GiB RSS,
16 MiB output and768 MiB disk reserve. Same6,000,000 candidate-face cap and fresh
4.3 GiB available-memory admission. Stage67 cost≈562 CPU seconds and3.4 MiB for
one lap suggests≈1,686 CPU seconds and10.2 MiB for three; neither is guaranteed.
Budget stops retain partial evidence and are not success. CSV is flushed every
actual row; verbose XZ is lossless on normal close but may lose a recent tail on
abrupt termination. No precision reduction or omitted failed attempts.

This remains a static, recorded, evaluator-assisted simulation with manually
assisted source ROI. Floor contacts are unmeasured. Three nominal laps would not
prove live iPhone navigation, child safety or robustness to sensor/motion errors.
