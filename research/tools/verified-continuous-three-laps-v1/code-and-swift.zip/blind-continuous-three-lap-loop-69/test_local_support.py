import unittest,math,numpy as np
from types import SimpleNamespace
import local_support as l

def row(x=0,z=0,yaw=0,heightfn=lambda x,z:0.):
 offsets=[(0,0),(-.075,-.1125),(-.075,.1125),(.075,-.1125),(.075,.1125),(-.15,-.225),(-.15,.225),(.15,-.225),(.15,.225)];p=[]
 for i,(a,b)in enumerate(offsets):
  xx=x+a*math.cos(yaw)-b*math.sin(yaw);zz=z+a*math.sin(yaw)+b*math.cos(yaw);p.append({'hit':True,'referenceCellID':i,'modelXZ':[xx,zz],'modelHeightY':heightfn(xx,zz)})
 return {'hitCount':9,'missingCount':0,'probes':p}
def ground(known=True,plane=(0,0,0)):return SimpleNamespace(is_ground=lambda i:known,plane_coefficients=np.array(plane,float))
class Terrain:
 def __init__(self,fn=lambda x,z:0.):self.fn=fn
 def support_probes(self,p,yaw):return row(p[0],p[2],yaw,self.fn)
class Tests(unittest.TestCase):
 def test_gradual_observed_floor_no_global_datum_drift(self):
  s=Terrain(lambda x,z:.02*x);g=ground(plane=(0,0,.3));state=np.array([0,l.height(s.support_probes([0,0,0],0)),0.])
  for i in range(250):
   p=state.copy();p[0]+=.02;segments,checks,motion=l.proposed_ground_motion(s,g,state,p,0,0);self.assertIsNotNone(segments);state=segments[1]
  self.assertGreater(state[1],.10);self.assertAlmostEqual(state[0],5.)
 def test_unknown_void_rejects(self):
  class S(Terrain):
   def support_probes(self,p,yaw):r=super().support_probes(p,yaw);r['probes'][0]['hit']=False;return r
  self.assertIsNone(l.proposed_ground_motion(S(),ground(),np.zeros(3),np.array([.02,0,0]),0,0)[0])
 def test_unknown_membership_rejects(self):self.assertIsNone(l.proposed_ground_motion(Terrain(),ground(False),np.zeros(3),np.array([.02,0,0]),0,0)[0])
 def sequenced(self,heights,dx=.02):
  class S:
   def __init__(self):self.i=0
   def support_probes(self,p,yaw):h=heights[self.i];self.i+=1;return row(p[0],p[2],yaw,lambda x,z:h)
  return l.proposed_ground_motion(S(),ground(),np.zeros(3),np.array([dx,0,0]),0,0)
 def test_abrupt_30mm_drop_rejects(self):self.assertIsNone(self.sequenced([0,-.03,-.03])[0])
 def test_abrupt_30mm_step_rejects(self):self.assertIsNone(self.sequenced([0,.03,.03])[0])
 def test_abrupt_10mm_within_old_band_rejected_by_continuity(self):
  a,b,c=self.sequenced([0,.01,.01]);self.assertIsNone(a);self.assertFalse(b[0]['localHeightContinuity']['accepted'])
 def test_sub4mm_ambiguity_explicit(self):self.assertIsNotNone(self.sequenced([0,.003,.003])[0])
 def test_original3d_cap_retained(self):
  a,b,c=self.sequenced([0,.004,0],.024);self.assertIsNone(a);self.assertGreater(c['attempted3DDistanceMetres'],.025)
 def test_foot_mismatch_no_snap(self):
  state=np.array([0,.001,0.]);a,_,_=l.proposed_ground_motion(Terrain(),ground(),state,np.array([.02,.001,0]),0,0);self.assertIsNone(a);self.assertEqual(state[1],.001)
 def test_pure_yaw_uses_corner_displacement(self):
  a=row();b=row(yaw=.01);r=l.continuity(a,b,0,np.zeros(3),0,np.zeros(3),.01);self.assertGreater(r['maximumCorrespondingProbeXZDisplacementMetres'],0);self.assertGreater(r['heightChangeLimitMetres'],.004)
 def test_max9_not_mean(self):
  r=row();r['probes'][-1]['modelHeightY']=.003;self.assertEqual(l.height(r),.003)
 def test_nonfinite_rejects_before_arithmetic(self):
  r=row();r['probes'][0]['modelHeightY']=float('nan');self.assertFalse(l.connected(r,ground(),0)['acceptedFiniteSupportModel'])
 def test_spread20mm_unchanged(self):
  r=row();r['probes'][0]['modelHeightY']=.021;self.assertFalse(l.connected(r,ground(),0)['acceptedFiniteSupportModel'])
 def test_handoff_no_reset_even_different_provenance_plane(self):
  state=np.zeros(3);r=l.overlap_admission(Terrain(),ground(),ground(plane=(1,2,3)),state,0);self.assertTrue(r['accepted']);np.testing.assert_array_equal(state,np.zeros(3));self.assertFalse(r['poseReset'])
 def test_handoff_actual_height_mismatch_rejected(self):self.assertFalse(l.overlap_admission(Terrain(),ground(),ground(),np.array([0,.001,0]),0)['accepted'])
 def test_xz_yaw_not_corrected(self):
  a,_,_=self.sequenced([0,.003,.003]);np.testing.assert_array_equal(a[1][[0,2]],[.02,0])
 def test_actual_midpoint_peak_covered_by_two_guards(self):
  class Spy:
   def contact_corners(self,c):return {'contact':False}
  raw=[row(x=xx,heightfn=lambda x,z:h)for xx,h in zip([0,.01,.02],[0,.004,0])];s=Spy();a=np.array([0,0,0]);m=np.array([.01,.004,0]);b=np.array([.02,0,0]);first=l.underbody_guard(s,ground(),a,m,0,0,raw[:2]);second=l.underbody_guard(s,ground(),m,b,0,0,raw[1:]);self.assertAlmostEqual(first['upperY'],.006);self.assertAlmostEqual(second['upperY'],.006)
 def test_full_footprint_rotation_enclosed(self):
  class Spy:
   def contact_corners(self,c):self.c=np.array(c);return {'contact':False}
  s=Spy();raw=[row(),row(yaw=.01)];r=l.underbody_guard(s,ground(),[0,0,0],[0,0,0],0,.01,raw);self.assertGreater(np.ptp(s.c[:,2]),.45);self.assertEqual(r['lowerY'],-.02)
 def test_unknown_guard_support_not_accepted(self):
  with self.assertRaises(ValueError):l.underbody_guard(None,ground(False),[0,0,0],[0,0,0],0,0,[row(),row()])
 def test_reordered_probes_rejected_before_continuity(self):
  a=row();b=row(.01);b['probes'][1],b['probes'][8]=b['probes'][8],b['probes'][1];r=l.continuity(a,b,0,np.zeros(3),0,np.array([.01,0,0]),0);self.assertFalse(r['accepted']);self.assertFalse(r['probeOrderValidated'])
if __name__=='__main__':unittest.main(verbosity=2)
