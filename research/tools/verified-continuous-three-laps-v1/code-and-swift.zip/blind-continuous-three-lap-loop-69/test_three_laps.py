import unittest,json,math
from unittest.mock import patch
import numpy as np
import loop_episode as le
import loop_map as lm
import loop_controller as lc
from source_runtime import ActualArrivalPlanner,SourcePlanner
from test_loop_contract import FakeModel
class Tests(unittest.TestCase):
 def test_fifteen_goals_same_sequence(self):
  p=lm.load_plan();self.assertEqual(len(p['legs']),15)
  for i in range(15):self.assertEqual(p['legs'][i]['originalTaskGoal'],p['legs'][i%5]['originalTaskGoal'])
 def test_boundaries_preserve_controller_time_and_no_actor_reset(self):
  p=lm.load_plan();c=lc.Controller();c.plan=p;c.model=FakeModel(p);c.goal=np.array(p['goal']);c.tick=123;c.revision=p['mapRevision']
  for i in range(1,15):
   r=c.consume({'command':'beginNextLeg','leg':i,'goal':p['legs'][i]['originalTaskGoal']})
   self.assertEqual(c.tick,123);self.assertEqual(c.model.leg,i);self.assertTrue(c.model.pending_replan);self.assertTrue(r['noReset']);self.assertEqual(c.revision,p['mapRevision'])
  with self.assertRaises(ValueError):c.model.begin_next(15)
 def test_source_modulo_at_lap_boundaries_and_identity(self):
  p=object.__new__(ActualArrivalPlanner);p.verify_runtime=lambda:{'sameGraph':True};p.validate_segments=lambda path:{'accepted':True}
  for leg in [4,5,9,10,14]:
   actual=[1.,.012,2.];goal=[3.,0.,4.]
   with patch.object(SourcePlanner,'query',return_value={'complete':True,'points':[actual,goal]})as q:r=p.query(actual,goal,leg)
   q.assert_called_once_with(actual,goal,leg%5);self.assertEqual(r['globalLeg'],leg);self.assertEqual(r['lapIndex'],leg//5);self.assertEqual(r['runtimeExclusionIdentity'],{'sameGraph':True})
 def circle(self):return np.array([[1.,0,0],[0,0,-1],[-1,0,0],[0,0,1],[1,0,0]])
 def plan(self):return {'start':[1.,0,0],'tableWindingPointOriginalXYZ':[0,0,0],'requiredActualWinding':-1,'requiredTotalActualWinding':-3}
 def test_three_laps_complete_not_two_or_fourteen_goals(self):
  p=self.plan();lap=le.lap_completion(self.circle(),p,0,self.circle()[-1]);total=le.actual_winding(np.vstack([self.circle(),self.circle()[1:],self.circle()[1:]]),[0,0,0]);self.assertTrue(le.three_lap_success(15,[lap]*3,total,p));self.assertFalse(le.three_lap_success(14,[lap]*3,total,p));self.assertFalse(le.three_lap_success(10,[lap]*2,total,p))
 def test_boundary_winding_failure_is_not_lap(self):
  p=self.plan();a=self.circle();back=np.vstack([a[:3],a[1::-1]]);r=le.lap_completion(back,p,0,back[-1]);self.assertFalse(r['accepted'])
 def test_original_start_not_relative_lap_start_owns_arrival(self):
  p=self.plan();a=self.circle();a[-1]=[1.36,0,0];self.assertFalse(le.lap_completion(a,p,1,a[-1])['accepted'])
 def test_lap_gap_recorded_not_teleported(self):
  a=self.circle();a[0]=[1.,0,.2];a[-1]=[1.,0,-.2];r=le.lap_completion(a,self.plan(),1,a[-1]);self.assertTrue(r['accepted']);self.assertAlmostEqual(r['topology']['mathematicalClosingGap3DMetres'],.4);self.assertTrue(r['closureWasNotExecuted'])
 def test_pending_boundary_cannot_arrive(self):
  a=np.array([1.,0,0]);self.assertFalse(le.arrived({'goalReached':True},False,True,a,a,2.,np.zeros(3)));self.assertFalse(le.arrived({'goalReached':True},True,False,a,a,2.,np.zeros(3)))
 def test_membership_cycles_but_queries_remain_fresh(self):
  from types import SimpleNamespace
  from test_local_support import row
  calls=[];raw=row();base=SimpleNamespace(support_probes=lambda p,y:(calls.append((p.copy(),y))or raw));g=SimpleNamespace(is_ground=lambda i:True,plane_coefficients=np.zeros(3))
  for ix in [4,9]:
   old=[g]*5;new=old[(ix+1)%5];r=le.overlap_admission(base,old[ix%5],new,np.zeros(3),0.);self.assertTrue(r['accepted'])
  self.assertEqual(len(calls),2)
 def test_reused_scorer_A_B_A_matches_fresh_and_membership_isolation(self):
  from test_low_objects import scene,plate
  le.motion.serial_vtk();base,reused,g=scene(plate(.01))
  ids=np.array([0,1,2],np.int64);ids.setflags(write=False)
  other=le.motion.GroundSupport(ids,{},base.surface,base.mesh,int(base.mesh.GetMTime()),base.transform,g.plane_coefficients)
  accepted=le.motion.GroundTiledReferenceContainer(base.surface,base.transform,ground=other,body=base.body)
  def check(s,p):return s.swept_contacts(p,p,0.,0.)['actualBody']
  a=np.array([0.,0,0]);b=np.array([1.,0,1.]);r1=check(reused,a);check(reused,b);check(accepted,a);r2=check(reused,a)
  fresh=le.motion.GroundTiledReferenceContainer(base.surface,base.transform,ground=g,body=base.body)
  for key in ['contact','firstReferenceCellID']:
   self.assertEqual(r1[key],r2[key]);self.assertEqual(r2[key],check(fresh,a)[key])
  self.assertTrue(r2['contact']);self.assertFalse(check(accepted,a)['contact'])
  np.testing.assert_equal(reused.support_probes(a,0),fresh.support_probes(a,0))
if __name__=='__main__':unittest.main()
