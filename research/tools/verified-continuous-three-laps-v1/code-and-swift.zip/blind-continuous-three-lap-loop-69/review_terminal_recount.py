from pathlib import Path
import json,lzma,gzip,numpy as np,math,hashlib
h=Path('blind-continuous-three-lap-loop-69');p=h/'run-01/result';r=json.load(open(p/'RESULT.json'));plan=json.load(open(h/'SELECTED_PLAN.json'));a=np.load(p/'ACTOR_TRACE.npz')['trace'];csv=np.loadtxt(p/'ACTUAL_TRACE_PARTIAL.csv',delimiter=',',skiprows=1);assert np.array_equal(a,csv);ev=[json.loads(s)for s in lzma.open(p/'TICK_EVIDENCE.jsonl.xz','rt')];assert len(a)==len(ev)+1==r['ticks']+1;distance=float(np.linalg.norm(np.diff(a[:,[2,4]],axis=0),axis=1).sum());assert abs(distance-r['actualDistanceMetres'])<1e-10;assert np.linalg.norm(np.diff(a[:,[2,4]],axis=0),axis=1).max()<=.025000001;assert abs(np.diff(a[:,5])).max()<=math.radians(1)+1e-10
actual3d=0;committed=0
for i,x in enumerate(ev):
 assert x['candidateStateCommitted'];moved=np.linalg.norm(a[i+1,2:5]-a[i,2:5])>1e-12 or abs(a[i+1,5]-a[i,5])>1e-12
 if not moved:continue
 committed+=1;assert all(not c['actualBody']['contact']and not c['horizontalMargin']['contact']for c in x['contacts']);assert len(x['contacts'])==2;guards=x['underbodyGuard']['halfSegments'];assert len(guards)==2 and not x['underbodyGuard']['contact']
 rows=x['movement']['supportRows'];pos=[a[i,2:5].copy(),(a[i,2:5]+a[i+1,2:5])/2,a[i+1,2:5].copy()];pos[1][1]=max(t['modelHeightY']for t in rows[1]['probes']);length=np.linalg.norm(pos[1]-pos[0])+np.linalg.norm(pos[2]-pos[1]);assert abs(length-x['movement']['attempted3DDistanceMetres'])<1e-12;assert length<=.025000001;actual3d+=length
 for j in range(2):
  old=rows[j]['probes'];new=rows[j+1]['probes'];assert len(old)==len(new)==9 and all(q['hit']for q in old+new);assert x['support'][j]['acceptedFiniteSupportModel'];disp=max(np.linalg.norm(np.array(q['modelXZ'])-v['modelXZ'])for q,v in zip(old,new));limit=.004+math.tan(math.radians(5))*disp;assert abs(max(q['modelHeightY']for q in new)-pos[j][1])<=limit+1e-12;assert not guards[j]['contact'];assert abs(guards[j]['lowerY']-(min(q['modelHeightY']for q in old+new)-.02))<1e-12;assert abs(guards[j]['upperY']-(max(pos[j][1],pos[j+1][1])+.002))<1e-12
assert abs(actual3d-r['actual3DDistanceMetres'])<1e-10
assert r['arrival']and r['completedLegs']==15 and r['completedLaps']==3;assert not r['finalPendingMotion'];assert r['finalAppliedCommand']['forward_metres']==0 and r['finalAppliedCommand']['yaw_radians']==0
arrivals=[]
for t in r['legTransitions']:
 assert not t['pendingMotion']and not t['appliedMotion'];assert np.linalg.norm(np.array(t['position'])-t['goal'])<=.35;assert np.array_equal(t['goal'],plan['legs'][t['leg']]['originalTaskGoal']);arrivals.append({'leg':t['leg'],'tick':t['tick'],'goalError':t['full3DGoalErrorMetres']})
 if t['leg']<14:assert t['nextMembershipOverlap']['accepted']and t['nextMembershipOverlap']['observedHeightMatchesActualFoot']and not t['nextMembershipUnderbodyGuard']['contact']
q=a[:,[2,4]]-np.array(plan['tableWindingPointOriginalXYZ'])[[0,2]];q=np.vstack([q,q[0]]);wind=float(np.arctan2(q[:-1,0]*q[1:,1]-q[:-1,1]*q[1:,0],(q[:-1]*q[1:]).sum(1)).sum()/(2*np.pi));assert abs(wind+3)<1e-5;gap=float(np.linalg.norm(a[-1,[2,4]]-a[0,[2,4]]));assert gap<=.35;assert r['actualTrajectoryWinding']['closingSegmentWasNotExecuted']
assert np.array_equal(a[:,0],np.arange(-1,len(ev)))
assert r['initialSettlementCount']==1 and r['actorInstanceCount']==1
assert r['membershipSequence']==[i%5 for i in range(15)]
laps=[];start_index=0
for li in range(3):
 end_index=r['legTransitions'][li*5+4]['tick']+1
 part=a[start_index:end_index+1];v=part[:,[2,4]]-np.array(plan['tableWindingPointOriginalXYZ'])[[0,2]];v=np.vstack([v,v[0]])
 w=float(np.arctan2(v[:-1,0]*v[1:,1]-v[:-1,1]*v[1:,0],(v[:-1]*v[1:]).sum(1)).sum()/(2*np.pi));assert abs(w+1)<1e-5
 rr=r['lapReceipts'][li];assert rr['accepted'] and rr['actualStartStateIndex']==start_index and rr['actualEndStateIndex']==end_index
 assert np.array_equal(rr['lapActualStartXYZ'],part[0,2:5]) and np.array_equal(rr['lapActualEndXYZ'],part[-1,2:5])
 assert np.linalg.norm(part[-1,2:5]-plan['start'])<=.35+1e-10
 gaplap=float(np.linalg.norm(part[-1,2:5]-part[0,2:5]));assert abs(gaplap-rr['topology']['mathematicalClosingGap3DMetres'])<1e-12
 laps.append({'lapIndex':li,'actualWinding':w,'startStateIndex':start_index,'endStateIndex':end_index,'mathematicalClosingGap3DMetres':gaplap,'closingSegmentNotExecuted':True});start_index=end_index
bounds=json.load(open('blind-polycam-table-loop-proposals-44/PROPOSED_PHYSICS_BOUNDS.json'))['perLeg'];ids=[];dualcount=0
for leg in range(1,15):
 f=p/f'SOURCE_REPLAN_LEG{leg}.json.gz';s=json.load(gzip.open(f,'rt'));t=r['legTransitions'][leg-1];assert s['complete'];assert np.array_equal(s['actualDeliveredXYZ'],t['position']);assert np.array_equal(s['points'][0],t['position']);assert np.array_equal(s['points'][-1],plan['legs'][leg]['originalTaskGoal']);identity=s['runtimeExclusionIdentity'];assert identity['markedCompactSpans']==636 and identity['baselineValidatorMarkedSpans']==0 and identity['graphSHA256']=='5d46b91940ff6b8d4aacab8e8c7f7b6c695ab91c65620ba06b05073b627cf681';xz=np.array(s['points'])[:,[0,2]];bo=np.array(bounds[leg%5]['floorCandidateXZBounds']);rad=math.hypot(.225,.15);assert np.all(xz.min(0)-rad>=bo[0])and np.all(xz.max(0)+rad<=bo[1]);v=s['dualSourceSegmentValidation'];assert v['accepted']and len(v['segments'])==len(s['points'])-1
 for seg in v['segments']:
  assert seg['accepted']
  for ctx in ['baseline','excluded']:
   c=seg[ctx];assert c['valid']and c['maximumSampleSpacing']<=.025+1e-12
   for pt in c['samples']:assert np.linalg.norm((np.array(pt['nativeXYZ'])-pt['requestedXYZ'])[[0,2]])<=1e-4 and abs(pt['nativeXYZ'][1]-pt['requestedXYZ'][1])<=.05
  dualcount+=1
 ids.append({'leg':leg,'actualStartMatchesDrainedArrival':True,'identity':identity,'querySHA256':hashlib.sha256(f.read_bytes()).hexdigest()})
out={'status':'threeContinuousSimulatedLapsIndependentlyRecounted','scope':'Saved complete trace/evidence/query recount; not independent full physics rerun or human navigation proof','traceRows':len(a),'ticks':len(ev),'committedMotionTicks':committed,'CSVAndNPZExactlyEqual':True,'actualHorizontalDistanceMetres':distance,'actual3DDistanceMetresIncludingMidpoints':actual3d,'drainedGoalArrivals':arrivals,'actualWinding':wind,'perLapRecount':laps,'finalHorizontalGapToInitialActualPoseMetres':gap,'closureIsMathematicalNotTraveled':True,'finalFIFOAndAppliedMotionDrained':True,'zeroCommittedOrPredictedBodyAndUnderbodyContacts':True,'allCommittedContinuityAndBothGuardsRecounted':True,'runtimeSourceQueriesVerified':ids,'dualSourceSegmentsVerified':dualcount,'sourceExclusionManuallyAssistedAndUncertaintyUnknown':True,'resultSHA256':hashlib.sha256((p/'RESULT.json').read_bytes()).hexdigest()};(h/'INDEPENDENT_TERMINAL_REVIEW.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items()if k!='runtimeSourceQueriesVerified'},indent=2))
