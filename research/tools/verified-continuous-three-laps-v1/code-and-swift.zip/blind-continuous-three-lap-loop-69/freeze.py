from pathlib import Path
import json,hashlib
H=Path(__file__).resolve().parent;W=H.parent;SOURCE=W/'blind-tabletop-exclusion-planner-66'
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb')as f:
  while b:=f.read(65536):h.update(b)
 return h.hexdigest()
f=json.loads((W/'blind-tabletop-exclusion-loop-67/FROZEN.json').read_text());files=f['files'].copy();files.update(json.loads((SOURCE/'FROZEN.json').read_text())['files']);files.update(json.loads((SOURCE/'SOURCE_RUNTIME_MANIFEST.json').read_text())['runtimeFiles'])
for p in [*H.glob('*.py'),H/'SELECTED_PLAN.json',H/'MOVEMENT_PROTOCOL.md',H/'EVIDENCE_CODEC.json',H/'DUAL_SOURCE_FIXED_PATH_AUDIT.json',H/'DUAL_SOURCE_FIXED_SEGMENTS.json.gz',SOURCE/'GRAPH_IDENTITY.json',SOURCE/'graph_identity.py',SOURCE/'SOURCE_RUNTIME_MANIFEST.json',SOURCE/'source-01/RESULT.json',SOURCE/'INDEPENDENT_SOURCE_RESULT_REVIEW.json',SOURCE/'FRAME_METADATA_PARITY.json',SOURCE/'METADATA_ONLY_PATH_PARITY.json',SOURCE/'GRID_MONOTONICITY_AUDIT.json']:
 files[str(p.relative_to(W))]=sha(p)
for p,d in files.items():assert sha(W/p)==d,p
for name in ['local_support.py','loop_controller.py','evidence_codec.py','run_loop.py']:
 assert(H/name).read_bytes()==(W/'blind-tabletop-exclusion-loop-67'/name).read_bytes(),name
assert not(H/'FROZEN.json').exists()
f['resourceLimits'].update(outputBytes=16*1024**2,CPUSeconds=2100,wallSeconds=2700,maxTicks=7500)
f.update(files=files,scope='69 three continuous laps; unchanged67 physical world and source exclusions; actual pose requery every handoff',outputCapBytes=16*1024**2,sourcePlanSHA256=sha(H/'SELECTED_PLAN.json'),physicalPoliciesUnchangedFrom67=True,requiredLaps=3,maxTicks=7500,sourceUnknownExclusion=True,runtimeExclusionRequiredAndVerified=True,sourceOnlyMetadataAllowlist=True)
(H/'FROZEN.json').write_text(json.dumps(f,indent=2)+'\n');print(sha(H/'FROZEN.json'),len(files))
