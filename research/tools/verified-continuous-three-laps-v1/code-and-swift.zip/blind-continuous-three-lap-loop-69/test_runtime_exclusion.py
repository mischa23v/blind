import unittest,copy,json
from pathlib import Path
from source_runtime import validate_receipt,EXPECTED,verify_initial_source_plan
class Tests(unittest.TestCase):
 def test_valid_frozen_provenance(self):validate_receipt(copy.deepcopy(EXPECTED['exclusionReceipt']),EXPECTED['graphSHA256'])
 def test_missing_or_invalid_exclusion_fails(self):
  for k,v in [('unknownExclusion',False),('markedCompactSpans',0),('rawPolygonInflated',True),('physicalAuthority',True),('affectedCandidateFootHeightInterval',[0,0])]:
   r=copy.deepcopy(EXPECTED['exclusionReceipt']);r[k]=v
   with self.assertRaises(ValueError):validate_receipt(r,EXPECTED['graphSHA256'])
 def test_old_graph_rejected(self):
  with self.assertRaises(ValueError):validate_receipt(EXPECTED['exclusionReceipt'],'old55graph')
 def test_initial_frozen_exclusion_path_required(self):
  p=json.loads((Path(__file__).resolve().parent/'SELECTED_PLAN.json').read_text());verify_initial_source_plan(p);p['legs'][0]['originalFramePath'][1][0]+=.01
  with self.assertRaises(ValueError):verify_initial_source_plan(p)
 def test_no_runtime_leg_zero_requery(self):
  from source_runtime import ActualArrivalPlanner
  p=object.__new__(ActualArrivalPlanner)
  with self.assertRaises(ValueError):p.query([0,0,0],[1,0,0],0)
 def test_reverse_edges_and_duplicates_not_hidden_by_hash(self):
  from source_runtime import validate_undirected_graph
  validate_undirected_graph([[(1,1.)],[(0,1.)]],2)
  for bad in [[[(1,1.)],[(0,2.)]],[[(1,1.)],[]],[[(1,1.),(1,1.)],[(0,1.)]],[[(2,1.)],[(0,1.)]]]:
   with self.assertRaises(ValueError):validate_undirected_graph(bad,2)
 def test_dual_context_checks_include_exact_connectors(self):
  import numpy as np
  from source_runtime import ActualArrivalPlanner
  class Native:
   def __init__(self,valid=True):self.valid=valid
   def sample(self,p):return np.array(p),.5
   def segment(self,a,b):return self.valid
  p=object.__new__(ActualArrivalPlanner);p.native=Native();p.baseline=Native();p.corrected=lambda a:np.array(a)
  path=np.array([[0,.012,0],[.01,0,0],[.4,0,0],[.41,.003,0]])
  r=p.validate_segments(path);self.assertTrue(r['accepted']);self.assertEqual(len(r['segments']),3);np.testing.assert_array_equal(r['segments'][0]['exactOriginalStartXYZ'],path[0]);np.testing.assert_array_equal(r['segments'][-1]['exactOriginalEndXYZ'],path[-1])
  for q in r['segments']:
   for context in ['baseline','excluded']:self.assertLessEqual(q[context]['maximumSampleSpacing'],.025)
  p.baseline.valid=False;self.assertFalse(p.validate_segments(path)['accepted'])
 def test_failed_dual_check_rejects_without_path_replacement(self):
  from unittest.mock import patch
  from source_runtime import ActualArrivalPlanner,SourcePlanner
  p=object.__new__(ActualArrivalPlanner);p.verify_runtime=lambda:{'fixtureIdentity':True};p.validate_segments=lambda path:{'accepted':False,'fixture':True};path=[[0,0,0],[1,0,0]]
  with patch.object(SourcePlanner,'query',return_value={'complete':True,'points':path}):r=p.query([0,0,0],[1,0,0],1)
  self.assertFalse(r['complete']);self.assertEqual(r['points'],path);self.assertEqual(r['reason'],'baselineOrExcludedSourceSegmentRejected')
if __name__=='__main__':unittest.main()
