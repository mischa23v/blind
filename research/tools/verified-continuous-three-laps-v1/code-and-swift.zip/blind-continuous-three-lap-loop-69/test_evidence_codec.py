import unittest,tempfile,lzma,json
from pathlib import Path
from evidence_codec import read_jsonl,partial_xz_complete_lines
class Tests(unittest.TestCase):
 def test_lossless_and_explicit_truncated_prefix(self):
  rows=[{'tick':i,'x':i*.000123456789012345,'payload':str(i*i)*20}for i in range(10000)]
  raw=b''.join((json.dumps(x,separators=(',',':'))+'\n').encode()for x in rows);packed=lzma.compress(raw,preset=6)
  with tempfile.TemporaryDirectory()as t:
   p=Path(t)/'data.jsonl.xz';p.write_bytes(packed);self.assertEqual(read_jsonl(p),rows);full=partial_xz_complete_lines(p);self.assertTrue(full['streamComplete']);self.assertEqual(full['rows'],rows)
   p.write_bytes(packed[:len(packed)//2]);partial=partial_xz_complete_lines(p);self.assertFalse(partial['streamComplete']);self.assertGreater(len(partial['rows']),0);self.assertLess(len(partial['rows']),len(rows));self.assertEqual(partial['rows'],rows[:len(partial['rows'])])
if __name__=='__main__':unittest.main()
