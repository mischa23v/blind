from pathlib import Path
import json,numpy as np
from PIL import Image,ImageDraw,ImageFont
H=Path(__file__).resolve().parent;W=H.parent;r=json.loads((H/'run-01/result/RESULT.json').read_text());plan=json.loads((H/'SELECTED_PLAN.json').read_text())
with np.load(W/'blind-polycam-alignment-feasibility-36/POLYCAM_INTRINSIC_GEOMETRY.npz')as z:v=z['verticesOBJ'];tri=z['triangles']
with np.load(W/'blind-polycam-rigid-registration-37/run-01/CANDIDATE_RIGID_TRANSFORM.npz')as z:lev=v@z['rotationOBJToLevel'].T+z['translationOBJToLevel']
f=json.loads((W/'blind-polycam-comparator-publication-42/PHONE_FRAME_METADATA_ONLY.json').read_text())['frames'];R=np.array(f['original']['R']);t=np.array(f['original']['t']);N=np.array(f['corrected']['R']);nt=np.array(f['corrected']['t'])
def original(lev):
 old=((lev-nt)@N)@R.T+t;return np.c_[old[:,0],old[:,2],-old[:,1]]
v=original(lev);xyz=v[tri];keep=(xyz.mean(1)[:,1]>.15)&(xyz.mean(1)[:,1]<1.8);lo=v[:,[0,2]].min(0);hi=v[:,[0,2]].max(0)
poly=np.array(json.loads((W/'blind-tabletop-exclusion-hypothesis-65/FROZEN_EXCLUSION.json').read_text())['polygonPlannerXZ']);poly=original(np.c_[poly[:,0],-poly[:,1],np.zeros(len(poly))])
with np.load(H/'run-01/result/ACTOR_TRACE.npz')as z:a=z['trace']
im=Image.new('RGB',(1500,950),'white');d=ImageDraw.Draw(im);font='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf';big=ImageFont.truetype(font,27);sm=ImageFont.truetype(font,17);scale=min(430/(hi[0]-lo[0]),650/(hi[1]-lo[1]));colors=['#16773b','#225fba','#9b3d9c']
d.text((25,18),'Three continuous simulated laps — 61.792 m, 15 / 15 goals, zero nonground contacts',font=big,fill='black');d.text((25,58),'Same actor and FIFO throughout; no resets. 45 x 30 x 160 cm body, zero margin. Static recorded room.',font=sm,fill='black')
for k,lap in enumerate(r['lapReceipts']):
 def p(q):return(25+k*500+(q[0]-lo[0])*scale,145+(q[2]-lo[1])*scale)
 b=a[lap['actualStartStateIndex']:lap['actualEndStateIndex']+1];dist=np.linalg.norm(np.diff(b[:,[2,4]],axis=0),axis=1).sum();d.text((25+k*500,100),f'Lap {k+1}: {dist:.3f} m | winding -1',font=big,fill=colors[k])
 for q in xyz[keep]:d.line([p(x)for x in q]+[p(q[0])],fill='#dddddd',width=1)
 d.polygon([p(q)for q in poly],fill='#ffda9b',outline='#a55300');d.line([p(q)for q in b[:,2:5]],fill=colors[k],width=4)
 for j,q in enumerate([plan['start'],*[x['originalTaskGoal']for x in plan['legs'][:4]]]):
  x,y=p(q);d.ellipse((x-3,y-3,x+3,y+3),fill='#111111');d.text((x+5,y),str(j),font=sm,fill='black')
 x,y=p(plan['start']);rr=.35*scale;d.ellipse((x-rr,y-rr,x+rr,y+rr),outline='#7550a0',width=2)
 d.text((25+k*500,810),f"States {lap['actualStartStateIndex']}–{lap['actualEndStateIndex']}",font=sm,fill='black');d.text((25+k*500,838),f"Unexecuted closing gap: {lap['topology']['mathematicalClosingGap3DMetres']*100:.2f} cm",font=sm,fill='black')
d.text((25,883),'Colored lines: actual committed movement. Orange: source-only unknown tabletop exclusion. Purple: 35 cm return region.',font=sm,fill='black');d.text((25,911),'Assisted source ROI + evaluator floor support. Ground contacts unmeasured. Not live-phone navigation or human-safety proof.',font=sm,fill='black');im.save(H/'ACTUAL_THREE_LAPS.png')
