"""Lossless evidence reader; partial recovery never implies a complete run."""
from pathlib import Path
import gzip,lzma,json

def open_text(path):
 path=Path(path)
 if path.suffix=='.xz':return lzma.open(path,'rt',encoding='utf-8')
 if path.suffix=='.gz':return gzip.open(path,'rt',encoding='utf-8')
 return path.open('r',encoding='utf-8')
def read_json(path):
 with open_text(path)as f:return json.load(f)
def read_jsonl(path):
 with open_text(path)as f:return [json.loads(line)for line in f if line.strip()]
def partial_xz_complete_lines(path):
 # Recovery helper for budget interruption: only complete JSON lines returned;
 # explicit stream-complete marker must be checked before full-run claims.
 d=lzma.LZMADecompressor();raw=bytearray()
 with Path(path).open('rb')as f:
  while chunk:=f.read(65536):
   raw.extend(d.decompress(chunk))
   if d.eof:break
 lines=bytes(raw).split(b'\n');return {'streamComplete':d.eof,'rows':[json.loads(x)for x in lines[:-1]if x.strip()],'trailingIncompleteBytes':len(lines[-1])}
