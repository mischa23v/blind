import unittest,sys,numpy as np
from pathlib import Path
H=Path(__file__).resolve().parent;W=H.parent;sys.path.insert(0,str(H));import loop_episode as e
from local_support import underbody_guard
from test_local_support import row
sys.path.insert(0,str(W/'blind-split-candidate-game-03/source'));import test_oriented_container as f
from reference_geometry import ReferenceSurface

def plate(y):return [[[.002,y,-.003],[.008,y,-.003],[.005,y,.003]]]
def scene(extra=(),floorheight=0.):
 floor=np.array(f.floor());floor[:,:,1]+=floorheight;surface=ReferenceSurface(f.mesh(floor.tolist()+list(extra)));T=np.eye(4);ids=np.array([0,1],np.int64);ids.setflags(write=False);g=e.motion.GroundSupport(ids,{},surface,surface.mesh,int(surface.mesh.GetMTime()),T,np.array([0,0,.016]));body=e.legacy.BodyGeometry(width=.45,depth=.3,height=1.6,horizontal_margin=0.);base=e.legacy.OrientedReferenceContainer(surface,T,body);return base,e.motion.GroundTiledReferenceContainer(surface,T,ground=g,body=body),g
class Tests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):e.motion.serial_vtk()
 def test_10mm_nonground_toy_body_detected(self):
  _,s,g=scene(plate(.01));self.assertTrue(s.swept_contacts([0,0,0],[.02,0,0],0,0)['actualBody']['contact'])
 def test_1mm_nonground_toy_underbody_detected(self):
  _,s,g=scene(plate(.001));a=np.array([0.,0,0]);b=np.array([.02,0,0]);self.assertFalse(s.swept_contacts(a,b,0,0)['actualBody']['contact']);self.assertTrue(underbody_guard(s,g,a,b,0,0,[s.support_probes([0,0,0],0),s.support_probes([.02,0,0],0)])['contact'])
 def test_only_floor_membership_exempted(self):
  _,s,g=scene();self.assertFalse(underbody_guard(s,g,[0,0,0],[.02,0,0],0,0,[s.support_probes([0,0,0],0),s.support_probes([.02,0,0],0)])['contact']);np.testing.assert_array_equal(g.ground_cell_ids,[0,1])
 def test_untyped_coplanar_geometry_blocked(self):
  _,s,g=scene(plate(0));self.assertTrue(underbody_guard(s,g,[0,0,0],[.02,0,0],0,0,[s.support_probes([0,0,0],0),s.support_probes([.02,0,0],0)])['contact'])
 def test_guard_rejects_floating_actual_foot(self):
  _,s,g=scene()
  with self.assertRaises(ValueError):underbody_guard(s,g,[0,.016,0],[.02,.016,0],0,0,[s.support_probes([0,0,0],0),s.support_probes([.02,0,0],0)])
 def test_initial_settlement_recorded_before_guard_stop(self):
  base,s,g=scene(plate(.004),floorheight=.003);p=e.load_plan();p['start']=[0.,0.,0.];p['initialYawRadians']=0.;r=e.episode(p,base,[g]*5,Path('/tmp/unused61initialguard'))
  self.assertEqual(r['status'],'initialNonFloorUnderbodyGuardContact');self.assertAlmostEqual(r['initialVerticalSettlementMetres'],.003,places=7);self.assertFalse(r['motionExecuted']);self.assertTrue(r['globalPlaneProvenanceOnly'])
if __name__=='__main__':unittest.main(verbosity=2)
