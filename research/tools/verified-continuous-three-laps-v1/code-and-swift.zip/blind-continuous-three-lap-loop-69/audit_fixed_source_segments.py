from pathlib import Path
import json,gzip,time
H=Path(__file__).resolve().parent
from source_runtime import ActualArrivalPlanner,SOURCE,sha
r=json.loads((SOURCE/'source-01/RESULT.json').read_text());p=ActualArrivalPlanner();start=time.monotonic();rows=[];full=[]
for leg in r['legs']:
 q=p.validate_segments(leg['originalFramePath']);full.append(q);rows.append({'leg':leg['leg'],'accepted':q['accepted'],'segments':len(q['segments']),'failedSegmentIndices':[x['segment']for x in q['segments']if not x['accepted']]})
identity=p.verify_runtime();p.close()
with gzip.open(H/'DUAL_SOURCE_FIXED_SEGMENTS.json.gz','wt')as f:json.dump(full,f,separators=(',',':'))
out={'scope':'fixed source66 complete paths and exact connectors checked against both baseline and exclusion native maps; no reference geometry or route changes','allSegmentsAccepted':all(x['accepted']for x in rows),'legs':rows,'sourceResultSHA256':sha(SOURCE/'source-01/RESULT.json'),'runtimeSourceSHA256':sha(H/'source_runtime.py'),'runtimeExclusionIdentity':identity,'maximumSampleSpacingMetres':.025,'wallSeconds':time.monotonic()-start,'movementExecuted':False};(H/'DUAL_SOURCE_FIXED_PATH_AUDIT.json').write_text(json.dumps(out,indent=2)+'\n');print(out)
