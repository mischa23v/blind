# Three continuous simulated table laps — completed

**The same simulated actor completed all three laps without resetting, reaching
15 of 15 original goal regions and traveling 61.792 m horizontally.** All predicted
and committed non-floor body/underbody contact counts were zero. The independent
saved-evidence recount passed. This is an assisted, static recorded-room result,
not live iPhone navigation or a human-safety certificate.

![Actual committed trajectories for all three laps](ACTUAL_THREE_LAPS.png)

## Measured outcome

| Measure | Result |
|---|---:|
| Original goal regions reached, with actuator drained | 15 / 15 |
| Completed continuous laps | 3 |
| Actual horizontal distance | 61.791889 m |
| Actual 3D distance, including measured support midpoints | 61.903697 m |
| Committed movement ticks | 4,909 |
| Total ticks / saved states | 4,924 / 4,925 |
| Predicted or committed non-floor body/underbody contacts | 0 |
| Initial settlements / actor instances | 1 / 1 |
| Actual winding per lap / total | −1, −1, −1 / −3 |
| Final distance from original nominal start | 33.052936 cm |
| Wall time / process-tree CPU time | 1,618.38 s / 1,637.43 s |
| Peak sampled/waited process-tree RSS | 2,427,781,120 bytes |

The body remained **45 × 30 × 160 cm, with zero horizontal margin**. No collision
rule, support threshold, obstacle or reference geometry was relaxed for this run.
Floor faces retain the existing evaluator-assisted exemption; floor contact events
are **unmeasured**, not counted as zero.

| Lap | Actual trace states (inclusive) | Horizontal distance | End-to-lap-start gap |
|---|---|---:|---:|
| 1 | 0–1,668 | 20.393912 m | 33.052121 cm |
| 2 | 1,668–3,296 | 20.698989 m | approximately 4.4 × 10⁻¹⁶ m |
| 3 | 3,296–4,924 | 20.698989 m | approximately 2.4 × 10⁻¹⁵ m |

Every return was inside the unchanged original **35 cm full-3D goal region**.
Lap 2 begins at the actual endpoint of lap 1; lap 3 begins at the actual endpoint
of lap 2. There was no artificial motion to close a loop. Winding calculations
use a mathematical closing chord, explicitly reported as unexecuted and excluded
from traveled distance. The tiny lap 2/3 gaps reflect deterministic repetition,
not independent robustness trials.

## What changed from stage 67

Only the predeclared repetition protocol and its accounting/resource limits:
- Fifteen goals repeat the same original five-goal sequence three times.
- The existing source-only planner queries from the actual delivered stationary
  pose at all 14 handoffs, including lap boundaries. Source bounds and immutable
  floor membership use leg modulo five.
- One actor, FIFO and monotonic simulation clock persist throughout. There is
  exactly one initial settlement, with no later reset, teleport or height snap.
- Five scorer objects are reused. Every handoff still performs fresh overlap,
  static-body and underbody checks. Query optimization evidence is grouped by
  those five memberships, preserving all calls across laps.
- Limits were frozen before launch: 7,500 ticks, 2,100 CPU seconds, 2,700 wall
  seconds, 3.5 GiB RSS, 16 MiB output and 768 MiB disk reserve.

The source65 manually assisted, uncertainty-labeled tabletop exclusion, source66
native Recast/Detour graph and costs, actual-arrival routing, stage59 ground IDs,
stage61 local support model, full-body sweeps and underbody guards stayed fixed.
Every runtime route checked the same polygon/library/graph identity and actual
native handles: **636 excluded spans versus zero in the baseline validator**.
All **137 runtime route segments**, including exact connectors, passed both native
contexts at sample spacing no greater than 25 mm. No reference geometry selected
a route or modified the source map.

## Independent review and reproduction

- `FROZEN.json`: 559 input hashes; SHA-256
  `f9c95f9ec2c273fbb8ca541fd9b51fac26f7e9cf2338c9f6b8ee00c6b1d4692f`.
- `INDEPENDENT_FINAL_REVIEW.json`: prelaunch gate, all 81 fixtures passed.
- `run-01/RUN_RECEIPT.json`: successful bounded process and resource evidence.
- `run-01/result/RESULT.json`: full terminal result and lap/handoff receipts.
- `run-01/result/ACTUAL_TRACE_PARTIAL.csv` and `ACTOR_TRACE.npz`: byte-value-exact
  matching committed traces; CSV flushed each row.
- `TICK_EVIDENCE.jsonl.xz`, `QUERY_OPTIMIZATION.json.xz` and fourteen
  `SOURCE_REPLAN_LEG*.json.gz` files retain full detailed evidence.
- `INDEPENDENT_TERMINAL_REVIEW.json` and `review_terminal_recount.py`: independent
  recount of all ticks, guards, continuity bounds, arrivals, topology and queries.
- `MOVEMENT_PROTOCOL.md`: predeclared method, budget and limitations.
- `draw_three_laps.py`: figure generated from actual recorded positions.

With the pinned workspace inputs present, the existing run is reproduced by the
frozen wrapper in a fresh output workspace; it refuses to overwrite `run-01`.
Saved-evidence verification: `python blind-continuous-three-lap-loop-69/review_terminal_recount.py`.

## What remains unproven

This is one static room and a nominal simulated actor with exact delivered poses.
Its map includes a manually assisted source image contour and evaluator-assisted
floor membership/support. It is **not** an automatic phone-only perception result.
No sensor latency, pose noise, moving person, moved furniture, small-toy detection,
live-device scan, iPhone timing, child trial or three-month reliability test is
established by these three laps. Ground contacts are not measured. The zero-margin
body is not a real-world error budget. Prior failed runs remain preserved.

The result establishes the requested three-lap movement milestone under this
explicit model; it does not remove the perception and live-navigation work ahead.
