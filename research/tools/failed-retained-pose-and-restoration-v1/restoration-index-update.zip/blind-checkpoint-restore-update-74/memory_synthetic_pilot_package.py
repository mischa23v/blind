from pathlib import Path
import json,hashlib,zipfile,io,base64,sys,os
R=Path(os.environ.get('CHECKPOINT_WORKSPACE',Path(__file__).resolve().parent.parent));O=R/'blind-synthetic-pilot-publication';mp=O/'MANIFEST.json'
D=['blind-synthetic-stress-protocol-72','blind-synthetic-first-leg-pilot-73']
if not mp.exists():
 fs=[];inputs={}
 for d in D:
  mf=R/d/('MANIFEST.json'if d.endswith('-72')else'PUBLICATION_MANIFEST.json');raw=mf.read_bytes();inputs[str(mf.relative_to(R))]=hashlib.sha256(raw).hexdigest();data=json.loads(raw);allow=data.get('files',data);paths=sorted(allow)
  if mf.name not in paths:paths.append(mf.name)
  for rel in paths:
   p=R/d/rel;assert not p.is_symlink();b=p.read_bytes()
   if rel in allow:
    expected=allow[rel]if isinstance(allow[rel],str)else allow[rel]['sha256'];assert hashlib.sha256(b).hexdigest()==expected,str(p)
   g='code-and-protocol'
   if any(x in p.parts for x in ['pilot-nominal','pilot-command_delay','pilot-temporal_jitter']):g='pilots-nominal-delay-jitter'
   if any(x in p.parts for x in ['pilot-extra_translation','pilot-tracking_interruption']):g='pilots-translation-interruption'
   fs.append({'path':str(p.relative_to(R)),'source':str(p.relative_to(R)),'group':g,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
 for p,dest in [(O/'README.md','PUBLICATION/README.md'),(O/'CURRENT_CHECKPOINT_PREFIX.md','PUBLICATION/CURRENT_CHECKPOINT_PREFIX.md'),(R/'blind-tabletop-exclusion-planner-66/License.txt','THIRD_PARTY/RECAST_LICENSE.txt')]:
  b=p.read_bytes();fs.append({'path':dest,'source':str(p.relative_to(R)),'group':'code-and-protocol','bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
 mp.write_text(json.dumps({'scope':'Public source-derived five short synthetic first-leg pilots and frozen development protocol; no private data or live navigation validation.','source':'Xuqian Ren et al., MuSHRoom: https://zenodo.org/records/10230733 and https://zenodo.org/records/10222321; CC BY4.0 https://creativecommons.org/licenses/by/4.0/. Modifications documented; Recast license included.','inputPublicationManifestSHA256':inputs,'files':fs},indent=2)+'\n')
m=json.loads(mp.read_text());groups=sorted(set(e['group']for e in m['files']))
def make(g):
 buf=io.BytesIO()
 with zipfile.ZipFile(buf,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6)as z:
  for e in m['files']:
   if e['group']!=g:continue
   source=R/e['source']
   if e['path'] in ('PUBLICATION/README.md','PUBLICATION/CURRENT_CHECKPOINT_PREFIX.md'):
    source=O/'ORIGINAL_ARCHIVE_WRAPPERS'/Path(e['path']).name
   b=source.read_bytes();assert len(b)==e['bytes']and hashlib.sha256(b).hexdigest()==e['sha256'],e['path'];i=zipfile.ZipInfo(e['path'],(2026,10,26,0,0,0));i.compress_type=zipfile.ZIP_DEFLATED;i.external_attr=0o100644<<16;z.writestr(i,b)
  i=zipfile.ZipInfo('MANIFEST.json',(2026,10,26,0,0,0));i.compress_type=zipfile.ZIP_DEFLATED;i.external_attr=0o100644<<16;z.writestr(i,mp.read_bytes())
 b=buf.getvalue();assert len(b)<=int(6*1024**2),(g,len(b));return b
def meta(g,b):return {'group':g,'archiveBytes':len(b),'base64Chars':4*((len(b)+2)//3),'sha256':hashlib.sha256(b).hexdigest(),'gitBlobSHA':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(),'files':sum(e['group']==g for e in m['files'])+1}
if sys.argv[1]=='--metadata':
 out={'manifestSHA256':hashlib.sha256(mp.read_bytes()).hexdigest(),'groups':[meta(g,make(g))for g in groups]};(O/'PACKAGE_METADATA.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
else:
 g=sys.argv[1];assert g in groups;b=make(g)
 if len(sys.argv)>2:o=int(sys.argv[2]);print(base64.b64encode(b).decode()[o:o+120000],end='')
 else:print(json.dumps(meta(g,b)))
