# Checkpoint restoration index update

The index now retains all seven previous entries and adds thirteen verified archive groups from commits `219dc42`, `735ce766`, and `a148b4ef` (twenty entries total). Publication receipts and package metadata supply the hashes; the publishing root confirmed exact remote archive paths against its verified trees. This update performs no downloads or restoration into the project workspace.

`checkpoint.py` is byte-identical to stage 62: dry-run by default, checksum verification before writing, missing-file-only restoration on explicit `--restore`, no overwrite, no execution, and no automatic dependency acquisition. ZIP groups are not standalone environments. `PREVIOUS_INDEX.json` preserves the original seven entries. Fourteen fixtures include unsafe archive handling and wrapper-identity regressions.

## Archived wrappers versus current summaries

The stage 73 archives contain the original pinned `PUBLICATION/README.md` and `PUBLICATION/CURRENT_CHECKPOINT_PREFIX.md`. The readable publication-root summaries were subsequently edited; they are not substitutes for those archived bytes.

`memory_synthetic_pilot_package.py` resolves exactly those two archive members to `blind-synthetic-pilot-publication/ORIGINAL_ARCHIVE_WRAPPERS/`. It checks their original manifest hashes. All other sources still use their original manifest paths. Changing a readable summary cannot change an archive; changing an original snapshot fails closed. The existing manifest and original ZIP identities are unchanged. The historical wrapper note describes the previous broken-emitter state; this revision resolves it without altering that history.

Set `CHECKPOINT_WORKSPACE` to the project workspace (default: parent of this tool folder). Run `python memory_synthetic_pilot_package.py <group>` for identity metadata or append a base64 character offset for an in-memory chunk. `--metadata` rewrites only identical package metadata after validation. No ZIP files are created on disk. `ARCHIVE_REBUILD_CHECK.json` records all three reproduced identities and member checks.

Tests: `python test_checkpoint.py`. Example dry-run: `python checkpoint.py synthetic-pilot-code-and-protocol /path/to/code-and-protocol.zip --workspace /path/to/existing/workspace`. Downloading is intentionally outside this tool. Divergent current summaries at an archived member destination will be rejected, not overwritten.
