# Retaining unexpired poses reduced stops but failed the journey

**This candidate did not arrive.** It hit the unchanged450-tick limit after only
1.240m. The preserved stage73 jitter baseline arrived after370ticks and2.800m.
Reducing no-pose stops was not enough and did not improve usable navigation.

| Metric | Stage73: stop on no new packet | Stage74: retain unexpired packet |
|---|---:|---:|
| Arrival | Yes | **No — tick budget** |
| Ticks | 370 | 450 |
| Actual horizontal distance | 2.800m | 1.240m |
| No usable pose / no-pose stop ticks | 193 | 2 |
| Retained-observation ticks | 0 | 229 |
| Maximum delivered position error | 6.0004cm | 8.0001cm |
| Maximum delivered yaw error | 3° | 4° |
| Maximum original capture age | 266.7ms | 266.7ms |
| Predicted body/underbody contacts or support veto | 0 | 0 |

Both used the same jitter seed/magnitudes, source route/exclusion,45×30×160cm
zero-margin body and physical support/collision guards. Stage74 retained exact
old coordinates/yaw with original timestamps; it never predicted or injected true
current pose. All outputs and the failed attempt remain intact. No parameter was
changed after this result.

## Exact cause found in the saved evidence

This is a **waypoint/progress handling failure, not insufficient corridor width**.
All448 steering ticks continued targeting the same first source corner:
`[-1.9500001904, 0, 2.0499994672]` in the original game frame.

The cursor consumes a corner only when a selected delivered position is within
1cm. At tick63 the transport releases captures59,60,61 and62 together. Capture61
is inside that unchanged radius (about6.16mm), but the adapter selects only the
newest, capture62. Capture61 is coalesced away from controller input. The closest
selected delivered observation over the whole failed attempt is14.17mm away;
the cursor never advances, even though some captured/actual positions passed
inside the radius.

Retaining an old yaw also repeats the same steering correction while the physical
actor has already turned. Example ticks48–52 reuse the same captured yaw/error
and repeatedly apply its correction. The run accumulates442.09° of absolute yaw
motion across448 yaw ticks, with only62 forward ticks. The actor repeatedly turns
back toward the stale corner instead of progressing. The actual position trace
is used here only to diagnose the result, never as a controller correction.

`WAYPOINT_DIAGNOSIS.json` and `diagnose_waypoint.py` preserve exact packet IDs,
capture/release timestamps, chosen target, selected versus actual distances and
per-tick steering evidence. The full capture61 measurement was already present in
the released packet batch; diagnosing this does not require inventing geometry.

A principled **unimplemented** candidate is to process all valid, monotonic
released measurements for waypoint-progress accounting while steering only from
the newest, keeping the same1cm radius and geometry. That addresses information
lost by coalescing; it is not proof that all delayed-yaw/overshoot issues disappear.
Any prediction from commands would need explicit uncertainty and must not be
represented as measured motion. No new controller fix or physics rerun is included
in this packet.

## Verification and limits

- Frozen input manifest:586 pins,
  `12fed4bc8f5097c830fd391932d424e133015e36fa5f6c49631829d2a834193d`.
-91 prelaunch fixtures independently passed.
- `INDEPENDENT_TERMINAL_RECOUNT.json` independently verifies transport retention,
  actor replay, CSV/NPZ equality, all committed support/body/underbody evidence and
  unchanged frozen inputs. Original capture timestamps stayed intact.
- Wrapper completed within111.20CPU/110.01wall seconds and≈2.18GiB peak RSS.
  The episode itself **failed arrival**, even though the bounded process succeeded.
- `pilot-temporal_jitter/result/RESULT.json`, exact trace and lossless XZ evidence
  contain the complete failure. CSV was flushed per row.

No predicted collision veto occurred; nonetheless this is a navigation failure.
Zero committed contacts is not robustness proof because the reference evaluator
would veto an unsafe proposal. Floor contacts are unmeasured. This remains one
short synthetic route with assisted floor support/source ROI—not a live-phone,
100-episode or human-safety validation. Stage73 and successful three-lap69 are
unchanged.
