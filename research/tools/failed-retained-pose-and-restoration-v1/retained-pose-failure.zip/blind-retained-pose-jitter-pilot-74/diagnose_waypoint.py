"""Read-only saved-evidence diagnosis; never a controller correction."""
from pathlib import Path
import json,lzma,math,hashlib
import numpy as np
H=Path(__file__).resolve().parent;p=H/'pilot-temporal_jitter/result';a=np.load(p/'ACTOR_TRACE.npz')['trace'];events=[json.loads(x)for x in lzma.open(p/'TICK_EVIDENCE.jsonl.xz','rt')];rows=[]
for i,e in enumerate(events):
 obs=e['deliveredPose'];points=e['cue'].get('nativeCandidatePoints',[])
 if not obs or not points:continue
 q=np.asarray(obs['position']);target=next((np.asarray(v)for v in points if np.linalg.norm((np.asarray(v)-q)[[0,2]])>.01),None)
 if target is None:continue
 delta=target-q;heading=math.atan2(delta[2],delta[0]);err=math.atan2(math.sin(heading-obs['yaw']),math.cos(heading-obs['yaw']))
 rows.append({'tick':i,'targetXYZ':target.tolist(),'deliveredDistanceToTargetMetres':float(np.linalg.norm((target-q)[[0,2]])),'actualDistanceToTargetMetres':float(np.linalg.norm((target-a[i,2:5])[[0,2]])),'actualXYZBeforeCommand':a[i,2:5].tolist(),'deliveredPose':obs,'issuedForward':e['cue']['forwardMetres'],'issuedYawRadians':e['cue']['yawRadians'],'steeringErrorRadians':err})
targets={tuple(x['targetXYZ'])for x in rows};assert len(targets)==1;target=np.array(next(iter(targets)));cross=events[63]['poseDelivery'];release=[]
for r in cross['released']:
 obs=r['packet']['pose'];release.append({'sourceTick':r['source_tick'],'scheduledTick':r['scheduled_tick'],'deliveredTick':r['delivered_tick'],'position':obs['position'],'capturedAt':obs['capturedAt'],'distanceToUnchangedWaypointMetres':float(np.linalg.norm((np.array(obs['position'])-target)[[0,2]])),'selectedForController':r['source_tick']==cross['selectedSourceTick']})
turns=[x['appliedCommand']['yaw_radians']for x in events];forward=[x['appliedCommand']['forward_metres']for x in events];out={'scope':'saved failure diagnosis; actual trace used only for evaluation, never controller input or route selection','sourceResultSHA256':hashlib.sha256((p/'RESULT.json').read_bytes()).hexdigest(),'unchangedConsumptionRadiusMetres':.01,'singleTargetForAllSteeringTicks':target.tolist(),'steeringTicks':len(rows),'minimumSelectedDeliveredDistanceMetres':min(x['deliveredDistanceToTargetMetres']for x in rows),'minimumActualPrecommandDistanceMetres':min(x['actualDistanceToTargetMetres']for x in rows),'yawTicks':sum(bool(x)for x in turns),'forwardTicks':sum(bool(x)for x in forward),'absoluteYawTravelDegrees':sum(abs(x)for x in turns)*180/math.pi,'tick63ReleasedPackets':release,'retainedObservationCausesRepeatedOldYawCorrectionsExampleTicks':list(range(48,53)),'rows':rows,'candidateNotImplemented':'Process all valid monotonic released measurements for waypoint-progress accounting, steer from newest only; keep radius and geometry unchanged. This alone is not proven to fix all delayed-control problems.'};(H/'WAYPOINT_DIAGNOSIS.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items()if k!='rows'},indent=2))
