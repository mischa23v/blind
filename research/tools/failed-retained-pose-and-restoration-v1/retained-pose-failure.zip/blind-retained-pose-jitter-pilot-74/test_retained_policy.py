import unittest,copy
from unittest.mock import patch
import pose_delivery as d
import test_pose_delivery as base_tests
class Tests(unittest.TestCase):
 def test_retained_identical_coordinates_and_capture_timestamp(self):
  c=d.condition_by_id('nominal');c['withholdCaptureTicks']=[1,10];q=d.PoseDelivery(c,72000);p0,_=q.capture_and_release(0,100,[1,2,3],.2,'r',0)
  for t in range(1,8):
   p,r=q.capture_and_release(t,100+t/15,[99,99,99],2.,'r',0);self.assertEqual(p['position'],[1,2,3]);self.assertEqual(p['yaw'],.2);self.assertEqual(p['capturedAt'],100);self.assertEqual(p['capturedTick'],0);self.assertTrue(r['retainedObservation']);self.assertEqual(p['deliveryMode'],'retained');self.assertTrue(d.validate_delivered_pose(p,'r',0,t,100+t/15,0,100,p0)[0])
  p,r=q.capture_and_release(8,100+8/15,[99,99,99],2.,'r',0);self.assertIsNone(p)
 def test_retained_without_previously_accepted_packet_rejects(self):
  p=base_tests.Tests().packet();p['deliveryMode']='retained';self.assertFalse(d.validate_delivered_pose(p,'r',0,1,100+1/15,-1,-float('inf'),None)[0])
 def test_retained_changed_fields_or_redated_capture_reject(self):
  old=base_tests.Tests().packet()
  for field,value in [('position',[.01,0,0]),('yaw',.01),('capturedTick',1),('capturedAt',100+1/15),('sessionID','wrong')]:
   p=copy.deepcopy(old);p['deliveryMode']='retained';p[field]=value;self.assertFalse(d.validate_delivered_pose(p,'r',0,1,100+1/15,0,100,old)[0])
 def test_context_change_then_reversal_latches_stop(self):
  for revision,generation in [('other',0),('r',1)]:
   q=d.PoseDelivery(d.condition_by_id('nominal'),72000);q.capture_and_release(0,100,[0,0,0],0,'r',0);p,r=q.capture_and_release(1,100+1/15,[0,0,0],0,revision,generation);self.assertIsNone(p);self.assertTrue(r['invalidContextLatched']);p,r=q.capture_and_release(2,100+2/15,[0,0,0],0,'r',0);self.assertIsNone(p)
 def test_session_change_latches_stop(self):
  q=d.PoseDelivery(d.condition_by_id('nominal'),72000);q.capture_and_release(0,100,[0,0,0],0,'r',0)
  with patch.object(d,'SESSION_ID','other'):p,r=q.capture_and_release(1,100+1/15,[0,0,0],0,'r',0)
  self.assertIsNone(p);self.assertTrue(r['invalidContextLatched']);self.assertIsNone(q.capture_and_release(2,100+2/15,[0,0,0],0,'r',0)[0])
 def test_held_goal_cue_never_finishes_even_postmotion(self):
  p=base_tests.Tests().packet(4);p['deliveryMode']='retained';cue={'goalReached':True,'sourceGeneration':0,'sourceCapturedTick':4,'sourceDeliveryMode':'retained'};self.assertFalse(d.goal_observation_current(cue,p,0,3));p['deliveryMode']='new';cue['sourceDeliveryMode']='new';self.assertTrue(d.goal_observation_current(cue,p,0,3))
 def test_duplicate_new_and_reversed_new_still_rejected(self):
  old=base_tests.Tests().packet(3)
  for t in [2,3]:self.assertFalse(d.validate_delivered_pose(base_tests.Tests().packet(t),'r',0,4,100+4/15,3,100+3/15,old)[0])
 def test_retained_pose_is_copy_not_mutable_alias(self):
  c=d.condition_by_id('nominal');c['withholdCaptureTicks']=[1,10];q=d.PoseDelivery(c,72000);p,_=q.capture_and_release(0,100,[1,2,3],0,'r',0);p['position'][0]=999;new,_=q.capture_and_release(1,100+1/15,[99,0,0],0,'r',0);self.assertEqual(new['position'],[1,2,3])
if __name__=='__main__':unittest.main()
