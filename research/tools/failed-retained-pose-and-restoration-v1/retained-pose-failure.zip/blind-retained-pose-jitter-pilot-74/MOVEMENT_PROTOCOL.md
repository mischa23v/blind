# 74 — Retain an unexpired delivered observation: one jitter-policy candidate

Stage73 is preserved. It reached the short goal under temporal jitter, but needed
193 stop ticks under its frozen “no new packet => stop” policy. This separate
candidate tests a usability tradeoff, not a geometry repair or guaranteed pass.

Only the temporal-jitter condition is eligible: same2±2tick packet schedule,
seed72000, original first-leg start/heading/goal,45×30×160cm zero-margin body,
source map/exclusion and all support/body/underbody gates. One attempt only, after
independent review and parent authorization. No physics result exists at freeze.

## Exact observation policy
On a new released packet, retain a deep copy with its ORIGINAL capture time,
source tick, coordinates, yaw, map revision, generation and fixed episode session.
When no new packet is released, reuse that exact delivered observation only while
0<=currentTime−originalCaptureTime<=0.5seconds, the pre-existing freshness limit.
No prediction, extrapolation, coordinate correction or evaluator truth substitution.
Expiry producesNone/stop. A changed session/revision/generation invalidates the
adapter context and latches stop for this single-episode pilot; reversing back to
an earlier context cannot silently revive the cache. New session means a new,
separately initialized episode, not a reset inside this run.

The controller independently distinguishes `new` from `retained`. New packets
must strictly advance capture tick/time. Retained packets must exactly match all
fields of the previously accepted packet, except the explicit delivery-mode tag;
otherwise stop. Both kinds retain original age checks. The controller stores its
own deep copy, not a caller-mutable alias. Unknown session, wrong revision or
generation, future/reversed/duplicate-new captures or malformed poses stop.

Arrival MUST be authorized by a NEW accepted packet captured after the last
committed physical motion, in addition to original true-goal proximity and drained
FIFO. A retained goal cue may issue a conservative stop but can never finish the
episode. No true pose is fed back to the controller to satisfy this test.

## Main risk and evaluation
Repeated coordinates can issue extra commands as the physical actor moves beyond
its old estimate. This may overshoot, oscillate, encounter a predicted obstacle,
fail support or consume the budget. Such a result is preserved, not fixed by
shrinking geometry or changing freshness. Every actual proposed3D increment keeps
the same support continuity and full-body/underbody sweeps. The reference evaluator
is still an oracle, not claimed phone obstacle perception; predicted vetoes are
failures/assisted stops, not navigation successes. Ground contacts are unmeasured.

Compare against73's frozen jitter run: arrival, distance, ticks, stop ticks AND
stop-episode entries, original packet age, maximum delivered-pose/yaw error,
retained-observation ticks, no-new-packet ticks, expired/no-usable-observation ticks,
overshoot/goal error, pending motion, contacts and support stops. A lower stop count
alone is not sufficient if collision/arrival/performance worsens. This is one
predeclared development variant, not an independent safety holdout.

Limits unchanged from73 per episode:450ticks,180CPU/240wall seconds,3.5GiB RSS,
2MiB output and768MiB disk reserve, fresh4.3GiB available RAM. Full lossless XZ on
normal close plus per-row flushed CSV; no discarded attempts. No heavy run until
independent fixture/hash gate and root authorization. The planned20distinctpairs×5
matrix remains separate and unexecuted.
