from pathlib import Path
import json,hashlib,numpy as np
H=Path(__file__).resolve().parent;W=H.parent;r=json.loads((H/'RESULT.json').read_text());f=json.loads((H/'FROZEN.json').read_text());checks=[]
for p,h in f['files'].items():checks.append((p,hashlib.sha256((W/p).read_bytes()).hexdigest()==h))
for j,row in enumerate(r['results']):
 checks.append((f'{j}:fiveFixedLegs',len(row['legs'])==5))
 for k,leg in enumerate(row['legs']):
  checks.append((f'{j}/{k}:fixedEndpoints',np.array_equal(leg['requestedStartXYZ'],f['anchors'][k]['registeredGameXYZ'])and np.array_equal(leg['requestedGoalXYZ'],f['anchors'][k+1]['registeredGameXYZ'])))
  p=np.array(leg['native']['points']);length=np.linalg.norm(np.diff(p[:,[0,2]],axis=0),axis=1).sum();checks.append((f'{j}/{k}:length',abs(length-leg['horizontalLengthMetres'])<1e-10))
 if row['oneTableLapProposal']:
  p=np.array(row['oneLapXYZ']);q=np.array(row['threeLapXYZ']);checks.append((f'{j}:threeExactRepetitions',np.array_equal(q,np.vstack([p,p[1:],p[1:]]))))
  checks.append((f'{j}:closedXYZ',np.linalg.norm(p[-1]-p[0])<=1e-6))
  centre=np.array(r['tabletopDiagnostic']['centroidGameXYZ']);a=p[:,[0,2]]-centre[[0,2]];wind=np.arctan2(a[:-1,0]*a[1:,1]-a[:-1,1]*a[1:,0],(a[:-1]*a[1:]).sum(1)).sum()/(2*np.pi);checks.append((f'{j}:winding',abs(wind-row['tableDiagnosticWinding'])<1e-10 and abs(abs(wind)-1)<1e-5))
assert all(x[1]for x in checks)
out={'passed':True,'checks':len(checks),'details':[(name,bool(ok))for name,ok in checks],'independentPhysicsReview':False,'implementingAgentSavedDataRecount':True,'visualInspection':'PNG reviewed:complete15deg loops enclose central long table;5deg paths backtrack;all labelled proposals only','movementExecuted':False}
(H/'SELF_RECOUNT.json').write_text(json.dumps(out,indent=2)+'\n')
# Source-only per-leg local bounds for prospective preserved-state physics, no reference reads.
with np.load(W/'blind-split-candidate-game-03/inputs/koivu_5cm_v2_pipeline2_out.npz')as z:oldR=z['R'];oldt=z['t']
with np.load(W/'blind-pose-experiments-review-17/upstream/pose-consistency/runs/koivu_floorfix/pipeline2_out.npz')as z:newR=z['R'];newt=z['t']
row=next(x for x in r['results']if x['profile']=='body45cmMargin0'and x['nativeConfig']['max_slope']==15.)
bounds=[]
for leg in row['legs']:
 p=np.array(leg['native']['points']);level=np.c_[p[:,0],-p[:,2],p[:,1]];old=((level-newt)@newR)@oldR.T+oldt;g=np.c_[old[:,0],old[:,2],-old[:,1]];lo=g[:,[0,2]].min(0)-.8;hi=g[:,[0,2]].max(0)+.8
 bounds.append({'legIndex':leg['legIndex'],'originalGamePathXYZ':g.tolist(),'floorCandidateXZBounds':[lo.tolist(),hi.tolist()],'floorCandidateYBounds':[-.25,.25],'areaSquareMetres':float(np.prod(hi-lo)),'sourceOnlySelection':True,'FAROCandidateCountNotRead':True})
(H/'PROPOSED_PHYSICS_BOUNDS.json').write_text(json.dumps({'scope':'source-only bounds proposal, not admitted physics','selectedNominal45Slope15':True,'perLegEnvelopeMarginMetres':.8,'perLeg':bounds,'sameActorAcrossLegsRequired':True,'noGeometryOrClassificationChange':True},indent=2)+'\n')
print(json.dumps({'checks':len(checks),'perLegAreas':[x['areaSquareMetres']for x in bounds]}))
