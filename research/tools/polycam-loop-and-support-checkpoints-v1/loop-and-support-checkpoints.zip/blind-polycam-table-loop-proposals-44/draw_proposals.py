from pathlib import Path
import json, numpy as np
from PIL import Image,ImageDraw,ImageFont
H=Path(__file__).resolve().parent;W=H.parent;r=json.loads((H/'RESULT.json').read_text());f=json.loads((H/'FROZEN.json').read_text())
with np.load(W/'blind-polycam-alignment-feasibility-36/POLYCAM_INTRINSIC_GEOMETRY.npz')as z:obj=z['verticesOBJ'];tri=z['triangles']
with np.load(W/'blind-polycam-rigid-registration-37/run-01/CANDIDATE_RIGID_TRANSFORM.npz')as z:level=obj@z['rotationOBJToLevel'].T+z['translationOBJToLevel']
v=np.c_[level[:,0],level[:,2],-level[:,1]];xyz=v[tri];cent=xyz.mean(1);table=set(r['tabletopDiagnostic']['triangleIDs']);keep=(cent[:,1]>.15)&(cent[:,1]<1.8)
lo=v[:,[0,2]].min(0);hi=v[:,[0,2]].max(0)
im=Image.new('RGB',(1600,1320),'white');d=ImageDraw.Draw(im)
font='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf';big=ImageFont.truetype(font,25);small=ImageFont.truetype(font,17);tiny=ImageFont.truetype(font,14)
d.text((30,10),'Source Polycam native path proposals — NOT executed movement',font=big,fill='black')
d.text((30,45),'Exact frozen waypoints 92 → 120 → 200 → 220 → 20 → 92. Grey is projected source geometry, not verified obstacles/free space.',font=small,fill='#333333')
for j,row in enumerate(r['results']):
 x0=30+(j%2)*790;y0=90+(j//2)*600;scale=min(700/(hi[0]-lo[0]),470/(hi[1]-lo[1]))
 def p(q):return (x0+30+(q[0]-lo[0])*scale,y0+80+(q[2]-lo[1])*scale)
 title=f"{45 if row['profile']=='body45cmMargin0'else 55} cm envelope; {int(row['nativeConfig']['max_slope'])}° slope / 25 mm climb"
 d.text((x0,y0),title,font=big,fill='black')
 outcome=f"{'One loop proposal'if row['oneTableLapProposal']else 'Backtracks: NOT a loop'}; {row['oneLapHorizontalLengthMetres']:.2f} m; winding {row['tableDiagnosticWinding']:.0f}"
 d.text((x0,y0+33),outcome,font=small,fill='#126238'if row['oneTableLapProposal']else'#b3402b')
 for i in np.flatnonzero(keep):
  q=[p(z)for z in xyz[i]];d.line(q+[q[0]],fill='#dedede',width=1)
 for i in table:d.polygon([p(z)for z in xyz[i]],fill='#f1bd4e')
 for leg in row['legs']:
  pts=[p(z)for z in leg['native']['points']]
  if len(pts)>1:d.line(pts,fill='#1683b2'if leg['acceptedProposal']else'#b3402b',width=4,joint='curve')
 for a in f['anchors'][:-1]:
  x,y=p(a['registeredGameXYZ']);d.ellipse((x-4,y-4,x+4,y+4),fill='#111111');d.text((x+5,y-12),str(a['poseIndex']),font=tiny,fill='#111111')
 x,y=p(r['tabletopDiagnostic']['centroidGameXYZ']);d.ellipse((x-5,y-5,x+5,y+5),fill='#cf5d00')
d.text((30,1280),'Blue: proposed path only. Yellow/orange: source tabletop component and winding point. Body sweeps, turn clearance, support and sensor coverage remain untested.',font=small,fill='#333333')
im.save(H/'SOURCE_ONLY_LOOP_PROPOSALS.png')
