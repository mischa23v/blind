import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
import resource,signal,time
resource.setrlimit(resource.RLIMIT_AS,(1<<30,1<<30));resource.setrlimit(resource.RLIMIT_CPU,(30,30));resource.setrlimit(resource.RLIMIT_FSIZE,(5<<20,5<<20));signal.alarm(60)
from pathlib import Path
import json,numpy as np,hashlib,importlib.util,sys,dataclasses,math
sys.dont_write_bytecode=True
H=Path(__file__).resolve().parent;W=H.parent;START=time.monotonic()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
f=json.loads((H/'FROZEN.json').read_text())
def verify():
 for p,h in f['files'].items():assert sha(W/p)==h,p
 assert os.statvfs(H).f_bavail*os.statvfs(H).f_frsize>=768<<20
verify()
spec=importlib.util.spec_from_file_location('loop44detour',W/'blind-split-candidate-game-03/body-margin-variants-07/native025/detour_engine.py');de=importlib.util.module_from_spec(spec);sys.modules[spec.name]=de;spec.loader.exec_module(de)
with np.load(W/'blind-polycam-alignment-feasibility-36/POLYCAM_INTRINSIC_GEOMETRY.npz')as z:obj=z['verticesOBJ'];tri=z['triangles']
with np.load(W/'blind-polycam-rigid-registration-37/run-01/CANDIDATE_RIGID_TRANSFORM.npz')as z:level=obj@z['rotationOBJToLevel'].T+z['translationOBJToLevel'];assert z['scale']==1
v=np.c_[level[:,0],level[:,2],-level[:,1]];anchors=f['anchors'];points=np.array([a['registeredGameXYZ']for a in anchors])
# Source-only tabletop diagnostic; no altered vertices/triangles.
xyz=v[tri];cross=np.cross(xyz[:,1]-xyz[:,0],xyz[:,2]-xyz[:,0]);double_area=np.linalg.norm(cross,axis=1);normal_y=np.divide(abs(cross[:,1]),double_area,out=np.zeros(len(tri)),where=double_area>0)
ids=np.flatnonzero((xyz[:,:,1].min(1)>=.60)&(xyz[:,:,1].max(1)<=.85)&(normal_y>=math.cos(math.radians(10))))
parent={int(i):int(i)for i in ids}
def root(a):
 while parent[a]!=a:parent[a]=parent[parent[a]];a=parent[a]
 return a
edges={}
for i in ids:
 a,b,c=map(int,tri[i])
 for edge in ((min(a,b),max(a,b)),(min(b,c),max(b,c)),(min(c,a),max(c,a))):
  if edge in edges:parent[root(int(i))]=root(edges[edge])
  else:edges[edge]=int(i)
components={}
for i in ids:components.setdefault(root(int(i)),[]).append(int(i))
ranked=sorted(components.values(),key=lambda a:(-double_area[a].sum(),min(a)))
if ranked:
 ix=np.array(ranked[0]);area=double_area[ix]/2;cent=(xyz[ix].mean(1)*area[:,None]).sum(0)/area.sum();table={'triangleIDs':ix.tolist(),'areaSquareMetres':float(area.sum()),'centroidGameXYZ':cent.tolist(),'boundsGameXYZ':[xyz[ix].reshape(-1,3).min(0).tolist(),xyz[ix].reshape(-1,3).max(0).tolist()],'allCandidateComponentAreas':sorted([float(double_area[a].sum()/2)for a in ranked],reverse=True),'semanticIdentityVerified':False}
else:cent=None;table={'failure':'no predeclared horizontal tabletop component'}
def assoc(a,b):
 b=np.array(b);ok=np.isfinite(b).all();d=b-a
 return {'horizontalMetres':float(np.linalg.norm(d[[0,2]]))if ok else None,'verticalMetres':float(d[1])if ok else None,'passes10cmHorizontal':bool(ok and np.linalg.norm(d[[0,2]])<=.1)}
def winding(path):
 q=path[:,[0,2]]-cent[[0,2]];return float(np.arctan2(q[:-1,0]*q[1:,1]-q[:-1,1]*q[1:,0],(q[:-1]*q[1:]).sum(1)).sum()/(2*np.pi))
rows=[]
for slope in (5.,15.):
 for profile,radius in [('body45cmMargin0',.225),('body45cmMargin5cm',.275)]:
  cfg=de.Config(radius=radius,height=1.75,cell_size=.025,max_climb=.025,max_slope=slope);legs=[]
  with de.Engine(v,tri,cfg,mode='known-provided-map')as engine:
   for i,(a,b)in enumerate(zip(points[:-1],points[1:])):
    r=engine.route(a,b,query_half_extents=(.2,.3,.2),max_points=256);aa=assoc(a,r.projected_start);bb=assoc(b,r.projected_goal);p=np.array(r.points)
    legs.append({'legIndex':i,'fromPoseIndex':anchors[i]['poseIndex'],'toPoseIndex':anchors[i+1]['poseIndex'],'requestedStartXYZ':a.tolist(),'requestedGoalXYZ':b.tolist(),'native':dataclasses.asdict(r),'startAssociation':aa,'goalAssociation':bb,'acceptedProposal':bool(r.complete and len(p)>=2 and aa['passes10cmHorizontal']and bb['passes10cmHorizontal']),'horizontalLengthMetres':float(np.linalg.norm(np.diff(p[:,[0,2]],axis=0),axis=1).sum())if len(p)>1 else None})
  allaccepted=all(x['acceptedProposal']for x in legs);joins=[]
  for i in range(5):
   a=np.array(legs[i]['native']['projected_goal']);b=np.array(legs[(i+1)%5]['native']['projected_start']);joins.append(float(np.linalg.norm(a-b)))
  connected=bool(allaccepted and max(joins)<=1e-6);loop=[];wind=None
  if connected:
   for leg in legs:loop.extend(leg['native']['points']if not loop else leg['native']['points'][1:])
   if cent is not None:wind=winding(np.array(loop))
  islap=bool(connected and wind is not None and abs(abs(wind)-1)<=1e-5)
  row={'profile':profile,'nativeConfig':dataclasses.asdict(cfg),'legs':legs,'nativeConnectedClosedProposal':connected,'junctionGapsMetres':joins,'tableDiagnosticWinding':wind,'oneTableLapProposal':islap,'oneLapXYZ':loop if islap else None,'oneLapHorizontalLengthMetres':sum(x['horizontalLengthMetres']or 0 for x in legs)if connected else None,'initialYawRadians':float(math.atan2(loop[1][2]-loop[0][2],loop[1][0]-loop[0][0]))if islap else None,'headingConvention':'atan2(deltaGameZ,deltaGameX); convert explicitly for controller convention','fullRectangleValidated':False,'movementExecuted':False,'centrelineOptimized':False}
  if islap:row['threeLapXYZ']=loop+loop[1:]+loop[1:];row['threeLapIsRepetitionNotIndependentValidation']=True
  rows.append(row)
verify()
def safe(x):
 if isinstance(x,float)and not np.isfinite(x):return None
 if isinstance(x,dict):return {k:safe(v)for k,v in x.items()}
 if isinstance(x,(tuple,list)):return [safe(v)for v in x]
 return x
out={'scope':'source-only fixed Polycam loop proposals; no physical movement','frozenManifestSHA256':sha(H/'FROZEN.json'),'tabletopDiagnostic':table,'results':rows,'referenceInputsUsed':False,'movementExecuted':False,'runtime':{'CPUSeconds':resource.getrusage(resource.RUSAGE_SELF).ru_utime+resource.getrusage(resource.RUSAGE_SELF).ru_stime,'peakRSSKiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'wallSeconds':time.monotonic()-START}}
(H/'RESULT.json').write_text(json.dumps(safe(out),indent=2)+'\n')
print(json.dumps({'results':[{k:r[k]for k in ('profile','nativeConfig','nativeConnectedClosedProposal','tableDiagnosticWinding','oneTableLapProposal','oneLapHorizontalLengthMetres')}for r in rows],'runtime':out['runtime']}))
