# Stage48: topology-owned support datum, incomplete threshold crossing

The actor moved 1.676166 m horizontally and 1.694241 m in 3D over 118 ticks. Entry and return remain incomplete. There were zero executed contacts and zero rejected predicted collision events. The valid bounded run completed in 52.21 seconds, using 2.11 GiB peak RSS. All 43 fixtures and 479 input pins passed before execution.

Topology-only ownership resolved the previous incorrect dual-floor lower-bound rule. The next stop is different: one of nine first-hit rays struck the already tagged steep sill riser, face16815455, with a 72.64-degree normal. Its triangle spans14.17–18.82 mm in height, below the exact foot support envelope at20.517 mm. There is no body collision or height-cap failure. The current policy nevertheless requires every ray to hit a walkable landing face and treats the known riser as untyped support.

This failure identifies a distinction still missing from the simulator: known structural transition geometry versus a valid landing surface. The riser must not be relabeled as flat floor, removed from collisions, or confused with an unseen hole. A later transition-support policy must be separately specified and tested. No such policy or completed journey is claimed in this result.

This remains manually assisted evaluator-world simulation, not automatic phone navigation, a human gait model, or a safety validation. All previous failures are preserved. See PROTOCOL.md, RAMP_OWNERSHIP.json, run-01/result/RESULT.json and postrun/ACTUAL_TRACE.csv. Detailed evidence is lossless gzip JSON.
