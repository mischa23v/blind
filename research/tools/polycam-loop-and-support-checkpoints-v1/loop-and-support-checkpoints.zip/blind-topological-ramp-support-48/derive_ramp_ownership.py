from pathlib import Path
import numpy as np,json,hashlib
from collections import defaultdict,deque
H=Path(__file__).resolve().parent;W=H.parent;I=W/'blind-assisted-threshold-traversal-proposal-43'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
paths=[I/'complete-manual-sill/FIXED_IMAGE_ROI_REFERENCE_FACES.npz',I/'complete-manual-sill/TYPED_SILL_FACE_IDS.npz',I/'floor-gate-01/FROZEN_FLOOR_MEMBERSHIP.npz']
with np.load(paths[0])as z:ids=z['referenceCellIDs'];tri=z['trianglesOriginalVertexIDs']
with np.load(paths[1])as z:transition=set(z['transitionReferenceCellIDs'].tolist());ramps=z['rampSupportReferenceCellIDs'];tops=z['topReferenceCellIDs']
with np.load(paths[2])as z:red=set(z['redGroundIDs'].tolist());gray=set(z['grayGroundIDs'].tolist())
edges=defaultdict(list)
for cid,t in zip(ids,tri):
 for a,b in [(t[0],t[1]),(t[1],t[2]),(t[2],t[0])]:edges[tuple(sorted((int(a),int(b))))].append(int(cid))
adj=defaultdict(set);touch=defaultdict(set)
for group in edges.values():
 ts=[cid for cid in group if cid in transition]
 for cid in ts:
  adj[cid].update(x for x in ts if x!=cid)
  if any(x in red for x in group):touch[cid].add(0)
  if any(x in gray for x in group):touch[cid].add(1)
remaining=set(transition);owner={};components=[]
while remaining:
 seed=min(remaining);queue=deque([seed]);remaining.remove(seed);comp=[];joined=set()
 while queue:
  cid=queue.popleft();comp.append(cid);joined.update(touch[cid])
  for n in adj[cid]:
   if n in remaining:remaining.remove(n);queue.append(n)
 assignment=next(iter(joined))if len(joined)==1 else -1
 for cid in comp:owner[cid]=assignment
 components.append({'seedID':seed,'faceCount':len(comp),'touchesRedExactEdge':0 in joined,'touchesGrayExactEdge':1 in joined,'assignedFloor':assignment,'assignmentUsesHeightsOrRoute':False})
rampowners=np.array([owner[int(i)]for i in ramps],np.int8)
np.savez_compressed(H/'RAMP_OWNER_IDS.npz',rampReferenceCellIDs=ramps,ownerFloorIndex=rampowners)
receipt={'scope':'Frozen topology-derived adjacent-floor ownership; no height residual or route used','components':components,'rampCount':len(ramps),'unresolvedRampCount':int((rampowners<0).sum()),'redRampCount':int((rampowners==0).sum()),'grayRampCount':int((rampowners==1).sum()),'pins':{str(p.relative_to(W)):sha(p)for p in paths},'outputSHA256':sha(H/'RAMP_OWNER_IDS.npz'),'geometryChanged':False}
(H/'RAMP_OWNERSHIP.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
