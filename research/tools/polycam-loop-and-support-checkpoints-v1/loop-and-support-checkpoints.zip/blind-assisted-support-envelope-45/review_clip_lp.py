"""Independent clipping oracle: barycentric LP, not another polygon clipper."""
import json, math
import numpy as np
from scipy.optimize import linprog
from support_envelope import clip_triangle

def main():
    rng = np.random.default_rng(4517)
    bad, matches, empties = [], 0, 0
    for i in range(300):
        tri = rng.uniform(-.5, .5, (3, 3))
        center = np.array([.02, 0, -.03])
        yaw = float(rng.uniform(-math.pi, math.pi))
        c, s = math.cos(yaw), math.sin(yaw)
        d = tri[:, [0, 2]] - center[[0, 2]]
        f, l = d[:, 0]*c+d[:, 1]*s, -d[:, 0]*s+d[:, 1]*c
        res = linprog(-tri[:, 1], A_ub=np.array([f, -f, l, -l]),
                      b_ub=[.15, .15, .225, .225], A_eq=[[1, 1, 1]],
                      b_eq=[1], bounds=[(0, None)]*3, method='highs')
        p = clip_triangle(tri, center, yaw, .15, .225)
        if res.success:
            if not len(p) or abs(p[:, 1].max()+res.fun) > 1e-8:
                bad.append([i, 'height', None if not len(p) else float(p[:, 1].max()), -res.fun])
            else:
                matches += 1
        elif len(p):
            bad.append([i, 'spurious', len(p)])
        else:
            empties += 1
    result = dict(seed=4517, randomCases=300,
                  nonemptyMaxYMatchesIndependentBarycentricLP=matches,
                  emptyMatches=empties, mismatches=bad,
                  scope='Numerical clipping check only, not navigation or physical safety')
    print(json.dumps(result, indent=2))
    assert not bad

if __name__ == '__main__':
    main()
