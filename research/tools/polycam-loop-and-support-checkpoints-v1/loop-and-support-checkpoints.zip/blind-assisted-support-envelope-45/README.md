# Stage45 exact support envelope: terminal floor-datum rejection

The actor travelled1.500m, then stopped before the sill. Entry and return remain incomplete.0 executed contacts and0 predicted body contacts.39 fixtures and300 independent clipping-vs-linear-program cases passed. Full result is run-01/result/RESULT.json, actual path postrun/ACTUAL_TRACE.csv.

Exact clipped geometry found the sill top, but the expanded all-vertex cap rejected its known connected ramp toe5.466mm below the retained historical stage14 red-floor plane. All9 support rays hit knownfloor; there was no missing support ray. The sill annotation had used a different, independently fitted local red-floor plane. This is an inconsistent support datum, not evidence of a physical barrier. Both variants and all unchanged geometry are preserved. No post-run tolerance widening was applied.

This remains manually assisted evaluator-world simulation, not phone-only obstacle recognition or human-safety evidence. See PROTOCOL.md and FROZEN.json. Detailed arrays are lossless JSON gzip. Requires prior stage43 support/annotation and hashed original assets.
