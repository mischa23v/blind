# Stage47: consistent local datum, terminal dual-floor lower-bound rejection

Actual motion1.636166m horizontally/1.653986m3D over107ticks. Entry and return remain incomplete.0 actual contacts and0 predicted collision rejections.39fixtures passed; all464frozen input hashes matched. Run42.16s wall/42.47s CPU/2.10GiB peakRSS.

Using the existing independent red-floor plane resolved the previous datum mismatch, and the exact support envelope progressed past the prior interior-top collision. It then hit the preserved lower gate: a known ramp toe lies2.026667mm below the gray-floor plane,27micrometres beyond the2mm cutoff. It is not a physical27micrometre obstacle. The original tagged support geometry lies no lower than1.217mm below the red plane. All9 first-hit support rays are known, none missing. This exposes a two-floor-reference policy issue. No tolerance was silently widened; the run stops as frozen.

The next correction must associate a connecting ramp with its own adjacent floor rather than demand every point sit above both different floor planes. All geometry, upper25mm rise cap, actual vertical transition cap, and missing-support veto must remain. This report does not claim that correction has run.

This is manually assisted evaluator-world simulation, not automatic phone navigation/human safety evidence. Full result and trace are in run-01/result and postrun. See PROTOCOL.md and FROZEN.json.
