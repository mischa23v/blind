# Stage47: use the independently frozen local-floor datum consistently

Stage45 stopped because its exact typed-ramp envelope was compared to the historical stage14 broad red-floor plane, while the manual annotation had been checked against the independently fitted local red-floor plane. This variant uses that existing stage43floor-gate redGround plane for vertical support/caps, matching the annotation. The gray plane is unchanged. No plane is refitted or chosen using the new route outcome. Both plane coefficient arrays must exactly match the frozen annotation definition.

This changes initial vertical settlement and the red-floor vertical support trajectory; both are explicitly reported. It does not modify horizontal route, goals, body, margin, ground face memberships, sill face identities, exact clipped support-envelope calculation, collision sweeps, unknown-support rules, or25mm/-2mm support gates. Full original geometry remains.39 authored fixtures pass unchanged. A few original tagged ramp vertices have relative minima -2.026667mm against the gray plane; if they trigger the fixed gate they must still reject. No tolerance is widened.

All stage45 assistance/limitations remain: evaluator-world floor/sill support and geometry are manually associated; this is NOT automatic phone navigation or a human gait/safety result. Exact UP/SIDE/DOWN support envelope, same actor/FIFO across serial entry/return, no post-start reset. First rejection stops. Stage43 and45 failures remain unchanged.

Resource gates unchanged:4.3GiB availableRAM,3.5GiB sampledRSS,600CPU/900wall seconds,32MiB output,768MiB disk reserve. Detailed evidence lossless gzip JSON. Freeze all inputs before one bounded run.
