# Stage54: source-only return replanning from actual delivered arrival

## New rule
Entry, task goals, body45×30×160cm, zero margin, same-actor/FIFO state, all evaluator geometry and manual sill/floor support semantics are unchanged from51. On accepted entry, the return planner uses the controller's **last valid delivered entry-arrival pose**, not the deeper initial reverse-route endpoint. A missing, stale, busy or non-arrival last packet cannot authorize the query. Physics still verifies stationary/drained actual goal arrival before issuing beginReturn. No actor coordinate is reset or snapped.

The planner flattens only the planning query Y to0, as the existing source adapter does; actual footY remains in physics and trace. Original-game start/outside goal transform through the unchanged paired18 old→new map. The original Polycam mesh is transformed by unchanged rigid37 scale1 registration. Native Recast/Detour uses exactly radius0.225m,height1.75m,cell0.025m,maxclimb0.025m,maxslope15°, query extents(.2,.3,.2),maxpoints256. This is a disc proposal, not rectangle clearance. Exactly one deterministic route query is made, not candidate selection by the evaluator.

Returned corners and projected endpoints map back through paired18 new→old. Complete finite route, endpoint horizontal association≤0.1m and absolute height≤0.05m are required; all corners must meet the original height bound. Route starts at actual planar arrival, then native corners, then unchanged original outside goal. Any small projected-start connector is executed through the same full-body continuous sweeps; no teleport. The source query result is frozen for this return leg and recorded in SOURCE_ONLY_RETURN_QUERY.json. The old deeper connector is not executed.

No FARO face, support label, contact, failure-face diagnosis, reference map or future pose is an input to the source planner. The actual delivered physics pose is the permitted localization input. No map data is repaired. Exact source-only dataflow and real subprocess IPC are fixture-tested. Source return route is explicitly NEW; entry is unchanged.

## Unchanged assistance and limits
This remains an explicitly manually assisted evaluator-world kinematic box simulation, not autonomous iPhone navigation, native Jolt, a human footfall model or a safety claim. Exact frozen structural sill faces may supply bounded UP/SIDE/DOWN support; unknown support and unrelated objects remain rejected. Every original sill face remains a full-body collider. No floor membership, tolerance, slope, body dimension, route-goal tolerance or collision guard is changed.

Every motion phase≤25mm3D and yaw≤1degree; original caps and full sweeps retained. Same actor and queues persist across entry/return. Initial settlement is recorded separately; no later reset. Old phone-map uncertainty flags remain diagnostic and are reported, never cleared. All failed prior variants remain immutable.

## Acceptance and resource gate
Report entry and return separately, actual distance, contact counts, rejected predicted contacts, goal errors, exact traces and failure reasons. Complete same-actor return to original outside goal is the objective. A route query alone is not movement success. First failed macro terminates; no tuning/relabeling within a run.

Minimum available RAM4.3GiB, process-treeRSS3.5GiB,600CPU/900wall seconds,16MiB output,768MiB disk reserve. One heavy reference run at a time. Input manifest freezes code/source data/protocol before movement. Actual CSV flushes each committed tick. Failed runs remain preserved.

Expected incomplete or unassociated return queries produce a strict physicalAuthority:false rejection ACK and a valid terminal result retaining entry success; unexpected exceptions remain errors. No second route is tried.
