import unittest,tempfile,math
from pathlib import Path
import numpy as np
from unittest.mock import patch
import step_world as w
from step_controller import Controller
class Tests(unittest.TestCase):
 def test_return_without_delivered_arrival_rejects(self):
  c=Controller();c.goal=np.zeros(3);c.plan={'start':[1,0,0]}
  with self.assertRaisesRegex(ValueError,'validated arrival'):c.consume({'command':'beginReturn','goal':[1,0,0]})
 def test_busy_arrival_is_not_replan_authority(self):
  from test_step_integration import Tests as Old
  c=Old().ctrl();Old().tick(c,[.1,0,0],True);self.assertIsNone(c.arrivalPose)
 def test_stale_arrival_cannot_replan(self):
  from test_step_integration import Tests as Old
  c=Old().ctrl();Old().tick(c,[.1,0,0],False);self.assertIsNotNone(c.arrivalPose)
  c.consume({'command':'tick','tick':1,'now':102.,'actuatorBusy':False,'deliveredPose':{'kind':'simulated-physics-body-pose','position':[.1,0,0],'yaw':0.,'capturedAt':100.,'mapRevision':'fixture'}});self.assertIsNone(c.arrivalPose)
 def test_real_ipc_queries_from_delivered_arrival_not_old_endpoint(self):
  plan=w.legacy.load_plan();p=[4.321740543651417,.002055131685870024,.566131201400236]
  with tempfile.TemporaryDirectory()as d:
   c=w.ControllerProcess(Path(d))
   try:
    c.ask({'command':'beginRun','goal':plan['goal']})
    row=c.ask({'command':'tick','tick':0,'now':100.,'actuatorBusy':False,'deliveredPose':{'kind':'simulated-physics-body-pose','position':p,'yaw':-.6610204437540492,'capturedAt':100.,'mapRevision':c.initial['mapRevision']}})
    self.assertTrue(row['goalReached'])
    r=c.ask({'command':'beginReturn','goal':plan['start']});q=r['sourceOnlyReturnRequery']
    self.assertIs(r['physicalAuthority'],False);self.assertTrue(r['noReset']);self.assertEqual(q['actualDeliveredArrivalOriginalXYZ'],p);self.assertFalse(q['referenceInputsUsed']);self.assertFalse(q['oldDeeperConnectorUsed']);self.assertTrue(q['native']['complete'])
    self.assertLess(np.linalg.norm((np.array(q['projectedStartOriginalXYZ'])-p)[[0,2]]),.1)
   finally:c.close()
 def test_source_plan_rejection_preserves_strict_ack(self):
  from actual_return_map import SourcePlanRejected
  c=Controller();c.goal=np.zeros(3);c.plan={'start':[1,0,0]};c.arrivalPose=np.zeros(3)
  class Model:
   def begin_return(self,p):raise SourcePlanRejected('no complete source-only return')
  c.model=Model();r=c.consume({'command':'beginReturn','goal':[1,0,0]});self.assertIs(r['physicalAuthority'],False);self.assertEqual(r['status'],'sourcePlanRejected');self.assertTrue(r['noReset'])
 def test_physics_identical_except_recording(self):
  h=Path(__file__).resolve().parent;old=h.parent/'blind-entry-return-protocol-retry-51'
  for n in('step_kernel.py','support_envelope.py'):self.assertEqual((h/n).read_bytes(),(old/n).read_bytes())
if __name__=='__main__':unittest.main(verbosity=2)
