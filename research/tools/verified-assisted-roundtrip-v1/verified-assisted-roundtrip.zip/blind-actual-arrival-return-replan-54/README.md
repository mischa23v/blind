# Stage54: same-actor assisted doorway entry and return completed

**One controlled offline simulation completed entry into the adjoining room and return to the original outside goal region, with no recorded contacts.** This is an explicitly manually assisted evaluator-world result—not phone-only obstacle detection, human walking validation or a real-device safety claim.

## Measured result

| Measure | Entry | Return | Total |
|---|---:|---:|---:|
| Arrival | Yes | Yes | Both |
| Horizontal distance | 4.388010405 m | 4.043973663 m | **8.431984068 m** |
| Arrival tick | 263 | 685 | 686 recorded states |
| Full-3D goal error | 0.343921464 m | 0.344307103 m | Frozen tolerance 0.35 m |
| Stationary and queues drained at arrival | Yes | Yes | No actor reset |

Total 3-D travel: **8.507299542 m**. Executed body, margin and supplementary underbody contact counts: **0 / 0 / 0**. Predicted collision rejections: **0 / 0 / 0**. Largest executed 3-D substep: 0.020000011 m; largest yaw substep: 1 degree. Independent arithmetic recount matched every committed state to its accepted macro and matched the flushed CSV exactly to the terminal trace. Initial vertical settlement is separately recorded; no post-start pose reset or teleport occurred.

## What changed—and what did not

Stage51 reached the entry goal but unnecessarily advanced to a deeper old reverse-route endpoint before turning back, then stopped at untyped support face7253304. This variant does **not** relabel or remove that face. At the actual delivered, validated entry arrival, it makes one source-only native Recast/Detour return query from that pose to the unchanged original outside goal. It uses the same Polycam geometry, rigid registration, radius, climb, slope and association checks. No reference mesh, failure-face information, collision feedback or support classification is supplied to the planner. The small native start association is walked through normal full-body sweeps, not snapped.

Entry and all physics/support/geometry policies remain unchanged from51. The actor remains a nominal45×30×160cm box with **zero horizontal margin**. The same actor and actuator queues persist across the transition. Manually typed evaluator-world sill geometry still drives bounded support placement; original structural geometry remains collidable. The exact return query and route are saved in `run-01/result/SOURCE_ONLY_RETURN_QUERY.json`.

This corrects a return-path initialization defect. It does not solve automatic floor/sill perception, uncertainty estimation, general room mapping, latency/jitter robustness, child-body validation or physical navigation. All **686** evaluated ticks retain unresolved low-obstacle exposure under the old phone-map diagnostic. The result covers **one deterministic assisted round trip**, not 100 journeys or a full table loop.

## Evidence

- Frozen manifest SHA-256: `89a9f5550c21b8cc34263206b53f7455dee8aa5dd01a6e691867aa4324858d9c`; 522 pinned inputs.
- `PROTOCOL.md`: declared source-only return rule, assistance boundary and resource limits.
- 59 pre-run fixtures passed, including real subprocess return querying, stale/busy rejection and failure acknowledgement accounting.
- `run-01/RUN_RECEIPT.json`: valid bounded process; 425.078s wall,429.41s CPU,peak sampled/waited process-treeRSS2,329,743,360bytes;16MiB output cap and768MiB disk reserve retained.
- `run-01/result/RESULT.json`: complete measured terminal result and both stationary arrival receipts.
- `run-01/result/ACTOR_TRACE.npz` and `ACTUAL_TRACE_STREAM.csv`: original committed states.
- `postrun/ACTUAL_TRACE.csv`: exact original and registered-source coordinates, leg labels and cumulative distance.
- `postrun/ACTUAL_SOURCE_MODEL_PATH.png`: committed entry solidblue and committed return dashedorange on registered original source geometry, with no proposed or failed connectors. Gray source geometry is not a clearance certification.
- `postrun/RECOUNT.json`: arithmetic, arrival, phase, substep and stream consistency checks.

All earlier failed variants are preserved. This report does not retrospectively convert them into successes.
