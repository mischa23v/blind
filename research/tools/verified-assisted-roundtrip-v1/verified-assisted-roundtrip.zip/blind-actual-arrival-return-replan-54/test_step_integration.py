import unittest,math,json,ast
from pathlib import Path
import numpy as np
import step_world as w
from step_controller import Controller
H=Path(__file__).resolve().parent
class FakeMap:
 leg=0
 def flag_receipt(self,p,y):return {'sampledFit':False,'lowUnresolvedCells':2,'usedAsVeto':False}
 def route(self,p,g):return {'complete':True,'points':[list(g)],'projectedStart':list(p),'projectedGoal':list(g)}
 def begin_return(self):pass
class Tests(unittest.TestCase):
 def ctrl(self):
  c=Controller();c.model=FakeMap();c.goal=np.zeros(3);c.route_goal=np.array([.1,0,0]);c.revision='fixture';c.plan={'geometry':{'width':.45,'depth':.30,'margin':0},'start':[2,0,0]};return c
 def tick(self,c,pos,busy):return c.consume({'command':'tick','tick':0,'now':100.,'actuatorBusy':busy,'deliveredPose':{'kind':'simulated-physics-body-pose','position':pos,'yaw':math.pi,'capturedAt':100.,'mapRevision':'fixture'}})
 def test_busy_cannot_complete_goal(self):
  r=self.tick(self.ctrl(),[.1,0,0],True);self.assertFalse(r['goalReached']);self.assertEqual((r['forwardMetres'],r['yawRadians']),(0,0));self.assertEqual(r['reason'],'assistedStepMacroPending')
 def test_original_arrival_boundaries_remain(self):
  for x,y,expected in[(.339,0,True),(.345,0,True),(.35,0,True),(.350001,0,False),(.345,.061,False)]:self.assertEqual(self.tick(self.ctrl(),[x,y,0],False)['goalReached'],expected)
 def test_notbusy_same_follower_moves_and_preserves_flags(self):
  r=self.tick(self.ctrl(),[1,0,0],False);self.assertGreater(r['forwardMetres'],0);self.assertFalse(r['phoneFlagReceipt']['sampledFit'])
 def world(self,ids,heights):
  obj=object.__new__(w.AssistedWorld);obj.red=np.array([1]);obj.gray=np.array([2]);obj.top=np.array([3]);obj.risers=np.array([4,5]);obj.ramps=np.array([5]);obj.planes=[np.zeros(3),np.zeros(3)]
  class Base:
   def support_probes(self,p,y):
    rows=[{'hit':True,'referenceCellID':i,'modelXZ':[0.,0.],'modelHeightY':h}for i,h in zip(ids,heights)];return {'probes':rows,'hitCount':len(rows),'missingCount':9-len(rows)}
  obj.base=Base();obj.ramp_slopes={5:15.};obj.ramp_owners={5:0};return obj
 def test_both_preanchored_floors_supported(self):self.assertTrue(self.world([1]*4+[2]*5,[0]*9).support([0,0,0],0)['accepted'])
 def test_unknown_landing_object_not_typed_by_height(self):self.assertFalse(self.world([1]*8+[99],[0]*8+[.005]).support([0,0,0],0)['accepted'])
 def test_low_sill_riser_not_landing_plane(self):self.assertFalse(self.world([1]*8+[4],[0]*8+[.005]).support([0,0,0],0)['accepted'])
 def test_typed_top_height_cap(self):
  self.assertTrue(self.world([1]*8+[3],[0]*8+[.025]).support([0,0,0],0)['accepted']);self.assertFalse(self.world([1]*8+[3],[0]*8+[.026]).support([0,0,0],0)['accepted'])
 def test_explicit_coherent_sill_ramp_supported(self):
  self.assertTrue(self.world([1]*8+[5],[0]*8+[.011]).support([0,0,0],0)['accepted'])
  self.assertFalse(self.world([1]*8+[5],[0]*8+[.026]).support([0,0,0],0)['accepted'])
 def test_wrongly_tagged_steep_ramp_rejected(self):
  obj=self.world([1]*8+[5],[0]*8+[.011]);obj.ramp_slopes[5]=46.;self.assertFalse(obj.support([0,0,0],0)['accepted'])
 def test_unknown_ramp_owner_rejects(self):
  obj=self.world([1]*8+[5],[0]*8+[.011]);obj.ramp_owners={};self.assertFalse(obj.support([0,0,0],0)['accepted'])
 def test_missing_support_rejected(self):self.assertFalse(self.world([1]*8,[0]*8).support([0,0,0],0)['accepted'])
 def test_underbody_plane_bound_includes_downhill_corner(self):
  from step_kernel import Phase
  obj=object.__new__(w.AssistedWorld);obj.planes=[np.array([0.,.1,0.]),np.array([0.,.1,0.])]
  class Guard:
   def contact_corners(self,c):
    self.corners=c;return {'contact':False}
  obj.guard=Guard();r=obj.underbody_collision(Phase((0,.02,0),(.02,.02,0),0,0,'SIDE',0))
  self.assertLessEqual(r['guardBottomY'],-.0225+1e-12)
  self.assertGreaterEqual(r['guardTopY'],.022)
 def test_episode_rejected_prediction_is_not_actual_contact(self):
  import tempfile
  from unittest.mock import patch
  class Collider:
   optimization_rows=[]
   def swept_contacts(self,*args):return {'actualBody':{'contact':False},'horizontalMargin':{'contact':False}}
  class World:
   body=Collider();guard=Collider()
   def support(self,*args):return {'accepted':True,'hitCount':9,'missingCount':0,'typedSill':False,'footHeight':0.}
   def body_collision(self,p):return {'contact':True,'parts':[{'actualBody':{'contact':True},'horizontalMargin':{'contact':False}}]}
   def underbody_collision(self,p):return {'contact':False}
  class Process:
   initial={'mapRevision':'fixture'}
   def __init__(self,*args):pass
   def ask(self,p):return {'forwardMetres':.02,'yawRadians':0.,'sourceCapturedAt':100.,'reason':'fixture','goalReached':False}
   def close(self):pass
  with tempfile.TemporaryDirectory() as d,patch.object(w,'ControllerProcess',Process):
   r=w.episode({'start':[0.,0.,0.],'goal':[2.,0.,0.],'initialYawRadians':0.,'profile':'fixture','geometry':{}},World(),Path(d))
  self.assertEqual(r['actualDistanceMetres'],0);self.assertFalse(r['arrival']);self.assertFalse(r['motionExecuted']);self.assertEqual(r['actualBodyContactEvents'],0);self.assertEqual(r['rejectedPredictedBodyContactEvents'],1)
 def test_driver_owner_array_contract_is_explicit(self):
  text=(H/'run_step.py').read_text();self.assertIn('owner_indices.shape==ramps.shape',text);self.assertIn('np.isin(owner_indices,[-1,0,1]).all()',text);self.assertIn('owners.get(int(cid),-1)',text)
 def test_known_riser_is_coverage_not_landing_height(self):
  from support_envelope import TypedSupportEnvelope
  obj=self.world([1]*8+[4],[0]*8+[.015]);obj.envelope=TypedSupportEnvelope([3],[[[.01,.02,.01],[.03,.02,.01],[.01,.02,.03]]]);obj.floor_envelope=None
  r=obj.support([0,0,0],0);self.assertTrue(r['accepted']);self.assertEqual(r['knownStructuralRiserHitCount'],1);self.assertFalse(r['riserSuppliesSupportHeight']);self.assertAlmostEqual(r['footHeight'],.02)
 def test_all_riser_without_landing_rejects(self):
  from support_envelope import TypedSupportEnvelope
  obj=self.world([4]*9,[.015]*9);obj.envelope=TypedSupportEnvelope([3],[[[1,.02,1],[1.1,.02,1],[1,.02,1.1]]]);obj.floor_envelope=None
  self.assertFalse(obj.support([0,0,0],0)['accepted'])
 def test_known_riser_tangent_only_landing_rejects(self):
  from support_envelope import TypedSupportEnvelope
  obj=self.world([1]*8+[4],[0]*8+[.015]);obj.envelope=TypedSupportEnvelope([3],[[[.15,.02,-.1],[.2,.02,0],[.15,.02,.1]]]);obj.floor_envelope=None
  self.assertFalse(obj.support([0,0,0],0)['accepted'])
 def test_last_riser_with_known_floor_landing(self):
  from support_envelope import TypedSupportEnvelope
  obj=self.world([1]*8+[4],[0]*8+[.015]);obj.envelope=TypedSupportEnvelope([3],[[[1,.02,1],[1.1,.02,1],[1,.02,1.1]]]);obj.floor_envelope=TypedSupportEnvelope([1],[[[-.1,0,-.1],[.1,0,-.1],[0,0,.1]]])
  r=obj.support([0,0,0],0);self.assertTrue(r['accepted']);self.assertAlmostEqual(r['footHeight'],0.)
 def test_untagged_object_still_rejects_with_landing(self):
  from support_envelope import TypedSupportEnvelope
  obj=self.world([1]*8+[99],[0]*8+[.015]);obj.envelope=TypedSupportEnvelope([3],[[[.01,.02,.01],[.03,.02,.01],[.01,.02,.03]]]);obj.floor_envelope=None
  self.assertFalse(obj.support([0,0,0],0)['accepted'])
 def test_high_tangent_cannot_raise_lower_floor_landing(self):
  from support_envelope import TypedSupportEnvelope
  obj=self.world([1]*7+[3,4],[0]*7+[.02,.015]);obj.envelope=TypedSupportEnvelope([3],[[[.15,.02,-.1],[.2,.02,0],[.15,.02,.1]]]);obj.floor_envelope=TypedSupportEnvelope([1],[[[-.1,0,-.1],[.1,0,-.1],[0,0,.1]]])
  r=obj.support([0,0,0],0);self.assertTrue(r['accepted']);self.assertAlmostEqual(r['footHeight'],0.);self.assertIsNone(r['typedSupportEnvelope']['maxY'])
 def test_transit_tangent_bounds_clearance_not_landing_height(self):
  from support_envelope import TypedSupportEnvelope
  obj=self.world([1]*8+[4],[0]*8+[.015]);obj.envelope=TypedSupportEnvelope([3],[[[.15,.02,-.1],[.2,.02,0],[.15,.02,.1]]]);obj.floor_envelope=TypedSupportEnvelope([1],[[[-.1,0,-.1],[.1,0,-.1],[0,0,.1]]])
  landing=obj.support([0,0,0],0);transit=obj.apply_envelope(landing,[0,0,0],[0,0,0],0,0,transit=True)
  self.assertAlmostEqual(landing['footHeight'],0.);self.assertAlmostEqual(transit['footHeight'],.02)
 def test_unknown_owner_tangent_rejects_despite_lower_floor(self):
  from support_envelope import TypedSupportEnvelope
  obj=self.world([1]*8+[4],[0]*8+[.015]);obj.envelope=TypedSupportEnvelope([5],[[[.15,.02,-.1],[.2,.02,0],[.15,.02,.1]]],owners=[-1]);obj.floor_envelope=TypedSupportEnvelope([1],[[[-.1,0,-.1],[.1,0,-.1],[0,0,.1]]])
  self.assertFalse(obj.support([0,0,0],0)['accepted'])
 def test_one_fifo_no_reset_at_return(self):
  s=(H/'step_world.py').read_text();self.assertEqual(s.count('actor=motion.ActorFIFO('),1);a=s.split("if status=='entryArrivedContinueReturn':")[1].split("elif status!='timeout':")[0];self.assertNotIn('state=',a);self.assertNotIn('actor=',a);self.assertNotIn('yaw=',a)
 def test_arrival_requires_drained_macro_and_fifo(self):
  tree=ast.parse((H/'step_world.py').read_text());n=next(n for n in ast.walk(tree)if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='arrival'for t in n.targets));code=compile(ast.Expression(n.value),'<actual arrival>','eval');d=dict(bool=bool,float=float,np=np,max=max,cue={'goalReached':True},moved=False,pending=False,error=.345,full=.345,leg_distance=1.,leg_start=np.array([1.,0,0]),goal=np.zeros(3));self.assertTrue(eval(code,d));self.assertFalse(eval(code,{**d,'pending':True}));self.assertFalse(eval(code,{**d,'moved':True}))
 def test_sill_ids_never_skipped_by_fullbody(self):
  s=(H/'step_world.py').read_text();self.assertIn('self.body_ground=frozen_ground(base,floors,',s);self.assertIn('self.guard_ground=frozen_ground(base,np.union1d(floors,structural),',s)
if __name__=='__main__':unittest.main(verbosity=2)
