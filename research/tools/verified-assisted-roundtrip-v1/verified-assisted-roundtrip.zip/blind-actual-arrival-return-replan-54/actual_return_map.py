"""Source-only return query from delivered arrival, never from reference geometry."""
from pathlib import Path
import sys,importlib.util,dataclasses,numpy as np
W=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(W/'blind-polycam-varpu-executor-40'))
from goal_region_map import GoalRegionMap,load_plan
class SourcePlanRejected(ValueError):pass
class ActualReturnMap(GoalRegionMap):
 def begin_return(self,arrival):
  if self.leg!=0:raise ValueError('one return only')
  arrival=np.asarray(arrival,float)
  if arrival.shape!=(3,)or not np.isfinite(arrival).all():raise ValueError('finite delivered arrival required')
  start=arrival.copy();start[1]=0.;goal=np.array(self.plan['start'],float);goal[1]=0.
  a,_=self.pair.map_objective(start,self.old,self.new);b,_=self.pair.map_objective(goal,self.old,self.new)
  spec=importlib.util.spec_from_file_location('return54_detour',W/'blind-split-candidate-game-03/body-margin-variants-07/native025/detour_engine.py');de=importlib.util.module_from_spec(spec);sys.modules[spec.name]=de;spec.loader.exec_module(de)
  with np.load(W/'blind-polycam-alignment-feasibility-36/POLYCAM_INTRINSIC_GEOMETRY.npz')as z:obj=z['verticesOBJ'];tri=z['triangles']
  with np.load(W/'blind-polycam-rigid-registration-37/run-01/CANDIDATE_RIGID_TRANSFORM.npz')as z:
   assert z['scale']==1;level=obj@z['rotationOBJToLevel'].T+z['translationOBJToLevel']
  v=np.c_[level[:,0],level[:,2],-level[:,1]]
  cfg=de.Config(radius=.225,height=1.75,cell_size=.025,max_climb=.025,max_slope=15.)
  with de.Engine(v,tri,cfg,mode='known-provided-map')as engine:r=engine.route(a,b,query_half_extents=(.2,.3,.2),max_points=256)
  if not r.complete or len(r.points)<1:raise SourcePlanRejected('no complete source-only return')
  def convert(p):return self.pair.map_objective(np.asarray(p,float),self.new,self.old)[0]
  pa=convert(r.projected_start);pb=convert(r.projected_goal);pts=np.array([convert(p)for p in r.points])
  if not r.complete or len(pts)<1 or not np.isfinite(pts).all():raise SourcePlanRejected('no complete source-only return')
  for p,q in((pa,start),(pb,goal)):
   if not np.isfinite(p).all()or np.linalg.norm((p-q)[[0,2]])>.1 or abs(p[1])>.05:raise SourcePlanRejected('unassociated return endpoint')
  if np.any(np.abs(pts[:,1])>.05):raise SourcePlanRejected('unassociated return height')
  self.return_receipt={'actualDeliveredArrivalOriginalXYZ':arrival.tolist(),'requestedPlanarStartOriginalXYZ':start.tolist(),'requestedOriginalOutsideGoal':goal.tolist(),'requestedSourceStartXYZ':a.tolist(),'requestedSourceGoalXYZ':b.tolist(),'projectedStartOriginalXYZ':pa.tolist(),'projectedGoalOriginalXYZ':pb.tolist(),'nativeConfig':dataclasses.asdict(cfg),'native':dataclasses.asdict(r),'referenceInputsUsed':False,'sourceOnlyRequery':True,'oldDeeperConnectorUsed':False,'noActorSnap':True}
  self.leg=1;self.points=np.vstack([start,pts,goal]);self.cursor=0
  return self.return_receipt
