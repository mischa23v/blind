# Post-run diagnosis of stage51 return stop

No motion, mesh change, floor relabeling or classifier relaxation is performed here. Stage51 remains immutable.

The rejected midpoint probe hit original FARO face **7253304**, at approximately original-game XZ (4.86465, 0.09973). All nine rays hit geometry; this was not an unobserved-support hole. The exact original triangle was read directly from the binary PLY, with the same float32 vertex quantization and pinned world transform as the collision evaluator.

- Absolute-Y normal slope: **19.93484°**, outside the ≤5° training rule, within the ≤45° recovery guard.
- Saved assigned local-plane residuals at the three original vertices: **+2.72772, +1.49923, +1.42949 mm**.
- The first vertex fails the existing **2 mm every-vertex** recovery criterion. This is an exact eligibility rejection; we have not separately rerun the full adjacency component calculation.
- Broad active gray-plane residuals: −1.26570, −2.51967, −2.54609 mm.
- The recorded midpoint support spread and height-cap checks pass, but the frozen semantic membership does not.

## Source photographs

`project_face_views.py` projects the exact triangle centroid through the original game-to-phone transform and original camera poses, not the corrected display frame. It requires visibility and a source-depth median within 10 cm of predicted axial depth; this is an association check, not a clearance or identity guarantee.

Frames **00145** and **00126** were selected and visually inspected. The projected point is close to the far wall/baseboard and a small pale strip or object at floor level, not an unambiguous central patch of empty carpet. RGB and reference captures can disagree; this evidence does **not** justify automatically declaring the face noise or free space. Exact camera/UV/depth association values and source-image hashes are in `SOURCE_VIEW_ASSOCIATION.json`.

## Independent controller issue

Stage51 starts its return by first moving from the accepted arrival pose to the old precomputed reverse route's deeper starting waypoint. This is unnecessary if a return route can instead be queried from the actual delivered arrival pose. A new source-only planner variant can test that without relabeling this disputed face. Such a test must preserve the current mesh, collision, body, goal and support rules and report any new route separately.
