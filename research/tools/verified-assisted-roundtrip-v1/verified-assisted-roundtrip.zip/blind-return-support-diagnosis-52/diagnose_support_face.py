"""Read one original PLY face and saved classifier patch: no motion/reclassification."""
from pathlib import Path
import json,struct,hashlib,math
import numpy as np
H=Path(__file__).resolve().parent;W=H.parent;S=W/'blind-entry-return-protocol-retry-51'
r=json.loads((S/'run-01/result/RESULT.json').read_text());r['groundComponent']=json.loads((W/'blind-assisted-threshold-traversal-proposal-43/floor-gate-01/RESULT.json').read_text())['grayGround'];cell=r['terminal']['macroEvent']['supportMid']['untypedHitIDs'][0]
mesh=W/'blind-koivu-faro-acquisition-04/selected-reference/gt_mesh.ply'
with mesh.open('rb')as f:
 header=b''
 while not header.endswith(b'end_header\n'):header+=f.readline()
 assert b'element vertex 8940320\n' in header and b'property list uchar uint vertex_indices\n' in header
 f.seek(len(header)+8940320*48+cell*13);n,*ids=struct.unpack('<BIII',f.read(13));assert n==3
 ref=[]
 for v in ids:f.seek(len(header)+v*48);ref.append(struct.unpack('<ddd',f.read(24)))
ref=np.array(ref);quantized=ref.astype(np.float32).astype(np.float64)
with np.load(W/'blind-split-candidate-game-03/inputs/koivu_5cm_v2_pipeline2_out.npz')as z:R=z['R'];t=z['t']
A=np.array(json.loads((W/'blind-koivu-faro-acquisition-04/selected-reference/icp_iphone.json').read_text())['gt_transformation']);B=np.array([[1.,0,0],[0,0,-1],[0,1,0]]);M=np.eye(4);M[:3,:3]=R.T@B;M[:3,3]=-R.T@t;T=A@M;I=np.linalg.inv(T)
assert hashlib.sha256(T.tobytes()).hexdigest()==r['groundComponent']['referenceTransformSHA256']
q=quantized@I[:3,:3].T+I[:3,3];n=np.cross(q[1]-q[0],q[2]-q[0]);normal=n/np.linalg.norm(n);slope=math.degrees(math.acos(min(1,abs(normal[1]))));centre=q.mean(0);tile=np.floor(centre[[0,2]]/.1).astype(int)
patch=next(p for p in r['groundComponent']['patchFits']if p['tile']==tile.tolist());active=np.array(r['groundComponent']['planeCoefficientsYEqualsAXPlusBZPlusC']);active_res=q[:,1]-(active[0]*q[:,0]+active[1]*q[:,2]+active[2])
local=None
if patch['status']=='fit':
 plane=np.array(patch['planeYEqualsAXPlusBZPlusC']);local=(q[:,1]-(plane[0]*q[:,0]+plane[1]*q[:,2]+plane[2])).tolist()
bounds=np.array(r['groundComponent']['patchGameBounds']).reshape(3,2);within=bool(q[:,1].min()>=bounds[1,0] and q[:,1].max()<=bounds[1,1] and q[:,0].max()>=bounds[0,0] and q[:,0].min()<=bounds[0,1] and q[:,2].max()>=bounds[2,0] and q[:,2].min()<=bounds[2,1])
check=r['terminal']['macroEvent']['supportMid'];summary={'scope':'Postrun single-face/saved-local-patch diagnosis; no full mesh load, classifier rerun, route change or motion','referenceCellID':cell,'originalVertexIDs':ids,'originalReferenceVerticesDouble':ref.tolist(),'VTKQuantizedReferenceVertices':quantized.tolist(),'verticesOriginalGameXYZ':q.tolist(),'centroidOriginalGameXYZ':centre.tolist(),'unitNormalOriginalGame':normal.tolist(),'absoluteYNormalSlopeDegrees':slope,'withinFrozenClassificationBounds':within,'eligible5DegreeTrainingNormal':slope<=5,'passes45DegreeRawGuard':slope<=45,'savedAssignedPatch':patch,'localPlaneVertexResidualsMetres':local,'passes2mmLocalEveryVertexResidual':bool(local is not None and max(map(abs,local))<=.002),'activePlaneVertexResidualsMetres':active_res.tolist(),'recordedMembership':False,'numericSupportHeightChecksPass':bool(check['hitCount']==9 and check['rawSpreadMetres']<=check['spreadLimitMetres'] and not check['capFailures']),'missingRays':check['missingCount'],'classificationInterpretation':'training requires <=5deg AND original shared-edge connection; recovery requires <=45deg AND local every-vertex residual<=2mm AND connection; exact failed local eligibility below does not establish semantic object/floor','sourceResultSHA256':hashlib.sha256((S/'run-01/result/RESULT.json').read_bytes()).hexdigest(),'referenceTransformSHA256':hashlib.sha256(T.tobytes()).hexdigest(),'geometryWasChanged':False,'physicalAuthority':False}
(H/'SUPPORT_FACE_DIAGNOSIS.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({k:summary[k]for k in ['referenceCellID','centroidOriginalGameXYZ','absoluteYNormalSlopeDegrees','withinFrozenClassificationBounds','eligible5DegreeTrainingNormal','passes45DegreeRawGuard','localPlaneVertexResidualsMetres','passes2mmLocalEveryVertexResidual','activePlaneVertexResidualsMetres','numericSupportHeightChecksPass']},indent=2))
