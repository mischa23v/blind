# Next test: progressive path proposals, not usable-path proof

**Design only; no heavy run.** Four recorded prefixes: 32, 128, 214, 294. Preserve the released training split: 29, 116, 193, 265 integrated RGB-D observations.

- Reuse Open3D CPU 0.19.0 native TSDF: 4 cm voxels, 20 cm truncation, 4 m depth cutoff, original K/poses. Extract four unmodified meshes in memory; never save meshes.
- Reuse unchanged Recast/Detour nominal-body comparator: radius .225 m, height 1.75 m, 2.5 cm cells, 5° slope, zero climb. Keep every build/association/partial-route rejection. These are inherited diagnostic settings, not a universal walking policy.
- Reject old full-recording floor transforms, endpoints, corrected poses and coverage patches. No final mesh, FARO, future floor, camera-height guess, floor flattening or custom classifier.
- Keep current-prefix native OctoMap ray-occupancy provenance separate from TSDF surface inference. Missing/smoothed triangles are not observed clearance; complete TSDF weights are unavailable in the reviewed legacy mesh interface.
- Official installed Open3D `segment_plane(.01,3,1000)` is available for an **untrusted plane hypothesis** from prefix-only points after review. It may return a tabletop/wall; it cannot identify floor or establish support. Do not run its sample downloader or sample-specific flip.
- **Missing:** defensible current-prefix support orientation/identity, source-grounded endpoints, continuous foot support, low-obstacle/unknown coverage, body pose/extrinsics, and swept-body validation. Without these, report route **not evaluable**, not walkability or zero safe routes. Manual-floor annotations, if approved as a separate comparator, do not solve natural scanning.

Measured historical fusion was 105.25 CPU s; all-frame occupancy 63.07 CPU s. Combined workload plus four extractions may approach/exceed 180 CPU s; exact historical full TSDF RSS is unavailable. Proposed caps: 180 CPU / 240 wall / 1.2 GiB sampled RSS / 3 MiB outputs / 768 MiB reserve. First request an independently reviewed, separately approved two-frame in-memory preflight capped at 30 CPU / 45 wall / 1.2 GiB / 256 KiB. No automatic retry or cap increase.

Launch requires independent source/anchor or hypothesis review, immutable input allowlist, release-order proof, native pins, watchdog review, and explicit root approval. Full details and source hashes: `PROTOCOL.md`, `DESIGN_RECEIPT.json`.
