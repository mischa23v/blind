# Independent calibration/export audit (2026-10-27)

**Finding: no demonstrated gross scale/axis/crop mismatch, but physical RGB–depth registration is not independently certified.** The small sparse-map result must not be presented as a limit on localization from pictures.

## Verified locally

`CHECKS.json` records header checks of all 20 baseline reference RGB/depth pairs: JPEG and uint16 PNG dimensions match their per-frame metadata, 738×994. EXIF orientation was checked; no alternate orientation was recorded. No query depth was opened. The complete metadata contains 294 entries with frame IDs spanning **1–309**, with gaps. Thus a dense uniform selection should sample actual eligible metadata IDs, not assume frame IDs end at 294. All frame records expose only the fields listed in CHECKS.json, with no distortion coefficients, timestamps, confidence or native sensor calibration.

The old estimator uses `transform_matrix` as OpenGL camera-to-world, and maps CV `(x,y,z)` to GL `(x,-y,-z)` before transforming. Its metre conversion (`depth/1000`) matches the author's documented processing convention. It reads original JPEGs and raw exported PNGs, not square-cropped SDFStudio converted outputs. Neither a further square crop nor unit-box scene normalization belongs in this estimator.

## Primary-source check

The [author conversion source](https://github.com/TUTvision/MuSHRoom/blob/main/iphone_tools/1_nerfstudio_to_sdfstudio_within.py) reads per-frame Polycam intrinsics and changes camera-to-world columns two and three in sign for OpenCV. It converts PNG values to metres by dividing by 1000. Crop/resize only occurs with the optional mono-prior branch; otherwise image/depth transforms are empty. Its later reconstruction scene scaling changes both pose translation and depth, and is unrelated to the original metre-space inputs used here. This source establishes the intended consumer convention, **not the upstream Polycam capture/export calibration accuracy**.

A second existing, pinned implementation is `blind-open3d-author-baseline-10/author-inputs/pointcloud_utils.py` (DN-Splatter commit `97588b4290128ce7ba6fdbfaac3020b42b17de4c`; hash in SOURCE_ACQUISITION.json). It similarly constructs intrinsics from each frame and converts OpenGL pose axes. It resizes depth to RGB dimensions before fusion. Our already-matching input dimensions do not require this resize.

## Half-resolution detail

A small synthetic ramp through the installed OpenCV 4.14.0 `INTER_AREA` half-resize gave `[0.5,2.5,4.5,6.5]` from native samples `[0,1,...,7]`. With integer-centred pixel coordinates, a half-res keypoint `u` therefore maps to native `2u+0.5`, and the consistent half-res principal point is `(cx+0.5)/2-0.5 = cx/2-0.25` (same for y). Baseline uses `2u` and `cx/2`: a 0.5-native-pixel / 0.25-half-pixel convention discrepancy. This small subpixel issue is **not established as the cause of gross wrong poses**. Preserve it for a density-only comparator; any correction should be a separate predeclared variant, not silently change density and calibration together. Original exporter principal-point pixel-origin semantics remain incompletely documented.

## Limits and recommended interpretation

- Matching dimensions and author-compatible conventions support loader consistency, not verified per-pixel physical registration. The PNG is processed/exported depth at image resolution, not original native-depth resolution.
- No native RGB–depth extrinsics, distortion/rectification description or independent checkerboard/edge calibration is present in the inspected contract. Do not invent them or assert that registration was proven.
- A training-only cross-view landmark reprojection/depth-consistency audit can quantify internal consistency, but cannot become independent physical truth because reference poses and depth derive from the same processing pipeline.
- Repeated textures, sparse accepted reference landmarks and guarded temporal gaps remain plausible causes to measure rather than assume. A denser uniformly sampled train-only map, same gates, and separately sealed scorer is the clean next density experiment.

Only about 0.64 CPU seconds used for local header/metadata/synthetic checks. No download, installation, image remapping, threshold tuning or estimator modification performed.
