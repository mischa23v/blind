# Scoring-only coverage characterization. NEVER imported by estimate.py.
import json,sys
from pathlib import Path
sys.path.insert(0,'/workspace/shared/blind-perception-private-replay/runtime')
import numpy as np
out=Path(__file__).resolve().parent
T={int(k):np.array(v['transform_matrix']) for k,v in json.load(open(out/'train-only.json')).items()};Q={int(k):np.array(v) for k,v in json.load(open(out/'evaluator-only.json')).items()};r=json.load(open(out/'RESULTS.json')); rows=[]
for row in r['queries']:
 q=Q[row['frame']];metrics=[]
 for i,t in T.items():metrics.append({'reference':i,'distance_m':float(np.linalg.norm(q[:3,3]-t[:3,3])),'full_rotation_deg':float(np.degrees(np.arccos(np.clip((np.trace(q[:3,:3].T@t[:3,:3])-1)/2,-1,1))))})
 rows.append({'query':row['frame'],'nearest_center':min(metrics,key=lambda x:x['distance_m']),'nearest_rotation':min(metrics,key=lambda x:x['full_rotation_deg']),'selected_reference_geometry':next(x for x in metrics if x['reference']==row['reference_frame']),'maximum_reference_matches':max(x['matches'] for x in row['reference_match_counts']),'query_keypoints':row['keypoints']})
(out/'COVERAGE_POSTHOC.json').write_text(json.dumps({'scope':'Withheld poses used only after estimator sealed; not reference retrieval or model selection. Distance/angle alone not visibility proof.','queries':rows},indent=2))
for x in rows: print(x)
