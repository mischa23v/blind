# Denser train-only reference experiment (v3b)

**Result: 3/8 fixed development query images accepted, versus 1/8 with 20 references.** Reference coverage materially affects the result; 1/8 was not a limit on information available in photographs.

| Query | Accepted | Inliers | Position error | Full rotation error |
|---|---|---:|---:|---:|
|50|yes|97|1.09 cm|0.162°|
|58|yes|35|3.76 cm|0.582°|
|120|no|10|14.97 cm|0.405°|
|128|no|0|no pose|no pose|
|190|no|0|no pose|no pose|
|198|no|0|no pose|no pose|
|260|no|19|8.93 cm|2.262°|
|268|yes|21|19.43 cm|2.163°|

No accepted estimate exceeds the previously declared diagnostic scoring criterion of 0.25 m or 10°. That is **not calibrated clearance, body heading, safe guidance, or an operational acceptance guarantee**. Frame260 stays rejected despite looking close after scoring; no threshold was relaxed.

## Frozen method and isolation

80 reference frames were uniformly selected by integer position from **175 actual eligible metadata IDs**, excluding the original four withheld blocks plus five-frame guards. The original eight query IDs are unchanged. Metadata has 294 entries spanning IDs1–309 with gaps; the earlier range-based baseline stopped at289. This variant explicitly uses actual IDs through309. It does not claim density alone explains every improvement: both sampling density and inclusion of late eligible IDs changed.

The map contains **21,318 depth-backed SIFT descriptors** from 28,670 detected reference features. Original SIFT, descriptor ratio, top-three reference candidate PnP, ambiguity rule, and strict acceptance gates are unchanged. Same recording, same development queries, supplied globally optimized reference poses: not independent holdout or causal SLAM.

Estimator `estimate.py` reads only `train-only.json`, `query-intrinsics-only.json`, training RGB/depth, and query RGB; it does not open original combined pose metadata, evaluator-only.json, or query depth. It writes ESTIMATES.json and SHA256-sealed UNSCORED.json before `score.py` separately reads evaluator-only.json. This is separate input/process separation, not an OS sandbox preventing all conceivable file access. FROZEN.json records pre-execution hashes. No scored query pose selected a reference.

Initial v3 failed on frame31 RGB path resolution before query estimation. Preserve `../dense-reference-v3/`: the existing recorded_subset contained the file. V3b adds only that third local resolver path. No downloads or dropped missing reference frames.

## Calibration audit and limitations

All80 actual training depth rasters and downsampled RGB dimensions match per-frame metadata; depth dtype is uint16. Independent exporter review confirms depth millimetres→metres and camera-to-world OpenGL→OpenCV conversion. No extra crop belongs to these original inputs. See `../calibration-audit-20261027/` for primary-source references and checks.

The baseline half-resolution convention differs from exact INTER_AREA pixel-center mapping by 0.25 half-resolution pixels. Preserved here to keep this comparison focused; any correction needs its own frozen variant. Matching dimensions and documented units/axes **do not prove native physical RGB–depth alignment**: original registration/extrinsic calibration evidence is absent. We did not inspect query depth to calibrate the model.

## Coverage and descriptor diagnosis (post-hoc only)

`coverage_posthoc.py` opens withheld poses only after sealing, for explanation—not retrieval or parameter fitting. `COVERAGE_POSTHOC.json` reports distances and full camera-rotation differences; they are not visibility/occlusion proof.

- Query50 has a reference0.163 m away with1.74° rotation difference and118 matches; it localizes strongly.
- Query120 has640 SIFT features but at most18 ratio-passing matches in any reference. Its nearest camera is only0.092 m away but faces114° differently. Its chosen descriptor reference is6.09 m away. Thus proximity does not imply reference view coverage.
- Query128's nearest camera is1.317 m away and134° different. Query190's maximum reference match count is15.
- Query198 selects a42-match reference7.17 m away/161° different, with no PnP inliers: descriptor ambiguity/outliers remain despite many query features.
- Query260 has only86 detected query features and at most28 matches; best candidate19 inliers stays below the fixed20-inlier gate.

These explain heterogeneous failures without labeling all failures as image scarcity. Repetitive/descriptively ambiguous features and viewpoint coverage are supported diagnoses; no visual-semantic room coverage guarantee follows from80 frames.

## Reproduction/resources

From workspace root run `python blind-visual-relocalization-77/dense-reference-v3b/estimate.py`, then `python blind-visual-relocalization-77/dense-reference-v3b/score.py`. These overwrite only this variant's outputs; use a copied variant for immutable historical retention. Recorded run: **7.95 CPU seconds,106.3 MB peak RSS**. Source/input hashes and frozen selection are included. All original baseline artifacts remain unchanged.
