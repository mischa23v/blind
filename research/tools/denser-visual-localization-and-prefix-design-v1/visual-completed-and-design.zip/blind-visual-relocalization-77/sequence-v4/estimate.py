import os,sys,time,json,hashlib,resource
os.environ['OPENBLAS_NUM_THREADS']='1'
sys.path.insert(0,'/workspace/shared/blind-perception-private-replay/runtime')
import cv2,numpy as np
from pathlib import Path
cv2.setNumThreads(1);cv2.setRNGSeed(77)
resource.setrlimit(resource.RLIMIT_CPU,(120,120))
OUT=Path(__file__).resolve().parent; W=OUT.parent.parent
P=json.loads((OUT/'PROTOCOL.json').read_text()); start=time.process_time()
def budget():
 assert resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024 < 1024**3
 s=os.statvfs(OUT);assert s.f_bavail*s.f_frsize >= 768*1024**2
 assert sum(x.stat().st_size for x in OUT.iterdir() if x.is_file()) < 3*1024**2
budget()
train=P['train_frames']; queries=P['query_frames']
T={int(k):v for k,v in json.load(open(OUT/'train-only.json')).items()}
Q={int(k):v for k,v in json.load(open(OUT/'query-intrinsics-only.json')).items()}
rgb=W/'blind-open3d-author-baseline-10/author-inputs/selected/images'; dep=W/'blind-koivu-game-07/map/depths'
sift=cv2.SIFT_create(nfeatures=1000); matcher=cv2.BFMatcher(cv2.NORM_L2)
def rgbpath(i):
 p=rgb/f'frame_{i:05d}.jpg'
 paths=[p,W/'koivu-room-photo-catalog/missing-rgb'/p.name,W/'blind-mushroom-koivu-acquisition-01/recorded_subset/room_datasets/koivu/iphone/long_capture/images'/p.name]
 return next(x for x in paths if x.exists())
def features(i):
 image=cv2.imread(str(rgbpath(i)),cv2.IMREAD_GRAYSCALE);assert image is not None
 im=cv2.resize(image,None,fx=.5,fy=.5,interpolation=cv2.INTER_AREA)
 k,d=sift.detectAndCompute(im,None);return k,d,im.shape
refs=[]; calibration=[]; inputs={str(p.relative_to(W)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [OUT/'train-only.json', OUT/'query-intrinsics-only.json']}
for i in train:
 budget();f=T[i];k,d,shape=features(i); depth=cv2.imread(str(dep/f'frame_{i:05d}.png'),cv2.IMREAD_UNCHANGED)
 assert depth.shape==(f['h'],f['w'])
 assert shape==(f['h']//2,f['w']//2) and depth.dtype==np.uint16
 p=[];desc=[];pose=np.array(f['transform_matrix'])
 for j,kp in enumerate(k):
  u,v=np.array(kp.pt)*2; x,y=int(round(u)),int(round(v))
  if not (2<=x<f['w']-2 and 2<=y<f['h']-2):continue
  patch=depth[y-2:y+3,x-2:x+3].astype(float)/1000;z=depth[y,x]/1000
  if not (.3<=z<=5 and patch.min()>0 and np.ptp(patch)<=.1):continue
  # OpenGL camera right/up/back, vs CV right/down/forward.
  cam=np.array([(u-f['cx'])/f['fl_x']*z,-(v-f['cy'])/f['fl_y']*z,-z])
  p.append(pose[:3,:3]@cam+pose[:3,3]);desc.append(d[j])
 calibration.append({'frame':i,'rgb_half_shape':shape,'depth_shape':depth.shape,'sift_features':len(k),'retained_depth_landmarks':len(p),'pose_rotation_orthogonality_error':float(np.linalg.norm(pose[:3,:3].T@pose[:3,:3]-np.eye(3))),'focal_xy':[f['fl_x'],f['fl_y']],'principal_point':[f['cx'],f['cy']]})
 if p: refs.append((i,np.array(p,np.float32),np.array(desc,np.float32)))
 for path in [rgbpath(i),dep/f'frame_{i:05d}.png']: inputs[str(path.relative_to(W))]=hashlib.sha256(path.read_bytes()).hexdigest()
results=[]; anchors={}; candidate_geometry={}
for i in queries:
 budget();k,d,shape=features(i);candidates=[]
 for ti,points,descriptors in refs:
  good=[pair[0] for pair in matcher.knnMatch(d,descriptors,k=2) if len(pair)==2 and pair[0].distance<.7*pair[1].distance]
  candidates.append((len(good),ti,points,good))
 candidates.sort(key=lambda a:-a[0]);attempts=[];f=Q[i]
 for count,ti,points,good in candidates[:3]:
  row={'reference_frame':ti,'matches':count,'accepted':False,'inliers':0}
  if count>=6:
   obj=np.array([points[m.trainIdx] for m in good],np.float32);img=np.array([k[m.queryIdx].pt for m in good],np.float32)
   K=np.array([[f['fl_x']/2,0,f['cx']/2],[0,f['fl_y']/2,f['cy']/2],[0,0,1.]])
   ok,rv,tv,idx=cv2.solvePnPRansac(obj,img,K,None,iterationsCount=1000,reprojectionError=3,confidence=.999,flags=cv2.SOLVEPNP_EPNP)
   if ok and idx is not None:
    ix=idx.ravel();candidate_geometry[(i,ti)]=(obj[ix].copy(),img[ix].copy());span=np.ptp(img[ix],axis=0)/np.array([shape[1],shape[0]])
    R=cv2.Rodrigues(rv)[0];C=-R.T@tv.ravel();Rc=R.T@np.diag([1,-1,-1]);proj=cv2.projectPoints(obj[ix],rv,tv,K,None)[0][:,0,:]
    row.update(inliers=len(ix),inlier_fraction=len(ix)/count,span=span.tolist(),median_reprojection_px=float(np.median(np.linalg.norm(proj-img[ix],axis=1))),camera_position=C.tolist(),camera_rotation_gl=Rc.tolist(),accepted=bool(len(ix)>=20 and len(ix)/count>=.35 and min(span)>=.2))
  attempts.append(row)
 chosen=max(attempts,key=lambda a:a['inliers']);row=dict(chosen);row.update(frame=i,keypoints=len(k),ambiguous=False)
 for alt in attempts:
  if row['accepted'] and alt['accepted']:
   distance=np.linalg.norm(np.array(row['camera_position'])-alt['camera_position']);angle=np.degrees(np.arccos(np.clip((np.trace(np.array(row['camera_rotation_gl']).T@np.array(alt['camera_rotation_gl']))-1)/2,-1,1)))
   if distance>.5 or angle>15:row['ambiguous']=True
 if row['ambiguous']:row['accepted']=False
 if row['accepted']:anchors[i]=candidate_geometry[(i,row['reference_frame'])]
 row['reference_match_counts']=[{'frame':x[1],'matches':x[0]} for x in candidates];row['candidates']=attempts;results.append(row)
 path=rgbpath(i);inputs[str(path.relative_to(W))]=hashlib.sha256(path.read_bytes()).hexdigest()
 print(json.dumps(row),flush=True)

independent={r['frame']:r for r in results}; trials=[]
def gray(i):return cv2.resize(cv2.imread(str(rgbpath(i)),cv2.IMREAD_GRAYSCALE),None,fx=.5,fy=.5,interpolation=cv2.INTER_AREA)
def track(src,dst,state):
 obj,img=state;prev=gray(src);now=gray(dst);f=Q[dst]
 pts,status,err=cv2.calcOpticalFlowPyrLK(prev,now,img.reshape(-1,1,2),None,winSize=(21,21),maxLevel=3,criteria=(cv2.TERM_CRITERIA_COUNT+cv2.TERM_CRITERIA_EPS,30,.01),flags=0,minEigThreshold=1e-4)
 row={'frame':dst,'source_frame':src,'accepted':False,'inliers':0}
 if pts is None:return row,None
 img=pts[:,0,:];valid=(status.ravel()==1)&np.isfinite(img).all(axis=1)&(img[:,0]>=0)&(img[:,0]<now.shape[1])&(img[:,1]>=0)&(img[:,1]<now.shape[0]);obj=obj[valid];img=img[valid];row['matches']=len(img)
 if len(img)<6:return row,None
 K=np.array([[f['fl_x']/2,0,f['cx']/2],[0,f['fl_y']/2,f['cy']/2],[0,0,1.]])
 cv2.setRNGSeed(77);ok,rv,tv,idx=cv2.solvePnPRansac(obj,img,K,None,iterationsCount=1000,reprojectionError=3,confidence=.999,flags=cv2.SOLVEPNP_EPNP)
 if not ok or idx is None:return row,None
 ix=idx.ravel();span=np.ptp(img[ix],axis=0)/np.array([now.shape[1],now.shape[0]]);R=cv2.Rodrigues(rv)[0];C=-R.T@tv.ravel();Rc=R.T@np.diag([1,-1,-1]);projected=cv2.projectPoints(obj[ix],rv,tv,K,None)[0][:,0,:]
 row.update(inliers=len(ix),inlier_fraction=len(ix)/len(img),span=span.tolist(),camera_position=C.tolist(),camera_rotation_gl=Rc.tolist(),median_reprojection_px=float(np.median(np.linalg.norm(projected-img[ix],axis=1))),accepted=bool(len(ix)>=20 and len(ix)/len(img)>=.35 and min(span)>=.2))
 return row,(obj[ix],img[ix]) if row['accepted'] else None
for seq in P['sequences']:
 for mode,views in [('one',[seq[-1]]),('two',[seq[0],seq[-1]]),('five',seq)]:
  state=None;prev=None;steps=[]
  for i in views:
   budget();ind=independent[i];tracked=None;newstate=None
   if state is not None:tracked,newstate=track(prev,i,state)
   chosen=dict(ind);chosen.pop('reference_match_counts',None);chosen.pop('candidates',None);chosen['source']='independent'
   conflict=False
   if ind['accepted'] and tracked is not None and tracked['accepted']:
    distance=np.linalg.norm(np.array(ind['camera_position'])-tracked['camera_position']);angle=np.degrees(np.arccos(np.clip((np.trace(np.array(ind['camera_rotation_gl']).T@tracked['camera_rotation_gl'])-1)/2,-1,1)));conflict=bool(distance>.5 or angle>15)
   if conflict:chosen['accepted']=False;chosen['source']='conflict';state=None
   elif ind['accepted']:state=anchors[i]
   elif tracked is not None and tracked['accepted']:chosen=dict(tracked);chosen['source']='tracked';state=newstate
   else:state=None
   steps.append({'frame':i,'selected':chosen,'tracking_attempt':tracked,'conflict':conflict});prev=i
  endpoint=dict(steps[-1]['selected']);endpoint.update(mode=mode,views=views,steps=steps);trials.append(endpoint)
# Seal all independent estimates and endpoint trials before separate evaluation.
results=[dict(r,mode='independent') for r in results]+trials
(OUT/'ESTIMATES.json').write_text(json.dumps(results,indent=2));seal=hashlib.sha256((OUT/'ESTIMATES.json').read_bytes()).hexdigest()
result={'protocol_sha256':hashlib.sha256((OUT/'PROTOCOL.json').read_bytes()).hexdigest(),'estimates_sha256':seal,'opencv':cv2.__version__,'train_frames':train,'train_landmarks':sum(len(x[1]) for x in refs),'queries':results,'cpu_seconds':time.process_time()-start,'max_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,'input_sha256':inputs}
(OUT/'UNSCORED.json').write_text(json.dumps(result,indent=2)); print('SEALED',seal,result['cpu_seconds'],result['max_rss_bytes'])
