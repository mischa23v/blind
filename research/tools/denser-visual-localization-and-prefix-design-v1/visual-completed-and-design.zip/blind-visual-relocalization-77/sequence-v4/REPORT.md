# Frozen one/two/five-image current-camera comparison

**No endpoint improvement: one, two and five images each accepted the same2/4 final camera poses.** Additional images did not rescue either failed endpoint in this fixed development comparison.

| Observation sequence | One(final only) | Two(first+final) | Five(all shown) | Final accepted error |
|---|---|---|---|---|
|50,52,54,56,58|accept58|accept58|accept58|3.76 cm /0.582°|
|120,122,124,126,128|reject128|reject128|reject128|no accepted pose|
|190,192,194,196,198|reject198|reject198|reject198|no accepted pose|
|260,262,264,266,268|accept268|accept268|accept268|19.43 cm /2.163°|

## Method

The frozen80-reference map and unchanged SIFT/PnP acceptance gates are reused. Independently localize all20 query images once; share these independent results across modes. For extra views, track mapped PnP inlier correspondences only from a previously accepted frame with released OpenCV pyramidal Lucas–Kanade defaults, then run the same PnP/gates for the CURRENT frame. No query depth or supplied query poses are used by estimator. Query intrinsics and reference poses are separate inputs; evaluator loads query poses only after estimate sealing.

Independent accepted localization is preferred; a sole accepted tracked pose could be used. If both were accepted but inconsistent by the existing0.5 m/15° ambiguity rule, reject. A rejection discards the tracking state. No old pose is reused as fresh. Five observations are every second exported frame, not a claim about elapsed seconds: original capture timestamps are unavailable. Seed handling is frozen in PROTOCOL.json; independent endpoint estimates equal v3b in this execution.

## Cold-start versus tracking

Every accepted final estimate comes from **independent current-image localization**. Tracking-only accepted poses: **0**. A pair with an accepted first anchor is not a cold-start rescue. In50→58, first50 already localizes, but LK→PnP58 is rejected; independent58 succeeds. In260→268, first260 is rejected, no tracking is attempted, and268 independently reacquires. For failed120/190 starts, no accepted anchor exists and no pose is propagated.

Seven tracking attempts were made across pair/sequence modes; all were rejected by unchanged gates. The50–58 sequence independently localizes each of its five sampled observations. The260–268 sequence has acceptance pattern **reject,accept,accept,reject,accept**: loss at266 and reacquisition268, NOT continuous localization. The120–128 and190–198 sequences reject every sampled view. No rejected intermediate candidate was promoted based on its scoring error, even though some were numerically close.

Independent accepted count8/20; all are within the existing diagnostic0.25 m/10° score criterion, which is not safety/clearance/body-heading calibration. Rejected candidates include large errors (e.g.194:12.57 m/175°), preserving why rejection matters.

This is a simple released tracking baseline, not generalized multi-view cold-start localization or a claim that two/five photos cannot help. More capable train-only map matching and viewpoint coverage remain next research questions. Do not tune LK/gates on these already-scored cases; freeze a method and assess a newly reserved block/session for generalization.

## Resources/reproduction

12.12 CPU seconds,106.9 MB peak RSS. No downloads/pushes. Run `estimate.py`, then `score.py` in this folder's workspace-relative path. FROZEN.json records pre-run configuration/source hashes; ESTIMATES.json is sealed in UNSCORED.json before scoring. Do not overwrite retained historical outputs; copy the variant for reruns.

[OpenCV LK API](https://docs.opencv.org/4.x/dc/d6b/group__video__track.html) supplies the standard tracking implementation; this experiment uses explicit documented defaults, not tuned thresholds. Camera-to-body orientation, safe route connector, and continuous-deviation navigation remain unestablished and must not consume rejected poses.
