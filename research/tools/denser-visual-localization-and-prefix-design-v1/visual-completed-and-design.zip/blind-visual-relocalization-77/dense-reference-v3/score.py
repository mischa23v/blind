import json,hashlib,sys
from pathlib import Path
sys.path.insert(0,'/workspace/shared/blind-perception-private-replay/runtime')
import numpy as np
out=Path(__file__).resolve().parent
r=json.loads((out/'UNSCORED.json').read_text());assert r['estimates_sha256']==hashlib.sha256((out/'ESTIMATES.json').read_bytes()).hexdigest()
g=json.loads((out/'evaluator-only.json').read_text())
for x in r['queries']:
 if 'camera_position' not in x:continue
 gt=np.array(g[str(x['frame'])]);R=np.array(x['camera_rotation_gl']);x['position_error_m']=float(np.linalg.norm(np.array(x['camera_position'])-gt[:3,3]));x['rotation_error_deg']=float(np.degrees(np.arccos(np.clip((np.trace(R.T@gt[:3,:3])-1)/2,-1,1))))
 h=np.arctan2(-R[1,2],-R[0,2]);hgt=np.arctan2(-gt[1,2],-gt[0,2]);x['heading_error_deg']=float(abs(np.degrees(np.arctan2(np.sin(h-hgt),np.cos(h-hgt)))))
 x['false_accepted']=bool(x['accepted'] and (x['position_error_m']>.25 or x['rotation_error_deg']>10))
(out/'RESULTS.json').write_text(json.dumps(r,indent=2))
for x in r['queries']:print({k:x.get(k) for k in ['frame','accepted','reference_frame','matches','inliers','position_error_m','rotation_error_deg']})
