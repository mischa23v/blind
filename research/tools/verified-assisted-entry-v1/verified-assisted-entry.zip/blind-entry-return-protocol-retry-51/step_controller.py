"""Frozen40 source planner/follower, with explicit actuator-busy hold protocol."""
from pathlib import Path
import sys,json
S=Path(__file__).resolve().parent.parent/'blind-polycam-varpu-executor-40';sys.path.insert(0,str(S))
from goal_region_controller import Controller as Original
class Controller(Original):
 def consume(self,p):
  busy=False
  if p.get('command')=='tick':
   if type(p.get('actuatorBusy'))is not bool:raise ValueError('explicit step actuator busy required')
   p=dict(p);busy=p.pop('actuatorBusy')
  row=super().consume(p)
  if p.get('command')=='beginReturn':
   if row!={'status':'sameActorReturn','noReset':True,'connectorToFrozenReturnStartRequired':True}:raise ValueError('unexpected original return acknowledgment')
   row={**row,'physicalAuthority':False}
  if busy:row.update(forwardMetres=0.,yawRadians=0.,goalReached=False,reason='assistedStepMacroPending')
  return row
if __name__=='__main__':
 c=Controller()
 try:
  for line in sys.stdin:
   if len(line)>1024**2:raise ValueError('packet cap')
   print(json.dumps(c.consume(json.loads(line)),allow_nan=False),flush=True)
 finally:c.close()
