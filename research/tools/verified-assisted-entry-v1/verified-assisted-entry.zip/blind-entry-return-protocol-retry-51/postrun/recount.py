from pathlib import Path
import json,gzip,csv,math,hashlib
import numpy as np
H=Path(__file__).resolve().parent;S=H.parent;W=S.parent;R=S/'run-01/result'
r=json.loads((R/'RESULT.json').read_text());receipt=json.loads((S/'run-01/RUN_RECEIPT.json').read_text())
with np.load(R/'ACTOR_TRACE.npz')as z:t=z['trace'];cols=z['columns'].tolist()
idx={k:i for i,k in enumerate(cols)};xyz=t[:,[idx[k]for k in['x','y','z']]];states=np.vstack([r['settledStart'],xyz]);d=np.diff(states,axis=0);horizontal=np.linalg.norm(d[:,[0,2]],axis=1);three=np.linalg.norm(d,axis=1)
with gzip.open(R/'STEP_MACROS.json.gz','rt')as f:events=json.load(f)
macros={e['tick']:e for e in events};consumed={};checked=0;errors=[]
for i,row in enumerate(t):
 moved=bool(three[i]>1e-12 or abs(row[idx['yawDelta']])>1e-12)
 if not moved:continue
 source=int(row[idx['phaseSourceTick']]);event=macros.get(source)
 if not event or not event['acceptedBeforeCommit']:errors.append({'tick':i,'reason':'motion lacks accepted macro'});continue
 j=consumed.get(source,0);consumed[source]=j+1
 if j>=len(event['phases']):errors.append({'tick':i,'reason':'too many consumed phases'});continue
 p=event['phases'][j]
 if not np.allclose(states[i],p['start'],atol=1e-12,rtol=0)or not np.allclose(states[i+1],p['end'],atol=1e-12,rtol=0):errors.append({'tick':i,'reason':'phase endpoint mismatch'})
 if abs(float(row[idx['yaw']])-(p['start_yaw']+p['yaw_delta']))>1e-12:errors.append({'tick':i,'reason':'phase yaw mismatch'})
 checked+=1
stream=list(csv.DictReader((R/'ACTUAL_TRACE_STREAM.csv').open()))
stream_match=len(stream)==len(t)+1
if stream_match:
 for row,arr in zip(stream[1:],t):
  if not all(float(row[k])==float(arr[idx[k]])for k in cols):stream_match=False;break
arrivals=[]
for a in r['legTransitions']:
 row=t[a['tick']];pos=row[[idx[k]for k in['x','y','z']]];err=float(np.linalg.norm(pos-np.asarray(a['goal'])));ok=err<=.35 and row[idx['actual3DDistance']]==0 and row[idx['yawDelta']]==0 and row[idx['pendingStepPhases']]==0 and not a['pendingFIFO'] and not a['pendingMacro'];arrivals.append({'leg':a['leg'],'tick':a['tick'],'full3DErrorMetres':err,'stationaryDrainedWithinGoal':bool(ok)})
old=[]
for line in(W/'blind-known-riser-transition-49/run-01/stdout.log').read_text().splitlines():
 try:q=json.loads(line)
 except json.JSONDecodeError:continue
 if q.get('phase')=='actor_tick':old.append(q)
progress_match=all(q['tick']<len(t)and abs(t[q['tick'],idx['y']]-q['Y'])<=1e-12 and abs(float(horizontal[:q['tick']+1].sum())-q['distance'])<=1e-10 for q in old)
q={'scope':'Independent arithmetic/state-record recount, not independent geometry re-evaluation','runReceiptSuccess':receipt['success'],'states':len(t),'actualDistanceRecountMetres':float(horizontal.sum()),'actual3DDistanceRecountMetres':float(three.sum()),'reportedDistanceMatches':bool(abs(horizontal.sum()-r['actualDistanceMetres'])<1e-10),'reported3DDistanceMatches':bool(abs(three.sum()-r['actual3DDistanceMetres'])<1e-10),'maximumActual3DStepMetres':float(three.max()),'maximumActualYawDeltaRadians':float(abs(t[:,idx['yawDelta']]).max()),'actualCapsPass':bool(three.max()<=.025000001 and abs(t[:,idx['yawDelta']]).max()<=math.radians(1)+1e-10),'acceptedMacroMotionPhasesChecked':checked,'macroCommitErrors':errors,'streamExactlyMatchesFinalTrace':stream_match,'arrivalChecks':arrivals,'prior49PublishedProgressRowsChecked':len(old),'prior49ProgressMatchesUnchangedMotion':progress_match,'actualBodyContactTraceSum':int(t[:,idx['actualBodyContact']].sum()),'actualMarginContactTraceSum':int(t[:,idx['marginContact']].sum()),'actualUnderbodyContactTraceSum':int(t[:,idx['nonSillUnderbodyContact']].sum()),'entryArrival':r['entryArrival'],'returnArrival':r['returnArrival'],'finalStatus':r['status'],'physicalAuthority':False}
(H/'RECOUNT.json').write_text(json.dumps(q,indent=2)+'\n');print(json.dumps(q,indent=2))
