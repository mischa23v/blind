from pathlib import Path
import json,sys,math,hashlib,csv
import numpy as np
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
from matplotlib.patches import Polygon
H=Path(__file__).resolve().parent;S=H.parent;W=S.parent
sys.path.insert(0,str(W/'blind-polycam-varpu-executor-40'));import goal_region_map as gm
r=json.loads((S/'run-01/result/RESULT.json').read_text());p=gm.load_plan();ad=gm.load_paired();old=ad.metadata('old');new=ad.metadata('new')
with np.load(S/'run-01/result/ACTOR_TRACE.npz')as z:t=z['trace'];cols=z['columns'].tolist()
states=np.vstack((r['settledStart'],t[:,[cols.index(k)for k in ['x','y','z']]]));yaw=np.r_[p['initialYawRadians'],t[:,cols.index('yaw')]];legs=np.r_[0,t[:,cols.index('leg')].astype(int)];q,_=ad.map_objective(states,old,new);xy=q[:,[0,2]];dist=np.r_[0,np.cumsum(np.linalg.norm(np.diff(states[:,[0,2]],axis=0),axis=1))]
with(H/'ACTUAL_TRACE.csv').open('w',newline='')as f:
 w=csv.writer(f);w.writerow(['stateIndex','tickMinusOneInitial','originalGameX','originalGameY','originalGameZ','yawRadians','registeredSourceGameX','registeredSourceGameZ','cumulativeHorizontalDistanceM','leg0Entry1Return'])
 for i,s in enumerate(states):w.writerow([i,i-1,*s,yaw[i],*xy[i],dist[i],legs[i]])
with np.load(W/'blind-polycam-alignment-feasibility-36/POLYCAM_INTRINSIC_GEOMETRY.npz')as z:obj=z['verticesOBJ'];tri=z['triangles']
with np.load(W/'blind-polycam-rigid-registration-37/run-01/CANDIDATE_RIGID_TRANSFORM.npz')as z:level=obj@z['rotationOBJToLevel'].T+z['translationOBJToLevel']
v=np.c_[level[:,0],level[:,2],-level[:,1]];faces=v[tri];cent=faces.mean(1);keep=(cent[:,1]>.15)&(cent[:,1]<1.8);lines=faces[keep][:,:,[0,2]];lines=np.concatenate((lines,lines[:,:1]),axis=1)
goal,_=ad.map_objective(np.array(p['goal']),old,new);goalxy=goal[[0,2]]
fig=plt.figure(figsize=(14,8));a=fig.add_axes([.05,.2,.52,.7]);b=fig.add_axes([.62,.48,.33,.42]);c=fig.add_axes([.64,.21,.3,.18])
for ax in(a,b):
 ax.add_collection(LineCollection(lines,colors='#d3d6db',linewidths=.4));ax.set_aspect('equal');ax.grid(alpha=.15);ax.set_xlabel('Registered source X (m)');ax.set_ylabel('Registered source Z (m)')
 for leg,color,label in[(0,'#087e9a','Committed entry motion'),(1,'#d87916','Committed return motion')]:
  ids=np.flatnonzero(legs==leg)
  if len(ids):
   if leg==1 and ids[0]>0:ids=np.r_[ids[0]-1,ids]
   ax.plot(xy[ids,0],xy[ids,1],color=color,lw=2.8,label=label,zorder=4)
 ax.scatter(*xy[0],s=45,color='#176a3b',label='Initial settled pose',zorder=5);ax.scatter(*xy[-1],s=45,marker='s',color='#a52c35',label='Final committed pose',zorder=5);ax.scatter(*goalxy,s=65,marker='X',color='#7b4f9b',label='Entry goal (no connector)',zorder=5)
 cc,ss=math.cos(yaw[-1]),math.sin(yaw[-1]);local=np.array([[-.15,-.225],[.15,-.225],[.15,.225],[-.15,.225]]);px=states[-1,0]+local[:,0]*cc-local[:,1]*ss;pz=states[-1,2]+local[:,0]*ss+local[:,1]*cc;body,_=ad.map_objective(np.c_[px,np.full(4,states[-1,1]),pz],old,new);ax.add_patch(Polygon(body[:,[0,2]],fill=False,color='#174957',lw=1.5,zorder=6))
a.set_xlim(v[:,0].min()-.1,v[:,0].max()+.1);a.set_ylim(v[:,2].min()-.1,v[:,2].max()+.1);a.set_title('Whole source reconstruction; actual motion only');a.legend(fontsize=8,loc='upper left')
bounds=np.vstack((xy,goalxy));b.set_xlim(bounds[:,0].min()-.35,bounds[:,0].max()+.35);b.set_ylim(bounds[:,1].min()-.35,bounds[:,1].max()+.35);b.set_title('Doorway and requested destination')
c.plot(dist,states[:,1]*1000,color='#087e9a');c.set_xlabel('Committed horizontal distance (m)');c.set_ylabel('Foot Y (mm)');c.grid(alpha=.2)
fig.suptitle(f"Stage51: {r['actualDistanceMetres']:.3f} m committed; entry {'complete'if r['entryArrival']else'incomplete'}, return {'complete'if r['returnArrival']else'incomplete'}",weight='bold',fontsize=15)
fig.text(.05,.08,'Grey: registered original Polycam source geometry, not verified free space. Blue/orange: committed actor positions only.\nNo proposed route or failed connector is drawn. Outline: final actual45 x30cm footprint.\nThis is manually assisted evaluator-world threshold simulation, not phone-only navigation or human-safety validation.',fontsize=10)
fig.savefig(H/'ACTUAL_SOURCE_MODEL_PATH.png',dpi=150);plt.close(fig)
sha=lambda path:hashlib.sha256(Path(path).read_bytes()).hexdigest()
(H/'EXPORT_RECEIPT.json').write_text(json.dumps({'actualOnly':True,'plannedOrFailedConnectorsDrawn':False,'sourceTraceSHA256':sha(S/'run-01/result/ACTOR_TRACE.npz'),'figureSHA256':sha(H/'ACTUAL_SOURCE_MODEL_PATH.png'),'csvSHA256':sha(H/'ACTUAL_TRACE.csv'),'statesIncludingInitial':len(states),'entryArrival':r['entryArrival'],'returnArrival':r['returnArrival'],'sourceModelTransform':'frozen37 proper rigid transform; original actual game positions mapped through frozen paired18 old->new frame'},indent=2)+'\n')
