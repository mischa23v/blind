"""Exact triangle clipping to an oriented or conservatively swept footprint.
Frozen evaluator geometry only; no phone inference or scene modification.
Boundary is inclusive; numerical tolerance1e-12m applies solely to inside tests.
No positive height pad. Y is linearly interpolated at clipping intersections.
"""
import math
import numpy as np
EPS=1e-12

def clip_triangle(triangle,center,yaw,half_forward,half_lateral):
 tri=np.asarray(triangle,float);c,s=math.cos(yaw),math.sin(yaw);p=tri.copy();d=tri[:,[0,2]]-np.asarray(center)[[0,2]]
 p[:,0]=d[:,0]*c+d[:,1]*s;p[:,2]=-d[:,0]*s+d[:,1]*c
 polygon=[x.copy()for x in p]
 for axis,sign,bound in [(0,1,half_forward),(0,-1,half_forward),(2,1,half_lateral),(2,-1,half_lateral)]:
  result=[]
  if not polygon:break
  a=polygon[-1];da=sign*a[axis]-bound
  for b in polygon:
   db=sign*b[axis]-bound;ai=da<=EPS;bi=db<=EPS
   if ai!=bi:
    den=da-db
    if abs(den)>1e-30:result.append(a+(b-a)*(da/den))
   if bi:result.append(b.copy())
   a=b;da=db
  polygon=result
 if not polygon:return np.empty((0,3))
 out=np.asarray(polygon);local=out[:,[0,2]].copy();out[:,0]=center[0]+local[:,0]*c-local[:,1]*s;out[:,2]=center[2]+local[:,0]*s+local[:,1]*c
 return out

class TypedSupportEnvelope:
 def __init__(self,ids,triangles,owners=None):
  self.ids=np.asarray(ids,dtype=np.int64);self.tri=np.asarray(triangles,float);self.owners=np.full(len(self.ids),-2,np.int8)if owners is None else np.asarray(owners,np.int8)
  if self.owners.shape!=(len(self.ids),)or not np.isin(self.owners,[-2,-1,0,1]).all():raise ValueError('explicitownerindices')
  if self.tri.shape!=(len(self.ids),3,3)or not np.isfinite(self.tri).all():raise ValueError('finite3Dtriangles')
  n=np.cross(self.tri[:,1]-self.tri[:,0],self.tri[:,2]-self.tri[:,0]);length=np.linalg.norm(n,axis=1)
  if np.any(length<=1e-15)or np.any(abs(n[:,1])/length<math.cos(math.radians(45))-1e-12):raise ValueError('non-support triangle normal')
  self.lo=self.tri[:,:,[0,2]].min(axis=1);self.hi=self.tri[:,:,[0,2]].max(axis=1)
 def query(self,start,end,start_yaw,delta_yaw,planes=None):
  a=np.asarray(start,float);b=np.asarray(end,float);center=(a+b)/2;yaw=start_yaw+delta_yaw/2;c,s=math.cos(yaw),math.sin(yaw)
  d=(b-a)[[0,2]];pad=2*math.hypot(.15,.225)*math.sin(abs(delta_yaw)/4)
  hf=.15+abs(d@[c,s])/2+pad;hl=.225+abs(d@[-s,c])/2+pad
  corners=np.array([[center[0]+f*c-l*s,center[2]+f*s+l*c]for f,l in [(-hf,-hl),(hf,-hl),(hf,hl),(-hf,hl)]])
  lo=corners.min(axis=0);hi=corners.max(axis=0);candidates=np.flatnonzero(np.all(self.hi>=lo-EPS,axis=1)&np.all(self.lo<=hi+EPS,axis=1))
  hits=[];maxy=None;peak=None;cid=None;relative_min=None;relative_max=None;owner_min=None;unresolved=0;positive_area=0.;area_faces=0;maxall=None
  for i in candidates:
   clipped=clip_triangle(self.tri[i],center,yaw,hf,hl)
   if not len(clipped):continue
   hits.append(int(self.ids[i]))
   area=abs(float(np.dot(clipped[:,0],np.roll(clipped[:,2],1))-np.dot(clipped[:,2],np.roll(clipped[:,0],1))))*.5
   j=int(np.argmax(clipped[:,1]));h=float(clipped[j,1]);maxall=h if maxall is None else max(maxall,h)
   if planes is not None:
    rel=np.array([clipped[:,1]-(A*clipped[:,0]+B*clipped[:,2]+C)for A,B,C in planes]);mn=float(rel.min());mx=float(rel.max());relative_min=mn if relative_min is None else min(relative_min,mn);relative_max=mx if relative_max is None else max(relative_max,mx)
    own=int(self.owners[i])
    if own==-1:unresolved+=1
    else:
     ownlow=float(rel.min())if own==-2 else float(rel[own].min());owner_min=ownlow if owner_min is None else min(owner_min,ownlow)
   if area<=1e-12:continue # line/point bounds transit clearance, never landing height
   positive_area+=area;area_faces+=1
   if maxy is None or h>maxy:maxy=h;peak=clipped[j].tolist();cid=int(self.ids[i])
  return {'maxY':maxy,'maxYPositiveArea':maxy,'maxYAllClipped':maxall,'positiveSupportProjectedAreaSumMetres2':positive_area,'positiveAreaSupportFaces':area_faces,'areaDegeneracyToleranceMetres2':1e-12,'areaSumIsNotUnion':True,'allClippedVerticesMinRiseVsAssignedFloor':owner_min,'unresolvedOwnerIntersectedFaces':unresolved,'allClippedVerticesMinRiseVsBothPlanes':relative_min,'allClippedVerticesMaxRiseVsBothPlanes':relative_max,'peakPointOriginalGameXYZ':peak,'peakReferenceCellID':cid,'intersectedSupportFaces':len(hits),'candidateSupportFaces':len(candidates),'halfExtentsForwardLateral':[hf,hl],'midYawRadians':yaw,'rotationEnclosurePadding':pad,'exactTriangleFootprintClipping':True,'sweptFootprintConservativeForRotation':True,'numericInsideToleranceMetres':EPS,'heightPaddingMetres':0.}
