# Stage51: protocol and evidence-retention retry only

Stage49 reached the entry-arrival transition but its beginReturn acknowledgment omitted the required physicalAuthority:false field. This retry adds that explicit field only for the exact known historical return acknowledgment. The shared IPC authority validator remains unchanged and still rejects invalid responses. There is no removal or relaxation of a guard.

The movement kernel, geometry, source route, goals, body, margin, floor planes, structural annotation, support-envelope policy and collision logic remain identical to stage49. The world now writes initial settlement and flushes each committed actual trace row to CSV before any next controller call. If an exception occurs, completed positions survive; a partial stream is not a complete successful result.

The retry adds a real subprocess initialization/beginRun/beginReturn test through the strict ControllerProcess.ask wrapper, and a simulated controller-exception test proving actual trace retention. All55 fixtures pass. Same-actor entry followed by return remains the success criterion. No post-start pose reset, route repair, or extra geometry clearance is introduced.

This is still explicit manually assisted evaluator-world simulation, not automatic phone navigation or human safety evidence. Stage49 failure and all earlier variants remain unchanged. Resource limits remain4.3GiB availableRAM admission,3.5GiB sampledRSS,600CPU/900wall seconds,32MiB output,768MiB disk reserve. Full detailed evidence is lossless gzipJSON. Freeze before the bounded retry; no run edits.
