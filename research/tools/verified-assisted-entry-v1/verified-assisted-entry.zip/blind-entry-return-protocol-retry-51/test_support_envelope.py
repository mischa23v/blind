import unittest,math
import numpy as np
from support_envelope import TypedSupportEnvelope,clip_triangle
from step_kernel import build_macro

def q(y,typed=True):return {'accepted':True,'hitCount':9,'missingCount':0,'footHeight':y,'typedSill':typed}
class Tests(unittest.TestCase):
 def test_interior_crest_missed_by_nine_probes(self):
  t=np.array([[[.04,.02,.04],[.05,.02,.04],[.045,.02,.05]]]);e=TypedSupportEnvelope([1],t);r=e.query([0,0,0],[0,0,0],0,0)
  self.assertAlmostEqual(r['maxY'],.02);self.assertEqual(r['peakReferenceCellID'],1)
 def test_outside_tall_vertex_clipped_with_interpolated_height(self):
  t=np.array([[[0,0,-.1],[.3,.03,0],[0,0,.1]]]);e=TypedSupportEnvelope([1],t);r=e.query([0,0,0],[0,0,0],0,0)
  self.assertAlmostEqual(r['maxY'],.015,places=12)
 def test_whole_triangle_outside_not_support(self):
  e=TypedSupportEnvelope([1],[[[.3,.02,0],[.4,.02,0],[.3,.02,.1]]]);self.assertIsNone(e.query([0,0,0],[0,0,0],0,0)['maxY'])
 def test_rotation_enclosure_keeps_intermediate_corner(self):
  a=math.atan2(.225,.15)-math.radians(.5);d=math.radians(1);x=math.hypot(.15,.225)-1e-6
  e=TypedSupportEnvelope([1],[[[x,.02,-3e-6],[x+1e-6,.02,0],[x,.02,3e-6]]]);r=e.query([0,0,0],[0,0,0],a,d)
  self.assertIsNotNone(r['maxY']);self.assertIsNone(e.query([0,0,0],[0,0,0],a,0)['maxY']);self.assertIsNone(e.query([0,0,0],[0,0,0],a+d,0)['maxY'])
 def test_sub2mm_transit_crest_explicit_up_side_down(self):
  phases,_=build_macro([0,.02,0],[.02,.02,0],0,0,q(.0205),q(.019),0,current_sill=True)
  self.assertEqual([p.kind for p in phases],['UP','SIDE','DOWN']);self.assertAlmostEqual(phases[1].start[1],.0205);self.assertAlmostEqual(phases[1].end[1],.0205);self.assertAlmostEqual(phases[-1].end[1],.019)
 def test_degenerate_vertical_support_rejected(self):
  with self.assertRaises(ValueError):TypedSupportEnvelope([1],[[[0,0,0],[0,.02,0],[0,.01,.1]]])
 def test_relative_rise_uses_all_clipped_vertices(self):
  e=TypedSupportEnvelope([1],[[[-.1,.02,-.1],[.1,.021,0],[-.1,.02,.1]]]);r=e.query([0,0,0],[0,0,0],0,0,planes=[[.1,0,0],[.1,0,0]])
  self.assertAlmostEqual(r['maxY'],.021);self.assertAlmostEqual(r['allClippedVerticesMaxRiseVsBothPlanes'],.03);self.assertAlmostEqual(r['allClippedVerticesMinRiseVsBothPlanes'],.011)
 def test_owner_floor_not_whichever_plane_passes(self):
  tri=[[[0,0,0],[.1,0,0],[0,0,.1]]]
  e=TypedSupportEnvelope([1],tri,owners=[0]);r=e.query([0,0,0],[0,0,0],0,0,planes=[[0,0,0],[0,0,.003]])
  self.assertAlmostEqual(r['allClippedVerticesMinRiseVsBothPlanes'],-.003);self.assertAlmostEqual(r['allClippedVerticesMinRiseVsAssignedFloor'],0.)
  e=TypedSupportEnvelope([1],tri,owners=[1]);r=e.query([0,0,0],[0,0,0],0,0,planes=[[0,0,0],[0,0,.003]])
  self.assertAlmostEqual(r['allClippedVerticesMinRiseVsAssignedFloor'],-.003)
 def test_unknown_owner_retained_as_unresolved(self):
  e=TypedSupportEnvelope([1],[[[0,0,0],[.1,0,0],[0,0,.1]]],owners=[-1]);r=e.query([0,0,0],[0,0,0],0,0,planes=[[0,0,0],[0,0,0]])
  self.assertEqual(r['unresolvedOwnerIntersectedFaces'],1);self.assertIsNone(r['allClippedVerticesMinRiseVsAssignedFloor'])
 def test_tangent_has_no_positive_landing_area(self):
  e=TypedSupportEnvelope([1],[[[.15,.02,-.1],[.2,.02,0],[.15,.02,.1]]]);r=e.query([0,0,0],[0,0,0],0,0)
  self.assertEqual(r['positiveAreaSupportFaces'],0);self.assertEqual(r['positiveSupportProjectedAreaSumMetres2'],0.)
 def test_yaw_transform_equivariance(self):
  tri=np.array([[.04,.02,.04],[.05,.02,.04],[.045,.02,.05]]);yaw=.7;c,s=math.cos(yaw),math.sin(yaw);r=tri.copy();r[:,0]=tri[:,0]*c-tri[:,2]*s+2;r[:,2]=tri[:,0]*s+tri[:,2]*c+3
  out=clip_triangle(r,[2,0,3],yaw,.15,.225);self.assertEqual(len(out),3);self.assertAlmostEqual(out[:,1].max(),.02)
if __name__=='__main__':unittest.main(verbosity=2)
