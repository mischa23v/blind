import unittest,tempfile,csv
from pathlib import Path
from unittest.mock import patch
import step_world as w
class Tests(unittest.TestCase):
 def test_real_subprocess_return_ack_passes_strict_boundary(self):
  plan=w.legacy.load_plan()
  with tempfile.TemporaryDirectory()as d:
   c=w.ControllerProcess(Path(d))
   try:
    c.ask({'command':'beginRun','goal':plan['goal']});r=c.ask({'command':'beginReturn','goal':plan['start']})
    self.assertIs(r['physicalAuthority'],False);self.assertTrue(r['noReset']);self.assertEqual(r['status'],'sameActorReturn')
   finally:c.close()
 def test_committed_trace_survives_controller_exception(self):
  class Collider:
   optimization_rows=[]
   def swept_contacts(self,*args):return {'actualBody':{'contact':False},'horizontalMargin':{'contact':False}}
  class World:
   body=Collider();guard=Collider()
   def support(self,*args):return {'accepted':True,'hitCount':9,'missingCount':0,'typedSill':False,'footHeight':0.}
   def body_collision(self,p):return {'contact':False}
   def underbody_collision(self,p):return {'contact':False}
  class Process:
   initial={'mapRevision':'fixture'}
   def __init__(self,*args):pass
   def ask(self,p):
    if p.get('tick')==1:raise RuntimeError('fixture interruption')
    return {'forwardMetres':.02,'yawRadians':0.,'sourceCapturedAt':100.,'reason':'fixture','goalReached':False}
   def close(self):pass
  with tempfile.TemporaryDirectory()as d,patch.object(w,'ControllerProcess',Process):
   with self.assertRaisesRegex(RuntimeError,'fixture interruption'):w.episode({'start':[0.,0.,0.],'goal':[2.,0.,0.],'initialYawRadians':0.,'profile':'fixture','geometry':{}},World(),Path(d))
   rows=list(csv.DictReader((Path(d)/'ACTUAL_TRACE_STREAM.csv').open()));self.assertEqual(len(rows),2);self.assertEqual(rows[-1]['tick'],'0');self.assertAlmostEqual(float(rows[-1]['x']),.02);self.assertTrue((Path(d)/'INITIAL_SETTLEMENT.json').exists())
if __name__=='__main__':unittest.main(verbosity=2)
