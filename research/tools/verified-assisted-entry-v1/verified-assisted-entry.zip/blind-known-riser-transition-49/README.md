# Stage49: entry-transition protocol failure, no complete saved journey

The bounded run advanced through the threshold and logged 4.256166 metres of committed movement at tick255. It subsequently entered the entry-arrival branch and attempted beginReturn, but the shared IPC validator rejected the acknowledgment because the historical controller omitted physicalAuthority:false. The strict boundary check was correct and was not disabled.

The process failed before serializing its terminal trajectory and result. Therefore this packet does NOT establish a fully verified entry arrival or return. Do not infer completed distance, zero-contact totals, or a successful journey from the progress log alone. The original frozen inputs, logs and failed execution receipt are retained. The run ended after183.28 wall seconds,185.02 CPU seconds and2.15GiB peak RSS, within its resource limits.

Stage51 is a separate protocol/reporting-only retry: restore the required explicit simulation-authority field in the return acknowledgment, retain the strict IPC validator, and flush each actual trace row to disk so an exception cannot discard completed positions. It must preserve the same geometry, source path, body, movement/support policy and collision guards. Stage49's 53 fixtures did not exercise the real subprocess beginReturn packet; the retry must add that regression.

This remains a manually assisted evaluator-world simulation, not automatic phone navigation or human-safety validation. See PROTOCOL.md, FROZEN.json and run-01/RUN_RECEIPT.json.
