"""Explicit assisted structural-step world. Frozen source corners; no route choice.
Sill triangles remain in full-body collision. Additional underbody guard alone
allows the exact frozen structural sill, never arbitrary low objects.
"""
from pathlib import Path
import sys,json,math,hashlib,selectors,subprocess,gzip
from dataclasses import asdict
from collections import deque
import numpy as np
from step_kernel import build_macro,validate_macro,StepRejected
H=Path(__file__).resolve().parent;W=H.parent;S=W/'blind-polycam-varpu-executor-40';sys.path.insert(0,str(S))
import run_north as legacy
from oriented_container import sweep_enclosure
motion=legacy.motion
class ControllerProcess(motion.ControllerProcess):
 def __init__(self,out):
  self.err=(Path(out)/'controller.stderr.log').open('x');self.p=subprocess.Popen([sys.executable,str(H/'step_controller.py')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=self.err,text=True,bufsize=1);self.selector=selectors.DefaultSelector();self.selector.register(self.p.stdout,selectors.EVENT_READ)
  try:self.initial=self.ask({'command':'initialize','planPath':str(legacy.PLAN),'planSHA256':legacy.PLAN_SHA})
  except BaseException:self.close();raise

def dump_evidence(path,value):
 with gzip.open(str(path)+'.gz','wt',encoding='utf-8')as f:json.dump(value,f,separators=(',',':'),allow_nan=False)

def contains(ids,value):
 i=int(np.searchsorted(ids,int(value)));return i<len(ids)and int(ids[i])==int(value)
def frozen_ground(base,ids,receipt,plane):
 a=np.array(np.unique(ids),np.int64,copy=True);a.setflags(write=False);t=np.array(base.transform,copy=True);t.setflags(write=False);p=np.asarray(plane,float).copy();p.setflags(write=False)
 return motion.GroundSupport(a,receipt,base.surface,base.mesh,int(base.mesh.GetMTime()),t,p)
class AssistedWorld:
 def __init__(self,base,red,gray,top,risers,red_plane,gray_plane,ramps=(),support_envelope=None,ramp_owners=None,floor_envelope=None):
  self.base=base;self.red=np.asarray(red);self.gray=np.asarray(gray);self.top=np.asarray(top);self.risers=np.asarray(risers);self.ramps=np.asarray(ramps,dtype=np.int64);self.planes=[np.asarray(red_plane),np.asarray(gray_plane)]
  floors=np.union1d(red,gray);structural=np.union1d(top,risers)
  self.body_ground=frozen_ground(base,floors,{'scope':'two separately anchored floor components only; sill NOT removed from body collision'},red_plane)
  self.guard_ground=frozen_ground(base,np.union1d(floors,structural),{'scope':'extra underbody guard only: floor+exact assisted sill; every non-sill face retained'},red_plane)
  self.envelope=support_envelope;self.floor_envelope=floor_envelope;self.ramp_owners={}if ramp_owners is None else dict(ramp_owners)
  self.ramp_slopes={}
  self.body=motion.GroundTiledReferenceContainer(base.surface,base.transform,ground=self.body_ground,body=base.body)
  self.guard=motion.GroundTiledReferenceContainer(base.surface,base.transform,ground=self.guard_ground,body=base.body)
 def ramp_slope(self,cid):
  if cid not in self.ramp_slopes:
   cell=self.base.mesh.GetCell(int(cid));pts=np.array([cell.GetPoints().GetPoint(i)for i in range(3)])
   p=pts@self.base.inverse[:3,:3].T+self.base.inverse[:3,3];n=np.cross(p[1]-p[0],p[2]-p[0]);length=np.linalg.norm(n)
   self.ramp_slopes[cid]=math.degrees(math.acos(float(np.clip(abs(n[1])/length,0,1))))if length>1e-15 else math.inf
  return self.ramp_slopes[cid]
 def support(self,pos,yaw):
  raw=self.base.support_probes(pos,yaw);heights=[];rawh=[];types=[];unknown=[];cap_failure=[]
  for row in raw['probes']:
   if not row['hit']:continue
   cid=row['referenceCellID'];x,z=row['modelXZ'];h=row['modelHeightY'];rawh.append(h)
   k=0 if contains(self.red,cid)else(1 if contains(self.gray,cid)else None)
   if k is not None:
    a,b,c=self.planes[k];ph=float(a*x+b*z+c);types.append('redFloor'if k==0 else'grayFloor');heights.append(ph)
    if abs(h-ph)>.02:cap_failure.append({'cell':cid,'floorPlaneResidual':h-ph})
   elif contains(self.top,cid)or contains(self.ramps,cid):
    types.append('typedSillTop'if contains(self.top,cid)else'typedSillRamp')
    if getattr(self,'envelope',None)is None:heights.append(h)
    if contains(self.ramps,cid):
     slope=self.ramp_slope(cid)
     if not math.isfinite(slope)or slope>45.+1e-10:cap_failure.append({'cell':cid,'rampSlopeDegrees':slope})
    # Relative to BOTH adjacent frozen planes, not arbitrary globalY.
    differences=[h-(a*x+b*z+c)for a,b,c in self.planes]
    owner=self.ramp_owners.get(int(cid),-1)if contains(self.ramps,cid)else -2
    lower=min(differences)if owner==-2 else(differences[owner]if owner in(0,1)else 0.)
    if owner==-1 or lower<-.002 or max(differences)>.025+1e-10:cap_failure.append({'cell':cid,'sillRiseVsAdjacentFloors':differences,'assignedLowerBoundOwner':owner})
   elif contains(self.risers,cid):
    types.append('knownStructuralRiser') # observed geometry only, NEVER a support-height contributor
   else:unknown.append(int(cid));types.append('untyped');heights.append(h)
  typed=bool('typedSillTop'in types or'typedSillRamp'in types or'knownStructuralRiser'in types);span=max(rawh)-min(rawh)if rawh else None;limit=.025 if typed or len(set(types))>1 else .02
  accepted=raw['hitCount']==9 and not unknown and not cap_failure and span is not None and span<=limit+1e-10
  receipt={'accepted':bool(accepted),'hitCount':raw['hitCount'],'missingCount':raw['missingCount'],'typedSill':typed,'footHeight':max(heights)if heights else None,'rawSpreadMetres':span,'spreadLimitMetres':limit,'supportTypes':types,'untypedHitIDs':unknown,'capFailures':cap_failure,'rawProbes':raw,'continuousSupportProven':False,'knownStructuralRiserHitCount':types.count('knownStructuralRiser'),'riserSuppliesSupportHeight':False}
  return self.apply_envelope(receipt,pos,pos,yaw,0.)
 def apply_envelope(self,receipt,start,end,yaw,dyaw,transit=False):
  if getattr(self,'envelope',None)is None:
   if receipt.get('knownStructuralRiserHitCount',0):receipt['accepted']=False;receipt['capFailures']+=[{'knownRiserWithoutLandingEnvelope':True}]
   return receipt
  env=self.envelope.query(start,end,yaw,dyaw,planes=self.planes);receipt=dict(receipt);receipt['typedSupportEnvelope']=env
  height=env['maxYAllClipped']if transit else env['maxYPositiveArea'];receipt['envelopeUsedForTransitOnly']=bool(transit)
  if env['maxYAllClipped']is not None:
   diff=[env['allClippedVerticesMinRiseVsAssignedFloor'],env['allClippedVerticesMaxRiseVsBothPlanes']]
   if env['unresolvedOwnerIntersectedFaces']:receipt['accepted']=False;receipt['capFailures']+=[{'unknownRampOwnerFaces':env['unresolvedOwnerIntersectedFaces']}]
   if diff[0]is None:diff[0]=0.
   if any(v<-.002 or v>.025+1e-10 for v in diff):receipt['accepted']=False;receipt['capFailures']+= [{'envelopeRiseVsBothFloors':diff}]
   if height is not None:receipt['footHeight']=max(receipt['footHeight'],height)if receipt['footHeight']is not None else height;receipt['typedSill']=True
  if receipt.get('knownStructuralRiserHitCount',0):
   floorenv=self.floor_envelope.query(start,end,yaw,dyaw,planes=self.planes)if getattr(self,'floor_envelope',None)is not None else None
   receipt['knownFloorLandingArea']=floorenv
   area=env['positiveSupportProjectedAreaSumMetres2']+(floorenv['positiveSupportProjectedAreaSumMetres2']if floorenv is not None else 0.)
   if area<=1e-12 or receipt['footHeight']is None:
    receipt['accepted']=False;receipt['capFailures']+=[{'knownRiserButNoPositiveAreaLandingOrHeight':True}]
  if receipt['footHeight']is None:receipt['accepted']=False;receipt['capFailures']+=[{'noPositiveAreaHeightContributor':True}]
  return receipt
 def body_collision(self,p):
  a=np.asarray(p.start);b=np.asarray(p.end);m=(a+b)/2;parts=[]
  for aa,bb,y,dy in [(a,m,p.start_yaw,p.yaw_delta/2),(m,b,p.start_yaw+p.yaw_delta/2,p.yaw_delta/2)]:
   r=self.body.swept_contacts(aa,bb,y,dy);parts.append(r)
   if r['actualBody']['contact']or r['horizontalMargin']['contact']:return {'contact':True,'parts':parts}
  return {'contact':False,'parts':parts}
 def underbody_collision(self,p):
  a=np.asarray(p.start).copy();b=np.asarray(p.end).copy()
  footprint,_=sweep_enclosure(a,b,p.start_yaw,p.yaw_delta,half_forward=.15,half_lateral=.225,height=.002,floor_contact_exclusion=0.)
  low=min(A*x+B*z+C for A,B,C in self.planes for x,_,z in footprint)
  top=max(a[1],b[1])+.002;a[1]=b[1]=low
  corners,_=sweep_enclosure(a,b,p.start_yaw,p.yaw_delta,half_forward=.15,half_lateral=.225,height=max(.002,top-low),floor_contact_exclusion=0.)
  r=self.guard.contact_corners(corners);return {'contact':bool(r['contact']),'raw':r,'guardBottomY':low,'guardTopY':top,'onlyExactStructuralSillExempted':True}

def episode(plan,world,out):
 state=np.asarray(plan['start'],float);goal=np.asarray(plan['goal'],float);yaw=float(plan['initialYawRadians']);initial=world.support(state,yaw)
 result={'scope':'Assisted manual structural-sill stepping benchmark; not automatic phone perception, native Jolt/PhysX, measured human/child capability or safety','profile':plan['profile'],'geometry':plan['geometry'],'arrival':False,'entryArrival':False,'returnArrival':False,'motionExecuted':False,'physicalAuthority':False,'actualDistanceMetres':0.,'actual3DDistanceMetres':0.,'actualBodyContactEvents':0,'marginContactEvents':0,'nonSillUnderbodyContactEvents':0,'rejectedPredictedBodyContactEvents':0,'rejectedPredictedMarginContactEvents':0,'rejectedPredictedUnderbodyContactEvents':0,'initialSupport':initial,'goal':goal.tolist(),'start':state.tolist(),'supportTrianglesNotRemovedFromBodyCollision':True,'assumedStructuralStepCapMetres':.025,'groundContactMeasurement':'unmeasured, floor IDs exempted as in prior scorer; sill remains full-body collider'}
 if not initial['accepted']:return {**result,'status':'initialIndependentSupportRejected','ticks':0}
 state[1]=initial['footHeight'];result['settledStart']=state.tolist();result['initialVerticalSettlementMetres']=float(state[1]-plan['start'][1]);result['initialSettlementBeforeMovementTrace']=True;result['noPoseResetAfterInitialSettlement']=True;start=state.copy();leg_start=state.copy();leg_distance=0.;distance=0.;distance3d=0.;attempted=0.;leg=0;transitions=[];trace=[];events=[];exposures=[];queue=deque();macro_support=None;current_support=initial;stationary=0;status='timeout';flagged=0
 # Full initial body check retains every sill face.
 init=world.body.swept_contacts(state,state,yaw,0.);result['initialContacts']=init
 if init['actualBody']['contact']or init['horizontalMargin']['contact']:return {**result,'status':'initialBodyContact','ticks':0,'actualBodyContactEvents':int(init['actualBody']['contact']),'marginContactEvents':int(init['horizontalMargin']['contact'])}
 controller=ControllerProcess(out);actor=motion.ActorFIFO(motion.ActorProfile());revision=controller.initial['mapRevision'];last={}
 try:
  controller.ask({'command':'beginRun','goal':goal.tolist()})
  for tick in range(1000):
   now=100+tick/15;before=state.copy();byaw=yaw;busy=bool(queue);pose={'kind':'simulated-physics-body-pose','position':state.tolist(),'yaw':yaw,'capturedAt':now,'mapRevision':revision}
   cue=controller.ask({'command':'tick','tick':tick,'now':now,'deliveredPose':pose,'actuatorBusy':busy});command=motion.ActorCommand(cue['forwardMetres'],cue['yawRadians'],tick,cue['sourceCapturedAt'],cue['reason']);applied=actor.step(tick,command);attempted+=abs(applied.forward_metres)
   if busy and (applied.forward_metres or applied.yaw_radians):raise RuntimeError('new horizontal command while step macro pending')
   macro_event=None;phase_kind='IDLE';source_tick=tick;actual_contact=False;margin_contact=False;under_contact=False
   if not busy and (applied.forward_metres or applied.yaw_radians):
    proposed=state.copy();pyaw=yaw+applied.yaw_radians;proposed[[0,2]]+=[math.cos(pyaw)*applied.forward_metres,math.sin(pyaw)*applied.forward_metres]
    mid=world.support((state+proposed)/2,yaw+applied.yaw_radians/2);end=world.support(proposed,pyaw)
    if hasattr(world,'apply_envelope'):mid=world.apply_envelope(mid,state,proposed,yaw,applied.yaw_radians,transit=True)
    try:
     phases,policy=build_macro(state,proposed,yaw,applied.yaw_radians,mid,end,tick,current_sill=current_support['typedSill'])
     use_guard=bool(current_support['typedSill']or mid['typedSill']or end['typedSill']or policy['typedStructuralTransition'])
     evidence=validate_macro(phases,world.body_collision,world.underbody_collision if use_guard else lambda p:{'contact':False,'reason':'outsideTypedTransitionBaselineCollisionOnly'})
     macro_event={'tick':tick,'acceptedBeforeCommit':True,'policy':policy,'supportMid':mid,'supportEnd':end,'phases':[asdict(x)for x in phases],'collisionEvidence':evidence};queue.extend(phases);macro_support=end
    except StepRejected as e:
     status='assistedStepRejected:'+e.reason;macro_event={'tick':tick,'acceptedBeforeCommit':False,'reason':e.reason,'details':e.details,'supportMid':mid,'supportEnd':end,'stateWasNotCommitted':True}
     under_contact=e.reason=='non_sill_underbody_collision'
     if e.reason=='body_or_head_or_side_collision':
      parts=e.details['collision']['parts'];actual_contact=any(x['actualBody']['contact']for x in parts);margin_contact=any(x['horizontalMargin']['contact']for x in parts)
     result['rejectedPredictedBodyContactEvents']+=int(actual_contact);result['rejectedPredictedMarginContactEvents']+=int(margin_contact);result['rejectedPredictedUnderbodyContactEvents']+=int(under_contact)
     macro_event['predictedRejectedContacts']={'body':actual_contact,'margin':margin_contact,'underbody':under_contact}
     actual_contact=False;margin_contact=False;under_contact=False
    events.append(macro_event)
   if status=='timeout'and queue:
    ph=queue.popleft();np.testing.assert_allclose(state,ph.start,atol=1e-12,rtol=0)
    if abs(yaw-ph.start_yaw)>1e-10:raise RuntimeError('queued yaw discontinuity')
    state=np.asarray(ph.end,float);yaw=ph.start_yaw+ph.yaw_delta;phase_kind=ph.kind;source_tick=ph.source_tick;distance+=float(np.linalg.norm((state-before)[[0,2]]));leg_distance+=float(np.linalg.norm((state-before)[[0,2]]));distance3d+=ph.length;result['motionExecuted']=True
    if not queue:current_support=macro_support
   moved=bool(np.linalg.norm(state-before)>1e-12 or abs(yaw-byaw)>1e-12);pending=bool(queue)or any(c.forward_metres or c.yaw_radians for _,c in actor.pending)
   if np.linalg.norm(state-before)>.025000001 or abs(yaw-byaw)>math.radians(1)+1e-10:raise RuntimeError('actual3D/yaw tick cap')
   error=float(np.linalg.norm((state-goal)[[0,2]]));full=float(np.linalg.norm(state-goal));arrival=bool(cue['goalReached']and not moved and not pending and error<=.35 and full<=.35 and leg_distance>0 and leg_distance>=max(0,float(np.linalg.norm((leg_start-goal)[[0,2]]))-.35))
   if arrival:
    transitions.append({'leg':leg,'tick':tick,'time':now,'position':state.tolist(),'yaw':yaw,'goal':goal.tolist(),'full3DGoalErrorMetres':full,'legDistanceMetres':leg_distance,'totalDistanceMetres':distance,'pendingMacro':False,'pendingFIFO':False,'actualMotion':False})
    if leg==0:result['entryArrival']=True;status='entryArrivedContinueReturn'
    else:result['returnArrival']=True;result['arrival']=True;status='entryAndReturnArrivalAssistedThresholdModelOnly'
   low=cue.get('phoneFlagReceipt',{}).get('lowUnresolvedCells',-1);flagged+=low>0;exposures.append({'tick':tick,'leg':leg,'current':cue.get('phoneFlagReceipt'),'proposed':cue.get('proposedPhoneFlagReceipt')})
   trace.append([tick,now,*state,yaw,float(np.linalg.norm((state-before)[[0,2]])),yaw-byaw,error,int(actual_contact),int(margin_contact),low,leg,int(busy),len(queue),source_tick,state[1]-before[1],float(np.linalg.norm(state-before)),int(under_contact)])
   last={'cue':cue,'appliedCommand':asdict(applied),'phase':phase_kind,'phaseSourceTick':source_tick,'pendingStepPhases':len(queue),'pendingMotion':pending,'support':current_support,'macroEvent':macro_event,'actualGoalErrorMetres':error,'actualFull3DGoalErrorMetres':full}
   stationary=0 if moved else stationary+1
   if stationary>=150 and not pending and not arrival:status='deadlockNoMotion'
   if tick%15==0:print(json.dumps({'phase':'actor_tick','tick':tick,'leg':leg,'distance':distance,'Y':state[1],'stepPhase':phase_kind,'pendingStepPhases':len(queue),'status':status}),flush=True)
   if status=='entryArrivedContinueReturn':
    goal=np.asarray(plan['start'],float);leg=1;leg_start=state.copy();leg_distance=0.;stationary=0;controller.ask({'command':'beginReturn','goal':goal.tolist()});status='timeout'
   elif status!='timeout':break
 finally:controller.close()
 np.savez_compressed(out/'ACTOR_TRACE.npz',trace=np.asarray(trace),columns=np.asarray(['tick','time','x','y','z','yaw','forward','yawDelta','goalError','actualBodyContact','marginContact','currentLowUnresolvedCells','leg','actuatorBusyAtTickStart','pendingStepPhases','phaseSourceTick','actualDeltaY','actual3DDistance','nonSillUnderbodyContact']))
 dump_evidence(out/'STEP_MACROS.json',events);dump_evidence(out/'PHONE_FOOTPRINT_EXPOSURES.json',exposures);dump_evidence(out/'BODY_QUERY_OPTIMIZATION.json',world.body.optimization_rows);dump_evidence(out/'UNDERBODY_QUERY_OPTIMIZATION.json',world.guard.optimization_rows)
 result.update(status=status,ticks=tick+1,actualDistanceMetres=distance,actual3DDistanceMetres=distance3d,attemptedHorizontalDistanceMetres=attempted,finalPosition=state.tolist(),finalYawRadians=yaw,goalErrorMetres=last['actualGoalErrorMetres'],terminal=last,legTransitions=transitions,ticksWithSampledLowUnresolvedExposure=flagged,traceSHA256=motion.sha(out/'ACTOR_TRACE.npz'),detailedEvidenceEncoding='lossless UTF8 JSON gzip, no evidence fields removed',exactTypedSupportEnvelope=True,queuedStepCommandSemanticsChanged=True,sourceHorizontalRouteUnchanged=True)
 return result
