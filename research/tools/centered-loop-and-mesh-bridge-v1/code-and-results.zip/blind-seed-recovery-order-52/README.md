# Seed-recovery ordering correction: all five loop memberships admitted

This is **membership preparation only; no movement was executed**. It preserves the failed stage50 result.

Stage50 required every one of nine initial floor triangles to satisfy the 5° training rule before local recovery could run. One original tiny seed triangle (5684633) has a 5.3315° normal but only 0.3225mm height variation. Stage52 lets the coherent eligible original seed subset bootstrap the unchanged local fits, then requires **all nine original seeds** to pass unchanged recovery and connectivity. It does not move the start, remove geometry, widen the 2mm residual rule or alter the 45° raw-normal guard.

Ten fixtures independently passed, including unchanged all-eligible behavior, rejection of raised objects, disconnected seeds and rank-deficient training. The pre-run manifest is `MEMBERSHIP_FROZEN.json` (`66a4cbd16f8a82747d99e4c1c75faaefed8a3af721f7973f6dce507bf1fbc297`).

All five original source-derived leg memberships completed:

| Leg | Retained support triangles | Wall seconds |
|---|---:|---:|
|0|555,862|21.65|
|1|801,739|27.03|
|2|464,207|18.94|
|3|679,229|23.69|
|4|1,023,067|31.11|

Leg0 used the original eight eligible seeds for training and recovered original seed5684633 afterward. Other legs had all nine eligible seeds. Peak process RSS was3.07GB. `SUMMARY.json` lists the immutable receipts and array checksums; per-leg JSON receipts retain full training provenance and fit diagnostics. The verbose retained receipts exceeded the initial5MiB preparation target; no evidence was deleted or compressed away from its frozen identity.

## Limits

These are evaluator-assisted reference-mesh support labels, **not phone sensor detections or clearance proof**. The fixed reused47/48 datum remains about16mm above raw floor at the initial start; classifying floor does not remove that discrepancy. Stage53 separately adds a full-footprint nonground underbody guard before any movement so small objects below the rigid body's foot plane are not silently skipped. Stage52 alone does not establish a navigable lap.
