from pathlib import Path
import json,struct,math,hashlib,numpy as np
H=Path(__file__).resolve().parent;P=H.parent;W=P.parent
r=json.loads((P/'run-01/result/RESULT.json').read_text());g=json.loads((W/'blind-seed-recovery-order-52/membership-leg1/RESULT.json').read_text())['groundReceipt'];mesh=W/'blind-koivu-faro-acquisition-04/selected-reference/gt_mesh.ply'
with np.load(W/'blind-split-candidate-game-03/inputs/koivu_5cm_v2_pipeline2_out.npz')as z:R=z['R'];t=z['t']
A=np.array(json.loads((W/'blind-koivu-faro-acquisition-04/selected-reference/icp_iphone.json').read_text())['gt_transformation']);B=np.array([[1.,0,0],[0,0,-1],[0,1,0]]);M=np.eye(4);M[:3,:3]=R.T@B;M[:3,3]=-R.T@t;T=A@M;I=np.linalg.inv(T);rows=[]
with mesh.open('rb')as f:
 header=b''
 while not header.endswith(b'end_header\n'):header+=f.readline()
 assert b'element vertex 8940320\n'in header and b'property list uchar uint vertex_indices\n'in header
 for cid in r['terminal']['support'][0]['nonGroundProbeCellIDs']:
  f.seek(len(header)+8940320*48+cid*13);n,*ids=struct.unpack('<BIII',f.read(13));assert n==3;ref=[]
  for v in ids:f.seek(len(header)+v*48);ref.append(struct.unpack('<ddd',f.read(24)))
  ref=np.array(ref);q=ref.astype(np.float32).astype(float)@I[:3,:3].T+I[:3,3];normal=np.cross(q[1]-q[0],q[2]-q[0]);normal/=np.linalg.norm(normal);slope=math.degrees(math.acos(np.clip(abs(normal[1]),0,1)));tile=np.floor(q[:,[0,2]].mean(0)/.1).astype(int).tolist();fit=next(x for x in g['patchFits']if x['tile']==tile);plane=np.array(fit['planeYEqualsAXPlusBZPlusC']);res=q[:,1]-(plane[0]*q[:,0]+plane[1]*q[:,2]+plane[2]);mem=[]
  for i in range(5):
   with np.load(W/f'blind-seed-recovery-order-52/membership-leg{i}/GROUND_IDS.npz')as z:mem.append(bool(np.isin(cid,z['groundIDs'])))
  rows.append({'referenceCellID':cid,'vertexIDs':ids,'referenceVerticesDouble':ref.tolist(),'verticesOriginalGameXYZ':q.tolist(),'centroidOriginalGameXYZ':q.mean(0).tolist(),'slopeDegrees':slope,'passes5DegreeTrainingNormal':slope<=5,'passes45DegreeRawGuard':slope<=45,'triangleXYZExtentMetres':np.ptp(q,axis=0).tolist(),'tile':tile,'frozenLocalPatchFit':fit,'localPatchVertexResidualsMetres':res.tolist(),'maximumAbsoluteLocalResidualMetres':float(abs(res).max()),'passes2mmRecoveryResidual':bool(abs(res).max()<=.002),'membershipInLeg0Through4':mem,'cause':'not eligible training normal; outside unchanged2mm local recovery residual'if slope>5 and abs(res).max()>.002 else'additional connectivity examination required'})
o={'scope':'post-terminal direct original PLY seek and frozen local-fit arithmetic; no reclassification or geometry change','status':r['status'],'actualDistanceMetres':r['actualDistanceMetres'],'supportFailure':r['terminal']['support'],'rows':rows,'referenceTransformSHA256':hashlib.sha256(T.tobytes()).hexdigest(),'routeOrPoliciesChanged':False};(H/'TERMINAL_FACE_DIAGNOSIS.json').write_text(json.dumps(o,indent=2)+'\n');print(json.dumps(o,indent=2))
