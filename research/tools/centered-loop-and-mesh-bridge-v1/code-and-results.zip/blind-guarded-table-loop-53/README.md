# Guarded table-loop attempt:3.640m, one leg reached, incomplete

The same45×30×160cm actor with zero horizontal margin moved3.640m in the frozen source-proposed loop. It reached the first original goal at2.740m, stopped with its motion queue drained, passed both old/new support-membership checks at the unchanged actual pose, and continued into leg1. No actor reset, waypoint change or reference-based steering was used.

It stopped at tick227 before committing a proposed2cm step because reference triangle921994 was absent from the frozen floor membership. **This is not a completed table loop, a collision, or evidence that the room is too narrow.**

| Measure | Result |
|---|---:|
|Completed original goals|1of5|
|Completed laps|0|
|Committed horizontal distance|3.640m|
|Committed3D distance|3.640191m|
|Actual body contacts|0|
|Rejected predicted body/underbody contacts|0/0|
|Terminal support rays hit|9of9|
|Terminal probe height spread|1.308mm|
|Wall/CPU time|76.02/76.66s|
|Peak treeRSS|2.268GB|

The support gate rejected before collision testing of the last candidate; zero contacts does not establish that this rejected candidate was clear.

## Exact blocker

`diagnosis/TERMINAL_FACE_DIAGNOSIS.json` reads original PLY triangle vertices directly (with the same float32 quantization as the runtime), without reloading the full mesh or changing classification:

- Face921994 spans4.334×7.254mm horizontally and3.128mm vertically.
- Its tiny-triangle normal is44.298°, so it is not training floor under the frozen5° rule.
- It passes the45° raw-normal recovery guard, but its maximum residual to the frozen local patch is3.235mm, above the unchanged2mm recovery limit.
- Its local fit used535 training points, with0.101mm median residual.
- It is absent from all five leg memberships, not merely lost at a cache boundary.

The source RGB/depth association overlays show this position near a chair base. They do **not** resolve whether the millimetric reference facet is carpet texture, reconstruction error or a furniture-related confound. We did not relabel it floor or increase a threshold to make this attempt pass.

## Reproduction and evidence

Frozen manifest `FROZEN.json`: `d6645904b5cc5b017aa9bb1ab60becc430f9fb01c1ff651ee8bf969838ad4e22`.

```
OPENBLAS_NUM_THREADS=1 python blind-guarded-table-loop-53/run_bounded.py d6645904b5cc5b017aa9bb1ab60becc430f9fb01c1ff651ee8bf969838ad4e22
```

The command intentionally refuses an existing `run-01`; reproduction requires a separately declared new output directory/manifest, not overwriting these results.

- `run-01/RUN_RECEIPT.json`: successful bounded process, **not successful lap**.
- `run-01/result/RESULT.json`: terminal support rejection and full transition evidence.
- `ACTUAL_TRACE_PARTIAL.csv`, `ACTOR_TRACE.npz`, `TICK_EVIDENCE.jsonl.gz` under that result directory: committed movement and every attempted tick.
- `ACTUAL_PATH.png`: green actual movement versus blue proposal over original registered source geometry.
- Independent prelaunch review:37fixtures,351frozen inputs,150 sampled sweeps/121200 boundary points checked.

## Separate changes and limits

Stage52 only corrected seed-bootstrap ordering. Stage53 separately adds a full swept-footprint nonground guard covering the existing20mm support-association envelope below the fixed datum; it exempts only identical frozen floor IDs. This prevents the roughly16mm initial datum offset from silently skipping low nonground geometry below the body box. It does not prove that the floor labels themselves correctly preserve every small object.

This is evaluator-assisted offline simulation using a source Polycam proposal and independently checked reference geometry. Source low-obstacle uncertainty persists; ground contacts are unmeasured because classified floor faces are exempted. No phone-device navigation or human safety has been established, and no three-lap test was run.
