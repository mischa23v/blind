"""Independent sampled sanity check of full-sweep guard coverage, not proof of sensing."""
from pathlib import Path
import sys,json,hashlib
import numpy as np
H=Path(__file__).resolve().parent;sys.path.insert(0,str(H));import loop_episode as e
rng=np.random.default_rng(53001);checks=0
class Spy:
 def contact_corners(self,c):self.c=np.array(c);return {'contact':False}
class Ground:pass
for i in range(150):
 g=Ground();slope=rng.uniform(0,np.tan(np.deg2rad(5)));az=rng.uniform(-np.pi,np.pi);g.plane_coefficients=np.array([slope*np.cos(az),slope*np.sin(az),rng.uniform(-.02,.02)])
 start=rng.uniform(-4,4,3);start[1]=0;end=start.copy();dist=rng.uniform(0,.025);ang=rng.uniform(-np.pi,np.pi);end[[0,2]]+=dist*np.array([np.cos(ang),np.sin(ang)]);yaw=rng.uniform(-np.pi,np.pi);dyaw=rng.uniform(-np.pi/180,np.pi/180)
 def footprint(t):
  pos=start+(end-start)*t;th=yaw+dyaw*t;c,s=np.cos(th),np.sin(th);local=np.array([[-.15,-.225],[.15,-.225],[.15,.225],[-.15,.225]])
  return pos[[0,2]]+local@np.array([[c,s],[-s,c]])
 A,B,C=g.plane_coefficients;start[1]=np.max(footprint(0)@np.array([A,B])+C);end[1]=np.max(footprint(1)@np.array([A,B])+C)
 spy=Spy();r=e.underbody_guard(spy,g,start,end,yaw,dyaw)
 origin=spy.c[0];basis=np.column_stack([spy.c[1]-origin,spy.c[3]-origin,spy.c[4]-origin]);inv=np.linalg.inv(basis)
 for t in np.linspace(0,1,101):
  xz=footprint(t);ys=xz@np.array([A,B])+C;foot_y=float(max(ys));p=np.c_[xz[:,0],np.full(4,foot_y+.002),xz[:,1]];q=np.c_[xz[:,0],ys-.02,xz[:,1]];u=(np.vstack([p,q])-origin)@inv.T
  assert np.all(u>=-1e-9)and np.all(u<=1+1e-9),(i,t,u)
  checks+=8
receipt={'status':'passed','seed':53001,'randomSweeps':150,'posesPerSweep':101,'testedBoundaryPoints':checks,'scope':'Independent sampled guard-enclosure sanity check using separately constructed rotating footprint; not continuous sensor coverage or physical walking proof','loopEpisodeSHA256':hashlib.sha256((H/'loop_episode.py').read_bytes()).hexdigest()}
(H/'INDEPENDENT_GUARD_SAMPLING.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
