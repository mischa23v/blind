from pathlib import Path
import json,hashlib
H=Path(__file__).resolve().parent;W=H.parent
if (H/'FROZEN.json').exists():raise RuntimeError('never overwrite frozen movement manifest')
f=json.loads((W/'blind-seed-recovery-order-52/MEMBERSHIP_FROZEN.json').read_text());files=f['files'].copy()
for i in range(5):
 d=W/'blind-seed-recovery-order-52'/f'membership-leg{i}';r=json.loads((d/'RESULT.json').read_text());assert r['status']=='membershipReady';assert r['runtime']['peakRSSBytes']<=3.5*1024**3
 for p in (d/'RESULT.json',d/'GROUND_IDS.npz'):files[str(p.relative_to(W))]=hashlib.sha256(p.read_bytes()).hexdigest()
for p in H.glob('*.py'):files[str(p.relative_to(W))]=hashlib.sha256(p.read_bytes()).hexdigest()
for p in [H/'SELECTED_PLAN.json',H/'MOVEMENT_PROTOCOL.md']:files[str(p.relative_to(W))]=hashlib.sha256(p.read_bytes()).hexdigest()
for p,h in files.items():assert hashlib.sha256((W/p).read_bytes()).hexdigest()==h,p
out={'outputDirectory':'run-01','scope':'one frozen nominal45 source Polycam table-loop attempt; unchanged original fullbody collider, one consistent fixedplane, explicit perleg floor memberships and old taskgeofence removal','files':files,'sourcePlanSHA256':files[str((H/'SELECTED_PLAN.json').relative_to(W))],'singleLap':True,'underbodyGuardEnabled':True,'same52MembershipsUnchangedByGuard':True,'maxTicks':2500,'resourceLimits':{'CPUSeconds':600,'wallSeconds':900,'RSSBytes':int(3.5*1024**3),'outputBytes':16*1024**2,'diskReserveBytes':768*1024**2},'physicalAuthority':False}
(H/'FROZEN.json').write_text(json.dumps(out,indent=2)+'\n');print(hashlib.sha256((H/'FROZEN.json').read_bytes()).hexdigest())
