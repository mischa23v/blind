from pathlib import Path
import json,numpy as np
from planner import Native
H=Path(__file__).resolve().parent;W=H.parent;r=json.loads((H/'RESULT.json').read_text());base=json.loads((W/'blind-polycam-table-loop-proposals-44/RESULT.json').read_text());base=next(x for x in base['results']if x['profile']=='body45cmMargin0'and x['nativeConfig']['max_slope']==15)
with np.load(W/'blind-polycam-alignment-feasibility-36/POLYCAM_INTRINSIC_GEOMETRY.npz')as z:obj=z['verticesOBJ'];tri=z['triangles']
with np.load(W/'blind-polycam-rigid-registration-37/run-01/CANDIDATE_RIGID_TRANSFORM.npz')as z:lev=obj@z['rotationOBJToLevel'].T+z['translationOBJToLevel']
n=Native(np.c_[lev[:,0],lev[:,2],-lev[:,1]],tri)
def measure(p):
 p=np.asarray(p);s=np.r_[0,np.cumsum(np.linalg.norm(np.diff(p[:,[0,2]],axis=0),axis=1))];at=np.r_[np.arange(0,s[-1],.025),s[-1]];q=np.array([np.interp(at,s,p[:,k])for k in range(3)]).T;values=[];missing=0
 for x in q:
  hit=n.sample(x)
  if hit is None:missing+=1
  else:values.append(hit[1])
 return {'samples':len(q),'missing':missing,'minP10MedianP90MaxMetres':np.quantile(values,[0,.1,.5,.9,1]).tolist()if values else None}
rows=[{'leg':i,'clearanceWeighted':measure(a['registeredNativeXYZ']),'funnel':measure(base['legs'][i]['native']['points'])}for i,a in enumerate(r['legs'])];n.close();o={'scope':'post-run source-only measurement, no path/parameter modification','sampling':'uniform horizontal arclength every25mm, plus final point; no repeated segment-boundary weighting','residualNavmeshClearanceNotPhysicalDistance':True,'legs':rows};(H/'UNIFORM_CLEARANCE_COMPARISON.json').write_text(json.dumps(o,indent=2)+'\n');print(json.dumps(rows))
