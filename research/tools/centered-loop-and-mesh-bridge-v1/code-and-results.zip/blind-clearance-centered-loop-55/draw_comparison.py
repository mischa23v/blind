from pathlib import Path
import json,numpy as np
from PIL import Image,ImageDraw,ImageFont
H=Path(__file__).resolve().parent;W=H.parent;r=json.loads((H/'RESULT.json').read_text());plan=json.loads((W/'blind-guarded-table-loop-53/SELECTED_PLAN.json').read_text())
with np.load(W/'blind-polycam-alignment-feasibility-36/POLYCAM_INTRINSIC_GEOMETRY.npz')as z:v=z['verticesOBJ'];tri=z['triangles']
with np.load(W/'blind-polycam-rigid-registration-37/run-01/CANDIDATE_RIGID_TRANSFORM.npz')as z:lev=v@z['rotationOBJToLevel'].T+z['translationOBJToLevel']
with np.load(W/'blind-split-candidate-game-03/inputs/koivu_5cm_v2_pipeline2_out.npz')as z:R=z['R'];t=z['t']
with np.load(W/'blind-pose-experiments-review-17/upstream/pose-consistency/runs/koivu_floorfix/pipeline2_out.npz')as z:N=z['R'];nt=z['t']
old=((lev-nt)@N)@R.T+t;v=np.c_[old[:,0],old[:,2],-old[:,1]];xyz=v[tri];keep=(xyz.mean(1)[:,1]>.15)&(xyz.mean(1)[:,1]<1.8)
lo=v[:,[0,2]].min(0);hi=v[:,[0,2]].max(0);im=Image.new('RGB',(1100,1300),'white');d=ImageDraw.Draw(im);font='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf';big=ImageFont.truetype(font,25);sm=ImageFont.truetype(font,17);scale=min(950/(hi[0]-lo[0]),1020/(hi[1]-lo[1]))
def p(q):return(65+(q[0]-lo[0])*scale,160+(q[2]-lo[1])*scale)
d.text((35,20),'Source-only clearance-weighted loop: NOT executed movement',font=big,fill='black');d.text((35,58),'Same source mesh, waypoints and native radius. Blue shortest funnel; green clearance-weighted.',font=sm,fill='black')
for q in xyz[keep]:d.line([p(x)for x in q]+[p(q[0])],fill='#dddddd',width=1)
for leg in plan['legs']:d.line([p(q)for q in leg['originalFramePath']],fill='#8cc9e4',width=3)
for leg in r['legs']:d.line([p(q)for q in leg['exactEndpointConnectedOriginalXYZ']],fill='#187b38',width=4)
for j,q in enumerate([plan['start'],*[x['originalTaskGoal']for x in plan['legs']]]):
 
 if j==5:continue
 x,y=p(q);d.ellipse((x-5,y-5,x+5,y+5),fill='#222222');d.text((x+8,y),('0 / 5' if j==0 else str(j)),font=sm,fill='black')
d.text((35,1215),'Green = clearance-weighted proposal (22.078m). Blue = funnel proposal (19.804m).',font=sm,fill='black');d.text((35,1245),'Both are source-only. Native boundary clearance is NOT measured real obstacle clearance.',font=sm,fill='black');d.text((35,1270),'Exact endpoints retained. Full-body/support/underbody movement checks remain unexecuted.',font=sm,fill='black');im.save(H/'SOURCE_CLEARANCE_COMPARISON.png')
