from pathlib import Path
import importlib.util,sys,ctypes as C,math,heapq,numpy as np
H=Path(__file__).resolve().parent;W=H.parent
spec=importlib.util.spec_from_file_location('clearance55native',W/'blind-split-candidate-game-03/body-margin-variants-07/native025/detour_engine.py');de=importlib.util.module_from_spec(spec);sys.modules[spec.name]=de;spec.loader.exec_module(de);de.ROOT=H
STEP=.05;WALL_CAP=2.;COST_SCALE=.30;EPS=.05;CONNECTOR=.15;MAX_GRID=100000
class Native:
 def __init__(self,v,t):
  self.engine=de.Engine(v,t,de.Config(radius=.225,height=1.75,cell_size=.025,max_climb=.025,max_slope=15),mode='known-provided-map');self.lib=self.engine.lib
  self.lib.bn_sample.argtypes=[C.c_void_p,de.F,de.F,C.c_float,de.F,de.F];self.lib.bn_sample.restype=C.c_int
  self.lib.bn_segment.argtypes=[C.c_void_p,de.F,de.F];self.lib.bn_segment.restype=C.c_int
 def sample(self,p,ext=(.001,.3,.001)):
  a=np.asarray(p,np.float32);e=np.asarray(ext,np.float32);out=np.zeros(3,np.float32);d=C.c_float()
  ok=self.lib.bn_sample(self.engine.handle,de._fp(a),de._fp(e),WALL_CAP,de._fp(out),C.byref(d))
  if not ok or not np.isfinite(out).all()or not np.isfinite(d.value):return None
  return out.astype(float),float(d.value)
 def segment(self,a,b):return bool(self.lib.bn_segment(self.engine.handle,de._fp(np.asarray(a,np.float32)),de._fp(np.asarray(b,np.float32))))
 def close(self):self.engine.close()
def penalty(c):return 1+(COST_SCALE/(max(0.,c)+EPS))**2
def edge_cost(a,b,ca,cb):return float(np.linalg.norm((np.asarray(b)-a)[[0,2]]))*(penalty(ca)+penalty(cb))/2

def dijkstra(adj,start,goal):
 dist={start:0.};prev={};heap=[(0.,start)]
 while heap:
  cost,u=heapq.heappop(heap)
  if cost!=dist[u]:continue
  if u==goal:
   p=[u]
   while p[-1]!=start:p.append(prev[p[-1]])
   return p[::-1],cost
  for v,w in sorted(adj[u]):
   nc=cost+w
   if nc<dist.get(v,float('inf'))-1e-12:dist[v]=nc;prev[v]=u;heapq.heappush(heap,(nc,v))
 return None,None

def build_graph(native,vertices,anchors):
 lo=np.floor(np.min(vertices[:,[0,2]],axis=0)/STEP).astype(int);hi=np.ceil(np.max(vertices[:,[0,2]],axis=0)/STEP).astype(int);assert np.prod(hi-lo+1)<=MAX_GRID
 # Constant sampling height from original source anchors only, never reference.
 y=float(np.median(np.array(anchors)[:,1]));points=[];clearance=[];keys={};adj=[]
 for ix in range(lo[0],hi[0]+1):
  for iz in range(lo[1],hi[1]+1):
   a=np.array([ix*STEP,y,iz*STEP]);s=native.sample(a)
   if s is None:continue
   p,c=s
   if np.linalg.norm((p-a)[[0,2]])>1e-4:continue
   keys[(ix,iz)]=len(points);points.append(p);clearance.append(c);adj.append([])
 for (ix,iz),u in keys.items():
  for dx,dz in((1,0),(0,1),(1,1),(1,-1)):
   v=keys.get((ix+dx,iz+dz))
   if v is None or not native.segment(points[u],points[v])or not native.segment(points[v],points[u]):continue
   cost=edge_cost(points[u],points[v],clearance[u],clearance[v]);adj[u].append((v,cost));adj[v].append((u,cost))
 nodes=[];associations=[]
 for a in anchors[:-1]:
  a=np.array(a);s=native.sample(a,(.2,.3,.2))
  if s is None:raise ValueError('original anchor cannot associate')
  p,c=s
  if np.linalg.norm((p-a)[[0,2]])>.1:raise ValueError('original anchor exceeds unchanged10cm association')
  u=len(points);points.append(p);clearance.append(c);adj.append([]);nodes.append(u);associations.append({'requestedXYZ':a.tolist(),'projectedXYZ':p.tolist(),'horizontalAssociationMetres':float(np.linalg.norm((p-a)[[0,2]])),'sourceNativeHeightRetained':True})
  for key,v in sorted(keys.items()):
   if np.linalg.norm((points[v]-p)[[0,2]])<=CONNECTOR and native.segment(p,points[v])and native.segment(points[v],p):
    cost=edge_cost(p,points[v],c,clearance[v]);adj[u].append((v,cost));adj[v].append((u,cost))
 return np.array(points),np.array(clearance),adj,nodes+[nodes[0]],associations

def compress_collinear(points):
 # Lossless geometric compression only: no clearance-lowering shortcut.
 p=np.asarray(points);out=[p[0]]
 for i in range(1,len(p)-1):
  a=p[i]-out[-1];b=p[i+1]-p[i]
  if np.linalg.norm(np.cross(a,b))>1e-8 or np.dot(a,b)<0:out.append(p[i])
 out.append(p[-1]);return np.array(out)
