import unittest,numpy as np
from planner import *
class Tests(unittest.TestCase):
 def test_penalty_decreases(self):self.assertGreater(penalty(.05),penalty(.5))
 def test_fixed_formula(self):self.assertAlmostEqual(penalty(.1),5.)
 def test_weighted_longer_clear_path(self):
  adj=[[(1,10.),(2,2.)],[(0,10.),(3,10.)],[(0,2.),(3,2.)],[(1,10.),(2,2.)]];self.assertEqual(dijkstra(adj,0,3)[0],[0,2,3])
 def test_disconnected(self):self.assertEqual(dijkstra([[],[]],0,1),(None,None))
 def test_stable_equalcost(self):self.assertEqual(dijkstra([[(2,1),(1,1)],[(3,1)],[(3,1)],[]],0,3)[0],[0,1,3])
 def test_collinear_preserves_height_bend(self):
  p=np.array([[0,0,0],[1,.1,0],[2,0,0]]);np.testing.assert_array_equal(compress_collinear(p),p)
 def test_collinear_only(self):self.assertEqual(len(compress_collinear([[0,0,0],[1,0,0],[2,0,0]])),2)
 def test_native_open_plane(self):
  v=np.array([[-2,0,-2],[2,0,-2],[2,0,2],[-2,0,2]]);t=np.array([[0,2,1],[0,3,2]])
  n=Native(v,t)
  try:
   centre=n.sample([0,0,0]);edge=n.sample([1.5,0,0]);self.assertIsNotNone(centre);self.assertGreater(centre[1],edge[1]);self.assertTrue(n.segment(centre[0],edge[0]));self.assertFalse(n.segment(centre[0],[3,0,0]));self.assertAlmostEqual(centre[0][1],edge[0][1])
  finally:n.close()
if __name__=='__main__':unittest.main(verbosity=2)
