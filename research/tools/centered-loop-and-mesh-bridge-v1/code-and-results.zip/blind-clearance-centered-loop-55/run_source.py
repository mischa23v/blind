from pathlib import Path
import os,resource,signal,time,json,hashlib,math,numpy as np
resource.setrlimit(resource.RLIMIT_AS,(1024**3,1024**3));resource.setrlimit(resource.RLIMIT_CPU,(120,120));resource.setrlimit(resource.RLIMIT_FSIZE,(5<<20,5<<20));signal.alarm(180)
from planner import *
H=Path(__file__).resolve().parent;W=H.parent;f=json.loads((H/'FROZEN.json').read_text());start=time.monotonic()
for p,h in f['files'].items():assert hashlib.sha256((W/p).read_bytes()).hexdigest()==h,p
assert os.statvfs(H).f_bavail*os.statvfs(H).f_frsize>=768<<20
source=json.loads((W/'blind-polycam-table-loop-proposals-44/FROZEN.json').read_text());oldresult=json.loads((W/'blind-polycam-table-loop-proposals-44/RESULT.json').read_text());bounds=json.loads((W/'blind-polycam-table-loop-proposals-44/PROPOSED_PHYSICS_BOUNDS.json').read_text())
with np.load(W/'blind-polycam-alignment-feasibility-36/POLYCAM_INTRINSIC_GEOMETRY.npz')as z:obj=z['verticesOBJ'];tri=z['triangles']
with np.load(W/'blind-polycam-rigid-registration-37/run-01/CANDIDATE_RIGID_TRANSFORM.npz')as z:lev=obj@z['rotationOBJToLevel'].T+z['translationOBJToLevel'];assert z['scale']==1
v=np.c_[lev[:,0],lev[:,2],-lev[:,1]];anchors=np.array([x['registeredGameXYZ']for x in source['anchors']]);native=Native(v,tri)
points,clearance,adj,nodes,associations=build_graph(native,v,anchors)
with np.load(W/'blind-split-candidate-game-03/inputs/koivu_5cm_v2_pipeline2_out.npz')as z:R=z['R'];t=z['t']
with np.load(W/'blind-pose-experiments-review-17/upstream/pose-consistency/runs/koivu_floorfix/pipeline2_out.npz')as z:N=z['R'];nt=z['t']
def original(p):
 p=np.asarray(p);lev=np.c_[p[:,0],-p[:,2],p[:,1]];old=((lev-nt)@N)@R.T+t;return np.c_[old[:,0],old[:,2],-old[:,1]]
def samples(path):
 out=[]
 for a,b in zip(path[:-1],path[1:]):
  for t in np.linspace(0,1,max(2,math.ceil(np.linalg.norm((b-a)[[0,2]])/.025)+1)):
   s=native.sample(a+(b-a)*t)
   if s is None:out.append(None)
   else:out.append(s[1])
 good=[x for x in out if x is not None];return {'samples':len(out),'missing':len(out)-len(good),'minimum':min(good)if good else None,'quantiles':np.quantile(good,[0,.1,.5,.9,1]).tolist()if good else None}
base=next(x for x in oldresult['results']if x['profile']=='body45cmMargin0'and x['nativeConfig']['max_slope']==15);rows=[];joined=[]
for i,(a,b)in enumerate(zip(nodes[:-1],nodes[1:])):
 path,cost=dijkstra(adj,a,b)
 if path is None:rows.append({'leg':i,'complete':False,'reason':'frozen source graph disconnected'});continue
 raw=points[path];p=compress_collinear(raw);orig=original(p);exact=np.vstack([source['anchors'][i]['originalGameXYZ'],orig,source['anchors'][i+1]['originalGameXYZ']]);bo=np.array(bounds['perLeg'][i]['floorCandidateXZBounds']);radius=math.hypot(.225,.15);xz=exact[:,[0,2]];within=bool(np.all(xz.min(0)-radius>=bo[0])and np.all(xz.max(0)+radius<=bo[1]));row={'leg':i,'complete':True,'weightedCost':cost,'gridNodes':len(path),'pointsAfterCollinearCompression':len(p),'registeredNativeXYZ':p.tolist(),'originalNativeXYZ':orig.tolist(),'exactEndpointConnectedOriginalXYZ':exact.tolist(),'originalStartXYZ':source['anchors'][i]['originalGameXYZ'],'originalGoalXYZ':source['anchors'][i+1]['originalGameXYZ'],'horizontalLengthMetres':float(np.linalg.norm(np.diff(p[:,[0,2]],axis=0),axis=1).sum()),'clearance':samples(p),'baselineFunnelClearance':samples(np.array(base['legs'][i]['native']['points'])),'existingLegBoundsContainFullRotatingBodyCircle':within,'bodyCircleRadiusMetresForBoundsOnly':radius,'existingFloorCandidateXZBounds':bo.tolist()};rows.append(row);joined.extend(p.tolist()if not joined else p[1:].tolist())
complete=all(x['complete']for x in rows);winding=None
if complete:
 q=np.array(joined)[:,[0,2]]-np.array(oldresult['tabletopDiagnostic']['centroidGameXYZ'])[[0,2]];winding=float(np.arctan2(q[:-1,0]*q[1:,1]-q[:-1,1]*q[1:,0],(q[:-1]*q[1:]).sum(1)).sum()/(2*np.pi))
native.close();result={'scope':'source-only clearance-weighted planner proposal; no physical movement','completeFiveLegTour':complete,'winding':winding,'oneLoopProposal':bool(complete and abs(winding+1)<1e-5),'legs':rows,'anchorAssociations':associations,'graphNodes':len(points),'graphUndirectedEdges':sum(map(len,adj))//2,'parameters':{'gridStep':STEP,'wallCap':WALL_CAP,'costScale':COST_SCALE,'epsilon':EPS,'connectorRadius':CONNECTOR},'nativeRadiusAppliedOnce':True,'referenceInputUsedForPlanning':False,'referenceMaskUsed':False,'movementExecuted':False,'runtime':{'wallSeconds':time.monotonic()-start,'CPUSeconds':resource.getrusage(resource.RUSAGE_SELF).ru_utime+resource.getrusage(resource.RUSAGE_SELF).ru_stime,'peakRSSKiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}}
(H/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k not in ['legs','anchorAssociations']}));print(json.dumps([{k:x.get(k)for k in ['leg','complete','horizontalLengthMetres','clearance','baselineFunnelClearance','existingLegBoundsContainFullRotatingBodyCircle']}for x in rows]))
