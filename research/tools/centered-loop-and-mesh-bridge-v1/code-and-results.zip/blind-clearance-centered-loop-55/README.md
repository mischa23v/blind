# Source-only clearance-weighted table-loop proposal

**A complete clockwise source proposal exists:22.078m versus19.804m for the previous shortest funnel. No physical movement was executed.**

This changes only the source planner objective. Same registered Polycam mesh, released pinned Recast/Detour, native radius0.225m, original endpoints, source heights and body specification. No FARO geometry, rejected reference face, floor relabeling or statistical mask guides the path.

The new adapter exposes released Detour `findDistanceToWall` and `raycast`. A deterministic5cm8-neighbor graph minimizes `length * average(1 + (0.30/(residual_clearance +0.05))²)`. Clearance is distance to the **already-eroded navmesh boundary**; native body radius is applied once, not again. This favors interior space but does not guarantee an exact medial axis, maximum minimum clearance, or true physical obstacle distance.

## Results

7,507graph nodes,28,247edges;1.91seconds and42MiB peakRSS. All five legs connect and source winding is−1. Every new route plus the entire rotating45×30cm body circle stays within the previously frozen leg-specific52/53floor bounds. No new reference membership is required just to enlarge those bounds.

Uniform25mm horizontal-arclength sampling gives these **source residual-clearance** medians:

| Leg | Shortest funnel | Clearance-weighted |
|---|---:|---:|
|0|22.3cm|24.8cm|
|1|12.3cm|32.1cm|
|2|41.4cm|44.9cm|
|3|24.2cm|28.3cm|
|4|15.0cm|29.3cm|

The funnel touches its eroded navmesh boundary on legs1and4; the new uniformly sampled minima are about10.0cm and6.7cm respectively. These are not extra guaranteed human safety margins. `UNIFORM_CLEARANCE_COMPARISON.json` is the comparable arclength-weighted measurement; the original `RESULT.json` also retains its earlier per-segment sampled diagnostics with repeated segment boundaries, which have different medians. Neither report changes routes.

`SOURCE_CLEARANCE_COMPARISON.png` shows green clearance-weighted versus blue funnel proposals. Native heights and exact caller endpoint connectors are retained in `RESULT.json`. Only exactly collinear3D points were removed:44/57/32/33/82corners remain, so the unchanged bounded actor may spend substantial time rotating. A later source-only smoothing variant would require its own frozen rule and evidence; none was applied here.

## Reproduction

Eight fixtures pass, covering native wall distance/raycast behavior, deterministic graph search, disconnected routes, fixed cost and height-preserving collinear compression.

```
OPENBLAS_NUM_THREADS=1 python blind-clearance-centered-loop-55/test_planner.py
OPENBLAS_NUM_THREADS=1 python blind-clearance-centered-loop-55/run_source.py
```

Final source manifest: `a619feebe8f79fad71491d4a14979480bc7a74cdc2f3eef5129a98e3bac09881`. A preliminary manifest with a bounds-array row/column interpretation typo was retained as `FROZEN_PREEXEC_BOUNDS_SCHEMA_ERROR.json`; corrected before the first source run, with no score-dependent parameter change. Existing upstream source was compiled locally; no downloads, installations or upstream copies were needed.

## Still required

Same-actor full-body, finite-support and underbody-guard execution against the unchanged reference world. Native proposals and improved source clearance do not establish a completed lap, live iPhone sensing, toy detection or human safety. Prior stage53partial movement remains unchanged.
