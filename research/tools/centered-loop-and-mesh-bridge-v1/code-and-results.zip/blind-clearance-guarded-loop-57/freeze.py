from pathlib import Path
import json,hashlib
H=Path(__file__).resolve().parent;W=H.parent;f=json.loads((W/'blind-guarded-table-loop-53/FROZEN.json').read_text());files=f['files'].copy();files.update(json.loads((W/'blind-clearance-los-simplification-56/FROZEN.json').read_text())['files'])
for p in [*H.glob('*.py'),H/'SELECTED_PLAN.json',H/'MOVEMENT_PROTOCOL.md',W/'blind-clearance-los-simplification-56/RESULT.json',W/'blind-clearance-los-simplification-56/SHORTCUT_EVIDENCE.json.gz',W/'blind-clearance-los-simplification-56/INDEPENDENT_KINEMATIC_REVIEW.json']:files[str(p.relative_to(W))]=hashlib.sha256(p.read_bytes()).hexdigest()
for p,h in files.items():assert hashlib.sha256((W/p).read_bytes()).hexdigest()==h,p
assert not(H/'FROZEN.json').exists();f.update(files=files,scope='57 source-clearance path variant, unchanged53 guarded world and actor',resourceLimits={**f['resourceLimits'],'outputBytes':8*1024**2,'CPUSeconds':900,'wallSeconds':1200},sourcePathOnlyChanged=True,sourcePlanSHA256=hashlib.sha256((H/'SELECTED_PLAN.json').read_bytes()).hexdigest());(H/'FROZEN.json').write_text(json.dumps(f,indent=2)+'\n');print(hashlib.sha256((H/'FROZEN.json').read_bytes()).hexdigest())
