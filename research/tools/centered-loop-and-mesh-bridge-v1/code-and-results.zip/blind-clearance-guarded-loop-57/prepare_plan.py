from pathlib import Path
import json,hashlib,numpy as np
H=Path(__file__).resolve().parent;W=H.parent;p=json.loads((W/'blind-guarded-table-loop-53/SELECTED_PLAN.json').read_text());r=json.loads((W/'blind-clearance-los-simplification-56/RESULT.json').read_text());assert r['oneLoopProposal'];assert all(x['existingLegBoundsContainFullRotatingBodyCircle']for x in r['legs'])
for old,new in zip(p['legs'],r['legs']):
 assert np.array_equal(old['originalTaskGoal'],new['originalGoalXYZ']);assert np.array_equal(old['sourceStartOriginalXYZ'],new['originalStartXYZ']);old['originalFramePath']=new['exactEndpointConnectedOriginalXYZ'];old['sourceNativeOriginalFramePath']=new['originalNativeXYZ']
p['sourceResultSHA256']=hashlib.sha256((W/'blind-clearance-los-simplification-56/RESULT.json').read_bytes()).hexdigest();p['plannerPolicy']='55 fixed source clearance cost plus56 sampled nondegrading LOS simplification';p['previous53PlanSHA256']=hashlib.sha256((W/'blind-guarded-table-loop-53/SELECTED_PLAN.json').read_bytes()).hexdigest();p['sourcePathOnlyChanged']=True;p['initialYawUnchangedFrom53']=True
(H/'SELECTED_PLAN.json').write_text(json.dumps(p,indent=2)+'\n')
