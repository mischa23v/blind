# Clearance-weighted guarded loop:6.950m, incomplete

The source-only clearance-centered planner plus nondegrading LOS simplification moved the unchanged45×30×160cm actor **6.950m**, compared with3.640m for53. It reached the first original goal and continued around the table, but **did not complete a lap**.

At tick515, a proposed step was rejected by the full-footprint underbody guard. All nine support probes passed and the body-only box was clear, but nonground reference face16422577 intersected the underbody enclosure. The rejected step was not committed. Zero actual body contacts does not negate this guard rejection.

| Measure | Result |
|---|---:|
|Original goals reached|1of5|
|Laps|0|
|Committed horizontal distance|6.950011m|
|Committed movement ticks|514|
|Actual body contacts|0|
|Predicted underbody rejections|1|
|Wall/CPU time|144.94/146.26s|
|Peak treeRSS|2.271GB|

The independent review confirms CSV/NPZ equality, all committed motion guards, drained first arrival and unchanged terminal pose on rejection.

## Exact unresolved facet

Direct original PLY extraction and the frozen local-fit receipt show:

- Face16422577 has only0.080mm vertical variation across a very thin5.557×0.254mm horizontal extent.
- Its individual triangle normal is62.836°, exceeding the unchanged45° raw-normal recovery guard.
- All vertices are within0.088mm of the frozen local floor fit, comfortably inside the unchanged2mm residual bound.
- It is absent from all five frozen memberships.

Source images00197and00184 associate this location with visibly clear red carpet away from furniture. This is useful evidence for investigating unstable thin-triangle normals, not automatic permission to relabel geometry. No classifier threshold, geometry, start, body, path or floor membership was changed after the result.

## Controlled comparison

Same53world/body/floor/underbody code, exact52memberships, original start and initial yaw, original five goals. Only the source path changes to55/56. Root authorized a **pre-run** resource budget900CPU/1200wall instead of600/900 based on the source-only1,675tick forecast; the old prelaunch manifest remains archived. Physical rules and2,500tick limit are unchanged. Output cap is conservatively8MiB with768MiB disk reserve.

Final manifest: `942c067e6928cd91efe4762845eae6abedf8c9a1fb74ceb879eae557e7d5016a`.

Evidence:
- `run-01/result/RESULT.json`, exact actor traces and lossless tick evidence.
- `INDEPENDENT_TERMINAL_REVIEW.json`.
- `ACTUAL_PATH.png` distinguishes executed movement from the unexecuted proposal.
- `diagnosis/TERMINAL_FACE_DIAGNOSIS.json` plus two source-image overlays and association provenance.

This remains evaluator-assisted offline simulation. Source low-obstacle uncertainty persists and exempted floor contacts are unmeasured. It does not establish autonomous phone navigation or human safety; no three-lap run was performed.
