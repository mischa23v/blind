from pathlib import Path
import sys,math,numpy as np
H=Path(__file__).resolve().parent;W=H.parent;sys.path.insert(0,str(W/'blind-clearance-centered-loop-55'))
from planner import Native,penalty
SPACING=.025;CLEARANCE_EPS=1e-6;COST_EPS=1e-6;HEIGHT_TOL=.05

def segment_measure(native,a,b):
 a=np.asarray(a);b=np.asarray(b);length=float(np.linalg.norm((b-a)[[0,2]]));count=max(2,math.ceil(length/SPACING)+1);samples=[]
 if not native.segment(a,b)or not native.segment(b,a):return {'valid':False,'reason':'nativeLOS'}
 for t in np.linspace(0,1,count):
  requested=a+(b-a)*t;hit=native.sample(requested)
  if hit is None:return {'valid':False,'reason':'nativeSampleUnavailable'}
  p,c=hit
  if np.linalg.norm((p-requested)[[0,2]])>1e-4 or abs(p[1]-requested[1])>HEIGHT_TOL:return {'valid':False,'reason':'nativeHeightOrXZAssociation'}
  samples.append({'nativeXYZ':p.tolist(),'requestedXYZ':requested.tolist(),'residualWallClearance':c})
 values=np.array([penalty(x['residualWallClearance'])for x in samples]);cost=float(np.sum((values[:-1]+values[1:])/2)*length/(count-1));return {'valid':True,'samples':samples,'minClearance':min(x['residualWallClearance']for x in samples),'integratedCost':cost,'horizontalLength':length,'maximumSampleSpacing':length/(count-1)}

def simplify(native,path):
 p=np.asarray(path);edge=[segment_measure(native,a,b)for a,b in zip(p[:-1],p[1:])]
 if not all(x['valid']for x in edge):return {'complete':False,'reason':'original source edge failed native recheck','edgeChecks':edge}
 chosen=[0];accepted=[];attempts=[];i=0
 while i<len(p)-1:
  selected=None
  for j in range(len(p)-1,i,-1):
   oldmin=min(x['minClearance']for x in edge[i:j]);oldcost=sum(x['integratedCost']for x in edge[i:j]);new=segment_measure(native,p[i],p[j]);ok=bool(new['valid']and new['minClearance']>=oldmin-CLEARANCE_EPS and new['integratedCost']<=oldcost+COST_EPS);attempts.append({'from':i,'to':j,'accepted':ok,'validNative':new['valid'],'reason':new.get('reason'),'originalMinClearance':oldmin,'originalCost':oldcost,'newMinClearance':new.get('minClearance'),'newCost':new.get('integratedCost')})
   if ok:selected=j;accepted.append({'from':i,'to':j,'originalMinClearance':oldmin,'originalCost':oldcost,**new});break
  if selected is None:return {'complete':False,'reason':'no nondegrading shortcut including original edge','attempts':attempts}
  chosen.append(selected);i=selected
 return {'complete':True,'chosenOriginalIndices':chosen,'nativeXYZ':p[chosen].tolist(),'acceptedSegments':accepted,'attempts':attempts,'originalPoints':len(p),'simplifiedPoints':len(chosen),'originalCost':sum(x['integratedCost']for x in edge),'simplifiedCost':sum(x['integratedCost']for x in accepted),'originalMinimumClearance':min(x['minClearance']for x in edge),'simplifiedMinimumClearance':min(x['minClearance']for x in accepted)}
