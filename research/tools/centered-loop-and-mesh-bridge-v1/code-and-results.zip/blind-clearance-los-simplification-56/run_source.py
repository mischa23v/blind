from pathlib import Path
import json,hashlib,gzip,resource,signal,time,os,math,numpy as np
resource.setrlimit(resource.RLIMIT_AS,(1024**3,1024**3));resource.setrlimit(resource.RLIMIT_CPU,(120,120));resource.setrlimit(resource.RLIMIT_FSIZE,(5<<20,5<<20));signal.alarm(180)
from simplify import *
H=Path(__file__).resolve().parent;W=H.parent;start=time.monotonic();f=json.loads((H/'FROZEN.json').read_text())
for p,h in f['files'].items():assert hashlib.sha256((W/p).read_bytes()).hexdigest()==h,p
assert os.statvfs(H).f_bavail*os.statvfs(H).f_frsize>768<<20
r=json.loads((W/'blind-clearance-centered-loop-55/RESULT.json').read_text());s=json.loads((W/'blind-polycam-table-loop-proposals-44/FROZEN.json').read_text());b=json.loads((W/'blind-polycam-table-loop-proposals-44/PROPOSED_PHYSICS_BOUNDS.json').read_text());table=json.loads((W/'blind-polycam-table-loop-proposals-44/RESULT.json').read_text())['tabletopDiagnostic']['centroidGameXYZ']
with np.load(W/'blind-polycam-alignment-feasibility-36/POLYCAM_INTRINSIC_GEOMETRY.npz')as z:obj=z['verticesOBJ'];tri=z['triangles']
with np.load(W/'blind-polycam-rigid-registration-37/run-01/CANDIDATE_RIGID_TRANSFORM.npz')as z:lev=obj@z['rotationOBJToLevel'].T+z['translationOBJToLevel']
with np.load(W/'blind-split-candidate-game-03/inputs/koivu_5cm_v2_pipeline2_out.npz')as z:R=z['R'];t=z['t']
with np.load(W/'blind-pose-experiments-review-17/upstream/pose-consistency/runs/koivu_floorfix/pipeline2_out.npz')as z:N=z['R'];nt=z['t']
def original(p):
 p=np.asarray(p);lev=np.c_[p[:,0],-p[:,2],p[:,1]];old=((lev-nt)@N)@R.T+t;return np.c_[old[:,0],old[:,2],-old[:,1]]
n=Native(np.c_[lev[:,0],lev[:,2],-lev[:,1]],tri);rows=[];joined=[];details=[]
for i,leg in enumerate(r['legs']):
 x=simplify(n,leg['registeredNativeXYZ']);details.append(x);row={k:v for k,v in x.items()if k not in ['acceptedSegments','attempts','nativeXYZ']};row['leg']=i
 if x['complete']:
  p=np.array(x['nativeXYZ']);orig=original(p);exact=np.vstack([s['anchors'][i]['originalGameXYZ'],orig,s['anchors'][i+1]['originalGameXYZ']]);bo=np.array(b['perLeg'][i]['floorCandidateXZBounds']);rad=math.hypot(.225,.15);xz=exact[:,[0,2]];row.update(registeredNativeXYZ=p.tolist(),originalNativeXYZ=orig.tolist(),exactEndpointConnectedOriginalXYZ=exact.tolist(),originalStartXYZ=s['anchors'][i]['originalGameXYZ'],originalGoalXYZ=s['anchors'][i+1]['originalGameXYZ'],horizontalLengthMetres=float(np.linalg.norm(np.diff(p[:,[0,2]],axis=0),axis=1).sum()),existingLegBoundsContainFullRotatingBodyCircle=bool(np.all(xz.min(0)-rad>=bo[0])and np.all(xz.max(0)+rad<=bo[1])),sourceNativeHeightRetained=True);joined.extend(p.tolist()if not joined else p[1:].tolist())
 rows.append(row)
n.close();complete=all(x['complete']for x in rows);wind=None
if complete:
 q=np.array(joined)[:,[0,2]]-np.array(table)[[0,2]];wind=float(np.arctan2(q[:-1,0]*q[1:,1]-q[:-1,1]*q[1:,0],(q[:-1]*q[1:]).sum(1)).sum()/(2*np.pi))
with gzip.open(H/'SHORTCUT_EVIDENCE.json.gz','wt')as fp:json.dump(details,fp,separators=(',',':'))
out={'scope':'source-only nondegrading LOS simplification of55, no physical movement','completeFiveLegTour':complete,'winding':wind,'oneLoopProposal':bool(complete and abs(wind+1)<1e-5),'legs':rows,'movementExecuted':False,'referenceUsed':False,'parameters':{'spacing':SPACING,'clearanceNumericalTolerance':CLEARANCE_EPS,'costNumericalTolerance':COST_EPS,'nativeHeightAssociation':HEIGHT_TOL},'runtime':{'wallSeconds':time.monotonic()-start,'CPUSeconds':resource.getrusage(resource.RUSAGE_SELF).ru_utime+resource.getrusage(resource.RUSAGE_SELF).ru_stime,'peakRSSKiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}};(H/'RESULT.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items()if k!='legs'}));print(json.dumps([{k:x.get(k)for k in ['leg','complete','originalPoints','simplifiedPoints','horizontalLengthMetres','existingLegBoundsContainFullRotatingBodyCircle']}for x in rows]))
