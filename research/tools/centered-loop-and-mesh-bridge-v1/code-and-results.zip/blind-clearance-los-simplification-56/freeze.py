from pathlib import Path
import json,hashlib
H=Path(__file__).resolve().parent;W=H.parent;f=json.loads((W/'blind-clearance-centered-loop-55/FROZEN.json').read_text());files=f['files'].copy()
for p in [*H.glob('*.py'),H/'PROTOCOL.md',W/'blind-clearance-centered-loop-55/RESULT.json']:files[str(p.relative_to(W))]=hashlib.sha256(p.read_bytes()).hexdigest()
for p,h in files.items():assert hashlib.sha256((W/p).read_bytes()).hexdigest()==h,p
assert not(H/'FROZEN.json').exists();(H/'FROZEN.json').write_text(json.dumps({'scope':'56 source-only LOS simplification, no new reference inputs','files':files},indent=2)+'\n');print(hashlib.sha256((H/'FROZEN.json').read_bytes()).hexdigest())
