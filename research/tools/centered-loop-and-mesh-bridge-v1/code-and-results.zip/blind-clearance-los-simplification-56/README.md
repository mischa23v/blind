# Source-only nondegrading LOS simplification

The frozen55clearance-weighted loop had248points and needed7,960ideal follower ticks—over the existing2,500tick movement budget. This separately frozen56variant reduces it to39points and1,675ideal ticks without changing original goals, body, navmesh, source heights or reference floor labels.

Each shortcut passes bidirectional released Detour LOS, samples native height and residual boundary clearance at<=25mm, preserves the replaced subchain's sampled minimum clearance and does not increase its integrated fixed55cost (only1e-6numerical tolerances). All34accepted shortcuts were independently recounted. This is sampled source geometry, not continuous full-body clearance proof.

| Leg | Before points | After points | Ideal ticks |
|---|---:|---:|---:|
|0|44|5|171|
|1|57|9|378|
|2|32|2|113|
|3|33|13|505|
|4|82|10|508|

The proposed clockwise loop is20.944m; every rotating45×30cm body-circle envelope remains inside the existing52/53leg bounds. Exact caller endpoint connectors remain explicit. No movement was performed here.

- `RESULT.json`: frozen source result and complete paths.
- `SHORTCUT_EVIDENCE.json.gz`: all accepted native-height samples, rejected candidates and cost/clearance receipts.
- `INDEPENDENT_KINEMATIC_REVIEW.json`: independent shortcut and ideal-tick recount.
- `SOURCE_CLEARANCE_COMPARISON.png`: simplified source proposal versus original shortest funnel.
- `FROZEN.json`: `35bcc6e04c376d267ec3031e896293d4bd23cbe608ea1f78802441bf952d0a46`.

Five fixtures pass. Runtime1.33seconds,35MiB peakRSS. Stage55rawproposal and prior53failure remain unchanged. Stage57must test this path with unchanged full-body/support/underbody guards before claiming any simulated lap.
