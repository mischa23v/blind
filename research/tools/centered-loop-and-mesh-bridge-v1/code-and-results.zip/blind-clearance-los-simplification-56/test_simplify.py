import unittest,numpy as np
from simplify import *
class Mock:
 def __init__(self,low=False,los=True):self.low=low;self.los=los
 def sample(self,p,ext=None):return np.array(p),(.01 if self.low and .2<p[0]<.8 and abs(p[2])<.1 else .5)
 def segment(self,a,b):return self.los
class Tests(unittest.TestCase):
 def test_clear_shortcut(self):
  r=simplify(Mock(),[[0,0,0],[.5,0,.2],[1,0,0]]);self.assertTrue(r['complete']);self.assertEqual(r['chosenOriginalIndices'],[0,2])
 def test_clearance_loss_rejected(self):
  r=simplify(Mock(True),[[0,0,0],[.5,0,.5],[1,0,0]]);self.assertEqual(r['chosenOriginalIndices'],[0,1,2])
 def test_blocked_edge_fails(self):self.assertFalse(simplify(Mock(los=False),[[0,0,0],[1,0,0]])['complete'])
 def test_native_height_receipt(self):
  r=segment_measure(Mock(),[0,.02,0],[1,.04,0]);self.assertTrue(r['valid']);self.assertLessEqual(r['maximumSampleSpacing'],.025);self.assertEqual(r['samples'][-1]['nativeXYZ'],[1.,.04,0.])
 def test_exact_endpoints(self):
  p=[[0,.01,0],[.5,.02,.2],[1,.03,0]];r=simplify(Mock(),p);self.assertEqual(r['nativeXYZ'][0],p[0]);self.assertEqual(r['nativeXYZ'][-1],p[-1])
if __name__=='__main__':unittest.main(verbosity=2)
