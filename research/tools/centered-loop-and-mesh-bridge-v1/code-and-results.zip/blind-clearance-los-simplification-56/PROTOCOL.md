# Frozen source-only LOS simplification of55

No reference geometry, masks, failed-face locations or physical outcomes are inputs. Preserve55rawpaths and exact original task anchors; same native engine/config/geometry. Deterministically start at the first path point and choose the farthest later original point satisfying ALL:

1. Released native Detour raycast passes both directions.
2. Samples are at most25mm apart horizontally. Every sample associates to native mesh within0.1mm horizontal and50mm vertical (existing source-height acceptance). Record every returned nativeXYZ and clearance. Endpoints retain exact original nativeXYZ; no floor snapping or reference-plane fitting.
3. Sampled minimum residual navmesh clearance is no lower than the replaced subchain minimum, allowing only1e-6m numerical tolerance.
4. Integrated SAME55penalty `1+(0.30/(c+0.05))²` by trapezoidal samples is no greater than replaced subchain cost, allowing only1e-6cost units.

The original subchain is sampled per original segment at<=25mm, including every vertex. No arbitrary path shortcut merely to reduce distance. If even an original edge fails recheck, report failure rather than relax. Recompute winding and full rotating body-circle bounds from source output; no reference querying. Exact task endpoint connectors remain unchanged and separately recorded, not claimed physically validated.

This changes controller corner count, not source geometry, floor labels, body or safety guards. Preserve all rejected shortcut diagnostics and accepted native-height sample receipts in losslessgzip.120CPU/180wall,1GiB address space,5MiB individual file,8MiB total output,768MiB disk reserve. No downloads/installs. Freeze before source run; independent ideal follower rehearsal before considering new57movement.
