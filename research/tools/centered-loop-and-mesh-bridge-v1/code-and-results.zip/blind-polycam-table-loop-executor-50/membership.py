import os,resource,signal,time,json,sys,hashlib
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
resource.setrlimit(resource.RLIMIT_AS,(int(3.5*1024**3),int(3.5*1024**3)));resource.setrlimit(resource.RLIMIT_CPU,(180,180));signal.alarm(240)
from pathlib import Path
from dataclasses import replace
import numpy as np
H=Path(__file__).resolve().parent;W=H.parent;S=W/'blind-polycam-varpu-executor-40';sys.path.insert(0,str(S));import run_north as d
start=time.monotonic();ix=int(sys.argv[1]);assert 0<=ix<5;f=json.loads((H/'MEMBERSHIP_FROZEN.json').read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def verify():
 for p,h in f['files'].items():assert sha(W/p)==h,p
 assert os.statvfs(H).f_bavail*os.statvfs(H).f_frsize>=768<<20
verify();available=int(next(x.split()[1]for x in Path('/proc/meminfo').read_text().splitlines()if x.startswith('MemAvailable:')))*1024;assert available>=4.3*1024**3
out=H/f'membership-leg{ix}';out.mkdir(exist_ok=False);motion=d.motion;motion.serial_vtk();surface,mi,reader=motion.load_surface()
with np.load(d.GAME/'inputs/koivu_5cm_v2_pipeline2_out.npz')as z:meta={'R':z['R'],'t':z['t']}
A=np.array(json.loads((W/'blind-koivu-faro-acquisition-04/selected-reference/icp_iphone.json').read_text())['gt_transformation']);base=d.OrientedReferenceContainer(surface,motion.transform(meta,A),d.BodyGeometry(width=.45,depth=.30,height=1.6,horizontal_margin=0.))
plan=json.loads((H/'SELECTED_PLAN.json').read_text());p=plan['legs'][ix];pre=json.loads((H/'preflight-01/RESULT.json').read_text())['rows'][ix];receipt={'legIndex':ix,'sourceSeedPolicy':'fixed original source leg-start nine probes, not a reached actor pose','movementExecuted':False,'originalGeometryChanged':False}
try:
 ground=d.shared_ground(base,[np.array(p['sourceNativeOriginalFramePath'])],pre['seedIDs'],pre['seedPoints'],lambda x:print(json.dumps({'phase':'candidateCount',**x}),flush=True));assert ground.receipt['patchGameBounds']==pre['gameBounds'];assert ground.receipt['groundSetupQuery']['uniqueOriginalIDs']==pre['candidateCells']
 diagnostic=ground.plane_coefficients.tolist();plane=np.array(plan['floorPolicy']['fixedPlaneCoefficients']);receipt.update(status='membershipReady',groundReceipt=ground.receipt,diagnosticMembershipBroadPlane=diagnostic,fixedActivePlane=plane.tolist(),activePlaneNeverRefit=True,groundCells=len(ground.ground_cell_ids),referenceTransformSHA256=hashlib.sha256(base.transform.tobytes()).hexdigest());np.savez_compressed(out/'GROUND_IDS.npz',groundIDs=ground.ground_cell_ids);receipt['membershipSHA256']=sha(out/'GROUND_IDS.npz')
except(ValueError,RuntimeError,AssertionError)as e:receipt.update(status='membershipRejected',reason=repr(e),details=getattr(e,'details',{}))
verify();receipt['runtime']={'wallSeconds':time.monotonic()-start,'CPUSeconds':resource.getrusage(resource.RUSAGE_SELF).ru_utime+resource.getrusage(resource.RUSAGE_SELF).ru_stime,'peakRSSBytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024};(out/'RESULT.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:receipt[k]for k in ['status','legIndex','runtime']}),flush=True)
