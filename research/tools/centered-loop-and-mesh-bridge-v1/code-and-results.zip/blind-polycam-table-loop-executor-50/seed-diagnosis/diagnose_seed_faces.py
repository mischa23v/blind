from pathlib import Path
import json,struct,math,hashlib,numpy as np
H=Path(__file__).resolve().parent;P=H.parent;W=P.parent;pre=json.loads((P/'preflight-01/RESULT.json').read_text())['rows'][0];mesh=W/'blind-koivu-faro-acquisition-04/selected-reference/gt_mesh.ply'
with np.load(W/'blind-split-candidate-game-03/inputs/koivu_5cm_v2_pipeline2_out.npz')as z:R=z['R'];t=z['t']
A=np.array(json.loads((W/'blind-koivu-faro-acquisition-04/selected-reference/icp_iphone.json').read_text())['gt_transformation']);B=np.array([[1.,0,0],[0,0,-1],[0,1,0]]);M=np.eye(4);M[:3,:3]=R.T@B;M[:3,3]=-R.T@t;T=A@M;I=np.linalg.inv(T);policy=json.loads((P/'SELECTED_PLAN.json').read_text())['floorPolicy'];plane=np.array(policy['fixedPlaneCoefficients']);rows=[]
with mesh.open('rb')as f:
 header=b''
 while not header.endswith(b'end_header\n'):header+=f.readline()
 assert b'element vertex 8940320\n'in header and b'property list uchar uint vertex_indices\n'in header
 for probe in pre['supportProbes']['probes']:
  cid=probe['referenceCellID'];f.seek(len(header)+8940320*48+cid*13);n,*ids=struct.unpack('<BIII',f.read(13));assert n==3;ref=[]
  for v in ids:f.seek(len(header)+v*48);ref.append(struct.unpack('<ddd',f.read(24)))
  ref=np.array(ref);q=ref.astype(np.float32).astype(float)@I[:3,:3].T+I[:3,3];normal=np.cross(q[1]-q[0],q[2]-q[0]);normal/=np.linalg.norm(normal);slope=math.degrees(math.acos(np.clip(abs(normal[1]),0,1)));lo,hi=q.min(0),q.max(0);bounds=np.array(pre['gameBounds']).reshape(3,2);within=bool(lo[1]>=bounds[1,0]and hi[1]<=bounds[1,1]and hi[0]>=bounds[0,0]and lo[0]<=bounds[0,1]and hi[2]>=bounds[2,0]and lo[2]<=bounds[2,1]);res=q[:,1]-(plane[0]*q[:,0]+plane[1]*q[:,2]+plane[2])
  rows.append({'referenceCellID':cid,'vertexIDs':ids,'referenceVerticesDouble':ref.tolist(),'verticesOriginalGameXYZ':q.tolist(),'centroidOriginalGameXYZ':q.mean(0).tolist(),'slopeDegrees':slope,'withinFrozenClassificationBounds':within,'eligible5DegreeTrainingNormal':slope<=5,'passes45DegreeRawGuard':slope<=45,'triangleXYZExtentMetres':(hi-lo).tolist(),'vertexHeightRangeMetres':[lo[1],hi[1]],'active47PlaneVertexResidualsMetres':res.tolist(),'rawSupportProbe':probe,'localResidualNotComputed':'training stage rejected all-seed admission before local patch fits exist; do not invent recovered membership'})
out={'scope':'post-failure exact nine original seed faces, direct PLY read, no geometry/classifier/path change','failureStage':'GroundSupport.from_geometry training_keep seeded_component BEFORE broad/local fit and recovery','allNineMustPassTrainingRule':True,'allNineNumericProbeChecksPassed':True,'rows':rows,'ineligibleSeedIDs':[r['referenceCellID']for r in rows if not(r['withinFrozenClassificationBounds']and r['eligible5DegreeTrainingNormal'])],'referenceTransformSHA256':hashlib.sha256(T.tobytes()).hexdigest(),'fixedActivePlane':plane.tolist(),'groundPlaneChanged':False,'movementExecuted':False}
(H/'SEED_FACE_DIAGNOSIS.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'ineligibleSeedIDs':out['ineligibleSeedIDs'],'faces':[{k:r[k]for k in('referenceCellID','slopeDegrees','triangleXYZExtentMetres','vertexHeightRangeMetres')}for r in rows]},indent=2))
