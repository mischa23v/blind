import os,resource,time,json,sys,hashlib,signal,math,gc
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
resource.setrlimit(resource.RLIMIT_CPU,(180,180));resource.setrlimit(resource.RLIMIT_AS,(int(3.5*1024**3),int(3.5*1024**3)));signal.alarm(240)
from pathlib import Path
import numpy as np
H=Path(__file__).resolve().parent;W=H.parent;started=time.monotonic();S=W/'blind-polycam-varpu-executor-40';sys.path.insert(0,str(S));import run_north as d
f=json.loads((H/'PREFLIGHT_FROZEN.json').read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def verify():
 for p,h in f['files'].items():assert sha(W/p)==h,p
 assert os.statvfs(H).f_bavail*os.statvfs(H).f_frsize>=(768<<20)
verify();available=int(next(x.split()[1]for x in Path('/proc/meminfo').read_text().splitlines()if x.startswith('MemAvailable:')))*1024;assert available>=4.3*1024**3,available
out=H/'preflight-01';out.mkdir(exist_ok=False);motion=d.motion;runtime=motion.serial_vtk();surface,mesh_info,reader=motion.load_surface()
with np.load(d.GAME/'inputs/koivu_5cm_v2_pipeline2_out.npz')as z:level={'R':z['R'],'t':z['t']}
A=np.asarray(json.loads((W/'blind-koivu-faro-acquisition-04/selected-reference/icp_iphone.json').read_text())['gt_transformation']);base=d.OrientedReferenceContainer(surface,motion.transform(level,A),d.BodyGeometry(width=.45,depth=.30,height=1.6,horizontal_margin=0.))
bounds=json.loads((W/'blind-polycam-table-loop-proposals-44/PROPOSED_PHYSICS_BOUNDS.json').read_text());rows=[]
for leg in bounds['perLeg']:
 p=np.array(leg['originalGamePathXYZ']);delta=next(x-p[0]for x in p[1:]if np.linalg.norm((x-p[0])[[0,2]])>.01);yaw=math.atan2(delta[2],delta[0]);probes=base.support_probes(p[0],yaw);check=motion.support_check(probes)
 lo2,hi2=np.array(leg['floorCandidateXZBounds']);lo=np.array([lo2[0],-.25,lo2[1]]);hi=np.array([hi2[0],.25,hi2[1]]);corners=np.array([[x,y,z]for x in(lo[0],hi[0])for y in(lo[1],hi[1])for z in(lo[2],hi[2])]);reference=corners@base.transform[:3,:3].T+base.transform[:3,3];rbounds=np.c_[reference.min(0),reference.max(0)].reshape(-1)
 ids,query=d._ground_setup.find_cells_tiled(base.surface.locator,rbounds,check=base.check,unique_cap=6000000)
 row={'legIndex':leg['legIndex'],'sourceStartXYZ':p[0].tolist(),'sourceInitialYaw':yaw,'supportProbes':probes,'numericSupportCheck':check,'sourceStartIsNotActualActorPose':True,'seedIDs':[int(q['referenceCellID'])for q in probes['probes']if q['hit']],'seedPoints':[[q['modelXZ'][0],q['modelHeightY'],q['modelXZ'][1]]for q in probes['probes']if q['hit']],'gameBounds':np.c_[lo,hi].reshape(-1).tolist(),'candidateCells':len(ids),'candidateIDsSHA256':hashlib.sha256(ids.tobytes()).hexdigest(),'nativeQuery':query,'areaSquareMetres':leg['areaSquareMetres']};rows.append(row);print(json.dumps({'leg':leg['legIndex'],'candidateCells':len(ids),'supportAccepted':check['acceptedFiniteSupportModel']}),flush=True);del ids;gc.collect()
verify();receipt={'scope':'fixed source loop per-leg count/support-anchor preflight; no movement or classifier changes','sourceManifestSHA256':sha(H/'PREFLIGHT_FROZEN.json'),'rows':rows,'allNumericStartsAdmitted':all(x['numericSupportCheck']['acceptedFiniteSupportModel']for x in rows),'allCandidateCountsWithinCap':all(x['candidateCells']<=6000000 for x in rows),'floorPolicy':f['floorPolicy'],'referenceMesh':mesh_info,'runtime':runtime,'availableRAMAtAdmissionBytes':available,'wallSeconds':time.monotonic()-started,'CPUSeconds':resource.getrusage(resource.RUSAGE_SELF).ru_utime+resource.getrusage(resource.RUSAGE_SELF).ru_stime,'peakRSSBytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,'movementExecuted':False,'physicalAuthority':False}
(out/'RESULT.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:receipt[k]for k in ['allNumericStartsAdmitted','allCandidateCountsWithinCap','wallSeconds','peakRSSBytes']}))
