from pathlib import Path
import json,hashlib,math,numpy as np
H=Path(__file__).resolve().parent;W=H.parent;r=json.loads((W/'blind-polycam-table-loop-proposals-44/RESULT.json').read_text());b=json.loads((W/'blind-polycam-table-loop-proposals-44/PROPOSED_PHYSICS_BOUNDS.json').read_text());f=json.loads((W/'blind-polycam-table-loop-proposals-44/FROZEN.json').read_text());base=json.loads((W/'blind-polycam-varpu-executor-40/SELECTED_PLAN.json').read_text());row=next(x for x in r['results']if x['profile']=='body45cmMargin0'and x['nativeConfig']['max_slope']==15.)
assert row['oneTableLapProposal'];legs=[]
for i,q in enumerate(b['perLeg']):
 start=f['anchors'][i]['originalGameXYZ'];goal=f['anchors'][i+1]['originalGameXYZ'];path=[start,*q['originalGamePathXYZ'],goal]
 legs.append({'legIndex':i,'sourceStartOriginalXYZ':start,'originalTaskGoal':goal,'originalFramePath':path,'sourceNativeOriginalFramePath':q['originalGamePathXYZ'],'sourceAnchors':[f['anchors'][i],f['anchors'][i+1]],'floorCandidateXZBounds':q['floorCandidateXZBounds'],'floorCandidateYBounds':q['floorCandidateYBounds']})
start=np.array(legs[0]['sourceStartOriginalXYZ']);p=next(np.array(q)for q in legs[0]['originalFramePath']if np.linalg.norm((q-start)[[0,2]])>.01)
plan={'status':'frozenLoopNominal45SourceProposalOnly','scope':'One source-planned complete table loop, same simulated actor; independent reference collision/support, no physical safety proof','profile':'body45cmMargin0','geometry':base['geometry'],'configuration':'S15_C25mm','sourceResultSHA256':hashlib.sha256((W/'blind-polycam-table-loop-proposals-44/RESULT.json').read_bytes()).hexdigest(),'start':start.tolist(),'initialYawRadians':math.atan2(p[2]-start[2],p[0]-start[0]),'legs':legs,'taskArrivalToleranceMetres':.35,'cornerConsumptionToleranceMetres':.01,'oneLapOnly':True,'sameActorFIFORequired':True,'referenceInputsUsedForSelection':False,'fullRectangleValidated':False,'historicalWesternTaskExclusionRemoved':True,'allPhysicalColliderRulesRetained':True,'sourceMaskFlagsDiagnosticNotVeto':True,'floorPolicy':json.loads((H/'PREFLIGHT_FROZEN.json').read_text())['floorPolicy']}
with np.load(W/'blind-split-candidate-game-03/inputs/koivu_5cm_v2_pipeline2_out.npz')as z:oldR=z['R'];oldt=z['t']
with np.load(W/'blind-pose-experiments-review-17/upstream/pose-consistency/runs/koivu_floorfix/pipeline2_out.npz')as z:newR=z['R'];newt=z['t']
q=np.array(r['tabletopDiagnostic']['centroidGameXYZ']);lev=np.array([q[0],-q[2],q[1]]);old=((lev-newt)@newR)@oldR.T+oldt
plan['tableWindingPointOriginalXYZ']=[float(old[0]),float(old[2]),float(-old[1])];plan['requiredActualWinding']=-1;plan['finalToInitialWindingClosureIsMathematicalNotMotion']=True
(H/'SELECTED_PLAN.json').write_text(json.dumps(plan,indent=2)+'\n')
