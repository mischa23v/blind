# Candidate-only mesh-to-native-planner replay prototype

**Transport parity passed; this is not live iPhone navigation.**
No application files changed, no iOS build, no deployment, no physical movement.
No FARO, downloads, new compiler or raw mesh copy used.

## What was tested

The exact public Polycam room geometry from the existing source acquisition was
split into 32 deterministic synthetic anchor-local tiles. Each had a quarter-turn
rotation, integer translation, session/generation, revision and timestamp. The
new Python adapter transformed those vertices into a single +Y-up metre frame,
then supplied the unchanged triangle geometry to the existing C++ Recast/Detour
library. The same library separately received the original monolithic geometry.

| Check | Result |
|---|---|
| Source vertices / triangles | 18,398 / 29,366 |
| Replayed triangles | 29,366 (none removed or fabricated) |
| Replayed vertices | 20,857; boundary vertices duplicated between tiles |
| Maximum double-coordinate error | 8.881784197001252e-16 m |
| Float32 triangle coordinates | Exactly identical |
| Fixed native route-pair parity | 5 / 5 |
| Authored lifecycle/transform/authority fixtures | 7 / 7 |

Route parity means identical complete/status/error, equal point counts and all
path/projection coordinates within the frozen 1e-5 m threshold. These are the
same five source-map queries, NOT five new movement trials. See RESULT.json for
full paths and timings. Both builds use 45cm-diameter native disc and zero margin,
height1.75m, 2.5cm cells, climb2.5cm, slope15°. These parameters are a comparator,
not a recommended body/safety profile or full-rectangle collision check.

## Implemented prototype contract

`bridge.py` holds tiles by anchor ID, session and generation. Proper rigid
column-vector transforms are validated and applied once. Revised geometry
replaces prior geometry. Duplicate packets do not mutate geometry; stale packets
are ignored; conflicting same revisions quarantine their tile and retain unknown
coverage. Removal, truncation, eviction and metadata-budget exhaustion retain
unknown coverage; they do not certify vacated space as clear. Old receipts become
invalid on session/generation or geometry revision change.

Geometry caps:64 tiles,200,000 retained vertices,256 metadata IDs,128-character
anchor IDs. Unknown reasons are retained conservatively until session reset.
`sourceDeliveryComplete` means only nonempty complete delivery of provided source
geometry, never actual-world coverage. `actualWorldCoverageKnown` is always false.
Every receipt and result has `authorizesPhysicalGuidance=false`. Raw-depth status
is independent and defaults to unknown/veto. This is a tested status gate, NOT a
new real-depth collision analyzer or a live hazard fusion implementation.

## Reproduce without downloads

From the existing workspace:

```
PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 python blind-native-mesh-replay-58/test_bridge.py
PYTHONDONTWRITEBYTECODE=1 python blind-native-mesh-replay-58/replay.py
```

The replay verifies FROZEN.json checksums before execution. It uses existing
`blind-split-candidate-game-03/body-margin-variants-07/native025/` wrapper/library,
`blind-polycam-alignment-feasibility-36/POLYCAM_INTRINSIC_GEOMETRY.npz`, stage37's
phone-only fixed-scale rigid transform and stage44's unchanged frozen anchors.
Exact native binary and inputs are pinned by hash, not copied here. The source
MuSHRoom Polycam data attribution/license remains with its existing acquisition
packet (CC BY 4.0). This artifact contains scripts, metrics and route coordinates,
not photos or raw mesh.

PROTOCOL.md and source/input hashes were frozen before scoring. Initial-v1 keeps
the first successful result and source; a subsequent code review corrected empty
snapshots reporting complete delivery and added metadata caps, then re-froze and
reran the unchanged geometry/route criteria. No hidden route retuning.

## What this establishes / does not establish

It establishes that an anchor-local→world adapter can preserve this room's metric
geometry and native routes without arbitrary rescaling, floor flattening or LLM
geometry decisions. Existing source geometry needs no new mapper for this parity
check. No measurable error was introduced by the tested tile transforms.

It does NOT test actual ARMeshAnchor output, mesh update cadence, real sensor
coverage, unseen objects, small-object recall, phone performance, live raw-depth
hazards, body movement or safe guidance. Synthetic tiling of a complete fused
Polycam model does not reproduce incomplete/time-varying live capture. Nor can a
matrix validator detect input vertices incorrectly labelled with a coordinate
frame: upstream capture ownership and revision association still need checking.

The bridge is Python for research; production Swift/C++ integration remains
missing. Existing app mesh capture truncates geometry and cannot simply be treated
as the complete source tested here. Guidance stays disabled. Next bounded work:
independently review adapter gates, then replay actual recorded ARMeshAnchor
updates with capture-time raw-depth observations; retain unknown coverage and
separate room-map candidate paths from movement authorization.
