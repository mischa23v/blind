# Frozen candidate-only native mesh replay protocol

Before scoring, hash this protocol, bridge, fixtures and replay scripts, existing
native025 Python wrapper/library, Polycam intrinsic geometry, phone-only rigid
transform from stage37, and stage44 frozen anchors. No FARO input.

This tests a proposed adapter, not actual ARKit anchor events or physical safety.
All outputs deny physical guidance. Mesh completeness means only complete delivery
of the provided source geometry, never actual observed room coverage.

Authored cases: rigid transform once; invalid transform rejected; revisions replace
rather than append; stale/duplicate events; conflicting revision quarantines tile;
removal retains unknown; explicit truncation retains unknown; budget eviction stays
unknown; session/generation reset invalidates old path; independent raw hazard veto.

Real case: unchanged Polycam vertices/triangles, existing phone-only rigid transform,
32 contiguous triangle batches, compact tile-local vertices with deterministic
quarter-turn rotations and integer translations. Reconstruct in original batch
order. Compare direct world triangle coordinates to reconstruction (max error <=
1e-9 metres in double, require identical float32 triangle coordinates). Build the
same native library twice using radius .225, height1.75, cell .025, climb .025,
slope15, other existing defaults. Compare five unchanged stage44 anchor-pair routes:
complete/status/error equal; point counts equal; positions/projections <=1e-5m.
Report all results, no threshold changes or route selection after scoring.

Limit: two native builds, 120 CPU seconds, 180 wall seconds, 1GiB address space,
2MiB new output total, 768MiB disk reserve. No raw mesh copies, installs or builds.
This is parity of equivalent geometry, not new room navigation success, collision
recall, streaming efficiency, Swift compilation, actual ARKit data or phone testing.

## Pre-second-run correction (initial results retained in initial-v1)
Code review after the initial six-fixture/parity pass found the empty snapshot
reported complete source delivery, and metadata ledger had no explicit count cap.
Require nonempty tiles for complete source delivery, cap ledger at256 IDs, reject
new IDs beyond cap with unknown coverage, and cap anchor ID length128. Add empty
and budget fixture. Original route criteria/geometry/config remain unchanged.
