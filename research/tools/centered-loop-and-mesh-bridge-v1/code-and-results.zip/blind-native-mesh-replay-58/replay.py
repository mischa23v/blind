import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
import sys,resource,signal,time,json,hashlib,importlib.util,dataclasses
sys.dont_write_bytecode=True
resource.setrlimit(resource.RLIMIT_AS,(1<<30,1<<30));resource.setrlimit(resource.RLIMIT_CPU,(120,120));resource.setrlimit(resource.RLIMIT_FSIZE,(2<<20,2<<20));signal.alarm(180)
from pathlib import Path
import numpy as np
from bridge import MeshReplay
H=Path(__file__).resolve().parent;W=H.parent;start=time.monotonic()
f=json.loads((H/'FROZEN.json').read_text())
for p,h in f['files'].items():assert hashlib.sha256((W/p).read_bytes()).hexdigest()==h,p
assert os.statvfs(H).f_bavail*os.statvfs(H).f_frsize>=768<<20
base=W/'blind-split-candidate-game-03/body-margin-variants-07/native025'
spec=importlib.util.spec_from_file_location('native58',base/'detour_engine.py');de=importlib.util.module_from_spec(spec);sys.modules[spec.name]=de;spec.loader.exec_module(de)
with np.load(W/'blind-polycam-alignment-feasibility-36/POLYCAM_INTRINSIC_GEOMETRY.npz')as z:obj=z['verticesOBJ'];tri=z['triangles']
with np.load(W/'blind-polycam-rigid-registration-37/run-01/CANDIDATE_RIGID_TRANSFORM.npz')as z:level=obj@z['rotationOBJToLevel'].T+z['translationOBJToLevel'];assert z['scale']==1
v=np.c_[level[:,0],level[:,2],-level[:,1]]
s=MeshReplay('synthetic-anchor-replay-of-real-polycam')
rots=[np.eye(3),np.array([[0,0,1],[0,1,0],[-1,0,0]]),np.diag([-1,1,-1]),np.array([[0,0,-1],[0,1,0],[1,0,0]])]
for i,ids in enumerate(np.array_split(np.arange(len(tri)),32)):
 unique,inverse=np.unique(tri[ids],return_inverse=True);r=rots[i%4];translation=np.array([i%5,i%3,-(i%7)],dtype=float);m=np.eye(4);m[:3,:3]=r;m[:3,3]=translation
 s.apply(session=s.session,generation=0,anchor=f'{i:03}',revision=1,timestamp=1+i,vertices=(v[unique]-translation)@r,triangles=inverse.reshape(-1,3),transform=m)
rv,rt=s.geometry();delta=float(abs(v[tri]-rv[rt]).max());same32=bool(np.array_equal(v[tri].astype(np.float32),rv[rt].astype(np.float32)))
points=np.array([a['registeredGameXYZ'] for a in json.loads((W/'blind-polycam-table-loop-proposals-44/FROZEN.json').read_text())['anchors']])
cfg=de.Config(radius=.225,height=1.75,cell_size=.025,max_climb=.025,max_slope=15.)
results=[]
for vv,tt in [(v,tri),(rv,rt)]:
 with de.Engine(vv,tt,cfg,mode='known-provided-map')as engine:
  results.append([dataclasses.asdict(engine.route(a,b,query_half_extents=(.2,.3,.2),max_points=256))for a,b in zip(points[:-1],points[1:])])
rows=[]
for i,(a,b)in enumerate(zip(*results)):
 shape=len(a['points'])==len(b['points']);errors={}
 for key in ['points','projected_start','projected_goal']:
  aa=np.asarray(a[key]);bb=np.asarray(b[key]);errors[key]=float(np.max(abs(aa-bb)))if aa.size and aa.shape==bb.shape and np.isfinite(aa).all()and np.isfinite(bb).all()else None
 sameflags=all(a[k]==b[k]for k in ['complete','status','error']);passed=shape and sameflags and all(x is not None and x<=1e-5 for x in errors.values())
 rows.append(dict(pair=i,passed=passed,maximumCoordinateErrors=errors,monolithic=a,replayed=b))
result=dict(scope='synthetic ARMeshAnchor-like transport of real public Polycam source geometry; not live ARKit',geometry=dict(sourceVertices=len(v),sourceTriangles=len(tri),tiles=32,replayedVertices=len(rv),replayedTriangles=len(rt),maxDoubleError=delta,float32TriangleCoordinatesIdentical=same32,passed=delta<=1e-9 and same32),config=dataclasses.asdict(cfg),routes=rows,parityPassed=bool(delta<=1e-9 and same32 and all(r['passed']for r in rows)),coverage=s.receipt(),rawDepthOverlayTestedOnRealStream=False,referenceDataUsed=False,physicalMovementExecuted=False,authorizesPhysicalGuidance=False,wallSeconds=time.monotonic()-start,peakRSSKiB=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
(H/'RESULT.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n');print(json.dumps({k:v for k,v in result.items()if k!='routes'}));print('route parity',[(r['pair'],r['passed'])for r in rows])
assert sum(p.stat().st_size for p in H.rglob('*')if p.is_file())<=2<<20
