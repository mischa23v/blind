import unittest,numpy as np
from bridge import MeshReplay
class Tests(unittest.TestCase):
 def packet(self,**kw):
  p=dict(session='s',generation=0,anchor='a',revision=1,timestamp=1.,vertices=[[0,0,0],[1,0,0],[0,0,1]],triangles=[[0,2,1]],transform=np.eye(4));p.update(kw);return p
 def test_transform_once(self):
  s=MeshReplay('s');m=np.array([[0,0,1,3],[0,1,0,2],[-1,0,0,4],[0,0,0,1]])
  s.apply(**self.packet(transform=m));v,f=s.geometry();np.testing.assert_array_equal(v,[[3,2,4],[3,2,3],[4,2,4]])
 def test_rigid_validation(self):
  for m in [np.diag([2,1,1,1]),np.diag([-1,1,1,1]),np.full((4,4),np.nan)]:
   with self.assertRaises(ValueError):MeshReplay('s').apply(**self.packet(transform=m))
 def test_replacement_stale_duplicate_conflict(self):
  s=MeshReplay('s');p=self.packet();self.assertEqual(s.apply(**p),'accepted');e=s.epoch
  self.assertEqual(s.apply(**p),'duplicate');self.assertEqual(s.epoch,e)
  self.assertEqual(s.apply(**self.packet(revision=0,timestamp=.5)),'stale')
  s.apply(**self.packet(revision=2,timestamp=2,vertices=[[0,0,0],[2,0,0],[0,0,2]]));self.assertEqual(len(s.geometry()[0]),3)
  self.assertEqual(s.apply(**self.packet(revision=2,timestamp=2)),'conflict');self.assertEqual(len(s.geometry()[0]),0);self.assertFalse(s.receipt()['sourceDeliveryComplete'])
 def test_removal_truncation_eviction_unknown(self):
  s=MeshReplay('s',max_tiles=1);s.apply(**self.packet());old=s.receipt()
  s.apply(**self.packet(anchor='b',complete=False));self.assertFalse(s.ticket_current(old));self.assertIn('evicted:a',s.receipt()['unknownCoverage']);self.assertIn('truncated:b',s.receipt()['unknownCoverage'])
  s.apply(**self.packet(anchor='b',revision=2,timestamp=2,removed=True));self.assertIn('removed:b',s.receipt()['unknownCoverage']);self.assertFalse(s.receipt()['sourceDeliveryComplete'])
 def test_reset_fences(self):
  s=MeshReplay('s');s.apply(**self.packet());t=s.receipt();s.reset('s',1);self.assertFalse(s.ticket_current(t));self.assertEqual(s.apply(**self.packet()),'wrong-session')
 def test_raw_hazard_independent(self):
  s=MeshReplay('s');s.apply(**self.packet())
  for h in ('clear','unknown','hazard'):
   r=s.receipt(h);self.assertFalse(r['authorizesPhysicalGuidance']);self.assertEqual(r['rawHazardVeto'],h!='clear');self.assertFalse(r['actualWorldCoverageKnown'])
if __name__=='__main__':unittest.main(verbosity=2)
