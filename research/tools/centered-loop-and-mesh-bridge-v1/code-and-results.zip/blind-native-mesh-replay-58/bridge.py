"""Research-only ARMeshAnchor-like replay. Not an iOS runtime or safety authority."""
import hashlib
import numpy as np

class MeshReplay:
    def __init__(self,session,generation=0,max_tiles=64,max_vertices=200000,max_records=256,max_triangles=100000):
        self.validate_frame(session,generation)
        for value,limit in [(max_tiles,64),(max_vertices,200000),(max_records,256),(max_triangles,100000)]:
            if type(value)!=int or not 1<=value<=limit:raise ValueError('budget')
        self.max_triangles=max_triangles
        self.session=session; self.generation=generation; self.max_tiles=max_tiles
        self.max_records=max_records; self.max_vertices=max_vertices; self.tiles={}; self.ledger={}; self.unknown=set(); self.epoch=0
    @staticmethod
    def validate_frame(session,generation):
        if not isinstance(session,str) or not 1<=len(session)<=128 or type(generation)!=int or not 0<=generation<2**63:raise ValueError('frame identity')
    def reset(self,session,generation):
        self.validate_frame(session,generation)
        if session==self.session and generation<=self.generation: raise ValueError('generation must advance')
        self.session=session;self.generation=generation;self.tiles.clear();self.ledger.clear();self.unknown.clear();self.epoch+=1
    def apply(self,*,session,generation,anchor,revision,timestamp,vertices=None,triangles=None,transform=None,complete=True,removed=False):
        if session!=self.session or generation!=self.generation:return 'wrong-session'
        if not isinstance(anchor,str) or not anchor or type(revision)!=int or not 0<=revision<2**63 or not np.isfinite(timestamp) or timestamp<0:raise ValueError('metadata')
        if type(complete)!=bool or type(removed)!=bool:raise ValueError('flags')
        if len(anchor)>128:raise ValueError('anchor length')
        if anchor not in self.ledger and len(self.ledger)>=self.max_records:
            self.unknown.add('metadata-budget');self.epoch+=1;return 'metadata-budget'
        if removed:
            payload=None; digest=hashlib.sha256(b'removed').hexdigest()
        else:
            if len(vertices)>self.max_vertices or len(triangles)>self.max_triangles:raise ValueError('geometry budget')
            v=np.array(vertices,dtype=np.float64,copy=True); raw=np.asarray(triangles)
            if raw.dtype.kind not in 'iu':raise ValueError('indices must be integers')
            f=np.array(raw,dtype=np.int64,copy=True);m=np.array(transform,dtype=np.float64,copy=True)
            if v.ndim!=2 or v.shape[1]!=3 or f.ndim!=2 or f.shape[1]!=3 or len(v)>self.max_vertices or not np.isfinite(v).all():raise ValueError('geometry')
            if len(f) and (f.min()<0 or f.max()>=len(v)):raise ValueError('indices')
            if m.shape!=(4,4) or not np.isfinite(m).all() or not np.allclose(m[3],[0,0,0,1],atol=1e-10,rtol=0) or not np.allclose(m[:3,:3].T@m[:3,:3],np.eye(3),atol=1e-10,rtol=0) or abs(np.linalg.det(m[:3,:3])-1)>1e-10:raise ValueError('rigid transform')
            digest=hashlib.sha256(v.tobytes()+f.tobytes()+m.tobytes()+bytes([complete])).hexdigest()
            payload=(v@m[:3,:3].T+m[:3,3],f) # exactly one local-to-world transform
        previous=self.ledger.get(anchor)
        if previous:
            oldrev,oldtime,oldhash=previous
            if revision<oldrev or timestamp<oldtime:return 'stale'
            if revision==oldrev:
                if digest==oldhash and timestamp==oldtime:return 'duplicate'
                self.tiles.pop(anchor,None);self.unknown.add('conflict:'+anchor);self.epoch+=1;return 'conflict'
            if timestamp==oldtime:raise ValueError('new revision needs newer capture')
        self.ledger[anchor]=(revision,timestamp,digest);self.epoch+=1
        if removed:
            self.tiles.pop(anchor,None);self.unknown.add('removed:'+anchor);return 'removed'
        self.tiles[anchor]=payload
        if len(payload[0])==0 or len(payload[1])==0:self.unknown.add('empty:'+anchor)
        if not complete:self.unknown.add('truncated:'+anchor)
        while len(self.tiles)>self.max_tiles or sum(len(x[0]) for x in self.tiles.values())>self.max_vertices or sum(len(x[1]) for x in self.tiles.values())>self.max_triangles:
            key=next(iter(self.tiles));self.tiles.pop(key);self.unknown.add('evicted:'+key)
        return 'accepted'
    def geometry(self):
        vs=[];fs=[];n=0
        for key in sorted(self.tiles):
            v,f=self.tiles[key];vs.append(v);fs.append(f+n);n+=len(v)
        return (np.concatenate(vs) if vs else np.empty((0,3)),np.concatenate(fs) if fs else np.empty((0,3),dtype=np.int64))
    def receipt(self,raw_hazard='unknown'):
        if raw_hazard not in ('unknown','clear','hazard'):raise ValueError('hazard')
        return dict(session=self.session,generation=self.generation,epoch=self.epoch,
                    unknownCoverage=sorted(self.unknown),sourceDeliveryComplete=bool(self.tiles) and all(len(v)>0 and len(f)>0 for v,f in self.tiles.values()) and not self.unknown,
                    actualWorldCoverageKnown=False,rawDepthHazard=raw_hazard,
                    rawHazardVeto=raw_hazard!='clear',authorizesPhysicalGuidance=False)
    def ticket_current(self,ticket):
        return (ticket['session'],ticket['generation'],ticket['epoch'])==(self.session,self.generation,self.epoch)
