# Live iPhone mesh → room planner integration audit

Read-only inspection, 2026-10-26. Pinned repository: mischa23v/blind at
`51bf9c5c13144d1b9a288e6ffb5078a4dca3fcba`. No app changes, deployment,
iOS build, physical trials or external publication performed.

## Conclusion

ARKit scene mesh capture already exists. The live local planner does not consume
that mesh: it uses one raw-depth observation with a 1.8 m horizon. Room-scale
mesh routing is a missing integration, not a missing sceneReconstruction flag.
Offline room-route results do not establish that integration or device safety.

All source references below are relative to the pinned repository. GitHub base:
https://github.com/mischa23v/blind/blob/51bf9c5c13144d1b9a288e6ffb5078a4dca3fcba/

## Verified source interfaces

* `ios/BlindAssist/NativeARObservationAdapter.swift:11-18`: enables supported
  meshWithClassification, otherwise mesh. `:26-28`: full column-major matrix
  serialization. `:60-100`: captures raw sceneDepth and plane/mesh surfaces.
  `:153-155,196-198`: retains anchor-local vertices with localToSessionWorld.
* `ios/BlindAssist/NavigationModel.swift:950-1055`: launch and scan recovery use
  gravity alignment, sceneDepth, horizontal plane detection and the adapter's
  mesh configuration. `:1273-1305`: raw-depth urgent detector runs before body
  collision assessment and nonurgent ObservedSceneRuntime work.
* `ios/BlindAssist/NativeARObservationBridge.swift:58-92`: historical snapshot
  and capture pipeline. Mesh capture goes into observation history, not Recast.
* `ios/BlindAssist/ObservedSceneRuntime.swift:38-43,66-87`: session/tracking
  fences, expiry after 0.5 s, and asynchronous current-observation planning.
* `BlindCore/Sources/BlindCore/ObservedScene.swift:24,36`: snapshot and plan
  authorizesPhysicalGuidance are false. `:187-193`: LocalPlanner receives only
  the current observation and body.radius + body.margin.
* `BlindCore/Sources/BlindCore/LocalPlanner.swift:21-65`: candidate-only,
  20 cm grid, 1.8 m horizon, fixed floor, fresh normal tracking, confidence-2
  samples, at least three returns per cell and every height within ±9 cm.
  Unknown footprint cells block. This is not full-room mesh planning.
* `ios/BlindAssist/NativeMapping.swift:5,33,92,100,155-182`: RTAB-Map is
  conditional on BLIND_RTABMAP. Tracking loss retires its coordinate generation;
  capture is fresh within 0.5 s and limited to 2 Hz.
* `BlindCore/Sources/BlindCore/NativeLocalGrid.swift:29-39,64-90,131-210`:
  node-local RTAB cells, Z-up map coordinates, full rigid transforms and pose
  lease checks. authorizesPhysicalGuidance is false at line 90. This consumer
  retains upstream grids; it does not infer support or make routes.
* `ios/BlindAssist/RegisteredIndoorNavigation.swift:216-255`: registered-route
  owner, replanning/restrictions and output retirement on loss of evidence.
* `BlindCore/Sources/BlindCore/SpatialRouteOwner.swift:245-274`: route output
  requires matching map/floor/session/capture support, freshness, route-leg
  association, uncertainty-inflated body and map/surface collision checks.
* `BlindCore/Package.swift`: Swift targets only; no Recast C/C++ target.
  Existing native source is under `tools/navigation-recast/`, including
  blind_detour.h/.cpp and detour_engine.py. That is not an iOS linkage proof.

## Capture is deliberately incomplete

Adapter lines 65-92 inspect only the first 128 anchors before filtering, sort
selected surface anchors by UUID, retain at most 32 surfaces and 2,048 vertices.
Lines 175-198 take first min(face count,512,remainingVertices/3) mesh faces.
It does not rotate through faces for complete coverage. Early anchors/faces can
repeatedly consume the budget and starve other geometry; planes share the budget.
Truncation is recorded. Missing triangles MUST NOT be interpreted as open space.
A historical partial snapshot is not a full incremental mesh lifecycle owner.

## Smallest isolated, candidate-only prototype

Do not modify application capture or physical-authority flags. Build a research
adapter that accepts explicit session ID, anchor ID/revision, timestamp, rigid
anchor-to-session matrix, local triangles, completeness and removal events.
Maintain a bounded nearby tile set. Replace rather than append revised anchors;
retire paths on geometry/session revision. Incomplete or evicted coverage remains
unknown. Avoid mixing RTAB node-local Z-up cells with ARKit session-world data.

Transform each mesh vertex exactly once into a chosen +Y-up metre frame and pass
triangles to the existing bn_build/bn_path C interface. Output candidate path,
projected query endpoints, completeness, source revisions and coverage status.
Never teleport start/goal to Detour projections or use absent triangles as free.
The first implementation can rebuild a bounded tile set; it need not introduce
an untested incremental Recast tile system. Preserve native raw-depth hazards as
an independent veto/uncertainty overlay, never erase them using smooth mesh.
The bridge must not issue SpatialLocalizationCapture or physical route leases.

### Bounded replay acceptance tests

1. Identity, translation and rotation transform fixtures match direct world
   vertices; reject nonfinite/nonrigid transforms and double-transformation.
2. Same complete geometry fed once vs through anchor replacement events gives
   matching candidate endpoints/connectivity within documented numeric tolerance.
3. Updating/removing a doorway or obstacle retires old route revision. Reordered,
   duplicate or stale packets and session resets cannot revive stale paths.
4. Truncated anchors, evicted regions and unobserved support remain unresolved;
   removing a triangle must not manufacture a safety claim.
5. Raw-depth low obstacle/overhang veto remains present when mesh is smooth.
6. Native route partial/truncated status and query projection offsets survive
   adapter serialization. No complete-route claim from a partial result.
7. Replay existing public room geometry with the same body parameters and mesh
   as the direct native baseline. Record parity separately from physical safety.

## Local feasibility, checked 2026-10-26

`g++` is Debian 14.2.0. Swift, clang++ and cmake were not on PATH. Existing
`blind-clearance-centered-loop-55/libblind_detour.so` successfully loaded using
Python ctypes (load test only, no path test in this audit). Existing C++ wrapper,
Python wrapper and upstream source are under `blind-authored-navigation-pilot/native/`;
other baseline variants exist, so pin wrapper/library hashes before reuse.
The interface declares +Y up/metres, bn_build and bn_path with explicit complete
flag and projected endpoints. Linux C++/Python replay is possible without large
downloads. Swift/ARKit compilation and phone performance are not testable here
with the presently available toolchain. No compiler installation attempted.
Disk before audit: 786 MiB free; reserve 768 MiB. This document is the only new
artifact, under 8 KiB. No source snapshot copies or build artifacts created.

## Official API confirmation

Apple documents anchor-local mesh geometry and reconstruction with plane data:
https://developer.apple.com/documentation/arkit/armeshanchor/geometry
https://developer.apple.com/documentation/arkit/visualizing-and-interacting-with-a-reconstructed-scene

Smoothing/classification are reconstruction aids, not proof of floor support or
absence of small objects. Device latency, thermal load, tracking recovery,
complete collision coverage and supervised real-world performance remain open.
