// swift-tools-version: 5.9
import PackageDescription
let package = Package(name:"BlindCore",products:[.library(name:"BlindCore",targets:["BlindCore"])],targets:[.target(name:"BlindCore",resources:[.copy("Resources/guide-prompt.txt")]),.testTarget(name:"BlindCoreTests",dependencies:["BlindCore"])])
