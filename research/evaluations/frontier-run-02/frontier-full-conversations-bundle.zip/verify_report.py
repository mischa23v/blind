#!/usr/bin/env python3
"""Read-only verification of the completed run and generated conversation report."""
import json, hashlib, pathlib, collections
root=pathlib.Path(__file__).resolve().parent
rows=[json.loads(l) for l in (root/'frontier-eval-02-frozen.jsonl').read_text().splitlines()]
report=json.loads((root/'frontier-full-conversations.json').read_text())
md=(root/'frontier-full-conversations.md').read_text()
assert report['exact_call_ledger']==rows
previous='0'*64
for n,r in enumerate(rows,1):
 signed=dict(r); digest=signed.pop('entry_sha256')
 assert digest==hashlib.sha256(json.dumps(signed,sort_keys=True,separators=(',',':')).encode()).hexdigest()
 assert r['sequence']==n and r['previous_sha256']==previous
 previous=digest
assert hashlib.sha256((root/'frontier-eval-02-frozen.jsonl').read_bytes()).hexdigest()==report['source_trace_sha256']
turns=report['turns'];assert len(turns)==23
accepted=[];rejected=[]
for t in turns:
 assert t['authored_utterance'] in md
 r=rows[t['input_sequence']-1]
 assert r['request']['op']=='next_user' and not r['response']['result'].get('done')
 assert r['response']['state']==t['input_state']
 assert t['accepted_deliveries']
 for collection,key in [(accepted,'accepted_deliveries'),(rejected,'rejected_candidates')]:
  for d in t[key]:
   r=rows[d['sequence']-1];res=r['response']['result']
   assert d['delivered']==res['delivered']
   assert d['text']==(res['text'] if res['delivered'] else r['request']['value'])
   assert d['text'] in md
   collection.append(d)
assert len(accepted)==23 and len(rejected)==4
assert collections.Counter(x['owner'] for x in accepted)=={'code':9,'frontier evaluation agent':14}
assert [x['sequence'] for x in rejected]==[41,59,62,63]
assert sum(r['response']['result'].get('done',False) for r in rows)==4
assert len(rows)==79
for r in rows:
 s=r['response']['state']
 assert s['image_ids']==[] and s['pose_id'] is None and s['sensor_evidence']=='NONE'
assert rows[36]['response']['state']['task_state']=='active'
assert rows[37]['response']['state']['task_state']=='needsHelp'
assert md.count('#### Turn ')==23
assert md.count('ACCEPTED AND DELIVERED (call ')==23
assert md.count('NOT DELIVERED (call ')==4
assert md.count('### Call ')==79
receipt=json.loads((root/'run-02-reviewed-freeze-receipt.json').read_text())
for name,digest in receipt['files'].items():
 p=root/name
 if p.exists(): assert hashlib.sha256(p.read_bytes()).hexdigest()==digest,name
assert len((root/'frontier-eval-01.jsonl').read_text().splitlines())==2
print('VERIFIED: 4 completed text episodes; 23 authored inputs and exact accepted replies; 9 code / 14 model; 4 rejected NOT DELIVERED; 79 calls; hash chain intact; original 14 PASS / 1 FAIL retained; run 01 separate.')
