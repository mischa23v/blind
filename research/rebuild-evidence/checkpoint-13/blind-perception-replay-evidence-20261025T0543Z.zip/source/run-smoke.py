"""Bounded existing YuNet/SFace API smoke, not independent recognition accuracy.
No network, user photos, saved embeddings, gallery writes, threshold tuning or native claim.
"""
import sys,pathlib,time,json,hashlib
import cv2,numpy as np
sys.path.insert(0,'/workspace/shared/blind-rebuild/tools/face-evaluation')
from image_smoke import checked_file,MODEL_FILES
root=pathlib.Path('/workspace/shared/blind-perception-private-replay')
assert cv2.__version__=='4.14.0'
cv2.setNumThreads(1)
models={name:checked_file(root,'models/'+name,sha) for name,sha in MODEL_FILES.items()}
image=checked_file(root,'fixtures/astronaut.png','88431cd9653ccd539741b555fb0a46b61558b301d4110412b5bc28b5e3ea6cb5')
bgr=cv2.imread(str(image));assert bgr is not None and bgr.shape==(512,512,3)
detector=cv2.FaceDetectorYN.create(str(models['face_detection_yunet_2023mar.onnx']),'',(320,320),.9,.3,5000)
recognizer=cv2.FaceRecognizerSF.create(str(models['face_recognition_sface_2021dec.onnx']),'')
# Protocol frozen in source before observing scores. All positives are SAME source capture;
# synthetic derivative images do not form held-out tests or unknown identity controls.
checker=np.indices((512,512)).sum(axis=0)//16%2*255
cases=[('source',bgr),('same-image-repeat',bgr.copy()),('dimmed-same-source',(bgr.astype(np.float32)*.8).astype(np.uint8)),('grayscale-same-source',cv2.cvtColor(cv2.cvtColor(bgr,cv2.COLOR_BGR2GRAY),cv2.COLOR_GRAY2BGR)),('blurred-same-source',cv2.GaussianBlur(bgr,(5,5),1.2)),('blank',np.zeros_like(bgr)),('checkerboard',np.repeat(checker.astype(np.uint8)[:,:,None],3,axis=2)),('duplicated-photo-two-face-composite',np.concatenate([bgr,bgr],axis=1))]
unknown_path=checked_file(root,'fixtures/unknown-public-portrait.jpg','a8ca6d734765703b09728ab47fe59f473d93ae3967fc24c7c0288c3c7adb7130')
unknown=cv2.imread(str(unknown_path));assert unknown is not None
cases.append(('different-public-source-not-enrolled',unknown))
observations=[];reference=None
for name,pixels in cases:
 start=time.perf_counter();h,w=pixels.shape[:2];scale=min(1,1024/max(h,w));pixels=cv2.resize(pixels,(round(w*scale),round(h*scale)))
 detector.setInputSize((pixels.shape[1],pixels.shape[0]));_,faces=detector.detect(pixels)
 count=0 if faces is None else len(faces)
 row={'case':name,'facesDetected':count,'size':[pixels.shape[1],pixels.shape[0]],'comparisons':[]}
 if faces is not None:
  for index,face in enumerate(faces):
   finite=bool(np.isfinite(face).all());x,y,fw,fh=face[:4];bounds=bool(finite and x>=0 and y>=0 and fw>0 and fh>0 and x+fw<=pixels.shape[1] and y+fh<=pixels.shape[0])
   landmarks=bool(bounds and all(x<=face[k]<=x+fw and y<=face[k+1]<=y+fh for k in range(4,14,2)))
   entry={'index':index,'validNativeBoundsAndLandmarks':landmarks,'nativePassiveMinimumSize':bool(fw>=80 and fh>=80)}
   if landmarks:
    aligned=recognizer.alignCrop(pixels,face);assert aligned.shape==(112,112,3) and aligned.dtype==np.uint8
    feature=recognizer.feature(aligned).copy();assert feature.size==128 and np.isfinite(feature).all() and np.linalg.norm(feature)>0
    entry['dimension']=int(feature.size)
    if name=='source':
     assert count==1;reference=feature.copy()
    if reference is not None:
     score=float(recognizer.match(feature.copy(),reference.copy(),cv2.FaceRecognizerSF_FR_COSINE));assert np.isfinite(score)
     entry['cosineToSameSource']=max(-1.,min(1.,score))
   row['comparisons'].append(entry)
 row['cpuMilliseconds']=(time.perf_counter()-start)*1000
 observations.append(row)
checks=[]
def check(value,label):
 checks.append({'check':label,'passed':bool(value)})
check(observations[0]['facesDetected']==1,'Original inspected public fixture produces one face')
check(observations[1]['facesDetected']==1,'Exact-repeat source produces one face')
check(all(o['facesDetected']==0 for o in observations if o['case'] in ['blank','checkerboard']),'Blank and checkerboard produce no face')
check(next(o for o in observations if o['case']=='duplicated-photo-two-face-composite')['facesDetected']==2,'Duplicated photograph exposes two detections')
check(observations[-1]['facesDetected']==1,'One different public portrait produced a face for rejection check')
check(observations[1]['comparisons'][0].get('cosineToSameSource',0)>.999,'Repeat embedding self-comparison deterministic')
report={'status':'BOUNDED API SMOKE, NOT ACCURACY/APP/CHILD/IOS VALIDATION','opencv':cv2.__version__,'numpy':np.__version__,'threads':cv2.getNumThreads(),'modelHashes':MODEL_FILES,'fixtureSHA256':hashlib.sha256(image.read_bytes()).hexdigest(),'fixtureLicense':'NASA public-domain fixture per scikit-image data documentation','unknownFixtureSHA256':hashlib.sha256(unknown_path.read_bytes()).hexdigest(),'unknownFixtureSource':'Existing matplotlib sample_data/grace_hopper.jpg; U.S. Navy public-domain portrait by James S. Davis; https://commons.wikimedia.org/wiki/File:Grace_Hopper.jpg','fixtureLicenseSource':'https://scikit-image.org/docs/0.24.x/api/skimage.data.html#skimage.data.astronaut','protocol':'One source capture and same-source transforms; one different public portrait for a bounded unknown rejection check, no held-out accuracy denominator, no tuning. App mean-of-3-to-6 enrollment is NOT exercised.','limits':['Python APIs share upstream models/alignment/recognizer with native adapter but do not execute Objective-C++/CoreGraphics/ARKit/Vision/PhotosPicker or prove channel/orientation parity.','Only one source gallery and one different adult portrait; no independent capture of the enrolled subject, no representative unknown-person population or demographic evaluation.','No raw embeddings or aligned faces saved.','CPU times here do not measure phone latency, battery, thermal or once-per-encounter speech.'],'observations':observations,'checks':checks}
(root/'evidence/face-api-smoke.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'checks':checks,'observations':observations},indent=2))
assert all(c['passed'] for c in checks)
