import urllib.request,hashlib,json,pathlib,time
r=pathlib.Path('/workspace/shared/blind-perception-private-replay')
assets=[('downloads/opencv_python_headless-4.14.0.94-cp37-abi3-manylinux2014_x86_64.manylinux_2_17_x86_64.whl','https://files.pythonhosted.org/packages/de/06/14c8c5d331bc72738683a9b227966aceaa4c6d08752f33d64578aebcb6f8/opencv_python_headless-4.14.0.94-cp37-abi3-manylinux2014_x86_64.manylinux_2_17_x86_64.whl',57534165,'5e02669eac0ba67b2a22d7245af1e8ee1a2ef1185ee526a063d8f0555224bd52'),('models/face_detection_yunet_2023mar.onnx','https://media.githubusercontent.com/media/opencv/opencv_zoo/main/models/face_detection_yunet/face_detection_yunet_2023mar.onnx',232589,'8f2383e4dd3cfbb4553ea8718107fc0423210dc964f9f4280604804ed2552fa4'),('models/face_recognition_sface_2021dec.onnx','https://media.githubusercontent.com/media/opencv/opencv_zoo/main/models/face_recognition_sface/face_recognition_sface_2021dec.onnx',38696353,'0ba9fbfa01b5270c96627c4ef784da859931e02f04419c829e83484087c34e79')]
receipts=[]
for path,url,size,digest in assets:
 dest=r/path
 if dest.exists() and len(dest.read_bytes())==size and hashlib.sha256(dest.read_bytes()).hexdigest()==digest:
  print('verified existing',path,flush=True)
 else:
  tmp=dest.with_suffix(dest.suffix+'.partial');count=0; h=hashlib.sha256();start=time.monotonic()
  with urllib.request.urlopen(url,timeout=90) as response, tmp.open('wb') as out:
   while block:=response.read(1024*1024):
    count+=len(block)
    if count>size: raise ValueError('size limit exceeded')
    out.write(block);h.update(block)
  assert count==size,(count,size)
  assert h.hexdigest()==digest,(h.hexdigest(),digest)
  tmp.replace(dest);print('download verified',path,count,round(time.monotonic()-start,2),flush=True)
 receipts.append({'path':path,'url':url,'bytes':size,'sha256':digest})
 (r/'evidence/acquisition.json').write_text(json.dumps(receipts,indent=2)+'\n')
print('verified total',sum(a[2] for a in assets),flush=True)
