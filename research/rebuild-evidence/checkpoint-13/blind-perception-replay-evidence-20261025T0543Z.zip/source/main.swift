import Foundation
let root = URL(fileURLWithPath: "/workspace/shared/blind-perception-private-replay")
let payload = try Data(contentsOf: root.appendingPathComponent("evidence/face-api-smoke.json"))
let report = try JSONSerialization.jsonObject(with: payload) as! [String: Any]
let rows = report["observations"] as! [[String: Any]]
let configuration = FamiliarModelConfiguration.selected
precondition(configuration.backendKind == "sface" && configuration.cosineThreshold == 0.7 && configuration.minimumMargin == 0.2)
let id = UUID(uuidString:"00000000-0000-0000-0000-000000000001")!
var checks=0
func check(_ value: @autoclosure ()->Bool,_ text:String) { precondition(value(),text); checks += 1 }
func scores(_ row: [String:Any])->[(id:UUID,cosine:Double)] {
    (row["comparisons"] as! [[String:Any]]).compactMap { ($0["cosineToSameSource"] as? Double).map { (id,$0) } }
}
for row in rows.prefix(5) {
    let values = scores(row)
    check(values.count==1,"Source-derived detection supplies one real comparison")
    check(FamiliarFacePolicy.candidate(scores:values,cosineThreshold:configuration.cosineThreshold,minimumMargin:configuration.minimumMargin)==id,"Existing selected policy receives actual model score")
}
let duplicate = rows.first { $0["case"] as? String == "duplicated-photo-two-face-composite" }!
let duplicateNames=scores(duplicate).map { value in FamiliarFacePolicy.candidate(scores:[value],cosineThreshold:configuration.cosineThreshold,minimumMargin:configuration.minimumMargin) }
check(duplicateNames.count==2,"Real two-face composite produced two candidates")
check(FamiliarFaceBatchPolicy.uniqueCandidates(duplicateNames).allSatisfy{$0==nil},"Duplicate same-source faces abstain instead of assigning the same identity twice")
for row in rows where ["blank","checkerboard"].contains(row["case"] as! String) {
    check(FamiliarFacePolicy.candidate(scores:scores(row),cosineThreshold:configuration.cosineThreshold,minimumMargin:configuration.minimumMargin)==nil,"No actual face result cannot create a name")
}
let unknown = rows.first { $0["case"] as? String == "different-public-source-not-enrolled" }!
check(scores(unknown).count==1,"Actual different public portrait supplies one comparison")
check(FamiliarFacePolicy.candidate(scores:scores(unknown),cosineThreshold:configuration.cosineThreshold,minimumMargin:configuration.minimumMargin)==nil,"Frozen existing policy abstains on this one unknown fixture")
let actual=FamiliarFacePolicy.candidate(scores:scores(rows[0]),cosineThreshold:configuration.cosineThreshold,minimumMargin:configuration.minimumMargin)!
var encounters=FamiliarEncounterPolicy()
check(encounters.observe([actual],detectedFaces:1,now:100).isEmpty,"One actual matched observation is not an encounter notice")
check(encounters.observe([actual],detectedFaces:1,now:100).isEmpty,"Replay timestamp cannot create a notice")
check(encounters.observe([actual],detectedFaces:1,now:100.75).isEmpty,"Replay invalidated evidence; fresh first observation needed")
check(encounters.observe([actual],detectedFaces:1,now:101.5)==[id],"Two new frames may propose tentative notice")
encounters.markAnnounced(id)
check(encounters.observe([actual],detectedFaces:1,now:102.25).isEmpty,"Same encounter does not repeat")
encounters.invalidateEvidence()
_ = encounters.observe([actual],detectedFaces:1,now:200)
check(encounters.observe([actual],detectedFaces:1,now:200.75).isEmpty,"Camera gap does not reset delivered-notice latch")
check(!FamiliarFacePolicy.fresh(capturedAt:100,now:102,frameAt:102),"Old successful inference cannot become current identity")
print("\(checks) existing Swift policy checks against actual OpenCV model scalar outputs passed; no accuracy claim")
