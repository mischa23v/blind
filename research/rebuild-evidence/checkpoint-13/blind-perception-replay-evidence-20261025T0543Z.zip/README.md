# Pinned YuNet/SFace actual CPU replay

2026-10-25. This is an asset-readiness and bounded execution addendum to the frozen automatic-perception source proposal, not a replacement for it. User permission for the specified roughly97MB model/runtime set was confirmed by parent before acquisition. No iOS framework, AuraFace, general Detector or large dataset was downloaded.

## Verified action and outcome

- Downloaded and SHA256-verified exactly the pre-existing pinned YuNet232,589B, SFace38,696,353B and OpenCV headless4.14.0.94 wheel57,534,165B: total96,463,107 bytes. Official artifact URLs/hashes in logs/acquisition.json; official model license texts retained.
- Installed wheel with --no-index --no-deps --target into /workspace/shared/blind-perception-private-replay/runtime only. Existing numpy2.3.5 satisfies numpy>=2, unchanged. Runtime reports OpenCV4.14.0; CPU single-thread chosen as native adapter already does. No Docker, global installs, GUI/contrib packages or paid service.
- Downloaded one small scikit-image NASA public-domain portrait fixture791,555B, with source/hash receipt. Inspected pixels before testing. Reused an already-installed Matplotlib public-domain Navy portrait as one different source after inspecting it. No personal/child/family images, uploads, saved aligned faces or saved embeddings.
- Actual existing FaceDetectorYN(.9,.3,5000), FaceRecognizerSF.alignCrop/feature/match(FR_COSINE) APIs ran using pinned models. Python preprocessing follows documented BGR/max1024 route; bounds/landmark checks mirror native expectations. This does NOT execute the Objective-C++ CGImage conversion, Apple Vision or iOS app.
- Nine input cases, six bounded API smoke checks passed. NASA source/repeat/dim/grayscale/blur derivatives yielded one face each; blank and checkerboard zero; duplicate-source composite two; separate Navy portrait one. All extracted embeddings were finite/nonzero128D, not serialized.
- Existing actual Swift FamiliarFacePolicy, FamiliarEncounterPolicy and FamiliarModelConfiguration executed on scalar model outputs:23 checks passed. Frozen SFace threshold0.7 and margin0.2 unchanged. One separate portrait scored0.151916951 versus the reference and abstained; duplicate same-reference detections abstain through uniqueCandidates; encounter latch/replayed timestamp/old evidence rules exercised.

## Strict evidence limits

This is not a recognition benchmark or measured family/child accuracy. Five positive inputs share one original capture; transformed copies are not independent known captures. Only one different portrait is an unknown example, not an unknown-person population. No representative demographic/pose/lighting/look-alike/sibling distribution, app mean-of3–6 enrollment, real consent/gallery storage, native SDK parity, camera mount, speech delivery, latency, thermal/battery or all-day acceptance was tested. Training overlap with public pictures is unknown. CPU timing in report is not phone latency. Thresholds were frozen from existing source before comparison and were not tuned here.

No release gate is relaxed. Default Xcode project still lacks enabled familiar assets/flags; reviewed exact config plus iOS runtime/framework/native validation remains necessary. Neutral fabric color, boarding-pass parsing, generic Detector selection, full RGB explicit-reader wiring and other inventory gaps remain independent of this face smoke.

## Image sources / rights

1. NASA portrait distributed by scikit-image v0.24.0, SHA25688431cd9653ccd539741b555fb0a46b61558b301d4110412b5bc28b5e3ea6cb5. Source URL in logs/small-assets.json. Public-domain declaration: https://scikit-image.org/docs/0.24.x/api/skimage.data.html#skimage.data.astronaut . It is test-source A, not a real user gallery entry.
2. Existing Matplotlib sample_data/grace_hopper.jpg, SHA256a8ca6d734765703b09728ab47fe59f473d93ae3967fc24c7c0288c3c7adb7130. U.S. Navy portrait by James S. Davis, public-domain attribution: https://commons.wikimedia.org/wiki/File:Grace_Hopper.jpg . It is test-source B, not an enrolled user identity.

Image/weight/runtime bytes remain in isolated private replay workspace. This evidence archive deliberately excludes them and all embeddings. It contains code, hashes, license notices and bounded result logs only. Scalar results are not a public identity lookup.

## Replay

Set PYTHONPATH=/workspace/shared/blind-perception-private-replay/runtime and PYTHONDONTWRITEBYTECODE=1, then run run-smoke.py against already-verified assets. It imports the repository's unchanged image_smoke.checked_file and MODEL_FILES. Frozen copies of those production sources are included for audit. Compile source/main.swift with included FamiliarFacePolicy, FamiliarEncounterPolicy and FamiliarModelConfiguration using Swift6.4.1/jobs2. Paths currently name this workspace. No script performs network acquisition during inference; acquire.py is a separate bounded SHA/size-pinned operation.
