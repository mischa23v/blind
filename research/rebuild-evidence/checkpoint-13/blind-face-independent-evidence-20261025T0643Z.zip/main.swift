import Foundation
let root=URL(fileURLWithPath:"/workspace/shared/blind-perception-private-replay")
let data=try Data(contentsOf:root.appendingPathComponent("evidence/independent-photo-smoke.json"))
let rows=(try JSONSerialization.jsonObject(with:data) as! [String:Any])["observations"] as! [[String:Any]]
let result=rows[1], values=result["comparisons"] as! [[String:Any]]
let config=FamiliarModelConfiguration.selected
precondition(config.cosineThreshold==0.7 && config.minimumMargin==0.2)
let id=UUID(uuidString:"00000000-0000-0000-0000-000000000001")!
let candidates=values.map { FamiliarFacePolicy.candidate(scores:[(id:id,cosine:$0["cosineToReference"] as! Double)],cosineThreshold:config.cosineThreshold,minimumMargin:config.minimumMargin) }
precondition(candidates.allSatisfy{$0==nil})
var policy=FamiliarEncounterPolicy()
precondition(policy.observe(candidates.compactMap { $0 },detectedFaces:result["facesDetected"] as! Int,now:100).isEmpty)
precondition(policy.observe(candidates.compactMap { $0 },detectedFaces:result["facesDetected"] as! Int,now:101).isEmpty)
print("4 unchanged Swift policy checks pass: measured score abstains; repeating this score at authored timestamps cannot announce identity")
