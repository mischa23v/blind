"""Bounded existing YuNet/SFace API smoke, not independent recognition accuracy.
No network, user photos, saved embeddings, gallery writes, threshold tuning or native claim.
"""
import sys,pathlib,time,json,hashlib
import cv2,numpy as np
sys.path.insert(0,'/workspace/shared/blind-rebuild/tools/face-evaluation')
from image_smoke import checked_file,MODEL_FILES
root=pathlib.Path('/workspace/shared/blind-perception-private-replay')
assert cv2.__version__=='4.14.0'
cv2.setNumThreads(1)
models={name:checked_file(root,'models/'+name,sha) for name,sha in MODEL_FILES.items()}
image=checked_file(root,'fixtures/astronaut.png','88431cd9653ccd539741b555fb0a46b61558b301d4110412b5bc28b5e3ea6cb5')
bgr=cv2.imread(str(image));assert bgr is not None and bgr.shape==(512,512,3)
detector=cv2.FaceDetectorYN.create(str(models['face_detection_yunet_2023mar.onnx']),'',(320,320),.9,.3,5000)
recognizer=cv2.FaceRecognizerSF.create(str(models['face_recognition_sface_2021dec.onnx']),'')

inputs=[('reference','fixtures/astronaut.png'),('independentCapture','fixtures/independent-nasa-1999.jpg')]
rows=[];reference=None
for label,path in inputs:
 pixels=cv2.imread(str(root/path));h,w=pixels.shape[:2];scale=min(1,1024/max(h,w));pixels=cv2.resize(pixels,(round(w*scale),round(h*scale)))
 detector.setInputSize((pixels.shape[1],pixels.shape[0]));_,faces=detector.detect(pixels)
 row={'case':label,'facesDetected':0 if faces is None else len(faces),'comparisons':[]}
 for index,face in enumerate([] if faces is None else faces):
  x,y,fw,fh=map(float,face[:4]);valid=bool(np.isfinite(face).all() and x>=0 and y>=0 and x+fw<=pixels.shape[1] and y+fh<=pixels.shape[0] and all(x<=face[k]<=x+fw and y<=face[k+1]<=y+fh for k in range(4,14,2)))
  entry={'index':index,'box':[x,y,fw,fh],'validNativeBoundsAndLandmarks':valid,'nativePassiveMinimumSize':fw>=80 and fh>=80}
  if valid:
   feature=recognizer.feature(recognizer.alignCrop(pixels,face));assert feature.size==128 and np.isfinite(feature).all()
   if label=='reference':assert len(faces)==1;reference=feature.copy()
   entry['cosineToReference']=float(recognizer.match(feature,reference,cv2.FaceRecognizerSF_FR_COSINE))
  row['comparisons'].append(entry)
 rows.append(row)
report={'status':'Independent photograph smoke, not accuracy estimate or calibrated gallery enrollment','observations':rows,'sourceURL':'https://www.nasa.gov/image-article/astronaut-eileen-collins-nasas-first-female-shuttle-commander/','imageURL':'https://www.nasa.gov/wp-content/uploads/2024/07/sts093-309-027orig.jpg','sha256':hashlib.sha256((root/inputs[1][1]).read_bytes()).hexdigest(),'limits':['One independently captured public photograph, two visibly present faces. Caption supplies reference subject and image date; model does not establish names.','Single reference embedding, not production mean-of-3-to-6 consented examples. No enrollment or device claim.','Threshold remains existing0.7; no tuning, embeddings not saved.','Not held out from unknown model training data, no population or child accuracy claim.']}
(root/'evidence/independent-photo-smoke.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
