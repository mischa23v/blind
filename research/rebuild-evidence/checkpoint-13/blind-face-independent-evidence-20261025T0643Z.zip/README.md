# Independent public-photo bounded replay

The separate official NASA photograph `sts093-309-027orig.jpg` (July 1999, source caption) visibly contains two faces. It was inspected before testing. With unchanged pinned YuNet/SFace and maximum input dimension1024, one face was detected. Its measured cosine to the earlier NASA portrait reference is0.6263607146, below the unchanged native threshold0.7. The actual Swift candidate policy abstains; repeated scalar input at authored timestamps also produces no encounter announcement.

This exposes both detection coverage and recognition limits on this one image. It does NOT measure production enrollment quality: one reference embedding is not the app’s required3–6 independent consented examples, and there is no per-person calibration, representative unknown population, training-disjoint dataset or iOS execution. No threshold was changed. No names are emitted by the test.

Source/caption: https://www.nasa.gov/image-article/astronaut-eileen-collins-nasas-first-female-shuttle-commander/
Image: https://www.nasa.gov/wp-content/uploads/2024/07/sts093-309-027orig.jpg
License/use policy: https://www.nasa.gov/nasa-brand-center/images-and-media/
NASA-created media are generally not copyrighted, subject to exceptions and endorsement/personality limitations. This NASA-credited image is used only in private bounded research, not advertising or public dataset redistribution. No endorsement is implied.
Image bytes840469; SHA256294434d55c19f00bfe4c078da58a93c908bc3df20e6925daff7c71830986e667.

All photos, weights, runtime binaries and embeddings are excluded from this evidence packet. The approved existing runtime/model hashes and earlier API smoke remain in separate archive091b3e3e. No new model or runtime download occurred. The only extra download was this bounded public image.
