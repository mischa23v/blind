# End-to-end feature inventory

Scope: current checked source, 2026-10-25. “Implemented” below means a source path exists, not device working, fully accurate or release-ready. No image-specific recognition claims were made without inspecting pixels; the Saudi archive was inventoried as archive metadata only and was not treated as model/source backup.

## Saudi banknotes

Actual automatic chain: AR frame -> updateBackgroundPerception -> ContextualCapabilityScheduler currencyProbe -> VisionService.currencyRectangleCandidate -> same-frame promotion -> existing SaudiBanknoteReferenceRecognition.inspect -> validated denomination -> two separate fresh observations in ContextualCurrencyConsensus -> exact capture/pose/lease checks -> semantic 60-second duplicate gate -> objects attention/quiet/budget -> Feedback.

Status: source-wired passive discovery; ordinary Release unavailable intentionally. SaudiBanknoteReferenceProfile.selected is nil except explicitly pinned DEBUG + BLIND_CURRENCY_DEVICE_TEST + BLIND_CURRENCY_REFERENCE. No recognizer guesses from OCR or model. Rectangle alone is not money, no-result is silent without payment goal. Existing reference archive contains 16 PNG entries plus manifest/README, 15,306,747 uncompressed bytes, representing eight labeled denomination filenames/both sides. This is reference-pack metadata, not held-out physical-note evidence or a trained model.

Remaining: exact approved Debug asset setup; native OpenCV/Apple build and latency; permissioned independent physical Saudi note tests including invalid/composite/multiple/occluded cases; calibrated production release approval. Production nil is a validation boundary, not a bug to bypass. Two-frame agreement does not establish independent accuracy.

## Color / white versus pale gray or cream

Actual automatic chain: dressing goal -> scheduler.color -> colorInspectionWork lease -> ClothingColorReader native foreground mask/isolation/person-overlap veto -> code sRGB/Lab broad appearance -> exact native work ownership and capture/pose gates -> objects attention. Requested path uses ClothingColorCommand and stricter neutral requests.

Status: broad anonymous isolated-item appearance code implemented. It is not outfit or personal-item identity. Neutral results explicitly abstain; exact white/gray/cream is NOT implemented as a reliable capability. The contextual branch speaks only .appearance and stays silent for .nearNeutral/.darkNeutral/.mixedOrUncertain/.insufficientPixels. Therefore no-command generic color discovery and useful automatic neutral-quality guidance remain code/UX gaps, not covered by this patch. Goal-driven color continues unchanged; no new switch, guessed color or new detector is introduced.

Remaining: controlled/known illumination reference method and independently measured held-out garments, genuine target association, device orientation/isolation tests and useful concise accessible framing. A color-difference formula or screen swatch does not solve intrinsic fabric reflectance under unknown light. No patch claims school-uniform suitability.

## OCR, boards and signs

Actual chain: context scheduler -> Apple VNRecognizeTextRequest -> ContextualTextPolicy.select -> captured-view text prefix -> signs attention -> delivery capture revalidation. Before this proposal it requires a qualifying retained goal even in otherwise idle Release. Proposed portable change removes that command requirement for one bounded high-confidence line, while preserving task relevance and money/hazard/spatial vetoes.

Status: automatic short text source fix staged. Full-page document reading is a separate explicit-reading path with stability, framing and bounded snapshot chunks, not equivalent to passive page understanding. No specialized board/layout/structured table parser exists. Existing broad spatial/money filters intentionally suppress some legitimate numeric/sign content; do not call that complete board understanding.

Concrete remaining code gap: startReadingTool, readingCapture and readingCaptureAllowed still demand observing monitoring / lastObservation / spatial generation, while contextual short OCR supports RGB-only continuation. Explicit document/liveText/barcode/light can therefore be blocked by unavailable depth/calibration although passive RGB probes work. This is independently identified from direct source guards, not fixed here. Native extraction/device tests are needed before a separate RGB-reader patch.

## Boarding passes

No boarding-pass semantic parser or task-specific flow found in ios/BlindAssist or BlindCore. VisionService.code returns only payload/isQR for the first nonempty code; non-QR types are treated as product codes by CodeReading. Apple supports PDF417/Aztec detection, but detection alone does not parse a boarding pass or validate journey/seat/gate/date. Generic OCR is not completion. Mark missing implementation, with a future narrow standards-based parser plus uncertainty/privacy tests; no invented airline facts and no online lookup required by this audit.

## Products / barcodes

Actual chain: scheduler.barcode -> Apple Vision code -> reject QR for passive output -> ProductMemory exact saved-payload name -> “code matches your saved label” -> objects attention. Proposal adds idle eligibility without a scan command. Unknown codes stay silent automatically. Requested code reading can read raw payload and allows explicit naming into existing local memory.

Status: saved-label product association source-wired, no global/offline Saudi product catalog. Product names do not prove contents, price, freshness, allergy safety or ownership. Existing first-code API can return a QR before a known product barcode in the same view, hiding the later barcode; multi-code selection is a separate gap requiring Vision adapter changes, not done here. Unknown-product identity requires vetted local catalog or user labeling, not an LLM guess.

## Family / friends

Actual chain: foreground init restores saved preference/gallery -> frame and RGB-only fallback -> familiarPeople.consume -> pinned YuNet/OpenCV inspectFaces (rotating bounded batch, no old-frame queue) -> independent per-face embedding comparisons + optional Vision veto -> unique identity candidates -> FamiliarEncounterPolicy two distinct matches / once-per-encounter latch -> onArrivalHint -> capture+quiet+social attention+budget -> tentative notice. No-face camera gap is not evidence someone left. Current capture remains stationary/upright/fresh/tracked; missed/back-facing/occluded faces cannot be named.

Status: automatic multi-face source path exists, but compile flag/models/native framework are absent from default project. Enrollment supports 3–6 examples with explicit consenting-adult checks, encrypted local save, exact model profile and deletion. Store currently permits only consent string self-or-consenting-adult. Guardian-consented child enrollment is not implemented. Relationship labels are provided by user, never inferred; no public face lookup. Need actual enrollment/multi-person/false-name/unknown/cancellation/device tests and separate consented child protocol; no model reputation establishes child reliability.

## Saved personal items

Actual chain: explicit user enrollment -> Vision foreground instance mask/feature print -> existing private MemoryStore; automatic frame/RGB fallback -> bounded passiveMemory -> ItemAppearance.candidates over bounded gallery -> margin-based match -> dated ObservedObjectMemory appearanceComparison with associationValidated:false. Explicit requests use ItemAppearance.find and exact request/work/pose gates. No raw personal pictures or feature prints leave device.

Status: passive matching source exists without general Detector weights, provided saved prints exist. Gallery is bounded (64 keys; up to 12 seen instances); generic object discovery requires missing Detector resource. Thresholds/margins are prototype policy, not validated personal-item accuracy. Enrollment chooses nearest-center masked item, which does not prove a user-intended item amid alternatives; this requires target-selection/device validation. Match history is not current presence, coordinates are not safe reach/pickup authority. This proposal does not upgrade candidate identity or spatial authority.

## Shared controls and interruption

Existing foreground camera ownership, permissions, mute/end/camera-off lifecycle generations, exact request/goal/session leases, native timeout/process-disable rather than stacked synchronous work, urgent hazard precedence, category mute, quiet state, ordinary word budget, semantic duplicate suppression and capture-pose revalidation remain. Staged companionMoment fix prevents unrelated passive output while moving on an active connected route even if no dialogue goal exists; requested conversation and urgent/mobility output still pass their normal gates. No claim of all-day operation, universal field of view, measured latency, battery life, child-safe solo use or superiority to Seeing AI.
