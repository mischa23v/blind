// Executes the exact native companionMoment function against lightweight dependencies,
// then the unmodified actual CompanionAttention policy. Not ARKit/audio execution.
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import assert from 'node:assert/strict';
const root='/workspace/shared/blind-perception-stage';
const variant=process.argv[2]??'proposed';
const live=`${root}/support`; // Frozen, byte-identical production attention dependencies.
const read=p=>readFileSync(p,'utf8');
function declaration(source,signature){const start=source.indexOf(signature);assert.ok(start>=0);const brace=source.indexOf('{',start);let depth=0;for(let i=brace;i<source.length;i++){if(source[i]==='{')depth++;if(source[i]==='}'&&--depth===0)return source.slice(start,i+1);}throw Error(signature);}
const native=read(`${root}/${variant}/ios/BlindAssist/NavigationModel.swift`);
const moment=declaration(native,'private func companionMoment(').replace('private func','func');
// Check the real path first, not a manually reconstructed feature flow.
const plan=declaration(native,'func planIndoor(');
assert.match(plan,/setDestination\(binding: installation.binding, nodeID: to, origin: .trustedInterface\)/);
assert.doesNotMatch(plan,/assistantDialogue.goal\s*=/);
const dispatch=declaration(native,'@discardableResult private func deliverCandidate(');
assert.match(dispatch,/companion.decide\(\[candidate\], moment: companionMoment\(now\), settings: companionSettings\)/);
const contextual=declaration(native,'private func updateContextualCapabilities(');
for(const pattern of [/!code.isQR, let name = self.products.name/, /category: category, requested: false, goalRelevant:/, /contextualLastSpoken\[key\].*>= 60/, /self.deliverCandidate\(candidate, speechID: id, nonspatialCapture: activeLease\)/]) assert.match(contextual,pattern);
const relevance = contextual.match(/expiresAt: capturedAt \+ 2, category: category, requested: false, goalRelevant: (.*)\)/)[1];
const policies=['ContextualCapabilityScheduler','ContextualTextPolicy','ReadingTools','SpatialClaimGuard','SaudiBanknotePolicy'].map(n=>read(`${root}/${variant}/BlindCore/Sources/BlindCore/${n}.swift`)).join('\n');
const core=['AssistantPreferences','SpeechPriority','NarrationBudget','CompanionAttention'].map(n=>read(`${live}/BlindCore/Sources/BlindCore/${n}.swift`)).join('\n');
const harness=`import Foundation
${core}
${policies}
func contextualRelevance(_ goal: ContextualCapabilityScheduler.Goal)->Bool { ${relevance} }
enum JourneyStatus { case active, paused, arrived, cancelled }
struct JourneyGoal { var status: JourneyStatus }
final class Runtime { var goal: JourneyGoal?; var question: String? }
final class Journeys { var runtime=Runtime(); func withConnectedJourney<T>(_ body: (Runtime)->T)->T { body(runtime) } }
struct Dialogue { var goal="" }
struct Attention { var stationary=false }
struct Observation { var trackingNormal=true }
struct Feedback { var speechPriority: SpeechPriority? }
struct Retake { var isPending=false }
final class NavigationModel {
 var assistantDialogue=Dialogue(), attention=Attention(), feedback=Feedback(), currencyRetake=Retake()
 var focusedFaceSearch=false, currencyActive=false, colorActive=false, busy=false, lookupInFlight=false, returning=false
 var objectSearch: String?, pendingQuestion: String?, readingTool: String?
 var lastObservation: Observation?=Observation()
 let journeys=Journeys()
 ${moment}
}
var checks=0, failures=0
func check(_ value: @autoclosure ()->Bool,_ label:String){checks += 1;if !value(){failures += 1;print("FAIL: \\(label)")}}
func candidate(_ kind:InformationCandidate.Kind = .discovery, requested:Bool=false, category:String="signs", goalRelevant:Bool=false) -> InformationCandidate {
 .init(key:"incidental",kind:kind,text:"Text in the captured view: Library",words:7,createdAt:100,expiresAt:102,category:category,requested:requested,goalRelevant:goalRelevant)
}
func reason(_ model:NavigationModel,_ item:InformationCandidate=candidate(),_ settings:CompanionSettings=CompanionSettings())->CompanionReason?{
 var attention=CompanionAttention();return attention.decide([item],moment:model.companionMoment(100),settings:settings).first?.reason
}
for status:JourneyStatus in [.active,.paused] {
 let m=NavigationModel();m.journeys.runtime.goal=JourneyGoal(status:status)
 check(m.companionMoment(100).goalActive,"Connected route owns attention despite empty dialogue goal")
 check(reason(m) == .goalInProgress,"Moving connected route suppresses incidental OCR")
 check(reason(m,candidate(category:"objects")) == .goalInProgress,"Moving connected route suppresses incidental product")
 check(reason(m,candidate(.answer,requested:true)) == .requested,"Requested conversation remains available")
 check(reason(m,candidate(.hazard)) == .hazard,"Hazards remain immediate")
 check(reason(m,candidate(.mobility)) == .mobility,"Mobility remains unbudgeted")
}
for status:JourneyStatus in [.arrived,.cancelled] {
 let m=NavigationModel();m.journeys.runtime.goal=JourneyGoal(status:status)
 check(!m.companionMoment(100).goalActive,"Terminal journey releases attention")
 check(reason(m) == .information,"Terminal journey permits passive discovery")
}
let m=NavigationModel();check(reason(m) == .information,"No task supports incidental discovery")
var quiet=CompanionSettings();quiet.quiet=true
check(reason(m,candidate(),quiet) == .quiet,"Quiet suppresses new passive text")
var muted=CompanionSettings();muted.preferences.setMode("muted",for:"signs")
check(reason(m,candidate(),muted) == .muted,"Signs mute retained")
muted.preferences.setMode("muted",for:"objects")
check(reason(m,candidate(category:"objects"),muted) == .muted,"Objects mute retained")
var budget=CompanionSettings();budget.wordsPerMinute=1
check(reason(m,candidate(),budget) == .budget,"Ordinary word budget retained")
var engine=CompanionAttention();let c=candidate()
_ = engine.decide([c],moment:m.companionMoment(100),settings:CompanionSettings())
check(engine.decide([c],moment:m.companionMoment(101),settings:CompanionSettings()).first?.reason == .alreadySaid,"Semantic same-revision dedup retained")
m.returning=true;check(m.companionMoment(100).goalActive,"Legacy return owns attention")
m.returning=false;m.journeys.runtime.question="Which return?";check(m.companionMoment(100).goalActive,"Pending journey clarification owns attention")
let unsupported=ContextualCapabilityScheduler.Goal.infer(from:"Practice spelling")
let r=NavigationModel();r.journeys.runtime.goal=JourneyGoal(status:.active)
check(!contextualRelevance(unsupported),"Unsupported task does not give unrelated currency priority")
check(reason(r,candidate(category:"objects",goalRelevant:contextualRelevance(unsupported))) == .goalInProgress,"Unrelated verified currency waits during connected route")
r.focusedFaceSearch=true
check(reason(r,candidate(category:"objects",goalRelevant:contextualRelevance(unsupported))) == .goalInProgress,"Unrelated currency does not override focused task")
print("\\(checks) actual native-attention checks, \\(failures) failures")
exit(failures==0 ? 0 : 1)
`;
const out=`${root}/evidence/${variant}-native-attention`;mkdirSync(out,{recursive:true});writeFileSync(`${out}/main.swift`,harness);
const swift='/workspace/shared/swift-toolchain/install/swift-6.4.1-RELEASE-debian13/usr/bin/swiftc';
execFileSync(swift,['-j','2','-module-cache-path',`${out}/cache`,`${out}/main.swift`,'-o',`${out}/check`],{stdio:'inherit'});
execFileSync(`${out}/check`,[],{stdio:'inherit'});
