#!/bin/bash
set -eu
source /workspace/shared/swift-toolchain/env.sh
root=/workspace/shared/blind-perception-stage
variant=${1:-proposed}
mkdir -p "$root/evidence/$variant-module-cache"
swiftc -j 2 -module-cache-path "$root/evidence/$variant-module-cache" "$root/$variant/BlindCore/Sources/BlindCore/"*.swift "$root/tests/main.swift" -o "$root/evidence/$variant-checks"
"$root/evidence/$variant-checks"
