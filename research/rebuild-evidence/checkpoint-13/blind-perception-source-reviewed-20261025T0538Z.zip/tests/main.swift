import Foundation
var failures = 0
var checks = 0
func check(_ value: @autoclosure () -> Bool, _ label: String) {
    checks += 1
    if !value() { failures += 1; print("FAIL: \(label)") }
}
typealias S = ContextualCapabilityScheduler
let request = UUID(), generation = UUID()
func moment(_ now: Double = 10) -> S.Moment {
    .init(now: now, requestID: request, perceptionGeneration: generation, sessionGeneration: 1, goalGeneration: "idle")
}
func line(_ text: String, confidence: Double = 0.95, x: Double = 0.3) -> TextLine {
    .init(text: text, confidence: confidence, x: x, y: 0.2)
}
// User acceptance: ordinary supported recognition does not wait for a scanner command.
for capability: S.Capability in [.text, .barcode] {
    var scheduler = S()
    let available: [S.Capability:S.Availability] = [capability:.available]
    let lease = scheduler.reserve(goal: .none, evidence: .init(capturedAt: 10), moment: moment(), availability: available)
    check(lease?.capability == capability, "No-command \(capability) discovery is eligible")
    if let lease {
        check(!scheduler.beforeSpeech(lease, moment: moment(), evidence: .init(capturedAt: 10), goal: .none, availability: available), "No \(capability) result cannot speak")
        check(scheduler.beforeSpeech(lease, moment: moment(10.1), evidence: .init(capturedAt: 10, textCandidate: capability == .text, barcodeCandidate: capability == .barcode), goal: .none, availability: available), "Fresh actual \(capability) output may seek attention admission")
        check(!scheduler.beforeSpeech(lease, moment: moment(10.2), evidence: .init(capturedAt: 10, textCandidate: true, barcodeCandidate: true), goal: .none, availability: available), "Single delivery permit")
    }
}
check(ContextualTextPolicy.select([line("Welcome to the library")], goalText: "  ", unrestrictedReading: false)?.text == "Welcome to the library", "Short observed text is discoverable with no task")
check(ContextualTextPolicy.select([line("Milk")], goalText: "Find my book", unrestrictedReading: false) == nil, "Unrelated active task still filters text")
check(ContextualTextPolicy.select([line("Reading glasses")], goalText: "Find my reading glasses", unrestrictedReading: false) != nil, "Target-relevant OCR remains available")
for text in ["Turn left", "500 riyals", "The path is clear", "Stairs", "Go upstairs"] {
    check(ContextualTextPolicy.select([line(text)], goalText: " ", unrestrictedReading: false) == nil, "Unsolicited text does not bypass existing claim filter: \(text)")
}
for bad in [line("Library", confidence: 0.84), line("Library", confidence: .nan), line("Library", x: .nan), line(String(repeating: "a", count: 101))] {
    check(ContextualTextPolicy.select([bad], goalText: " ", unrestrictedReading: false) == nil, "Invalid or low-confidence passive OCR rejected")
}
for configure in [0,1,2,3,4,5,6] {
    var scheduler = S(); var m = moment()
    switch configure {
    case 0: m.cameraEnabled = false
    case 1: m.sessionActive = false
    case 2: m.foregroundActive = false
    case 3: m.hazardActive = true
    case 4: m.listening = true
    case 5: m.busy = true
    default: m.now = 11
    }
    check(scheduler.reserve(goal: .none, evidence: .init(capturedAt: 10), moment: m, availability: [.text:.available,.barcode:.available]) == nil, "Lifecycle/freshness admission veto \(configure)")
}
for capability: S.Capability in [.light, .color] {
    var scheduler = S()
    check(scheduler.reserve(goal: .none, evidence: .init(capturedAt: 10, lightAvailable: true, centralIsolatedItem: true), moment: moment(), availability: [capability:.available]) == nil, "No arbitrary anonymous \(capability) narration")
}
for task in ["Practice spelling", String(repeating: "unknown ", count: 200)] {
    let goal = S.Goal.infer(from: task)
    check(!goal.isEmpty, "Unsupported retained task is not idle")
    for capability: S.Capability in [.text, .barcode] {
        var scheduler = S()
        check(scheduler.reserve(goal: goal, evidence: .init(capturedAt: 10), moment: moment(), availability: [capability:.available]) == nil, "Unsupported task does not admit incidental \(capability)")
    }
}
print("\(checks) checks, \(failures) failures")
exit(failures == 0 ? 0 : 1)
