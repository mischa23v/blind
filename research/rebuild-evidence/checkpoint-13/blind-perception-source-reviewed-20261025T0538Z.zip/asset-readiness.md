# Asset and API readiness, 2026-10-25

No downloads/installations in this audit. Weight approval pending at parent at time of writing. No authorization is inferred for iOS framework, new runtime, AuraFace or general Detector. No personal/reference images are in source package.

## Default current build

Checked ios/BlindAssist.xcodeproj/project.pbxproj has only inherited/DEBUG conditions, no BLIND_FAMILIAR_PEOPLE, BLIND_APPLE_MULTIMODAL or BLIND_CURRENCY_REFERENCE. No .onnx/.mlmodel/.mlpackage weight files found under ios. Thus source implementations must not be represented as enabled default features. Generate a reviewed configuration without accidentally dropping previously selected flags; never enable guessed model outputs.

## Existing familiar-person backend (not new architecture)

- YuNet face_detection_yunet_2023mar.onnx: 232,589 bytes; SHA256 8f2383e4dd3cfbb4553ea8718107fc0423210dc964f9f4280604804ed2552fa4. Existing model-directory MIT notice in ios/BlindAssist/FamiliarNative/MODEL_NOTICES.txt. Official pointer inspected: https://raw.githubusercontent.com/opencv/opencv_zoo/main/models/face_detection_yunet/face_detection_yunet_2023mar.onnx . Actual download must retrieve LFS content, not this tiny pointer, then verify exact hash. Model directory/license: https://github.com/opencv/opencv_zoo/tree/main/models/face_detection_yunet .
- SFace face_recognition_sface_2021dec.onnx: 38,696,353 bytes; SHA256 0ba9fbfa01b5270c96627c4ef784da859931e02f04419c829e83484087c34e79. Existing Apache-2.0 model notice. Official pointer inspected: https://raw.githubusercontent.com/opencv/opencv_zoo/main/models/face_recognition_sface/face_recognition_sface_2021dec.onnx . Model directory/license: https://github.com/opencv/opencv_zoo/tree/main/models/face_recognition_sface .
- Combined model payload 38,928,942 bytes. Both hashes are already enforced by FamiliarModelConfiguration and project generator; do not substitute a newer/int8 similarly named model.
- iOS runtime: official OpenCV 4.14.0 static framework ZIP, 75,208,871 bytes; SHA256 f4f428fa9270adf95b3ed4705eb18ba3028ed2c2777a4f1a002739b869986a6a, recorded by existing provenance audit research/FAMILIAR_PEOPLE_EXPERIMENT.md. Source/license Apache-2.0 plus transitive notices; no complete redistribution clearance from this audit. URL https://github.com/opencv/opencv/releases/download/4.14.0/opencv-4.14.0-ios-framework.zip . Previously inspected slices: arm64 iPhone / x86_64 simulator, no arm64 simulator. Do not embed as dynamic framework. NOT included in requested weight approval.
- Optional existing AuraFace variant is not needed to activate SFace: glintr100.onnx, 260,694,151 bytes, SHA256 a7933ea5330113b01c9b60351d8f4c33003f145d8470ac5f0e52ee2effe25c60, official fal revision af6d057c9b0ec4071d4c49c80e3539258798b609. Existing provenance tools/face-evaluation/auraface.provenance.json declares Apache-2.0; training rights/demographics and native device quality remain separate. https://huggingface.co/fal/AuraFace-v1/blob/af6d057c9b0ec4071d4c49c80e3539258798b609/README.md . No recommendation to acquire it now.

## Portable execution dependency, separately permissioned

Current Python has numpy and Pillow; cv2, onnx and coremltools absent. The existing face-evaluation scripts need OpenCV, not new detector/runtime architecture. Official PyPI smallest compatible pinned x86_64 headless wheel: opencv_python_headless-4.14.0.94-cp37-abi3-manylinux2014_x86_64.manylinux_2_17_x86_64.whl, published size 57.5 MB, SHA256 5e02669eac0ba67b2a22d7245af1e8ee1a2ef1185ee526a063d8f0555224bd52. Source https://pypi.org/project/opencv-python-headless/4.14.0.94/ . CPU-only/headless avoids GUI/contrib; model, code and wheel third-party licenses remain distinct. The other glibc2.28 x86_64 wheel is 62.0 MB. No package installed. Any portable result will not prove CoreGraphics orientation/channel handling or iPhone performance.

## Saudi currency

Existing private archive is 16 PNG reference entries + manifest + README, not trained weight/source backup. Existing OpenCV SIFT reference matcher requires the same separately approved iOS framework. Production profile deliberately absent pending independent release calibration. Debug device test requires exact reference manifest pin and flags; nothing in this audit supplies release approval, new licensed production note photography, weights or accuracy evidence. Do not upload private pack into repository without applicable source-image rights.

## Generic objects

VisionService loads Detector.mlmodelc; project generator accepts only reviewed Detector.mlmodel/.mlmodelc with artifact and provenance-manifest pins. Expected output is Vision VNRecognizedObjectObservation (image input plus detector/NMS convention), not raw YOLO tensors or image classification. research/OBJECT_DETECTOR_RESOURCE_CONTRACT.md explicitly records no selected/downloaded/licensed/accepted artifact. Therefore there is no honest exact artifact/license/size to request yet. Choosing and reviewing a compatible existing upstream artifact is a separate unresolved asset-selection task, not permission to install arbitrary weights or write a decoder.

## Apple multimodal API and built-in Vision

Official Apple updates document the iOS27 model/API generation and image-analysis support: https://developer.apple.com/documentation/updates/foundationmodels . Official image article documents Attachment image prompts and types including CVPixelBuffer: https://developer.apple.com/documentation/foundationmodels/analyzing-images-with-multimodal-prompting . Type page: https://developer.apple.com/documentation/foundationmodels/imageattachmentcontent . Thus Attachment(image, orientation:) is documented, not assumed from ordinary iOS26 text-only availability. LocalImageAssistant uses compile flag plus runtime iOS27/OnDeviceLanguage guard; default checked project does not set flag. This workspace has Linux Swift, not Apple SDK, so exact SDK overload/typechecking, runtime model download/readiness, requested Arabic language and actual device execution remain unverified. Do not swap to cloud/private-cloud models: privacy/offline requirements remain unchanged. Model output cannot mint identity, physical location or current absence even if multimodal API works.

Built-in Vision OCR, barcode, foreground segmentation and feature prints need no separate weight download here. Apple symbology documentation includes PDF417/Aztec (https://developer.apple.com/documentation/vision/vnbarcodesymbology), but no boarding-pass parser follows from that. Actual native compatibility and recognition/illumination/field-of-view quality still require Apple-device tests.

## Performance and validation boundary

New idle OCR/barcode eligibility adds periodic native Vision work, and rotating text→barcode→currencyProbe may delay the first currency probe by two job gaps compared with currency-only idle scheduling. Existing minimum-gap/cooldowns, one resource lease, failure backoff, timeout disable and quiet/delivery rules remain. No claim of neutral battery/latency cost or all-day behavior. Measure actual background producer load, response/hazard preemption, thermal/memory and currency first-result latency on the chest-worn device before supervised use.
