# Automatic everyday perception audit and source proposal

2026-10-25. Source-only staged work. Nothing in the live repository was edited. No model weights, iOS framework, personal photographs, embeddings or reference pictures are included in this artifact. No download or installation was performed. This is not an iOS build, device validation, recognition accuracy result, or release approval.

## Atomic integration proposal

Apply the four changed production/test paths together, only after current ordered integration and reviewer approval:

1. BlindCore/Sources/BlindCore/ContextualCapabilityScheduler.swift: no-task short text and saved-label barcode eligibility; distinct otherTask bit for unsupported/oversized retained tasks, preventing unsupported intent becoming idle.
2. BlindCore/Sources/BlindCore/ContextualTextPolicy.swift: incidental short high-confidence OCR only when retained task text is genuinely empty. Existing money/spatial/hazard/coordinate/length filters remain; an unknown task is not unrestricted reading.
3. ios/BlindAssist/NavigationModel.swift: narrow proposal only, not a live edit. companionMoment recognizes active/paused connected journeys, pending return clarification and legacy returning. Terminal journeys release attention. Contextual candidate relevance excludes otherTask so unrelated currency cannot gain goal priority.
4. BlindCore/Tests/BlindCoreTests/ContextualCapabilitySchedulerTests.swift: new acceptance and updated assertions distinguishing idle from unsupported tasks. Currency-alone test isolates currency availability rather than assuming the first rotating producer when other no-task producers are now eligible.

No VisionService, Feedback, native recognizer, model threshold, Xcode project or resource configuration changes. Do not replace live NavigationModel with this snapshot: apply only its two narrow hunks after checking the base hash and concurrent edits. Existing RGB continuation, rotating multi-face matching, consent/storage, physical-claim guards and explicit user controls are preserved.

## Independent evidence

- tests/run.sh base: actual production policy compilation and execution, 29 checks with 5 failures. Three failures establish no-command text/barcode/empty-task text discovery gap; two expose unsupported task conflation.
- tests/run.sh proposed: same harness, 35 checks, zero failures (extra permit checks run only when a real lease exists).
- tests/native-attention.mjs base: extracts actual companionMoment and contextual goalRelevant expression; verifies real planIndoor/setDestination and deliverCandidate/attention call chain; runs unchanged production CompanionAttention. 27 checks, 9 failures.
- tests/native-attention.mjs proposed: same actual-source extraction, 27 checks, zero failures. Covers active/paused/arrived/cancelled route, no dialogue goal, return/clarification, unsupported task currency, requested conversation, hazards, mobility, quiet, muted signs/objects, budget and dedup.
- Full copied BlindCore package targeted tests: 96 passed, zero failures; see evidence/policy-suite-final.log. Includes all-backends idle text→barcode→currencyProbe rotation after no-result/cancellation with unchanged two-second gap. Tests execute source policies, not camera/Vision/recognizer/audio.
- Existing native integration contracts: 36 passed, zero skipped, including extracted familiar RGB capture and reading dispatch checks. These are baseline read-only checks, not native iOS execution.
- Native Swift frontend parsing succeeded for staged NavigationModel. It does not typecheck Apple frameworks or linkage.
- Initial SwiftPM run failed because default caches were read-only. Retried using only workspace-owned HOME/cache/config/security/module paths, no permissions bypass; successful run logs supersede build setup failure.

Two early audit suspicions were DISPROVED by full traversal: passive faces do support multiple detections via inspectFaces with rotating bounded batches; missing depth does not stop the automatic RGB path because updateNonspatialObjectMemory calls familiar consume and updateBackgroundPerception. They are not backlog defects.

## Commands

bash tests/run.sh base
bash tests/run.sh proposed
node tests/native-attention.mjs base
node tests/native-attention.mjs proposed

The base commands intentionally exit nonzero. Paths inside the harness currently name /workspace/shared/blind-perception-stage. Uses existing Swift 6.4.1, jobs 2. See feature-inventory.md and asset-readiness.md for remaining explicit blockers. Source hashes are in SHA256SUMS.
