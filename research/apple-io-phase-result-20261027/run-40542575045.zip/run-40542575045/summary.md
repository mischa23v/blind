# Focused indoor IO diagnostic: review

Instrumented one-shot diagnostic, not a fix or an uninstrumented timing result. No physical navigation safety claim.

| Phase | Outcome | Exit |
|---|---|---|
| preflight | passed |  |
| build | passed | 0 |
| single-1 | passed | 0 |
