# Focused indoor IO diagnostic: baseline

No reproduction is not a fix. These repetitions do not establish latency or physical navigation safety.

| Phase | Outcome | Exit |
|---|---|---|
| preflight | passed |  |
| build | passed | 0 |
| single-1 | failed | 65 |
| single-2 | passed | 0 |
| single-3 | passed | 0 |
| class | passed | 0 |
