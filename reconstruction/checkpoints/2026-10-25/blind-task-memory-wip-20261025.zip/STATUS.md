# Task/memory source reconstruction: unfinished WIP

Snapshot 2026-10-25. Source only; not merged, not an iOS build, not a live app or real-model validation.

Implemented in staged source: idempotent repeated goals/progress; chronological location reports; code-bound exact pronoun-source retrieval; canonical task label separated from original user wording; target-named item completion; rejection of generic completion and self-location as unrelated step completion; retained original/unknown timestamps on legacy replay. Native integration is a separate patch.

Executed evidence: baseline Core regressions failed (3 tests/18 assertions); model-associated completion regression failed (6 assertions); extracted baseline production state failed (2 tests/28 assertions). Earlier staged full Core run: 939 tests passed, including 12 new synthetic regressions. Earlier patched extracted production state: 7 tests passed.

Since those passes, additional generic-completion/self-location rejection wording variants were added. The complete Core suite has not yet rerun on this exact snapshot. The reusable optional Node-to-Swift native replay runner is being checked separately. This snapshot must not inherit earlier pass counts as an exact-source full-suite pass.

Remaining: merge/review native patch, update superseded old test expectations accepting bare done, rerun combined suites. Same-goal movement between different physical fridges still lacks target/place-bound action-report invalidation. No camera, real-model, Apple SDK or physical safety validation is established.
