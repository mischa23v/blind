import Foundation
import XCTest
@testable import BlindCore
#if canImport(NativeSpatialAdapter)
@testable import NativeSpatialAdapter
#else
@testable import BlindAssist
#endif

/// Runs the real native storage/ownership adapter on Foundation with injected real
/// SHA-256. Synthetic map/pose/support only; no Apple sensor/audio SDK execution.
final class RegisteredIndoorNavigationTests: XCTestCase {
    typealias F = SpatialIntegrationFixture
    var directory: URL!
    override func setUpWithError() throws {
        directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
    }
    override func tearDownWithError() throws { try FileManager.default.removeItem(at: directory) }
    func adapter() -> RegisteredIndoorNavigation {
        .init(storage: directory.appendingPathComponent("registered.json"), sha256: F.sha256)
    }
    func ready() throws -> RegisteredIndoorNavigation {
        let adapter = adapter()
        try adapter.install(F.installation().encoded())
        try adapter.configure(body: F.body, limits: F.limits)
        try adapter.plan(from: "start", to: "end", goal: UUID())
        let capture = SpatialLocalizationCapture(sessionID: try XCTUnwrap(adapter.sessionID),
            binding: try XCTUnwrap(adapter.installation).binding, floorID: "floor", position: Point3(1, 1.3, 3), bodyYaw: -.pi / 2,
            source: .alignedMapPose, headingSource: .bodyAligned, trackingNormal: true,
            positionUncertainty: 0.1, headingUncertainty: 0.1, capturedAt: 10)
        try adapter.accept(capture, floorSupport: F.support(capture), now: 10)
        return adapter
    }
    func testActualAdapterPersistsEnvelopeAndRestoresNoAuthority() throws {
        let first = try ready(); let ticket = try first.next(now: 10)
        XCTAssertTrue(first.permits(ticket, now: 10))
        let restored = adapter(); try restored.restore()
        XCTAssertEqual(restored.installation?.artifact, first.installation?.artifact)
        XCTAssertNil(restored.currentPose(now: 10))
        XCTAssertFalse(restored.permits(ticket, now: 10))
        XCTAssertThrowsError(try restored.next(now: 10))
    }
    func testGoalCancellationRetiresOnlyHeldRouteOutputAndKeepsPose() throws {
        let adapter = try ready(); var retirements = 0
        adapter.onOutputRetired = { retirements += 1 }
        let ticket = try adapter.next(now: 10), session = adapter.sessionID
        adapter.cancelRoute()
        XCTAssertEqual(retirements, 1)
        XCTAssertFalse(adapter.permits(ticket, now: 10))
        XCTAssertEqual(adapter.sessionID, session)
        XCTAssertNotNil(adapter.currentPose(now: 10))
    }
    func testExpiryWithdrawsHeldOutputWithoutAnotherSensorCallback() throws {
        let adapter = try ready(); var retirements = 0
        adapter.onOutputRetired = { retirements += 1 }
        _ = try adapter.next(now: 10)
        adapter.revalidate(now: 10.6); adapter.revalidate(now: 11)
        XCTAssertEqual(retirements, 1)
    }
    func testMapReplacementAndSessionLossNotifyRouteOutputRetirement() throws {
        let adapter = try ready(); var retirements = 0
        adapter.onOutputRetired = { retirements += 1 }
        let old = try adapter.next(now: 10)
        try adapter.install(F.installation(map: F.map(revision: "r2"), prior: adapter.installation).encoded())
        XCTAssertEqual(retirements, 1); XCTAssertFalse(adapter.permits(old, now: 10))
        XCTAssertNil(adapter.currentPose(now: 10))
        let second = try ready(); var lost = 0
        second.onOutputRetired = { lost += 1 }; _ = try second.next(now: 10)
        second.loseTracking()
        XCTAssertEqual(lost, 1); XCTAssertNil(second.currentPose(now: 10))
    }
    func testLegacyImportCannotKeepRegisteredAuthority() throws {
        let adapter = try ready(); let old = try adapter.next(now: 10)
        adapter.clearForLegacyImport()
        XCTAssertNil(adapter.installation); XCTAssertFalse(adapter.permits(old, now: 10))
        XCTAssertThrowsError(try adapter.next(now: 10))
    }
    func testReconfigureOrRestoreCannotEraseRestrictionsInActiveOwner() throws {
        let adapter = try ready()
        try adapter.addRestrictions(binding: XCTUnwrap(adapter.installation).binding,
                                    blocked: [MapConnection("start", "middle")], zones: [])
        XCTAssertThrowsError(try adapter.configure(body: F.body, limits: F.limits))
        XCTAssertThrowsError(try adapter.restore())
        XCTAssertThrowsError(try adapter.plan(from: "start", to: "end", goal: UUID()))
    }
    func testReportedBlockedNextLegIsAppliedToRegisteredPlanner() throws {
        let adapter = try ready(); var retirements = 0
        adapter.onOutputRetired = { retirements += 1 }
        let ticket = try adapter.next(now: 10)
        XCTAssertThrowsError(try adapter.blockNextLegAndReplan()) // This authored fixture has no alternative.
        XCTAssertEqual(retirements, 1)
        XCTAssertTrue(adapter.route.isEmpty)
        XCTAssertFalse(adapter.permits(ticket, now: 10))
        XCTAssertThrowsError(try adapter.plan(from: "start", to: "end", goal: UUID()))
    }

    func testReportedClosureSurvivesRestoreAndReconfiguration() throws {
        let first = try ready()
        try first.addRestrictions(binding: XCTUnwrap(first.installation).binding,
                                  blocked: [MapConnection("middle", "end")], zones: [])
        let restored = adapter(); try restored.restore()
        try restored.configure(body: F.body, limits: F.limits)
        XCTAssertThrowsError(try restored.plan(from: "start", to: "end", goal: UUID()))
        XCTAssertNil(restored.currentPose(now: 10))
        XCTAssertEqual(restored.installation?.currentRestrictions.blocked, [SpatialBlockedEdge(MapConnection("middle", "end"))])
    }

}
