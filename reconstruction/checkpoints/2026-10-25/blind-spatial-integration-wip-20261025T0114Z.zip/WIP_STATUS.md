# Unfinished spatial integration source checkpoint

Status: source work in progress, 2026-10-25. Not a release or completed live-navigation integration.

Implemented in this isolated package:
- Exact map bytes, SHA-256 identity/history and hierarchy registry in an atomically persisted installation envelope.
- Existing IndoorMap planning and NavigationSurface collision checks reused with exact route/goal/body/restriction/map/session/capture ownership.
- Current-leg association, measured floor-support input, uncertainty-expanded body and stable directional-sector checks.
- Monotonic conservative restrictions persisted with their map binding. Failed restriction saves retire output and block guidance until persistence succeeds.
- Foundation native storage/output adapter, proposed IndoorNavigator hooks and updated native test/source-contract patches.
- Legacy manual/unregistered geometry remains preview-only, not live pose authority.

Verified:
- Swift 6.4.1 Linux isolated debug package: 41 tests passed, zero failures or skips. Includes 8 tests through the actual Foundation native adapter, 10 installation tests and 23 route-owner tests.
- Proposed native IndoorNavigator, native adapter and modified native test file passed Swift syntax parsing only.
- All fixtures are explicitly synthetic. Linux hashing tests use the installed OpenSSL implementation and a known SHA-256 vector. Apple uses CryptoKit. No custom cryptographic implementation or fallback hash.

Not yet verified or finished:
- Apple SDK compilation, hosted iOS tests, actual sensor/audio/haptic/VoiceOver behavior and physical-device accuracy.
- The proposed native patch still needs ticket-specific speech/beacon dispatch and retirement wiring in NavigationModel. No NavigationModel changes are included.
- No calibrated native map-pose/body-heading uncertainty issuer exists. No default confidence, error bounds or localization certificate are fabricated. The stricter path therefore withholds physical cues without such evidence.
- Fresh restriction removal/reopening remains open. It must require newer source-bound observed-clear coverage; empty detections or delayed older callbacks cannot remove a closure. Additive restrictions are not complete continuously updating mapping.
- No cross-map return journey, automatic floor transition, map accuracy certification or current physical-clearance assurance.

Reproduce the bounded portable tests with an official Swift toolchain and `swift test --jobs 1`. Linux requires an existing `/usr/bin/openssl` for the test-only digest provider. The standalone package's NativeSpatialAdapter target is a test harness for the exact native adapter source, not an additional app dependency.

The `native/*.patch` files are proposed changes, not already applied to the main checkout. Do not copy this standalone Package.swift over the application's package. Keep restore-time pose unknown and preserve independent hazards when cancelling an ordinary goal.
