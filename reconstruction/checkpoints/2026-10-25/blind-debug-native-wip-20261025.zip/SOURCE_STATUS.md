# Work-in-progress native debug-session integration source

Checkpoint date: 2026-10-25. This archive contains proposed source, not installed/live app code. The patch has not been applied to the working application. No deployment or native-device acceptance is claimed.

## Implemented in the proposed source

- DEBUG-only, explicit launch-opt-in session diagnostics through the existing bounded recorder.
- Actual bounded textual input, model prompt/response, tool-return, evidence/output-gate and speech lifecycle hooks. No hidden reasoning or raw image/audio/biometric capture is added.
- Actual AVSpeech start/finish/cancel callbacks are distinguished from enqueueing, app cancellation and timeout. VoiceOver callbacks without reliable IDs stay unbound.
- Shared cancellation-fence IDs are not invented as microphone/clock/code-owned request provenance. Direct clock replies preserve their actual distinct reply ID.
- Existing privacy deletion/correction flows purge diagnostic history, including names, family labels/examples, shopping items, journeys and private-map deletion. No diagnostic UI is added: purge outcomes use DEBUG-only receipts and fixed developer stderr reporting on a utility queue with one nonblocking admission slot.
- The direct-clock integration already present in the base is preserved, including one read and existing freshness/lease gates.

## Verification completed

- 18/18 focused Node source-contract checks pass.
- Default and DEBUG/familiar/multimodal Swift syntax parsing passes for the seven proposed native files. Syntax parsing is not Apple SDK typechecking.
- 18/18 executable assertions pass for the exact extracted Foundation-only DebugNativeSessionTrace helper linked against the actual prebuilt Debug BlindCore. These cover disabled laziness, output and thrown-error identity preservation for synthetic producers, unchanged invocation counts, actual prompt/correlation/file values, finish/purge rejection and write failure.
- The executable helper test uses synthetic text only. It does not execute or mock Apple's model/audio/UI callbacks and is not advertised as full native integration acceptance.
- Native patch dry-run against the recorded base succeeds. Per-file base and proposed hashes are in manifest.json.

## Known unfinished or unavailable evidence

- Full Apple SDK Debug/Release/optional-feature builds and native ASR, FoundationModels tools, AVSpeech and VoiceOver execution remain unverified.
- Device file protection/backup exclusion, lock/unlock/disk-full behavior, latency, memory, thermal and sustained-session behavior remain unverified.
- The existing model tool API does not expose SDK tool-call IDs; underlying context-record IDs are not provided by PromptPlan. These remain explicitly unbound, not inferred.
- Tool calls that throw or cancel before returning may lack a matching return event. No success is reconstructed from that absence.
- Process termination can interrupt final flush. Surviving unclean markers retain that uncertainty.
- Applying/merging the proposed patch and running the complete merged regression suite are still pending. This source checkpoint is not release-ready or a safety acceptance claim.

## Contents and reproduction

proposed/ contains seven native source files, the focused Node contracts, a Swift helper harness and a runner that extracts the actual helper from LocalImageAssistant.swift. The runner requires an existing official Swift compiler and prebuilt Debug BlindCore products; it does not install tools or rebuild Core.

Run source contracts from proposed/:

node --test --test-concurrency=1 tools/test/debug-native-session.test.mjs

Run the executable helper against an existing product directory:

python3 tools/run-debug-native-helper.py --products /path/to/debug/products --output /tmp/debug-native-helper-results

The product directory must contain BlindCore.swiftmodule and libBlindCore.a. The runner verifies that the library did not change while it ran and records source/library/toolchain hashes.

The archive excludes compiled products, model weights, runtime user logs, private user data and conversation material. FILES.sha256 lists the exact archived source hashes.
