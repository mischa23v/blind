import XCTest
@testable import BlindCore
final class ClockLegacyFailureTests: XCTestCase {
    let wall = Date(timeIntervalSince1970: 1_700_000_000)
    let utc = TimeZone(secondsFromGMT: 0)!
    func testWallRollbackAfterOriginalMonotonicLeaseMustNotAdmitOldToolClock() {
        let value = CompanionClock.read(now: wall, timeZone: utc, arabic: false).evidence[0]
        // Actual old production guard has no monotonic input. Eight seconds have
        // passed, but a wall adjustment makes the read appear four seconds old.
        let actualOldAdmission = CompanionEvidenceGuard.allows(value.text, reports: [], evidence: [value], now: wall.addingTimeInterval(4))
        XCTAssertFalse(actualOldAdmission, "Old wall-only tool path wrongly admits clock after monotonic age 8 seconds")
    }
    func testChangedDeviceTimeZoneMustNotAdmitEarlierZoneAsCurrent() {
        let value = CompanionClock.read(now: wall, timeZone: utc, arabic: false).evidence[0]
        // Device zone changed to Asia/Riyadh after acquisition. The production
        // guard accepts old evidence without receiving the new zone at all.
        let actualOldAdmission = CompanionEvidenceGuard.allows(value.text, reports: [], evidence: [value], now: wall.addingTimeInterval(1))
        XCTAssertFalse(actualOldAdmission, "Old guard ignores changed device time zone")
    }
    func testLegacyCodeOwnedClockMustNotSurviveFiveSecondReadLease() {
        let value = CompanionClock.read(now: wall, timeZone: utc, arabic: false).evidence[0]
        let codeOwned = true
        // Exact admission expression from legacy drainConversationSpeech. Its
        // independent 30-second queue age does not enforce clock acquisition age.
        let actualOldAdmission = codeOwned || CompanionEvidenceGuard.allows(value.text, reports: [], evidence: [value], now: wall.addingTimeInterval(9))
        XCTAssertFalse(actualOldAdmission, "Bare code-owned clock bypasses expired evidence")
    }
}
