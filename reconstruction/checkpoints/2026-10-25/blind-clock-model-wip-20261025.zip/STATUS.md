# Unfinished clock-tool reconstruction snapshot

2026-10-25. This is pending work, not a passing implementation or release.

The already-published direct read-only clock inquiry lane is checkpoint 6945dc73280ec2d1f8bda8e13f7531e8ed098f52. It is distinct from this unfinished snapshot.

This snapshot proposes original-acquisition clock receipts for legacy and model-selected tool results, delayed partial/final display, queued speech, and repeat. It reuses the published CompanionClockReplyLease and existing CompanionClock. Original source/record/session and five-second wall plus monotonic limits must survive delay; a new delivery cannot renew an old read.

Included changes are staged only, not applied to the shared checkout. The native patch base SHA-256 is c3df0a8fdcb17860867d4d8748d12ea1bfce7c63c15d1faa3a60d3c632a6abbc and must be reconciled with later native edits before application.

Actual test status at snapshot:
- Three fail-before regression tests executed against the old wall-only guard/legacy admission and reproduced all three intended failures: changed zone, rollback after original monotonic expiry, and bare code-owned stale time. XCTest exited 1, with 3 tests and 3 assertion failures.
- The newly proposed delivery policy/native patch is not yet compiled or tested. Passing after-change tests, exact native callback harness checks, independent review, and final aggregate validation remain pending.
- No Apple SDK/device/VoiceOver acceptance is claimed.

Next work: add and run after-change receipt tests; exercise actual extracted native callbacks; review all clock result/repeat boundaries; reconcile native patch after the concurrent debug increment; rerun focused and affected aggregate checks.
