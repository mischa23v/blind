import Foundation
actor Gate {
    var calls:[CapturedVoicePCM]=[]
    var waiting:[CheckedContinuation<CapturedVoiceEmbedding,Error>]=[]
    var observers:[(Int,CheckedContinuation<Void,Never>)]=[]
    func run(_ pcm:CapturedVoicePCM) async throws -> CapturedVoiceEmbedding {
        calls.append(pcm)
        for observer in observers where calls.count >= observer.0 {observer.1.resume()}
        observers.removeAll{calls.count >= $0.0}
        return try await withCheckedThrowingContinuation{waiting.append($0)}
    }
    func wait(_ count:Int) async {if calls.count >= count{return};await withCheckedContinuation{observers.append((count,$0))}}
    func finish() {let index=calls.count-1;waiting.removeFirst().resume(returning:CapturedVoiceEmbedding(turn:calls[index].turn,vector:[Float](repeating:0.1,count:256),captureRouteBinding:"synthetic-route"))}
    func ids()->[UUID]{calls.map{$0.turn.id}}
}
@MainActor final class Probe {
 var values:[CapturedVoiceEmbedding]=[];var waits:[(Int,CheckedContinuation<Void,Never>)]=[]
 func receive(_ value:CapturedVoiceEmbedding){values.append(value);for w in waits where values.count >= w.0{w.1.resume()};waits.removeAll{values.count >= $0.0}}
 func wait(_ count:Int) async {if values.count >= count{return};await withCheckedContinuation{waits.append((count,$0))}}
}
func pcm(_ text:String)->CapturedVoicePCM {
 let s=UUID(),c=UUID(),t=UUID(),turn=CapturedVoiceTurn(session:s,capture:c,recognitionTurn:t,text:text,completedAt:10)
 var window=VoicePCMWindow(session:s,capture:c,sampleRate:16000,captureRouteBinding:"synthetic-route")!;window.beginTurn(t)
 [Float](repeating:0.1,count:16000).withUnsafeBufferPointer{window.append(samples:$0,stride:1,sampleRate:16000)}
 return window.seal(turn:turn,startSeconds:0,endSeconds:1)!
}
var checks=0
@MainActor func check(_ b:Bool,_ text:String){checks += 1;if !b{print("FAIL "+text);exit(1)}}
@MainActor final class Boundary {
 var current:CapturedVoiceTurn?
 func admit(_ pcm:CapturedVoicePCM,to queue:VoicePCMJobQueue)->VoicePCMAdmissionTicket? {
  current=pcm.turn;defer{current=nil};return queue.admitCurrentSourceTurn(pcm.turn)
 }
}
let gate=Gate(),probe=Probe(),boundary=Boundary()
let queue=VoicePCMJobQueue(process:{try await gate.run($0)},isCurrentSource:{boundary.current==$0},receive:{probe.receive($0)},now:{11})
let a=pcm("a"),b=pcm("b"),c=pcm("c"),d=pcm("d"),e=pcm("e")
check(boundary.admit(a,to:queue)==nil,"disabled by default")
queue.setEnabled(true)
let ta=boundary.admit(a,to:queue)!;queue.submit(a,ticket:ta);await gate.wait(1)
let tb=boundary.admit(b,to:queue)!;queue.submit(b,ticket:tb)
let tc=boundary.admit(c,to:queue)!;queue.submit(c,ticket:tc)
queue.submit(a,ticket:ta)
check(queue.admitCurrentSourceTurn(a.turn)==nil,"late callback cannot select source owner")
check(await gate.ids()==[a.turn.id],"only one active native invocation")
await gate.finish();await gate.wait(2)
check(await gate.ids()==[a.turn.id,c.turn.id],"late A cannot replace latest pending C")
queue.submit(c,ticket:tc)
await gate.finish();await probe.wait(1)
check(probe.values.map{$0.turn.id}==[c.turn.id],"cancelled old result withheld; duplicate ticket ignored")
let td=boundary.admit(d,to:queue)!;queue.invalidate();queue.submit(d,ticket:td)
check(await gate.ids().count==2,"seal then invalidation then late submit is rejected")
let te=boundary.admit(e,to:queue)!;queue.submit(e,ticket:te);await gate.wait(3)
queue.invalidate();queue.submit(e,ticket:te)
let f=pcm("f"),tf=boundary.admit(f,to:queue)!;queue.submit(f,ticket:tf)
await gate.finish();await gate.wait(4);await gate.finish();await probe.wait(2)
check(probe.values.map{$0.turn.id}==[c.turn.id,f.turn.id],"epoch invalidation preserves new admitted job only")
queue.setEnabled(false)
check(boundary.admit(pcm("off"),to:queue)==nil,"disabled helper admits no PCM")
let expired=VoicePCMJobQueue(process:{try await gate.run($0)},isCurrentSource:{boundary.current==$0},receive:{probe.receive($0)},now:{30})
expired.setEnabled(true)
check(boundary.admit(pcm("expired"),to:expired)==nil,"expired sample never admitted")
print("PASS: \(checks) actual bounded queue async assertions; cancelled backend intentionally ignores cancellation until released")
