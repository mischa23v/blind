set -eu
set -o pipefail
R=/workspace/shared/blind-voice-pcm-stage
S=/workspace/shared/swift-toolchain/install/swift-6.4.1-RELEASE-debian13/usr/bin/swiftc
C=/workspace/shared/blind-rebuild/BlindCore/Sources/BlindCore
export TMPDIR="$R/tmp"
mkdir -p "$R/tmp/ring" "$R/tmp/queue" "$R/tmp/finish" "$R/tmp/session" "$R/tmp/nativepipeline"
python3 "$R/tests/make_finish_witness.py"
cp "$R/tests/main.swift" "$R/tmp/ring/main.swift"
cp "$R/tests/queue-main.swift" "$R/tmp/queue/main.swift"
cp "$R/tests/finish-main.swift" "$R/tmp/finish/main.swift"
for t in ring queue finish; do
 "$S" -swift-version 6 -module-cache-path "$R/tmp/cache" "$C/CommandAuthority.swift" "$C/AssistantDialogue.swift" "$C/VoiceAuthority.swift" "$R/source/BlindCore/Sources/BlindCore/VoicePCMWindow.swift" "$R/source/BlindCore/Sources/BlindCore/VoicePCMJobQueue.swift" "$R/tmp/$t/main.swift" -o "$R/tmp/$t/test"
 timeout 25 "$R/tmp/$t/test" | tee "$R/evidence/$t-result.log"
done
node --test "$R/tests/native-source-contracts.test.mjs" > "$R/evidence/native-source-contracts.log"
"$S" -frontend -parse "$R/source/ios/BlindAssist/"*.swift

sed '/^import BlindCore$/d' "$R/source/ios/BlindAssist/VoiceEvidenceSession.swift" > "$R/tmp/session/VoiceEvidenceSession.swift"
cp "$R/tests/session-main.swift" "$R/tmp/session/main.swift"
"$S" -swift-version 6 -module-cache-path "$R/tmp/cache" "$C/CommandAuthority.swift" "$C/AssistantDialogue.swift" "$C/VoiceAuthority.swift" "$R/source/BlindCore/Sources/BlindCore/"*.swift "$R/tmp/session/"*.swift -o "$R/tmp/session/test"
timeout 25 "$R/tmp/session/test" | tee "$R/evidence/session-result.log"
"$S" -swift-version 6 -module-cache-path "$R/tmp/cache" "$C/CommandAuthority.swift" "$C/AssistantDialogue.swift" "$C/VoiceAuthority.swift" "$R/evidence/fail-before/"*.swift -o "$R/tmp/fail-before"
timeout 20 "$R/tmp/fail-before" | tee "$R/evidence/fail-before/result.log"
# Reuse only the previously verified local official CPU assets; no downloads.
N=/workspace/shared/blind-voice-native-investigation
V=/workspace/shared/blind-voice-authority-stage/model-evaluation/.venv/lib/python3.12/site-packages/sherpa_onnx
cp "$R/tests/native-pipeline-main.swift" "$R/tmp/nativepipeline/main.swift"
"$S" -swift-version 6 -I "$N/tmp" -I "$N/tmp/SherpaOnnxC" -module-cache-path "$R/tmp/cache" "$C/CommandAuthority.swift" "$C/AssistantDialogue.swift" "$C/VoiceAuthority.swift" "$R/source/BlindCore/Sources/BlindCore/"*.swift "$N/source/LocalSpeakerEmbeddingWorker.swift" "$R/tmp/nativepipeline/main.swift" -o "$R/tmp/native-pipeline" -L "$N/tmp" -lSherpaOnnx -L "$V/lib" -lsherpa-onnx-c-api -Xlinker -rpath -Xlinker "$N/tmp" -Xlinker -rpath -Xlinker "$V/lib"
timeout 40 "$R/tmp/native-pipeline" /workspace/shared/blind-voice-authority-stage/model-evaluation/private-assets/wespeaker_en_voxceleb_resnet34_LM.onnx | tee "$R/evidence/native-pipeline-result.log"
