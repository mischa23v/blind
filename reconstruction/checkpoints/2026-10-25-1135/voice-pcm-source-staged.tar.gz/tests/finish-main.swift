import Foundation
struct Life {var requested=true;var session=UUID()}
struct Utterance {var text="hello";func deliverable(isEcho:Bool)->String?{isEcho ? nil:text}}
struct Engine {var isRunning=true}
final class Input {
 var seals=0
 func sealSpeakerPCM(turn:CapturedVoiceTurn,start:Double,end:Double)->CapturedVoicePCM? {
  seals += 1
  var ring=VoicePCMWindow(session:turn.session,capture:turn.capture,sampleRate:16000,captureRouteBinding:"synthetic-route")!
  ring.beginTurn(turn.recognitionTurn)
  [Float](repeating:0.1,count:16000).withUnsafeBufferPointer{ring.append(samples:$0,stride:1,sampleRate:16000)}
  return ring.seal(turn:turn,startSeconds:start,endSeconds:end)
 }
}
@MainActor final class Capture {
 var lifecycle=Life(),utterance=Utterance(),engine:Engine?=Engine(),input=Input()
 var canCapture=true,continuous=true,captureGeneration=UUID(),turn=UUID(),speakerEvidenceEnabled=false
 var recognizedAudioInterval:(text:String,start:Double,end:Double)?=("hello",0,1)
 var activeDelivery:CapturedVoiceTurn?,activeSpeakerBoundary:CapturedVoiceTurn?,shouldIgnore:((String)->Bool)?,onFinished:((CapturedVoiceTurn)->Void)?,onSpeakerPCM:((CapturedVoicePCM,VoicePCMAdmissionTicket)->Void)?,onSpeakerTurnWillSeal:((CapturedVoiceTurn)->VoicePCMAdmissionTicket?)?,onSpeakerEvidenceInvalidated:(()->Void)?
 func beginTurn(){turn=UUID();recognizedAudioInterval=nil}
 func cancel(){lifecycle.requested=false;turn=UUID();captureGeneration=UUID();activeDelivery=nil;recognizedAudioInterval=nil;activeSpeakerBoundary=nil;onSpeakerEvidenceInvalidated?()}
    func consumeDelivery(_ turn: CapturedVoiceTurn) -> Bool {
        guard activeDelivery == turn else { return false }
        activeDelivery = nil
        return true
    }
    func isCurrentSpeakerBoundary(_ turn: CapturedVoiceTurn) -> Bool {
        speakerEvidenceEnabled && lifecycle.requested && canCapture && activeSpeakerBoundary == turn
            && lifecycle.session == turn.session && captureGeneration == turn.capture
    }
    func finish() {
        guard lifecycle.requested, canCapture else { return }
        let text = utterance.deliverable(isEcho: shouldIgnore?(utterance.text) == true)
        // Bind the final transcript before beginTurn/cancel retires ASR identifiers.
        let completed = text.map { CapturedVoiceTurn(session: lifecycle.session,
            capture: captureGeneration, recognitionTurn: turn, text: $0,
            completedAt: ProcessInfo.processInfo.systemUptime) }
        // Seal against the exact final words and request interval before rotation.
        // Segment timestamps describe recognizer input, not speaker identity.
        let admittedPCM: (CapturedVoicePCM, VoicePCMAdmissionTicket)? = completed.flatMap { turn in
            guard speakerEvidenceEnabled, let interval = recognizedAudioInterval,
                  interval.text == turn.text else { return nil }
            activeSpeakerBoundary = turn
            defer { activeSpeakerBoundary = nil }
            guard let ticket = onSpeakerTurnWillSeal?(turn), isCurrentSpeakerBoundary(turn),
                  let pcm = input.sealSpeakerPCM(turn: turn, start: interval.start, end: interval.end) else { return nil }
            return (pcm, ticket)
        }
        if continuous, engine?.isRunning == true, canCapture { beginTurn() }
        else { cancel() }
        guard let completed else { return }
        activeDelivery = completed
        defer { activeDelivery = nil }
        onFinished?(completed)
        // A synchronous final callback may mute/end or change the route. Such a
        // change must retire private PCM even though generic speech was delivered.
        if let (pcm, ticket) = admittedPCM, speakerEvidenceEnabled, lifecycle.requested, canCapture,
           lifecycle.session == pcm.turn.session, captureGeneration == pcm.turn.capture {
            onSpeakerPCM?(pcm, ticket)
        }
    }
}

@MainActor final class Probe {
 var count=0;var waiter:CheckedContinuation<Void,Never>?
 func receive(_ result:CapturedVoiceEmbedding){count += 1;waiter?.resume();waiter=nil}
 func wait() async {if count>0{return};await withCheckedContinuation{waiter=$0}}
}
var checks=0
@MainActor func check(_ value:Bool,_ label:String){checks += 1;if !value{print("FAIL "+label);exit(1)}}
for continuous in [true,false] {
 let c=Capture();c.continuous=continuous;c.speakerEvidenceEnabled=true
 let expectedTurn=c.turn;var text=0;var segments:[CapturedVoicePCM]=[]
 let probe=Probe()
 let queue=VoicePCMJobQueue(process:{CapturedVoiceEmbedding(turn:$0.turn,vector:[Float](repeating:0.1,count:256),captureRouteBinding:"synthetic-route")},isCurrentSource:{c.isCurrentSpeakerBoundary($0)},receive:{probe.receive($0)})
 queue.setEnabled(true)
 c.onSpeakerTurnWillSeal={value in check(c.isCurrentSpeakerBoundary(value),"exact native mint boundary active");return queue.admitCurrentSourceTurn(value)}
 c.onSpeakerEvidenceInvalidated={queue.invalidate()}
 c.onFinished={value in check(c.consumeDelivery(value),"generic provenance unchanged");check(value.origin == .unverifiedMicrophone,"still unverified");text += 1}
 c.onSpeakerPCM={pcm,ticket in
  check(c.turn != pcm.turn.recognitionTurn,"recognizer already rotated before submission")
  check(!c.isCurrentSpeakerBoundary(pcm.turn),"mint boundary closed at submission")
  segments.append(pcm);queue.submit(pcm,ticket:ticket)
 };c.finish()
 if continuous {await probe.wait();check(probe.count==1,"ticket survives rotation to valid inference completion")}
 check(text==1,"normal speech still delivered")
 check(segments.count==(continuous ? 1:0),"only still-active continuous capture admits PCM")
 if let pcm=segments.first{check(pcm.turn.recognitionTurn==expectedTurn,"PCM bound before ASR rotation");check(pcm.samples.count==16000,"exact interval retained")}
}
for mode in ["defaultOff","muteInCallback","routeInCallback","optOutInCallback","sessionInCallback","wordsMismatch","missingRange","expiredRange"] {
 let c=Capture();c.speakerEvidenceEnabled=mode != "defaultOff";var text=0;var audio=0
 let queue=VoicePCMJobQueue(process:{CapturedVoiceEmbedding(turn:$0.turn,vector:[Float](repeating:0.1,count:256),captureRouteBinding:"synthetic-route")},isCurrentSource:{c.isCurrentSpeakerBoundary($0)},receive:{_ in})
 queue.setEnabled(true);c.onSpeakerTurnWillSeal={queue.admitCurrentSourceTurn($0)};c.onSpeakerEvidenceInvalidated={queue.invalidate()}
 if mode=="wordsMismatch"{c.recognizedAudioInterval=("other words",0,1)}
 if mode=="missingRange"{c.recognizedAudioInterval=nil}
 if mode=="expiredRange"{c.recognizedAudioInterval=("hello",0,7)}
 c.onFinished={value in
  check(c.consumeDelivery(value),"text consumes exact event");text += 1
  if mode=="muteInCallback"{c.lifecycle.requested=false}
  if mode=="routeInCallback"{c.captureGeneration=UUID()}
  if mode=="optOutInCallback"{c.speakerEvidenceEnabled=false}
  if mode=="sessionInCallback"{c.lifecycle.session=UUID()}
 }
 c.onSpeakerPCM={_,_ in audio += 1};c.finish()
 check(text==1,"generic conversation not blocked by missing PCM")
 check(audio==0,"private PCM rejected "+mode)
 if mode=="defaultOff"{check(c.input.seals==0,"default collects no PCM")}
}
print("PASS: \(checks) exact staged finish source assertions; recognizer/platform stubs, actual VoicePCMWindow")
