import Foundation
@MainActor final class ResultProbe {
 var result:CapturedVoiceEmbedding?
 var continuation:CheckedContinuation<CapturedVoiceEmbedding,Never>?
 func receive(_ value:CapturedVoiceEmbedding){result=value;continuation?.resume(returning:value);continuation=nil}
 func wait() async -> CapturedVoiceEmbedding {if let result{return result};return await withCheckedContinuation{continuation=$0}}
}
let worker=try LocalSpeakerEmbeddingWorker(verifiedModelPath:CommandLine.arguments[1])
let probe=ResultProbe()
@MainActor final class Boundary {var current:CapturedVoiceTurn?}
let boundary=Boundary()
let queue=VoicePCMJobQueue(process:{pcm in
 let observation=try await worker.extract(pcm.samples,sampleRate:pcm.sampleRate,turn:pcm.turn)
 return CapturedVoiceEmbedding(turn:observation.turn,vector:observation.vector,captureRouteBinding:pcm.captureRouteBinding)
},isCurrentSource:{boundary.current==$0},receive:{probe.receive($0)})
let session=UUID(),capture=UUID(),recognition=UUID()
let turn=CapturedVoiceTurn(session:session,capture:capture,recognitionTurn:recognition,text:"synthetic pipeline fixture",completedAt:ProcessInfo.processInfo.systemUptime)
var ring=VoicePCMWindow(session:session,capture:capture,sampleRate:16000,captureRouteBinding:"synthetic-route")!
ring.beginTurn(recognition)
let synthetic=(0..<24000).map{Float(0.15*sin(2 * Double.pi * 180 * Double($0)/16000))}
synthetic.withUnsafeBufferPointer{ring.append(samples:$0,stride:1,sampleRate:16000)}
let pcm=ring.seal(turn:turn,startSeconds:0,endSeconds:1.5)!
queue.setEnabled(true);boundary.current=turn
let ticket=queue.admitCurrentSourceTurn(turn)!;boundary.current=nil
queue.submit(pcm,ticket:ticket)
let result=await probe.wait()
var checks=0
@MainActor func check(_ value:Bool,_ label:String){checks += 1;if !value{print("FAIL "+label);exit(1)}}
check(result.turn==turn,"whole source turn preserved through actual native extraction")
check(result.vector.count==256 && result.vector.allSatisfy(\.isFinite),"actual256D finite embedding")
let evidence=VoiceEvidence(turn:result.turn)
check(!VoiceAuthorityPolicy.permits(.changeGoal,evidence:evidence),"no navigation authority")
check(!VoiceAuthorityPolicy.permitsPrivateContext(evidence:evidence),"no private context authority")
check(VoiceAuthorityPolicy.permits(.conversation,evidence:evidence),"generic conversation still eligible")
queue.setEnabled(false);ring.clear()
print("PASS: \(checks) real ring -> bounded queue -> official Swift/C/ONNX assertions; synthetic16kHz input only, no AVAudioConverter/ASR/device/identity claim")
