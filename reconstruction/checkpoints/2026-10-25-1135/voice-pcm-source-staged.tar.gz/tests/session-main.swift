import Foundation
actor Gate {
    var calls:[CapturedVoicePCM]=[]
    var waiting:[CheckedContinuation<CapturedVoiceEmbedding,Error>]=[]
    var observers:[(Int,CheckedContinuation<Void,Never>)]=[]
    func run(_ pcm:CapturedVoicePCM) async throws -> CapturedVoiceEmbedding {
        calls.append(pcm)
        for observer in observers where calls.count >= observer.0 {observer.1.resume()}
        observers.removeAll{calls.count >= $0.0}
        return try await withCheckedThrowingContinuation{waiting.append($0)}
    }
    func wait(_ count:Int) async {if calls.count >= count{return};await withCheckedContinuation{observers.append((count,$0))}}
    func finish() {let index=calls.count-1;waiting.removeFirst().resume(returning:CapturedVoiceEmbedding(turn:calls[index].turn,vector:[Float](repeating:0.1,count:256),captureRouteBinding:"synthetic-route"))}
    func ids()->[UUID]{calls.map{$0.turn.id}}
}
@MainActor final class Probe {
 var values:[CapturedVoiceEmbedding]=[];var waits:[(Int,CheckedContinuation<Void,Never>)]=[]
 func receive(_ value:CapturedVoiceEmbedding){values.append(value);for w in waits where values.count >= w.0{w.1.resume()};waits.removeAll{values.count >= $0.0}}
 func wait(_ count:Int) async {if values.count >= count{return};await withCheckedContinuation{waits.append((count,$0))}}
}
func pcm(_ text:String)->CapturedVoicePCM {
 let s=UUID(),c=UUID(),t=UUID(),turn=CapturedVoiceTurn(session:s,capture:c,recognitionTurn:t,text:text,completedAt:10)
 var window=VoicePCMWindow(session:s,capture:c,sampleRate:16000,captureRouteBinding:"synthetic-route")!;window.beginTurn(t)
 [Float](repeating:0.1,count:16000).withUnsafeBufferPointer{window.append(samples:$0,stride:1,sampleRate:16000)}
 return window.seal(turn:turn,startSeconds:0,endSeconds:1)!
}
var checks=0
@MainActor func check(_ b:Bool,_ text:String){checks += 1;if !b{print("FAIL "+text);exit(1)}}
@MainActor final class Source:VoiceEvidenceSource {
 var onSpeakerTurnWillSeal:((CapturedVoiceTurn)->VoicePCMAdmissionTicket?)?
 var onSpeakerPCM:((CapturedVoicePCM,VoicePCMAdmissionTicket)->Void)?
 var onSpeakerEvidenceInvalidated:(()->Void)?
 var voiceEvidenceOwner:UUID?
 var enabled=false
 var current:CapturedVoiceTurn?
 func isCurrentSpeakerBoundary(_ turn:CapturedVoiceTurn)->Bool {enabled && current==turn}
 func setSpeakerEvidenceEnabled(_ value:Bool){enabled=value;if !value{onSpeakerEvidenceInvalidated?()}}
 func seal(_ value:CapturedVoicePCM)->VoicePCMAdmissionTicket? {
  current=value.turn;defer{current=nil};return onSpeakerTurnWillSeal?(value.turn)
 }
}
let gate=Gate(),probe=Probe(),source=Source()
let session=VoiceEvidenceSession(source:source,process:{try await gate.run($0)},receive:{probe.receive($0)},now:{11})
check(!source.enabled,"initially off")
session.startAfterLocalConsent()
check(source.enabled,"single helper opt-in enables capture")
let a=pcm("a"),ta=source.seal(a)!
source.onSpeakerPCM?(a,ta);await gate.wait(1)
source.onSpeakerEvidenceInvalidated?()
let b=pcm("b"),tb=source.seal(b)!
source.onSpeakerPCM?(b,tb)
await gate.finish();await gate.wait(2);await gate.finish();await probe.wait(1)
check(probe.values.map{$0.turn.id} == [b.turn.id],"same queue invalidation retires in-flight A")
let c=pcm("c"),tc=source.seal(c)!
let delayed=source.onSpeakerPCM
let oldInvalidation=source.onSpeakerEvidenceInvalidated
let oldPreSeal=source.onSpeakerTurnWillSeal
session.stop()
check(!source.enabled && source.onSpeakerPCM == nil && source.onSpeakerTurnWillSeal == nil && source.onSpeakerEvidenceInvalidated == nil,"withdrawal disables capture and detaches callbacks")
delayed?(c,tc)
check(await gate.ids().count == 2,"retained callback cannot submit after withdrawal")
session.startAfterLocalConsent()
delayed?(c,tc)
check(await gate.ids().count == 2,"prior consent ticket cannot reenter new consent session")
let competing=VoiceEvidenceSession(source:source,process:{try await gate.run($0)},receive:{probe.receive($0)},now:{11})
let owner=source.voiceEvidenceOwner
competing.startAfterLocalConsent()
check(source.voiceEvidenceOwner==owner,"second owner cannot claim live source")
competing.stop()
check(source.enabled && source.voiceEvidenceOwner==owner && source.onSpeakerPCM != nil,"nonowner stop cannot tear down current session")
let d=pcm("d")
source.current=d.turn
check(oldPreSeal?(d.turn)==nil,"old consent pre-seal cannot mint in new legitimate boundary")
source.current=nil
let td=source.seal(d)!
oldInvalidation?()

source.onSpeakerPCM?(d,td);await gate.wait(3)
await gate.finish();await probe.wait(2)
check(probe.values.last?.turn.id==d.turn.id,"old invalidation cannot retire new consent ticket")
let e=pcm("e"),te=source.seal(e)!
source.onSpeakerPCM?(e,te);await gate.wait(4)
session.stop();await gate.finish()
for _ in 0..<20 {await Task.yield()}
check(probe.values.count==2,"withdrawal suppresses active ignored-cancel backend completion")
print("PASS: \(checks) actual session coordinator assertions with explicit capture stub")
