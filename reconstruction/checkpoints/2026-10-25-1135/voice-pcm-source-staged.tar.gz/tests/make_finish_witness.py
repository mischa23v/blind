from pathlib import Path
import hashlib,json
r=Path('/workspace/shared/blind-voice-pcm-stage');s=(r/'source/ios/BlindAssist/VoiceInput.swift').read_text();a=s.index('    func finish() {');b=s.index('\n    /// Scene operations',a);lines=[];skip=False
for line in s[a:b].splitlines():
 if line.strip()=='#if DEBUG':skip=True;continue
 if line.strip()=='#endif':skip=False;continue
 if not skip:lines.append(line)
body='\n'.join(lines);a=s.index('    func consumeDelivery(');b=s.index('\n    }',a)+6;consume=s[a:b];a=s.index('    func isCurrentSpeakerBoundary(');b=s.index('\n    }',a)+6;boundary=s[a:b]
code='''import Foundation
struct Life {var requested=true;var session=UUID()}
struct Utterance {var text="hello";func deliverable(isEcho:Bool)->String?{isEcho ? nil:text}}
struct Engine {var isRunning=true}
final class Input {
 var seals=0
 func sealSpeakerPCM(turn:CapturedVoiceTurn,start:Double,end:Double)->CapturedVoicePCM? {
  seals += 1
  var ring=VoicePCMWindow(session:turn.session,capture:turn.capture,sampleRate:16000,captureRouteBinding:"synthetic-route")!
  ring.beginTurn(turn.recognitionTurn)
  [Float](repeating:0.1,count:16000).withUnsafeBufferPointer{ring.append(samples:$0,stride:1,sampleRate:16000)}
  return ring.seal(turn:turn,startSeconds:start,endSeconds:end)
 }
}
@MainActor final class Capture {
 var lifecycle=Life(),utterance=Utterance(),engine:Engine?=Engine(),input=Input()
 var canCapture=true,continuous=true,captureGeneration=UUID(),turn=UUID(),speakerEvidenceEnabled=false
 var recognizedAudioInterval:(text:String,start:Double,end:Double)?=("hello",0,1)
 var activeDelivery:CapturedVoiceTurn?,activeSpeakerBoundary:CapturedVoiceTurn?,shouldIgnore:((String)->Bool)?,onFinished:((CapturedVoiceTurn)->Void)?,onSpeakerPCM:((CapturedVoicePCM,VoicePCMAdmissionTicket)->Void)?,onSpeakerTurnWillSeal:((CapturedVoiceTurn)->VoicePCMAdmissionTicket?)?,onSpeakerEvidenceInvalidated:(()->Void)?
 func beginTurn(){turn=UUID();recognizedAudioInterval=nil}
 func cancel(){lifecycle.requested=false;turn=UUID();captureGeneration=UUID();activeDelivery=nil;recognizedAudioInterval=nil;activeSpeakerBoundary=nil;onSpeakerEvidenceInvalidated?()}
'''+consume+'\n'+boundary+'\n'+body+'\n}\n'
code+='''
@MainActor final class Probe {
 var count=0;var waiter:CheckedContinuation<Void,Never>?
 func receive(_ result:CapturedVoiceEmbedding){count += 1;waiter?.resume();waiter=nil}
 func wait() async {if count>0{return};await withCheckedContinuation{waiter=$0}}
}
var checks=0
@MainActor func check(_ value:Bool,_ label:String){checks += 1;if !value{print("FAIL "+label);exit(1)}}
for continuous in [true,false] {
 let c=Capture();c.continuous=continuous;c.speakerEvidenceEnabled=true
 let expectedTurn=c.turn;var text=0;var segments:[CapturedVoicePCM]=[]
 let probe=Probe()
 let queue=VoicePCMJobQueue(process:{CapturedVoiceEmbedding(turn:$0.turn,vector:[Float](repeating:0.1,count:256),captureRouteBinding:"synthetic-route")},isCurrentSource:{c.isCurrentSpeakerBoundary($0)},receive:{probe.receive($0)})
 queue.setEnabled(true)
 c.onSpeakerTurnWillSeal={value in check(c.isCurrentSpeakerBoundary(value),"exact native mint boundary active");return queue.admitCurrentSourceTurn(value)}
 c.onSpeakerEvidenceInvalidated={queue.invalidate()}
 c.onFinished={value in check(c.consumeDelivery(value),"generic provenance unchanged");check(value.origin == .unverifiedMicrophone,"still unverified");text += 1}
 c.onSpeakerPCM={pcm,ticket in
  check(c.turn != pcm.turn.recognitionTurn,"recognizer already rotated before submission")
  check(!c.isCurrentSpeakerBoundary(pcm.turn),"mint boundary closed at submission")
  segments.append(pcm);queue.submit(pcm,ticket:ticket)
 };c.finish()
 if continuous {await probe.wait();check(probe.count==1,"ticket survives rotation to valid inference completion")}
 check(text==1,"normal speech still delivered")
 check(segments.count==(continuous ? 1:0),"only still-active continuous capture admits PCM")
 if let pcm=segments.first{check(pcm.turn.recognitionTurn==expectedTurn,"PCM bound before ASR rotation");check(pcm.samples.count==16000,"exact interval retained")}
}
for mode in ["defaultOff","muteInCallback","routeInCallback","optOutInCallback","sessionInCallback","wordsMismatch","missingRange","expiredRange"] {
 let c=Capture();c.speakerEvidenceEnabled=mode != "defaultOff";var text=0;var audio=0
 let queue=VoicePCMJobQueue(process:{CapturedVoiceEmbedding(turn:$0.turn,vector:[Float](repeating:0.1,count:256),captureRouteBinding:"synthetic-route")},isCurrentSource:{c.isCurrentSpeakerBoundary($0)},receive:{_ in})
 queue.setEnabled(true);c.onSpeakerTurnWillSeal={queue.admitCurrentSourceTurn($0)};c.onSpeakerEvidenceInvalidated={queue.invalidate()}
 if mode=="wordsMismatch"{c.recognizedAudioInterval=("other words",0,1)}
 if mode=="missingRange"{c.recognizedAudioInterval=nil}
 if mode=="expiredRange"{c.recognizedAudioInterval=("hello",0,7)}
 c.onFinished={value in
  check(c.consumeDelivery(value),"text consumes exact event");text += 1
  if mode=="muteInCallback"{c.lifecycle.requested=false}
  if mode=="routeInCallback"{c.captureGeneration=UUID()}
  if mode=="optOutInCallback"{c.speakerEvidenceEnabled=false}
  if mode=="sessionInCallback"{c.lifecycle.session=UUID()}
 }
 c.onSpeakerPCM={_,_ in audio += 1};c.finish()
 check(text==1,"generic conversation not blocked by missing PCM")
 check(audio==0,"private PCM rejected "+mode)
 if mode=="defaultOff"{check(c.input.seals==0,"default collects no PCM")}
}
print("PASS: \\(checks) exact staged finish source assertions; recognizer/platform stubs, actual VoicePCMWindow")
'''
(r/'tests/finish-main.swift').write_text(code);(r/'evidence/finish-source.json').write_text(json.dumps({'source_sha256':hashlib.sha256(s.encode()).hexdigest(),'finish':body,'consume':consume,'scope':'Exact staged source; recognizer/platform stubs, actual core PCM implementation'},indent=2))
