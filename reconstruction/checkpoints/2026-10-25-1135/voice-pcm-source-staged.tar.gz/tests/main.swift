import Foundation
var checks=0
@MainActor func check(_ x:Bool,_ label:String){checks += 1;if !x{print("FAIL "+label);exit(1)}}
let session=UUID(),capture=UUID(),recognition=UUID()
let turn=CapturedVoiceTurn(session:session,capture:capture,recognitionTurn:recognition,text:"authored test",completedAt:10)
var window=VoicePCMWindow(session:session,capture:capture,sampleRate:16000,captureRouteBinding:"synthetic-route")!
window.beginTurn(recognition)
@MainActor func push(_ values:[Float],rate:Double=16000){values.withUnsafeBufferPointer{window.append(samples:$0,stride:1,sampleRate:rate)}}
push([Float](repeating:0.1,count:48000))
let sealed=window.seal(turn:turn,startSeconds:0,endSeconds:3)!
check(sealed.samples.count==48000 && sealed.turn==turn,"exact interval binding")
for range in [(-1.0,1.0),(1.0,1.0),(0.0,4.0),(Double.nan,1.0),(0.0,Double.infinity)] {check(window.seal(turn:turn,startSeconds:range.0,endSeconds:range.1)==nil,"invalid ASR range")}
let changed=CapturedVoiceTurn(session:session,capture:UUID(),recognitionTurn:recognition,text:"test",completedAt:10)
check(window.seal(turn:changed,startSeconds:0,endSeconds:1)==nil,"source mismatch")
push([Float](repeating:0.2,count:80000))
check(window.seal(turn:turn,startSeconds:0,endSeconds:8)==nil,"no truncated long utterance")
check(window.seal(turn:turn,startSeconds:1,endSeconds:3)==nil,"expired interval")
let tail=window.seal(turn:turn,startSeconds:3,endSeconds:8)!
check(tail.samples.count==80000 && tail.samples.allSatisfy{$0==0.2},"wrapped interval matches frames")
window.beginTurn(UUID())
check(window.seal(turn:turn,startSeconds:0,endSeconds:1)==nil,"ASR rotation fences old turn")
window.beginTurn(recognition);push([Float](repeating:0.3,count:16000));window.clear()
check(window.seal(turn:turn,startSeconds:0,endSeconds:1)==nil,"mute/end clears PCM")
check(VoicePCMWindow(session:session,capture:capture,sampleRate:Double.infinity,captureRouteBinding:"synthetic-route")==nil,"invalid format")
check(VoicePCMWindow(session:session,capture:capture,sampleRate:96000,captureRouteBinding:"synthetic-route")==nil,"resource cap")
window=VoicePCMWindow(session:session,capture:capture,sampleRate:16000,captureRouteBinding:"synthetic-route")!;window.beginTurn(recognition);push([Float.nan]);push([Float](repeating:0.2,count:16000))
check(window.seal(turn:turn,startSeconds:0,endSeconds:1)==nil,"invalid data taints interval")
window=VoicePCMWindow(session:session,capture:capture,sampleRate:16000,captureRouteBinding:"synthetic-route")!;window.beginTurn(recognition)
push([Float](repeating:0.1,count:16000));push([0.1],rate:8000)
check(window.seal(turn:turn,startSeconds:0,endSeconds:1)==nil,"midstream format mismatch taints whole interval")
window=VoicePCMWindow(session:session,capture:capture,sampleRate:16000,captureRouteBinding:"synthetic-route")!;window.beginTurn(recognition)
push([Float](repeating:0,count:16000))
check(window.seal(turn:turn,startSeconds:0,endSeconds:1)?.samples.count==16000,"PCM retention never claims silence is a speaker")
window.invalidate()
check(window.seal(turn:turn,startSeconds:0,endSeconds:1)==nil,"unsupported native buffer invalidates ring")
print("PASS: \(checks) actual VoicePCMWindow assertions; synthetic sample intervals, no speech/identity claim")
