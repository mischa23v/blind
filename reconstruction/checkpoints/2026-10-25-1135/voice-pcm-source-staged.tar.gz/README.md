# Optional source-bound voice evidence stage

Not applied to the app. Microphone transcripts remain unverified. No speaker score, route, silence, VAD, ASR confidence or helper consent grants identity, addressee intent, private-history access or navigation authority.

## What is implemented
- Opt-in bounded six-second PCM ring, exact capture/session/recognizer/full-utterance ownership and ASR segment interval checks. The actual input route is captured at setup and carried unchanged as private metadata.
- Native pre-seal boundary issues a one-use admission ticket. Late submissions cannot choose a new owner. Recognition rotation does not invalidate an otherwise current completion.
- One active inference and one replacing pending buffer, cancellation/epoch retirement, ten-second expiry from final ASR completion. No raw PCM persistence or upload.
- Generation-bound, single-owner VoiceEvidenceSession connects all three native callbacks and revokes queue before capture/callback teardown. Explicit consent restart cannot reuse prior tickets.
- Optional AVAudioConverter to 16 kHz followed by the existing official sherpa Swift/C/ONNX worker. Fixed bundled model size and SHA256 verification. CPU synthetic mechanism executes on Linux, not Apple audio conversion.
- Generic transcript callbacks, current-turn anonymous privacy and existing hazards remain unchanged.

## Actual integration boundary
VoiceInput+EvidenceSource provides the real app conformance. The helper owner can construct VoicePCMProcessor, then VoiceEvidenceSession(source: voice, process: { try await processor.process($0) }, receive: localEnrollmentConsumer), retain it, and call startAfterLocalConsent only after explicit helper consent. Call stop on dismissal, consent withdrawal, lock/background, private-route loss, enrollment deletion/replacement. This stage supplies the coordinator, not a registered production helper screen or automatic app lifecycle observers. It is default off. Manual finish deliberately produces no PCM after cancellation; evidence delivery currently supports continuous mode only.

The local enrollment stage has bounded private template/held-out data, source-turn and model/route/preprocessing bindings, deletion and file-protection code. Connect each result's turn.id as sourceTurnID and captureRouteBinding as the enrolled route. Do not use an ASR recognition-session ID as an utterance ID. Enrollment/calibration is not a validated identity backend. A matched voice could be talking to somebody else, and replay can match. No threshold is supplied and no continuity/private context is unlocked.

## Evidence scope
Tests use public source and authored synthetic samples; no private child audio. Ring18, actual queue9, extracted native finish40, coordinator11 and source-contract5 checks. The original pre-ticket queue is retained under evidence/fail-before with executable-source reproduction of both late-owner failures. Finish platform/recognizer behavior is explicitly stubbed. Native pipeline uses actual official runtime/weights and synthetic tones; it does not measure wearer accuracy.
Main-thread seal copies at most six seconds under the sink lock; timing is unmeasured. AVAudioConverter full-output semantics, packaged CryptoKit model loader, iOS protected storage, background transitions, battery and real device capture are unexecuted on Apple. ASR timestamps are not forced alignment or overlap detection. Unsupported/short/long/expired input yields no evidence while ordinary nonprivate conversation remains available.

## Dependencies and device acceptance
Reuse /workspace/shared/blind-voice-native-investigation for pinned official source, C wrapper, model provenance and existing runtime. Optional iOS source-only build handoff is /workspace/shared/blind-voice-ios-build-stage. No dependency/runtime/model/audio/vector is included here.
Before recognition: opt-in local Arabic/English child/adult fixtures, family/TV/stranger/replay/overlap/noise/route changes, sensitivity-specific false accept/reject calibration, explicit intended-addressee evidence and replay limitations. Test mute/end/quiet, session/source switches and late ASR/embedding completion while hazards remain independent. Calibration and liveness/addressee gaps are functional blockers, not missing permission. Siri enrollment has no established public third-party identity API in the researched official APIs.

Final coordinator correction: all three callbacks are tied to the start generation and source owner. A second helper session cannot claim the same microphone; a stale/nonowning stop cannot detach current callbacks. Eleven source-bound checks pass; the original coordinator fails the new regression suite, retained under evidence/fail-before. Optional iOS package archive33edd11b predates this last coordinator correction; use this stage’s session source, not that stale snapshot, until refreshed.
