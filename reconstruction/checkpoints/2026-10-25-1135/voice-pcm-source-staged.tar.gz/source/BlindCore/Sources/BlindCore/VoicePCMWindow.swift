import Foundation

/// Ephemeral local PCM, deliberately not Codable. This binds the recognition
/// input interval, not a forced alignment, speaker identity or liveness claim.
public struct CapturedVoicePCM: Sendable {
    public let turn: CapturedVoiceTurn
    public let sampleRate: Int
    public let captureRouteBinding: String
    public let samples: [Float]
    public let firstFrame: Int64
    public let endFrame: Int64
}

/// A fixed six-second native-rate ring. Capture/turn swaps and append are guarded
/// by the existing audio sink lock; all allocation occurs before capture or seal.
/// Sample bounds are resource constraints, not acoustic quality/identity thresholds.
public struct VoicePCMWindow {
    public static let maximumSeconds = 6
    private let session: UUID
    private let capture: UUID
    public let sampleRate: Int
    private let captureRouteBinding: String
    private var recognitionTurn: UUID?
    private var storage: [Float]
    private var frames: Int64 = 0
    private var invalid = false
    public init?(session: UUID, capture: UUID, sampleRate: Double, captureRouteBinding: String) {
        guard sampleRate.isFinite, sampleRate >= 8000, sampleRate <= 48000,
              sampleRate.rounded() == sampleRate, !captureRouteBinding.isEmpty, captureRouteBinding.utf8.count <= 256 else { return nil }
        self.session = session; self.capture = capture; self.sampleRate = Int(sampleRate)
        self.captureRouteBinding = captureRouteBinding
        storage = [Float](repeating: 0, count: Int(sampleRate) * Self.maximumSeconds)
    }
    public mutating func beginTurn(_ id: UUID) {
        recognitionTurn = id; frames = 0; invalid = false
    }
    public mutating func append(samples: UnsafeBufferPointer<Float>, stride: Int, sampleRate: Double) {
        guard recognitionTurn != nil, !invalid else { return }
        guard stride > 0, sampleRate == Double(self.sampleRate) else { invalid = true; return }
        guard !samples.isEmpty else { return }
        let count = (samples.count - 1) / stride + 1
        guard frames <= Int64.max - Int64(count) else { invalid = true; return }
        for index in 0..<count {
            let value = samples[index * stride]
            guard value.isFinite, abs(value) <= 1 else { invalid = true; return }
            storage[Int(frames % Int64(storage.count))] = value
            frames += 1
        }
    }
    /// Apple transcription segment timestamps refer to this recognition request's
    /// audio interval. Missing/out-of-range/truncated intervals produce no evidence.
    /// No tail-only crop may stand in for an utterance longer than the retained ring.
    public func seal(turn: CapturedVoiceTurn, startSeconds: Double, endSeconds: Double) -> CapturedVoicePCM? {
        guard !invalid, turn.session == session, turn.capture == capture,
              turn.recognitionTurn == recognitionTurn, startSeconds.isFinite, endSeconds.isFinite,
              startSeconds >= 0, endSeconds > startSeconds,
              endSeconds <= Double(frames) / Double(sampleRate) else { return nil }
        let lower = Int64((startSeconds * Double(sampleRate)).rounded(.down))
        let upper = Int64((endSeconds * Double(sampleRate)).rounded(.up))
        let retainedStart = max(0, frames - Int64(storage.count))
        guard lower >= retainedStart, upper <= frames, upper > lower,
              upper - lower <= Int64(storage.count) else { return nil }
        var result = [Float](); result.reserveCapacity(Int(upper - lower))
        for frame in lower..<upper { result.append(storage[Int(frame % Int64(storage.count))]) }
        return CapturedVoicePCM(turn: turn, sampleRate: sampleRate, captureRouteBinding: captureRouteBinding, samples: result,
                                firstFrame: lower, endFrame: upper)
    }
    public mutating func invalidate() { invalid = true }
    public mutating func clear() {
        for index in storage.indices { storage[index] = 0 }
        recognitionTurn = nil; frames = 0; invalid = true
    }
}
