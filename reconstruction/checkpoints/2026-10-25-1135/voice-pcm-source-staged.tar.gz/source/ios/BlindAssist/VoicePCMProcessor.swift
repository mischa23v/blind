import Foundation
import AVFoundation
import BlindCore

/// Optional helper-enabled preprocessing/inference, never called from audio tap.
/// Connect only to the bounded VoicePCMJobQueue, not an unbounded Task per buffer.
actor VoicePCMProcessor {
    private let worker: LocalSpeakerEmbeddingWorker
    init() throws {
        let model = try PackagedSpeakerModel.verifiedURL()
        self.worker = try LocalSpeakerEmbeddingWorker(verifiedModelPath: model.path)
    }
    func process(_ pcm: CapturedVoicePCM) async throws -> CapturedVoiceEmbedding {
        try Task.checkCancellation()
        let samples = try Self.convert(pcm)
        let observation = try await worker.extract(samples, sampleRate: 16000, turn: pcm.turn)
        try Task.checkCancellation()
        guard observation.turn == pcm.turn else { throw CocoaError(.coderInvalidValue) }
        return CapturedVoiceEmbedding(turn: observation.turn, vector: observation.vector, captureRouteBinding: pcm.captureRouteBinding)
    }
    private static func convert(_ pcm: CapturedVoicePCM) throws -> [Float] {
        guard pcm.sampleRate >= 8000, pcm.sampleRate <= 48000, !pcm.samples.isEmpty,
              pcm.samples.count <= pcm.sampleRate * VoicePCMWindow.maximumSeconds,
              pcm.samples.allSatisfy({ $0.isFinite && abs($0) <= 1 }) else { throw CocoaError(.coderInvalidValue) }
        if pcm.sampleRate == 16000 { return pcm.samples }
        guard let sourceFormat = AVAudioFormat(commonFormat: .pcmFormatFloat32,
            sampleRate: Double(pcm.sampleRate), channels: 1, interleaved: false),
              let targetFormat = AVAudioFormat(commonFormat: .pcmFormatFloat32,
            sampleRate: 16000, channels: 1, interleaved: false),
              let source = AVAudioPCMBuffer(pcmFormat: sourceFormat, frameCapacity: AVAudioFrameCount(pcm.samples.count)),
              let destination = AVAudioPCMBuffer(pcmFormat: targetFormat, frameCapacity: 96000),
              let converter = AVAudioConverter(from: sourceFormat, to: targetFormat),
              let channel = source.floatChannelData?[0] else { throw CocoaError(.featureUnsupported) }
        pcm.samples.withUnsafeBufferPointer { channel.update(from: $0.baseAddress!, count: $0.count) }
        source.frameLength = AVAudioFrameCount(pcm.samples.count)
        var supplied = false
        var failure: NSError?
        let status = converter.convert(to: destination, error: &failure) { _, inputStatus in
            if supplied { inputStatus.pointee = .endOfStream; return nil }
            supplied = true; inputStatus.pointee = .haveData; return source
        }
        let expected = Double(pcm.samples.count) * 16000 / Double(pcm.sampleRate)
        guard failure == nil, status == .haveData || status == .endOfStream,
              Int(destination.frameLength) >= Int(expected.rounded(.down)),
              Int(destination.frameLength) <= Int(expected.rounded(.up)), destination.frameLength > 0,
              let output = destination.floatChannelData?[0] else { throw failure ?? CocoaError(.coderInvalidValue) as NSError }
        return Array(UnsafeBufferPointer(start: output, count: Int(destination.frameLength)))
    }
}
