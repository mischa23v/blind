import Foundation
import BlindCore

/// Internal seam for source-bound tests; implementation is the existing microphone owner.
@MainActor protocol VoiceEvidenceSource: AnyObject {
    var voiceEvidenceOwner: UUID? { get set }
    var onSpeakerTurnWillSeal: ((CapturedVoiceTurn) -> VoicePCMAdmissionTicket?)? { get set }
    var onSpeakerPCM: ((CapturedVoicePCM, VoicePCMAdmissionTicket) -> Void)? { get set }
    var onSpeakerEvidenceInvalidated: (() -> Void)? { get set }
    func isCurrentSpeakerBoundary(_ turn: CapturedVoiceTurn) -> Bool
    func setSpeakerEvidenceEnabled(_ enabled: Bool)
}

/// One helper-consented local diagnostic/enrollment session, not an identity provider.
/// The owning screen must call stop on dismissal, lock/background, route loss,
/// enrollment deletion/change and consent withdrawal. It must retain this owner.
/// No callback changes transcript authority, goal state, or conversation history.
@MainActor final class VoiceEvidenceSession {
    private weak var source: (any VoiceEvidenceSource)?
    private let queue: VoicePCMJobQueue
    private var running = false
    private var generation = UUID()
    init(source: any VoiceEvidenceSource, process: @escaping VoicePCMJobQueue.Processor,
         receive: @escaping @MainActor (CapturedVoiceEmbedding) -> Void,
         now: @escaping @Sendable () -> TimeInterval = { ProcessInfo.processInfo.systemUptime }) {
        self.source = source
        queue = VoicePCMJobQueue(process: process,
            isCurrentSource: { [weak source] in source?.isCurrentSpeakerBoundary($0) == true },
            receive: receive, now: now)
    }
    /// Only after the helper's explicit local biometric/diagnostic consent.
    func startAfterLocalConsent() {
        guard !running, let source, source.voiceEvidenceOwner == nil else { return }
        generation = UUID()
        let admittedGeneration = generation
        source.voiceEvidenceOwner = admittedGeneration
        running = true
        source.onSpeakerTurnWillSeal = { [weak self] turn in
            guard let self, self.owns(admittedGeneration) else { return nil }
            return self.queue.admitCurrentSourceTurn(turn)
        }
        source.onSpeakerPCM = { [weak self] pcm, ticket in
            guard let self, self.owns(admittedGeneration) else { return }
            self.queue.submit(pcm, ticket: ticket)
        }
        source.onSpeakerEvidenceInvalidated = { [weak self] in
            guard let self, self.owns(admittedGeneration) else { return }
            self.queue.invalidate()
        }
        queue.setEnabled(true)
        source.setSpeakerEvidenceEnabled(true)
    }
    private func owns(_ token: UUID) -> Bool {
        running && generation == token && source?.voiceEvidenceOwner == token
    }
    func stop() {
        let owned = owns(generation)
        // Revoke this session even when it never acquired (or no longer owns) the source.
        queue.setEnabled(false)
        running = false
        generation = UUID()
        guard owned, let source else { return }
        source.setSpeakerEvidenceEnabled(false)
        source.onSpeakerTurnWillSeal = nil
        source.onSpeakerPCM = nil
        source.onSpeakerEvidenceInvalidated = nil
        source.voiceEvidenceOwner = nil
    }
}
