import BlindCore

extension VoiceInput: VoiceEvidenceSource {}
