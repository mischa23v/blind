import Foundation
import CryptoKit

/// Only the pinned, public, signed-bundle model is accepted. No user-selected
/// model path, download, credential or network fallback is part of this loader.
enum PackagedSpeakerModel {
    static let expectedBytes = 26_530_550
    static let expectedSHA256 = "e9848563da86f263117134dfd7ad63c92355b37de492b55e325400c9d9c39012"
    static func verifiedURL(in bundle: Bundle = .main) throws -> URL {
        guard let resource = bundle.url(forResource: "wespeaker_en_voxceleb_resnet34_LM", withExtension: "onnx") else {
            throw CocoaError(.fileNoSuchFile)
        }
        let url = resource.resolvingSymlinksInPath().standardizedFileURL
        let root = bundle.bundleURL.resolvingSymlinksInPath().standardizedFileURL.path + "/"
        guard url.isFileURL, url.path.hasPrefix(root) else { throw CocoaError(.fileReadNoPermission) }
        let values = try url.resourceValues(forKeys: [.isRegularFileKey, .fileSizeKey])
        guard values.isRegularFile == true, values.fileSize == expectedBytes else { throw CocoaError(.fileReadCorruptFile) }
        let data = try Data(contentsOf: url, options: .mappedIfSafe)
        guard data.count == expectedBytes,
              SHA256.hash(data: data).map({ String(format: "%02x", $0) }).joined() == expectedSHA256 else {
            throw CocoaError(.fileReadCorruptFile)
        }
        return url
    }
}
