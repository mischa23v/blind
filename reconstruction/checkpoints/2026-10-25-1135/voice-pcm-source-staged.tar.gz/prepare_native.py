from pathlib import Path
import hashlib,json,difflib
live=Path('/workspace/shared/blind-rebuild/ios/BlindAssist/VoiceInput.swift');r=Path('/workspace/shared/blind-voice-pcm-stage');old=live.read_text();s=old
edits=[
('    private var captureGeneration = UUID()','    private var captureGeneration = UUID()\n    private var speakerEvidenceEnabled = false\n    var voiceEvidenceOwner: UUID?\n    private var recognizedAudioInterval: (text: String, start: Double, end: Double)?'),
('    var onFinished: ((CapturedVoiceTurn) -> Void)?','''    var onFinished: ((CapturedVoiceTurn) -> Void)?
    /// Optional memory-only diagnostics/enrollment hook. Never command authority.
    /// The receiver must enforce one active plus one pending inference at most.
    private var activeSpeakerBoundary: CapturedVoiceTurn?
    var onSpeakerTurnWillSeal: ((CapturedVoiceTurn) -> VoicePCMAdmissionTicket?)?
    var onSpeakerPCM: ((CapturedVoicePCM, VoicePCMAdmissionTicket) -> Void)?
    func isCurrentSpeakerBoundary(_ turn: CapturedVoiceTurn) -> Bool {
        speakerEvidenceEnabled && lifecycle.requested && canCapture && activeSpeakerBoundary == turn
            && lifecycle.session == turn.session && captureGeneration == turn.capture
    }
    var onSpeakerEvidenceInvalidated: (() -> Void)?
    func setSpeakerEvidenceEnabled(_ enabled: Bool) {
        guard enabled != speakerEvidenceEnabled else { return }
        speakerEvidenceEnabled = enabled
        if !enabled { input.discardSpeakerPCM(); onSpeakerEvidenceInvalidated?(); return }
        // Allocate the fixed ring on the main capture setup path, not the audio tap.
        if lifecycle.requested, canCapture {
            recover(message: arabic ? "أعيد توصيل الميكروفون." : "Reconnecting the microphone.", announce: false)
        }
    }'''),
('            sink.beginCapture(captureID) { [weak self] update in','            let routeBinding = audio.currentRoute.inputs.map { $0.portType.rawValue + ":" + $0.uid }.joined(separator: "|")\n            sink.beginCapture(captureID, session: sessionID, sampleRate: format.sampleRate,\n                              captureRouteBinding: routeBinding, collectSpeakerPCM: speakerEvidenceEnabled) { [weak self] update in'),
('        utterance = VoiceUtteranceTracker(); transcript = ""\n        speechBeganDelivered = false','        utterance = VoiceUtteranceTracker(); transcript = ""\n        recognizedAudioInterval = nil\n        speechBeganDelivered = false'),
('                    self.onSpeechBegan?()', '                    self.onSpeakerEvidenceInvalidated?()\n                    self.onSpeechBegan?()'),
('                        self.onSpeechBegan?()', '                        self.onSpeakerEvidenceInvalidated?()\n                        self.onSpeechBegan?()'),
('                    self.transcript = self.utterance.text','''                    self.transcript = self.utterance.text
                    let segments = result.bestTranscription.segments
                    if !segments.isEmpty, segments.allSatisfy({ $0.timestamp.isFinite && $0.duration.isFinite && $0.timestamp >= 0 && $0.duration >= 0 }),
                       let start = segments.map(\.timestamp).min(),
                       let end = segments.map({ $0.timestamp + $0.duration }).max(), end.isFinite, end > start {
                        self.recognizedAudioInterval = (self.utterance.text, start, end)
                    } else { self.recognizedAudioInterval = nil }'''),
('        if continuous, engine?.isRunning == true, canCapture { beginTurn() }\n        else { cancel() }','''        // Seal against the exact final words and request interval before rotation.
        // Segment timestamps describe recognizer input, not speaker identity.
        let admittedPCM: (CapturedVoicePCM, VoicePCMAdmissionTicket)? = completed.flatMap { turn in
            guard speakerEvidenceEnabled, let interval = recognizedAudioInterval,
                  interval.text == turn.text else { return nil }
            activeSpeakerBoundary = turn
            defer { activeSpeakerBoundary = nil }
            guard let ticket = onSpeakerTurnWillSeal?(turn), isCurrentSpeakerBoundary(turn),
                  let pcm = input.sealSpeakerPCM(turn: turn, start: interval.start, end: interval.end) else { return nil }
            return (pcm, ticket)
        }
        if continuous, engine?.isRunning == true, canCapture { beginTurn() }
        else { cancel() }'''),
('        onFinished?(completed)','''        onFinished?(completed)
        // A synchronous final callback may mute/end or change the route. Such a
        // change must retire private PCM even though generic speech was delivered.
        if let (pcm, ticket) = admittedPCM, speakerEvidenceEnabled, lifecycle.requested, canCapture,
           lifecycle.session == pcm.turn.session, captureGeneration == pcm.turn.capture {
            onSpeakerPCM?(pcm, ticket)
        }'''),
('        activeDelivery = nil\n        turn = UUID(); captureGeneration = UUID()','        activeDelivery = nil\n        recognizedAudioInterval = nil\n        activeSpeakerBoundary = nil\n        onSpeakerEvidenceInvalidated?()\n        turn = UUID(); captureGeneration = UUID()'),
('/// PCM is inspected synchronously, never stored, uploaded or shared across queues.','/// PCM is inspected synchronously; optional helper-enabled evidence retains only\n/// a bounded in-memory ring and emits a copied exact-interval segment. Never uploaded.'),
('    private var request: SFSpeechAudioBufferRecognitionRequest?','    private var request: SFSpeechAudioBufferRecognitionRequest?\n    private var speakerPCM: VoicePCMWindow?'),
('    func beginCapture(_ id: UUID, onUpdate: @escaping (AcousticOnsetMailbox.Update) -> Void) {\n        lock.lock(); defer { lock.unlock() }','''    func beginCapture(_ id: UUID, session: UUID, sampleRate: Double, captureRouteBinding: String, collectSpeakerPCM: Bool,
                      onUpdate: @escaping (AcousticOnsetMailbox.Update) -> Void) {
        // Called during main-thread setup before engine.start(), never in the tap.
        let window = collectSpeakerPCM ? VoicePCMWindow(session: session, capture: id, sampleRate: sampleRate, captureRouteBinding: captureRouteBinding) : nil
        lock.lock(); defer { lock.unlock() }
        speakerPCM = window'''),
('        mailbox.cancel(); onAcousticUpdate = nil; detector = AcousticSpeechOnset()','        mailbox.cancel(); onAcousticUpdate = nil; detector = AcousticSpeechOnset()\n        speakerPCM?.clear(); speakerPCM = nil'),
('        if let turn { mailbox.beginTurn(turn) }','        if let turn { mailbox.beginTurn(turn); speakerPCM?.beginTurn(turn) }'),
('            let wasActive = detector.isActive\n            let began = detector.process','            if request != nil { speakerPCM?.append(samples: samples, stride: stride, sampleRate: buffer.format.sampleRate) }\n            let wasActive = detector.isActive\n            let began = detector.process'),
('                scheduleDrain = mailbox.offer(isActive: detector.isActive, began: began, at: now)\n            }\n        }\n        lock.unlock()', '                scheduleDrain = mailbox.offer(isActive: detector.isActive, began: began, at: now)\n            }\n        } else if buffer.frameLength > 0 {\n            speakerPCM?.invalidate()\n        }\n        lock.unlock()'),
('        // Only a bounded edge notification crosses queues, never the PCM buffer.','        // The audio tap only schedules bounded edge metadata. Optional PCM is\n        // copied later by sealSpeakerPCM on the main thread, never queued per buffer.'),
('    private func drainAcousticUpdate() {','''    func discardSpeakerPCM() {
        lock.lock(); defer { lock.unlock() }
        speakerPCM?.clear(); speakerPCM = nil
    }
    func sealSpeakerPCM(turn: CapturedVoiceTurn, start: Double, end: Double) -> CapturedVoicePCM? {
        lock.lock(); defer { lock.unlock() }
        return speakerPCM?.seal(turn: turn, startSeconds: start, endSeconds: end)
    }
    private func drainAcousticUpdate() {''')]
for a,b in edits:
 assert ("\n"+s).count("\n"+a)==1,(a[:90],("\n"+s).count("\n"+a));s=("\n"+s).replace("\n"+a,"\n"+b)[1:]
(r/'source/ios/BlindAssist/VoiceInput.swift').write_text(s)
(r/'VoiceInput.swift.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),s.splitlines(True),fromfile='a/ios/BlindAssist/VoiceInput.swift',tofile='b/ios/BlindAssist/VoiceInput.swift')))
(r/'evidence/native-transform.json').write_text(json.dumps({'base_sha256':hashlib.sha256(old.encode()).hexdigest(),'staged_sha256':hashlib.sha256(s.encode()).hexdigest(),'edits':edits},indent=2))
print(hashlib.sha256(s.encode()).hexdigest())
