import Foundation

/// Local-only embedding handoff; never serializable by default and not identity.
public struct CapturedVoiceEmbedding: Sendable {
    public let turn: CapturedVoiceTurn
    public let vector: [Float]
    public init(turn: CapturedVoiceTurn, vector: [Float]) { self.turn = turn; self.vector = vector }
}

/// A single active job plus a replacing pending slot bounds retained PCM even
/// if native inference ignores cancellation until its current C call returns.
/// This queue controls lifecycle ownership only, never speaker/command authority.
@MainActor public final class VoicePCMJobQueue {
    public typealias Processor = @Sendable (CapturedVoicePCM) async throws -> CapturedVoiceEmbedding
    private let process: Processor
    private let now: @Sendable () -> TimeInterval
    private let receive: @MainActor (CapturedVoiceEmbedding) -> Void
    private var active: Task<Void, Never>?
    private var pending: CapturedVoicePCM?
    private var epoch = UUID()
    private var latest: CapturedVoiceTurn?
    public private(set) var enabled = false
    public init(process: @escaping Processor, receive: @escaping @MainActor (CapturedVoiceEmbedding) -> Void,
                now: @escaping @Sendable () -> TimeInterval = { ProcessInfo.processInfo.systemUptime }) {
        self.process = process; self.receive = receive; self.now = now
    }
    public func setEnabled(_ value: Bool) {
        guard value != enabled else { return }
        enabled = value
        invalidate()
    }
    /// Call on microphone mute/end, source change, private-route loss, lock,
    /// enrollment deletion/version change, and helper consent withdrawal.
    public func invalidate() {
        epoch = UUID(); pending = nil; latest = nil
        active?.cancel()
    }
    public func submit(_ pcm: CapturedVoicePCM) {
        guard enabled, isFresh(pcm.turn) else { return }
        latest = pcm.turn; pending = pcm
        if active != nil { active?.cancel(); return }
        startPending()
    }
    private func isFresh(_ turn: CapturedVoiceTurn) -> Bool {
        let time = now(), age = time - turn.completedAt
        return time.isFinite && turn.completedAt.isFinite && age >= 0 && age <= 10
    }
    private func startPending() {
        guard enabled, active == nil, let input = pending else { return }
        pending = nil
        guard isFresh(input.turn) else { latest = nil; return }
        let generation = epoch, processor = process
        active = Task { [weak self] in
            let result = try? await processor(input)
            guard let self else { return }
            if !Task.isCancelled, self.enabled, self.epoch == generation,
               self.latest == input.turn, self.isFresh(input.turn), let result, result.turn == input.turn,
               result.vector.count == 256, result.vector.allSatisfy(\.isFinite),
               result.vector.contains(where: { $0 != 0 }) {
                self.receive(result)
            }
            self.active = nil
            self.startPending()
        }
    }
}
