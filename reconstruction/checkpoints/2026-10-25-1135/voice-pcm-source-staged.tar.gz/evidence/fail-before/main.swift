import Foundation
actor Gate {
    var calls:[CapturedVoicePCM]=[]
    var waiting:[CheckedContinuation<CapturedVoiceEmbedding,Error>]=[]
    var observers:[(Int,CheckedContinuation<Void,Never>)]=[]
    func run(_ pcm:CapturedVoicePCM) async throws -> CapturedVoiceEmbedding {
        calls.append(pcm)
        for observer in observers where calls.count >= observer.0 {observer.1.resume()}
        observers.removeAll{calls.count >= $0.0}
        return try await withCheckedThrowingContinuation{waiting.append($0)}
    }
    func wait(_ count:Int) async {if calls.count >= count{return};await withCheckedContinuation{observers.append((count,$0))}}
    func finish() {let index=calls.count-1;waiting.removeFirst().resume(returning:CapturedVoiceEmbedding(turn:calls[index].turn,vector:[Float](repeating:0.1,count:256)))}
    func ids()->[UUID]{calls.map{$0.turn.id}}
}
@MainActor final class Probe {
 var values:[CapturedVoiceEmbedding]=[];var waits:[(Int,CheckedContinuation<Void,Never>)]=[]
 func receive(_ value:CapturedVoiceEmbedding){values.append(value);for w in waits where values.count >= w.0{w.1.resume()};waits.removeAll{values.count >= $0.0}}
 func wait(_ count:Int) async {if values.count >= count{return};await withCheckedContinuation{waits.append((count,$0))}}
}
func pcm(_ text:String)->CapturedVoicePCM {
 let s=UUID(),c=UUID(),t=UUID(),turn=CapturedVoiceTurn(session:s,capture:c,recognitionTurn:t,text:text,completedAt:10)
 var window=VoicePCMWindow(session:s,capture:c,sampleRate:16000)!;window.beginTurn(t)
 [Float](repeating:0.1,count:16000).withUnsafeBufferPointer{window.append(samples:$0,stride:1,sampleRate:16000)}
 return window.seal(turn:turn,startSeconds:0,endSeconds:1)!
}
let gate=Gate(),probe=Probe()
let queue=VoicePCMJobQueue(process:{try await gate.run($0)},receive:{probe.receive($0)},now:{11})
let a=pcm("a"),b=pcm("b")
queue.setEnabled(true)
queue.invalidate()
queue.submit(a)
await gate.wait(1)
print("BASELINE DEFECT: late A submitted after invalidation starts in new epoch")
queue.submit(b)
queue.submit(a)
await gate.finish()
await gate.wait(2)
let ids=await gate.ids()
guard ids == [a.turn.id,a.turn.id] else {fatalError("baseline reproduction failed")}
print("BASELINE DEFECT: late A replaces latest pending B")
await gate.finish()
await probe.wait(1)
print("Observed both source ownership failures; not an identity escalation")
