# Private voice enrollment: isolated source checkpoint

This directory is not applied to Blind Assist. It adds no microphone capture, model, upload, live enrollment, speaker threshold, authority elevation or UI. Only synthetic vectors are used in tests. The current app VoiceAuthority.swift remains unchanged: speaker candidates never unlock private history or consequential actions.

## Implemented local contracts

VoiceEnrollment.swift uses Foundation only. Helper setup requires an explicit consent receipt (self, or guardian for child), a pinned model SHA-256, embedding dimensions, capture route and preprocessing revision. The app must obtain consent through trusted helper UI, never an acoustic command or model inference. The receipt is bookkeeping, not authenticated identity or proof of informed consent.

A draft retains at most 12 vectors of at most 4,096 dimensions, with distinct source turn IDs (CapturedVoiceTurn.id, not the engine capture ID) and template versus held-out purpose. These are allocation bounds, not minimum speech, confidence or quality thresholds. A profile contains no raw audio, transcript, name, age or family data. Stored vectors remain private biometric data. Begin/cancel/finish rotates a ticket, rejecting late or reused results. Finish creates a new enrollment version. JSON-decoded records must pass validate before use; decode alone is insufficient. Several distinct utterances in one continuous capture are allowed; reusing one source turn, even with a different vector or purpose, is rejected. This source-only schema is unreleased; no migration for the earlier captureID spelling is provided. No averaging, matching decision or similarity cutoff is invented.

Calibration is unavailable for every record, including records with held-out samples. No persisted or caller-provided field can mark calibration complete. mayIdentifyWearer is always false. Held-out tags neither establish independent speech nor verify a person. The schema may support supervised future measurement, but has no calibrated matcher.

## iOS storage source proposal

ProtectedVoiceEnrollmentStore.swift is conditionally iOS-only and not Apple-typechecked or device-tested here. It uses Application Support / PrivateVoiceEnrollment and a fixed filename, serialized in an actor. Complete file protection and backup exclusion are set and verified on the directory before writing, with atomic complete-protected writes and reapplication/verification on each saved file. A failed precommit atomic write propagates unchanged without removing the destination, preserving any prior good enrollment. Only after the atomic write returns successfully does post-commit security verification run; if that verification fails, the committed replacement is removed and the error (or cleanup failure) is surfaced. This post-commit failure does not restore the previous record. A matching binding is required on load; older model/route/preprocessing records cannot be silently reused. Payload reads are bounded to 1 MiB.

Complete protection intentionally makes files unavailable while locked; do not weaken it to permit background identification. Host lifecycle must clear RAM records and pending PCM/embedding work on lock, mute/end, route change, deletion or consent withdrawal, and invalidate VoiceEvidenceOwnership. Swift arrays/Data do not guarantee secure RAM zeroization. File deletion is not a forensic flash-erasure guarantee. There is no migration, sync, cloud backup or export route. The private directory must not be included by future app export features.

Apple API sources, checked 2026-10-25:
- https://developer.apple.com/documentation/foundation/fileprotectiontype/complete
- https://developer.apple.com/documentation/foundation/nsdata/writingoptions/completefileprotection
- https://developer.apple.com/documentation/foundation/urlresourcekey/isexcludedfrombackupkey
- https://developer.apple.com/documentation/foundation/urlresourcevalues/isexcludedfrombackup
Apple states complete protection blocks reads/writes while locked/booting; backup exclusion must be reapplied after each save because file operations can reset it. This implements documented APIs, not a new cryptosystem.

## Next integration boundaries

1. A trusted helper screen explains local biometric templates, absent accuracy validation and review/delete controls. Obtain guardian consent for a child. Do not enroll live/private audio until specifically consented.
2. Only the active native capture owner sends model vectors with exact source turn ID (CapturedVoiceTurn.id) and matching immutable binding into the draft. Do not wire enrollment through anonymous conversation or accept external uploaded templates.
3. Mark separately recorded held-out utterances without converting successful extraction into a match. Target-device/headset/child-language experiments must establish distributions, false accepts/rejects, route sensitivity and an independently reviewed decision rule. No guessed cutoff is present here.
4. On finish, replace the single protected record and invalidate prior voice evidence. Review exposes status/version, not vectors. Delete clears disk and all active in-memory references/drafts. Host lock/route/deletion tests remain required.
5. Replay/liveness and addressee evidence remain separate absent capabilities. Even future speaker matching does not establish who was addressed, live intent, authority or safe physical guidance.

## Reproduction and limits

Run tests/run.sh /path/to/existing/swiftc. No dependency install or model download. It compiles only Foundation contracts plus synthetic tests, with a local temporary module cache. Apple storage APIs are excluded on Linux; Linux success says nothing about their compilation, backup exclusion, lock behavior or storage recovery on an iPhone. Apple SDK/Xcode and device verification are blockers, not passing checks. A host-app integration test must additionally show source-turn binding and no authority/private-context promotion.

Source-only checkpoint excludes tmp/, binaries and real enrollment data. Tests print counts only. Parent may integrate after review; this work makes no live-tree changes.

## Measured evidence

Earlier 2026-10-25 checkpoint: existing Swift 6.4.1 Debian toolchain compiled the Foundation source and executed 22 synthetic contract checks successfully (preserved in fail-before-storage-review.tar.gz). Build output was empty (evidence/build.log). This includes denied consent, malformed binding, model/route/preprocessing mismatch, stale session, NaN/zero/wrong-shape vectors, duplicate source turn, empty/held-out-only finish, capacity, cancellation, finished-ticket reuse, JSON roundtrip and rejected schema version. No Apple storage API ran. No real audio or embedding extraction ran in this stage.

## Storage-review correction and measured evidence

The previous archive is preserved as fail-before-storage-review.tar.gz (SHA-256 d123deedbffeac7d9402716547e13dac3cf1675e770ce3cb18b461de42ac13b7). After explicit release of the focused compile slot, the corrected Foundation source compiled using the existing 17 MiB scratch and executed 40 synthetic checks successfully. evidence/result.log and evidence/execution-receipt.json bind this run to exact source hashes. The preserved fail-before archive is source/prior-test evidence only: the newly added regression cases were not run against the old source.

Storage load now opens with Darwin O_NOFOLLOW/O_NONBLOCK, validates the descriptor with fstat as a regular file, and uses FileHandle reads totaling at most 1 MiB + 1 byte before rejecting actual oversized data or decoding. It no longer relies on path metadata size as an allocation bound. Symlinks/nonregular final files are rejected. Apple SDK compilation, filesystem replacement/failure-injection and device protection tests remain unexecuted.

A store-owned VoiceEnrollmentStoreGeneration issues an ephemeral ticket only at trusted helper setup start, before asynchronous extraction. Save requires that ticket and the record's matching consent setup ID. Delete invalidates the selected generation before cleanup, including if cleanup fails. A queued old save after deletion is rejected, and another setup rotates the generation. Store save has no suspension between validation and disk mutation. Callers must never beginHelperSetup from asynchronous completion or automatically acquire a new ticket to bypass stale-work rejection. Tests exercise the actual Foundation coordinator's delete, delayed save rejection, new setup, different consent, same-consent generation rotation and cleanup-failure invalidation; they do not execute Apple's file store.

Failed-deletion read fence: delete admission also retires in-process read eligibility before filesystem cleanup. load returns nil while that fence is active, even if an old disk profile survives a failed removal. Beginning another helper setup does not clear the fence. Only confirmed successful erase (including retry), or a newly selected committed replacement that passed protection verification, restores reads. Executed Foundation coordinator tests cover failed erase → withheld reads → helper setup still withheld → successful erase retry, and verified replacement restoration. This is an in-memory fence, not a durable tombstone: restarting the app/store after a failed erase can expose remaining bytes again. The UI must report deletion failure and require successful retry; persistent deletion intent across restart remains an explicit unresolved requirement. No forensic erase guarantee is made.

The 40-check run includes the actual shared bounded-read helper on synthetic files (exact 64-byte bound, 65-byte overflow rejection, empty file), save-generation invalidation, deletion callback failure and read eligibility fencing. These are production Foundation mechanisms with synthetic fixtures; the Apple actor, descriptor flags, file protection, race replacement and device lifecycle remain unexecuted. Reviewer source review found these mechanisms clear; this is not production biometric enrollment clearance.
