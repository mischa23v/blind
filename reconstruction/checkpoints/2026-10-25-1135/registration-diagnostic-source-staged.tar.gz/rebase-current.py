from pathlib import Path
import shutil
s=Path(__file__).parent;r=Path('/workspace/shared/blind-rebuild')
rel='ios/BlindAssist/NavigationModel.swift';t=(r/rel).read_text()
a='        guard running, !simulation, !places.scanning, frame.timestamp - lastProcessed >= 1.0 / 15 else { return }';assert t.count(a)==1;t=t.replace(a,'''        if places.scanning, let scanSession = UUID(uuidString: observationFrameID) {
            places.observeRegistrationFrame(frame, sessionID: scanSession, now: ProcessInfo.processInfo.systemUptime)
        }
'''+a)
a='places.startScan(session: session, name: name, compare: compare ? recognizedPlace : nil, relocalized: recognizedPlace != nil)';assert t.count(a)==1;t=t.replace(a,a[:-1]+', registrationSessionID: UUID(uuidString: observationFrameID))')
a='    var scopedConversationReviews:';assert t.count(a)==1;t=t.replace(a,'''    /// Explicit saved-place selection opens dated reports, not current identity.
    func historicalReports(for place: SavedPlace) -> [CompanionFact] {
        companionWorkingState.factBook.reportedHistory(placeID: place.id.uuidString)
    }

'''+a)
a='    func deletePlace(_ place: SavedPlace) {\n';assert t.count(a)==1;t=t.replace(a,a+'        places.retireRegistration(for: place)\n')
(s/'proposal'/rel).write_text(t)
rel='BlindCore/Sources/BlindCore/CompanionFacts.swift';t=(r/rel).read_text();a='    public init() {}';i=t.index(a,t.index('public struct CompanionFactBook:'));t=t[:i]+'''    /// Attributed history for an explicit stored place, never live localization.
    public func reportedHistory(placeID: String) -> [CompanionFact] {
        guard !placeID.isEmpty, placeID.utf8.count <= 128 else { return [] }
        return facts.filter { $0.scope?.valid == true && $0.scope?.placeID == placeID }
            .sorted { $0.at > $1.at }
    }

'''+t[i:];(s/'proposal'/rel).write_text(t)
# Current preimages are separate from the preserved initial provider checkpoint.
for p in (s/'proposal').rglob('*'):
 if p.is_file():
  rel=p.relative_to(s/'proposal')
  if (r/rel).exists():
   q=s/'baseline-current'/rel;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(r/rel,q)
