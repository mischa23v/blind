# Native memory scope acquisition: source checkpoint 00

This is a staged investigation, not a positive identity issuer or device accuracy claim.

## Existing evidence
- PlaceStore.worldMapArtifacts verifies saved world-map and CapturedRoom hashes and the declared origin anchor.
- SavedWorldFrameRecovery observes relocalizing -> normal, original anchor, exact session and a 0.5-second capture-time lease. This restores coordinate association only. It does not measure false relocalization, room containment uncertainty or container identity.
- PlaceStore comparison scanning uses RoomCaptureSession(arSession:) and receives actual RoomPlan measurements. Present comparison logic uses category/position matching and discards the structured rescan evidence. This is not independent instance correspondence.
- NativeLocalizationMeasurements is a future input contract. No production independentlyValidated producer exists; NavigationModel's calibration revision is unconfigured.
- CompanionMemoryScope requires place/floor/room identity. objectInstanceID is optional; room history must not inherit exact container authority, or vice versa.

## Acquisition opportunity under investigation
Retain bounded immutable baseline/rescan measurement records from the existing comparison-scan flow, tied to exact artifact hashes, scan/session ownership and original capture times. A review can explicitly select independent physical-feature correspondences; retain original feature transforms, units, residuals and provenance. Do not automatically pair by category or equal identifiers. Same-frame residuals measure consistency, not total accuracy or uniqueness. No default calibration bound may convert this record into an independently validated current scope.

Positive room association additionally needs a justified room/floor containment boundary and uncertainty model applicable to the actual acquisition conditions. Exact fridge identity additionally needs an explicit independently supported instance correspondence. Neither a requested saved place, a map label, GPS proximity nor a restored authored anchor alone supplies these.

## Official upstream sources consulted
- https://developer.apple.com/documentation/ARKit/managing-session-life-cycle-and-tracking-quality : saved-map recovery relies on environment-dependent relocalization; altered lighting/features affect reliability.
- https://developer.apple.com/videos/play/wwdc2023/10192/ : shared ARSession/multi-room capture and exported node-to-CapturedRoom identifier association.
- https://developer.apple.com/documentation/roomplan/capturedroom/identifier : identifier assigned to captured room.
- https://developer.apple.com/documentation/roomplan/capturedroom/object/identifier : identifier of captured object; not documentation of independent current physical re-identification.

## Separate justified integration
The already-reviewed loss-only retireCompanionMemoryScope method may be called at native perception invalidation. It retires conversation sources and output without minting a new place. Its executable wiring/regression will remain a separate narrow proposal.

## Checkpoint 04 implementation and limits
The existing helper comparison scan now acquires immutable, hash-bound original and measured RoomPlan feature matrices, dimensions, floor polygons and raw story metadata, original capture time, session and scan ownership. The helper selects correspondence IDs explicitly; code reports their center residual in metres without fitting or inventing a calibration bound. Counts and corners are checked before expansion. Restart reloads only diagnostic history, never live scope. Existing GRDB profile storage/tombstones prevent late room-record resurrection, including alternate-case IDs.

The helper can save and reload locally off-main. One active read/write is admitted; selecting B while A is held retires A's publication and exposes an explicit retry for B after completion, rather than silently losing B. Stale success/failure cannot overwrite B's status. Normal ordinary finding does not depend on this helper: the separately implemented automatic historical fallback remains available without a positive scope.

This is not a completed positive scope issuer. A measured relocalization/registration accuracy envelope and justified room/floor containment uncertainty are still missing. Raw story integers, equal labels, category similarity and saved-map recovery do not supply them. Exact container instance authority additionally needs independently supported correspondence, not inherited room confidence. Actual Apple SDK compilation/availability checks (including CapturedRoom.story) and supervised independent physical validation remain pending. Linux platform seams and authored two-fridge tests are not camera accuracy evidence.

Tests: 22 actual extracted/native/core acquisition cases, 41 real GRDB cases, 3 source contracts and four syntax parse configurations. Held selection/status and preflight-bound defects reproduce against checkpoint03 (3 cases, 9 failed assertions); final cases pass. Same-session delayed frame defect separately retained (1 case, 2 failed assertions). GRDB uses the existing pinned 7.11.1 checkout at revision b83108d10f42680d78f23fe4d4d80fc88dab3212; no new download.

## Durable repository replay (checkpoint 05)
The proposal now includes tools/test/room-registration-acquisition.test.mjs and three authored fixture files. The runner extracts current PlaceStore, RoomLayoutAdapter, WorkingState and historical selector calls, imports the actual proposed Core registration types, and wraps the real pinned GRDB store only to control blocked reads/writes. It preserves all 22 cases, rather than relying on archived copied reducers. The source-only projection passes all 4 Node checks and 22 extracted cases with zero skips. Set BLIND_SWIFTC and BLIND_GRDB_PATH to the existing pinned checkout; on Linux, retain the existing SQLITE_TEST_SDK flags. The runner never downloads dependencies and rejects a different GRDB revision. Final boarding/loss-first native/source-contract rebase and Apple SDK build are still required before any release.

## Checkpoint 06 preparation ownership and cost
The new comparison-scan preparation no longer rereads/unarchives the saved map or decodes CapturedRoom on the scan owner. It reuses immutable room bytes that the existing saved-world recovery already verified against the exact artifact hashes, capped at 8 MiB. One physical utility preparation lease survives selection cancellation until completion; no second decoder is spawned by rapid rescan. Only matching request, scan, session, store owner and current saved descriptor can publish the bounded feature snapshot. Deletion retires cached bytes and preparation publication before storage, including failed erasure. The asynchronous RoomBuilder result also retains its original measurement request before publishing either success or failure status.

The existing beginWorldMapRecovery/worldMapArtifacts path still synchronously loads/unarchives/hashes saved files. This increment removes only the newly added startScan read/decode, not that preexisting IO. Input/output bounds are not a device latency, allocation or energy guarantee. Feature conversion and decoding use authored RoomPlan types in Linux tests; actual Apple SDK build and device cost validation remain required.

All 26 extracted cases and 5 durable Node checks pass without skips. Four new cases cover off-main held decode, cancellation/new scan without fanout, descriptor/store replacement, deletion with a controlled failing storage boundary, and whole oversized-byte rejection. Storage failures are injected around the real GRDB store, not claimed to be a physical disk-full test. The original checkpoint05 main-owner source contract failure, the first fixture-only ambiguous-decoder compile failure, and the empty-feature positive-fixture failure are retained separately. Four native syntax configurations pass. No positive physical scope is issued.

## Checkpoint 07 pending selection deletion
An explicit selected-place receipt is now recorded before admitting a registration load, including a held/deferred load. Deletion admission retires that exact selection even after restart when no cached/current diagnostic exists. Matching cached preparation is retired independently; deleting A does not invalidate a held unrelated helper selection B. Physical saved-world recovery still resets after successful room erasure. Checkpoint06 reproduces both failures with 2 cases and 3 assertions; checkpoint07 passes all 28 cases and all 5 durable runner checks, with zero skips. No broader legacy comparison-narration cancellation change is included.

The runner supports BLIND_REGISTRATION_REPLAY_SCRATCH to reuse one bounded compiler tree; execution logs retain unique filenames. Only inactive generated output trees were cleaned. Source, test, dependency checkouts and all failure evidence remain intact.

## Checkpoint 08 loaded bytes versus pending selection
Deletion also clears an exact matching loaded registration independently of a different pending selection. Loaded A → selected/held B → failed deletion A now removes A from review/pair selection immediately while B retains its original request, owner and status and can complete. Checkpoint07 reproduces 1 case with 2 assertions; final checkpoint08 passes all29 extracted cases and5 durable runner checks with zero skips. All prior checkpoints and failures are preserved.

## Checkpoint 09 native privacy admission
The exact-target retireRegistration(for:) method is now called synchronously at native deletePlace admission before the asynchronous observed-geometry purge, and again idempotently by PlaceStore.delete. Failed/held earlier purge cannot leave a diagnostic selected for deletion eligible for review; unrelated B's pending selection remains owned. Exact extracted native deletePlace with an authored held/failing purge reproduces the missing call (1 case,1 assertion); final30 cases and5 durable checks pass without skips. Four syntax configurations pass. This adds one narrow native transform to the prior three acquisition transforms, not a legacy comparison-narration rewrite. Actual Apple platform compilation and ordered native-prefix integration remain outstanding.
