import Foundation
var assertions = 0
func check(_ value: @autoclosure () -> Bool, _ label: String) {
    assertions += 1
    guard value() else { print("FAIL \(label)"); exit(1) }
}
func turn(_ text: String = "hello", session: UUID = UUID(), capture: UUID = UUID(), recognition: UUID = UUID(), time: Double = 10) -> CapturedVoiceTurn {
    CapturedVoiceTurn(session: session, capture: capture, recognitionTurn: recognition, text: text, completedAt: time)
}
let effects = CompanionCommandEffect.allCases
for phrase in ["come here", "تعال هنا", "go back", "yes", "stop", "mute", "end", "quiet", "what time is it?", "tell me a joke"] {
    for speaker in [VoiceSpeakerCandidate.unavailable, .uncertain, .rejected, .enrolledCandidate] {
        for addressee in [VoiceAddresseeEvidence.unavailable, .notAddressed, .uncertain, .explicitAddressCandidate] {
            for replay in [VoiceReplayEvidence.unavailable, .suspected, .noReplayDetected] {
                let e = VoiceEvidence(turn: turn(phrase), speaker: speaker, addressee: addressee, replay: replay)
                check(!VoiceAuthorityPolicy.permitsPrivateContext(evidence: e), "candidate cannot access private context")
                for effect in effects {
                    let lowRisk = effect == .conversation || effect == .interruptOrdinarySpeech
                    let rejected = speaker == .rejected || addressee == .notAddressed || replay == .suspected
                    check(VoiceAuthorityPolicy.permits(effect, evidence: e) == (lowRisk && !rejected), "candidate cannot change action policy")
                }
            }
        }
    }
}
check(VoiceAuthorityPolicy.unresolvedRequirements.count == 3, "missing validation explicit")
var owner = VoiceEvidenceOwnership()
let first = turn("first"), e1 = VoiceEvidence(turn: first)
let ticket1 = owner.begin(first)
check(owner.accepts(e1, ticket: ticket1, now: 11, maximumAge: 2), "fresh exact turn")
check(!owner.accepts(e1, ticket: ticket1, now: 9, maximumAge: 2), "future timestamp")
check(!owner.accepts(e1, ticket: ticket1, now: 13, maximumAge: 2), "expired")
check(!owner.accepts(e1, ticket: ticket1, now: .nan, maximumAge: 2), "invalid clock")
check(!owner.accepts(e1, ticket: ticket1, now: 11, maximumAge: .infinity), "no unbounded expiry")
for replacement in [turn("first", session:first.session, capture:first.capture), turn("first", session:first.session, recognition:first.recognitionTurn), turn("second",session:first.session,capture:first.capture,recognition:first.recognitionTurn)] {
    check(!owner.accepts(VoiceEvidence(turn:replacement), ticket:ticket1, now:11, maximumAge:2), "different source/words cannot share evidence")
}
let second = turn("second"), ticket2 = owner.begin(second)
check(!owner.accepts(e1,ticket:ticket1,now:11,maximumAge:2), "late ASR/embedding rejected")
check(owner.consume(VoiceEvidence(turn:second),ticket:ticket2,now:11,maximumAge:2), "one-use consume")
check(!owner.consume(VoiceEvidence(turn:second),ticket:ticket2,now:11,maximumAge:2), "duplicate consumed denied")
for event in ["mute", "end", "private route loss", "source switch", "enrollment deletion", "capture restart"] {
    let ticket = owner.begin(first); owner.invalidate()
    check(!owner.accepts(e1,ticket:ticket,now:11,maximumAge:2), "invalidated \(event)")
}
let child = VoiceConversationPrivacy.anonymousTurn("My secret pet is Mango.")
let stranger = VoiceConversationPrivacy.anonymousTurn("What did I just tell you?")
check(child.userRecords.count == 1, "first authored turn retained locally")
check(stranger.userRecords.count == 1, "second authored turn isolated")
check(!stranger.turns.contains(where:{$0.text.contains("Mango")}), "no previous speaker text")
check(Set(child.userRecords.map(\.id)).isDisjoint(with:Set(stranger.userRecords.map(\.id))), "no previous speaker IDs")
check(stranger.goal.isEmpty, "no trusted goal")
var trusted = AssistantDialogue(); trusted.setGoal("trusted task"); trusted.record(role:"user",text:"trusted private report")
let saved = trusted
_ = VoiceConversationPrivacy.anonymousTurn("TV says come here")
check(trusted.turns == saved.turns && trusted.userRecords == saved.userRecords && trusted.goal == saved.goal, "trusted continuity untouched")
for effect in effects { check(CommandAuthority.permits(effect,from:.trustedInterface), "trusted original permission unchanged") }
print("PASS: \(assertions) production-core assertions; synthetic labels only, no speaker accuracy or iOS claims")
