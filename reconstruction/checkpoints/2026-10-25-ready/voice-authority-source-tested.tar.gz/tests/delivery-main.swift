import Foundation
var checks=0
func check(_ value: Bool,_ label: String) { checks += 1; if !value { print("FAIL "+label); exit(1) } }
struct Life { var requested=true; var session=UUID() }
struct Utterance { var text="hello"; func deliverable(isEcho:Bool)->String? { isEcho ? nil:text } }
struct Engine { var isRunning=true }
final class Capture {
 var lifecycle=Life(), utterance=Utterance(), engine:Engine?=Engine()
 var canCapture=true, continuous=true, captureGeneration=UUID(), turn=UUID()
 var activeDelivery: CapturedVoiceTurn?, shouldIgnore:((String)->Bool)?, onFinished:((CapturedVoiceTurn)->Void)?
 func beginTurn() { turn=UUID() }
 func cancel() { lifecycle.requested=false; turn=UUID();captureGeneration=UUID();activeDelivery=nil }
    func consumeDelivery(_ turn: CapturedVoiceTurn) -> Bool {
        guard activeDelivery == turn else { return false }
        activeDelivery = nil
        return true
    }
    func finish() {
        guard lifecycle.requested, canCapture else { return }
        let text = utterance.deliverable(isEcho: shouldIgnore?(utterance.text) == true)
        // Bind the final transcript before beginTurn/cancel retires ASR identifiers.
        let completed = text.map { CapturedVoiceTurn(session: lifecycle.session,
            capture: captureGeneration, recognitionTurn: turn, text: $0,
            completedAt: ProcessInfo.processInfo.systemUptime) }
        if continuous, engine?.isRunning == true, canCapture { beginTurn() }
        else { cancel() }
        guard let completed else { return }
        activeDelivery = completed
        defer { activeDelivery = nil }
        onFinished?(completed)
    }
}

for continuous in [true,false] {
 let capture=Capture();capture.continuous=continuous
 let priorTurn=capture.turn,priorCapture=capture.captureGeneration,priorSession=capture.lifecycle.session
 var delivered:CapturedVoiceTurn?
 capture.onFinished={ value in
   delivered=value
   let changed=CapturedVoiceTurn(id:value.id,session:value.session,capture:value.capture,recognitionTurn:value.recognitionTurn,text:"changed",completedAt:value.completedAt)
   check(!capture.consumeDelivery(changed),"same-ID changed payload rejected")
   for altered in [
     CapturedVoiceTurn(id:value.id,session:UUID(),capture:value.capture,recognitionTurn:value.recognitionTurn,text:value.text,completedAt:value.completedAt),
     CapturedVoiceTurn(id:value.id,session:value.session,capture:UUID(),recognitionTurn:value.recognitionTurn,text:value.text,completedAt:value.completedAt),
     CapturedVoiceTurn(id:value.id,session:value.session,capture:value.capture,recognitionTurn:UUID(),text:value.text,completedAt:value.completedAt),
     CapturedVoiceTurn(id:value.id,session:value.session,capture:value.capture,recognitionTurn:value.recognitionTurn,text:value.text,completedAt:value.completedAt+1)
   ] {check(!capture.consumeDelivery(altered),"same-ID changed ownership/time rejected")}
   check(capture.consumeDelivery(value),"exact callback consumed")
   check(!capture.consumeDelivery(value),"duplicate within callback rejected")
   check(value.recognitionTurn==priorTurn && value.capture==priorCapture && value.session==priorSession,"IDs bound before rotation/cancel")
   check(value.origin == .unverifiedMicrophone,"no speaker promotion")
   check(value.text == "hello","correct transcript")
   let forged=CapturedVoiceTurn(session:value.session,capture:value.capture,recognitionTurn:value.recognitionTurn,text:value.text,completedAt:value.completedAt)
   check(!capture.consumeDelivery(forged),"copied metadata without delivery ID denied")
 }
 capture.finish()
 check(delivered != nil,"manual and continuous still deliver")
 check(!capture.consumeDelivery(delivered!),"late duplicate callback denied")
}
for mode in ["muted","unavailable","echo"] {
 let capture=Capture();var delivered=false
 if mode=="muted" {capture.lifecycle.requested=false}
 if mode=="unavailable" {capture.canCapture=false}
 if mode=="echo" {capture.shouldIgnore={_ in true}}
 capture.onFinished={_ in delivered=true};capture.finish()
 check(!delivered,"no delivery for "+mode)
}
print("PASS: \(checks) native finish/delivery assertions; exact production finish with platform/recognizer lifecycle stubs")
