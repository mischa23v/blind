import Foundation
var checks=0
func check(_ value: Bool,_ label: String) { checks += 1; if !value { print("FAIL "+label); exit(1) } }
struct LocalImageAssistant {
 static var captured: [AssistantDialogue] = []
 static func converse(dialogue: AssistantDialogue, arabic: Bool, audience: Int, availableTools: [String], toolExecutor: String?, requestID: UUID) async -> Int { captured.append(dialogue); return 0 }
}
final class Baseline {
 var arabic=false, assistantAudience=0, unverifiedDialogue=AssistantDialogue()
 func run(_ text:String) async {
         unverifiedDialogue.record(role: "user", text: text)
        let dialogue = unverifiedDialogue
 let id=UUID()
             let answer = await LocalImageAssistant.converse(dialogue: dialogue, arabic: self.arabic,
                audience: self.assistantAudience,
                availableTools: [], toolExecutor: nil, requestID: id)
 _ = answer
 }
}
final class Staged {
 var arabic=false, assistantAudience=0, unverifiedDialogue=AssistantDialogue()
 func run(_ text:String) async {
         let dialogue = VoiceConversationPrivacy.anonymousTurn(text)
 let id=UUID()
             let answer = await LocalImageAssistant.converse(dialogue: dialogue, arabic: self.arabic,
                audience: self.assistantAudience,
                availableTools: [], toolExecutor: nil, requestID: id)
 _ = answer
 }
}

let original=Baseline()
await original.run("Authored child fixture: my pet is Mango")
await original.run("Authored stranger fixture: what did I say?")
check(LocalImageAssistant.captured[1].userRecords.count == 2,"baseline reproduces cross-speaker prompt inclusion")
check(LocalImageAssistant.captured[1].userRecords.contains(where:{$0.text.contains("Mango")}),"baseline prior text witnessed")
LocalImageAssistant.captured=[]
let staged=Staged()
await staged.run("Authored child fixture: my pet is Mango")
await staged.run("Authored stranger fixture: what did I say?")
check(LocalImageAssistant.captured.count == 2,"two actual call arguments captured")
let first=LocalImageAssistant.captured[0], second=LocalImageAssistant.captured[1]
check(second.userRecords.count == 1,"single current record")
check(!second.turns.contains(where:{$0.text.contains("Mango")}),"prior text absent at model boundary")
check(Set(first.userRecords.map(\.id)).isDisjoint(with:Set(second.userRecords.map(\.id))),"prior IDs absent at boundary")
check(second.goal.isEmpty,"private goal absent")
print("PASS: \(checks) native argument-witness assertions; exact production context-construction and converse call, stub model only")
