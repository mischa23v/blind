import Foundation
/// Provenance is assigned at the input boundary, never inferred from words,
/// acoustic energy, a familiar face, a name, or a model's identity claim.
/// This release has no verified-speaker backend. Even speech following a tap,
/// an offer, or a confirmation prompt remains unverified microphone input.
public enum CompanionCommandOrigin: String, CaseIterable, Equatable, Sendable {
    case trustedInterface
    case unverifiedMicrophone
    case modelOutput
    case observedContent
    case unknown
}

public enum CompanionCommandEffect: String, CaseIterable, Equatable, Sendable {
    case conversation
    case interruptOrdinarySpeech
    case changeGoal
    case cancelTaskOrNavigation
    case startReturn
    case changeMonitoring
    case requestPhysicalGuidance
    case commitUserReport
}

/// Small app-specific authorization adapter around existing input and evidence
/// policies, not a recognizer. Permission to request guidance is never evidence
/// that guidance is safe: target, pose, age and hazard gates still apply.
/// Independent local hazard alerts do not consult this command policy.
public enum CommandAuthority {
    public static func permits(_ effect: CompanionCommandEffect,
                               from origin: CompanionCommandOrigin) -> Bool {
        switch origin {
        case .trustedInterface:
            return true
        case .unverifiedMicrophone:
            return effect == .conversation || effect == .interruptOrdinarySpeech
        case .modelOutput, .observedContent, .unknown:
            return false
        }
    }
}


struct AssistantDialogue { static let maximumTurnScalars = 2000 }
struct Session { var shouldListen = true }
struct Photo { var selection: Int? = 7 }
final class Cancellable { var count = 0; func cancel() { count += 1 } }
final class Base {

 var selectedPhoto = Photo(), assistantSession = Session()
 var photoReferenceFailed = false, trustedContinuation = 0, clearCount = 0, clockCalls = 0, chatCalls = 0
 var exploreRequest = UUID(), exploreTask: Cancellable? = Cancellable(), exploreSnapshot: String? = "fixture"
 func clearSelectedPhotoReference() { clearCount += 1; selectedPhoto.selection = nil }
 func routeClockInquiry(_ text: String, origin: CompanionCommandOrigin) -> Bool {
  if text == "clock" { clockCalls += 1; return true }; return false
 }
 func receiveUnverifiedConversation(_ text: String, origin: CompanionCommandOrigin) { chatCalls += 1 }

    func receiveCompanionUtterance(_ text: String, fromVoice: Bool = false) {
        let text = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty, text.unicodeScalars.count <= AssistantDialogue.maximumTurnScalars,
              !fromVoice || assistantSession.shouldListen else {
            return
        }
        // This compatibility entry point is called by explicit UI submission or
        // the microphone callback. A tap to listen does not authenticate speech.
        let origin: CompanionCommandOrigin = fromVoice ? .unverifiedMicrophone : .trustedInterface
        // A read-only clock question needs conversation authority, not goal authority.
        // Intercept before cancellation, everyday-task mutation or camera work.
        if selectedPhoto.selection != nil { clearExploreSnapshot() }
        if routeClockInquiry(text, origin: origin) { return }
        guard CommandAuthority.permits(.changeGoal, from: origin) else {
            receiveUnverifiedConversation(text, origin: origin)
            return
        }
        trustedContinuation += 1
    }
    func clearExploreSnapshot() {
        photoReferenceFailed = false
        clearSelectedPhotoReference()
        exploreRequest = UUID(); exploreTask?.cancel(); exploreTask = nil; exploreSnapshot = nil
    }
}
final class Proposed {

 var selectedPhoto = Photo(), assistantSession = Session()
 var photoReferenceFailed = false, trustedContinuation = 0, clearCount = 0, clockCalls = 0, chatCalls = 0
 var exploreRequest = UUID(), exploreTask: Cancellable? = Cancellable(), exploreSnapshot: String? = "fixture"
 func clearSelectedPhotoReference() { clearCount += 1; selectedPhoto.selection = nil }
 func routeClockInquiry(_ text: String, origin: CompanionCommandOrigin) -> Bool {
  if text == "clock" { clockCalls += 1; return true }; return false
 }
 func receiveUnverifiedConversation(_ text: String, origin: CompanionCommandOrigin) { chatCalls += 1 }

    func receiveCompanionUtterance(_ text: String, fromVoice: Bool = false) {
        let text = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty, text.unicodeScalars.count <= AssistantDialogue.maximumTurnScalars,
              !fromVoice || assistantSession.shouldListen else {
            return
        }
        // This compatibility entry point is called by explicit UI submission or
        // the microphone callback. A tap to listen does not authenticate speech.
        let origin: CompanionCommandOrigin = fromVoice ? .unverifiedMicrophone : .trustedInterface
        // A read-only clock question needs conversation authority, not goal authority.
        // Intercept before cancellation, everyday-task mutation or camera work.
        if CommandAuthority.permits(.changeGoal, from: origin), selectedPhoto.selection != nil { clearExploreSnapshot() }
        if routeClockInquiry(text, origin: origin) { return }
        guard CommandAuthority.permits(.changeGoal, from: origin) else {
            receiveUnverifiedConversation(text, origin: origin)
            return
        }
        trustedContinuation += 1
    }
    func clearExploreSnapshot() {
        photoReferenceFailed = false
        clearSelectedPhotoReference()
        exploreRequest = UUID(); exploreTask?.cancel(); exploreTask = nil; exploreSnapshot = nil
    }
}
var checks=0, failures=0
func check(_ ok: Bool,_ label: String) { checks += 1; if !ok { failures += 1; print("FAIL: " + label) } }

let beforeBase=failures
for isVoice in [false,true] {
 for text in ["generic", "clock", "cancel task"] {
  let v=Base(), task=v.exploreTask!, request=v.exploreRequest
  v.receiveCompanionUtterance(text,fromVoice:isVoice)
  check((v.selectedPhoto.selection != nil) == isVoice,"Base: selection follows authority")
  check((v.clearCount == 0) == isVoice,"Base: private reference retirement follows authority")
  check((task.count == 0) == isVoice,"Base: task cancellation follows authority")
  check((v.exploreRequest == request) == isVoice,"Base: photo callback identity follows authority")
  check(v.clockCalls == (text == "clock" ? 1 : 0),"Base: clock route unchanged")
  check(v.chatCalls == (isVoice && text != "clock" ? 1 : 0),"Base: unverified route unchanged")
  check(v.trustedContinuation == (!isVoice && text != "clock" ? 1 : 0),"Base: command gate unchanged")
 }
}
print("Base failures: \(failures-beforeBase)")

let beforeProposed=failures
for isVoice in [false,true] {
 for text in ["generic", "clock", "cancel task"] {
  let v=Proposed(), task=v.exploreTask!, request=v.exploreRequest
  v.receiveCompanionUtterance(text,fromVoice:isVoice)
  check((v.selectedPhoto.selection != nil) == isVoice,"Proposed: selection follows authority")
  check((v.clearCount == 0) == isVoice,"Proposed: private reference retirement follows authority")
  check((task.count == 0) == isVoice,"Proposed: task cancellation follows authority")
  check((v.exploreRequest == request) == isVoice,"Proposed: photo callback identity follows authority")
  check(v.clockCalls == (text == "clock" ? 1 : 0),"Proposed: clock route unchanged")
  check(v.chatCalls == (isVoice && text != "clock" ? 1 : 0),"Proposed: unverified route unchanged")
  check(v.trustedContinuation == (!isVoice && text != "clock" ? 1 : 0),"Proposed: command gate unchanged")
 }
}
print("Proposed failures: \(failures-beforeProposed)")
print("Total assertions: \(checks); expected baseline failures: 12; corrected source failures: \(failures-beforeProposed)")
exit((beforeProposed == 12 && failures-beforeProposed == 0) ? 0 : 1)
