from pathlib import Path
import difflib
r=Path('/workspace/shared/blind-voice-authority-stage');live=Path('/workspace/shared/blind-rebuild');rel='tools/test/command-authority.test.mjs'
s=(live/rel).read_text();old=s
s=s.replace('assert.match(body(\'voice.onFinished =\'), /receiveCompanionUtterance\\(text, fromVoice: true\\)/);','''const final = body('voice.onFinished =');
  assert.match(final, /guard let self, self.voice.consumeDelivery\\(turn\\) else/);
  assert.match(final, /receiveCompanionUtterance\\(turn.text, fromVoice: true\\)/);
  assert.ok(final.indexOf('consumeDelivery(') < final.indexOf('receiveCompanionUtterance('));''')
s=s.replace('assert.match(chat, /let dialogue = unverifiedDialogue/);','''assert.match(chat, /let dialogue = VoiceConversationPrivacy.anonymousTurn\\(text\\)/);
  assert.doesNotMatch(model, /unverifiedDialogue/);''')
s=s.replace('assert.match(isolated, /unverifiedDialogue.record\\(role: "assistant", text: text\\)/);','assert.doesNotMatch(isolated, /\\.record\\(/);')
s=s.replace("test('clear conversation removes transient microphone history before another same-session turn', () => {", "test('anonymous conversation has explicit current-turn isolation and clear cancels pending output', () => {")
s=s.replace('  assert.match(clear, /unverifiedDialogue = AssistantDialogue\\(\\); unverifiedDialogueGeneration = nil/);','  assert.doesNotMatch(model, /unverifiedDialogue/);')
s=s.replace('  assert.match(chat, /unverifiedDialogueGeneration != assistantSession.generation/);','''  assert.match(chat, /VoiceConversationPrivacy.anonymousTurn\\(text\\)/);
  const privacy = declaration(read('BlindCore/Sources/BlindCore/VoiceAuthority.swift'), 'public static func anonymousTurn(');
  assert.match(privacy, /var dialogue = AssistantDialogue\\(\\)/);
  assert.match(privacy, /dialogue.record\\(role: "user", text: text\\)/);''')
s+='''

test('microphone cannot clear the selected photo before the command gate', () => {
  const receive = body('func receiveCompanionUtterance(');
  assert.match(receive, /if CommandAuthority.permits\\(\\.changeGoal, from: origin\\), selectedPhoto.selection != nil \\{ clearExploreSnapshot\\(\\) \\}/);
});

test('native microphone provenance is exact and one-use without speaker elevation', () => {
  const voice = read('ios/BlindAssist/VoiceInput.swift');
  const consume = declaration(voice, 'func consumeDelivery(');
  assert.match(consume, /guard activeDelivery == turn else/);
  assert.match(consume, /activeDelivery = nil/);
  const finish = declaration(voice, 'func finish(');
  assert.ok(finish.indexOf('CapturedVoiceTurn(') < finish.indexOf('beginTurn()'));
  assert.match(finish, /activeDelivery = completed/);
  assert.match(finish, /defer \\{ activeDelivery = nil \\}/);
  const contract = read('BlindCore/Sources/BlindCore/VoiceAuthority.swift');
  assert.match(contract, /var origin: CompanionCommandOrigin \\{ \\.unverifiedMicrophone \\}/);
  assert.match(contract, /permitsPrivateContext\\(evidence: VoiceEvidence\\) -> Bool \\{ false \\}/);
});
'''
assert s!=old
p=r/'source'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
(r/'command-authority.test.mjs.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),s.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel)))
proj=r/'tmp/node-projection'
for name in [rel,'ios/BlindAssist/NavigationModel.swift','ios/BlindAssist/VoiceInput.swift','BlindCore/Sources/BlindCore/VoiceAuthority.swift','BlindCore/Sources/BlindCore/CommandAuthority.swift','BlindCore/Sources/BlindCore/CompanionTaskSource.swift','ios/BlindAssist/LocalImageAssistant.swift']:
 p=proj/name;p.parent.mkdir(parents=True,exist_ok=True)
 source=r/'source'/name
 if not source.exists():source=live/name
 p.write_bytes(source.read_bytes())
