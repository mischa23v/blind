from pathlib import Path
import json,hashlib
r=Path('/workspace/shared/blind-voice-authority-stage'); live=Path('/workspace/shared/blind-rebuild')
old=(live/'ios/BlindAssist/NavigationModel.swift').read_text(); new=(r/'source/ios/BlindAssist/NavigationModel.swift').read_text()
call=new[new.index('            let answer = await LocalImageAssistant.converse(dialogue: dialogue, arabic: self.arabic,',new.index('private func receiveUnverifiedConversation')):]
call=call[:call.index('requestID: id)')+len('requestID: id)')]
oldbody='        unverifiedDialogue.record(role: "user", text: text)\n        let dialogue = unverifiedDialogue'
newbody='        let dialogue = VoiceConversationPrivacy.anonymousTurn(text)'
assert oldbody in old and newbody in new
prefix='''import Foundation
var checks=0
func check(_ value: Bool,_ label: String) { checks += 1; if !value { print("FAIL "+label); exit(1) } }
struct LocalImageAssistant {
 static var captured: [AssistantDialogue] = []
 static func converse(dialogue: AssistantDialogue, arabic: Bool, audience: Int, availableTools: [String], toolExecutor: String?, requestID: UUID) async -> Int { captured.append(dialogue); return 0 }
}
'''
for name,body in [('Baseline',oldbody),('Staged',newbody)]:
 prefix+=f'''final class {name} {{
 var arabic=false, assistantAudience=0, unverifiedDialogue=AssistantDialogue()
 func run(_ text:String) async {{
 {body}
 let id=UUID()
 {call}
 _ = answer
 }}
}}
'''
prefix+='''
let original=Baseline()
await original.run("Authored child fixture: my pet is Mango")
await original.run("Authored stranger fixture: what did I say?")
check(LocalImageAssistant.captured[1].userRecords.count == 2,"baseline reproduces cross-speaker prompt inclusion")
check(LocalImageAssistant.captured[1].userRecords.contains(where:{$0.text.contains("Mango")}),"baseline prior text witnessed")
LocalImageAssistant.captured=[]
let staged=Staged()
await staged.run("Authored child fixture: my pet is Mango")
await staged.run("Authored stranger fixture: what did I say?")
check(LocalImageAssistant.captured.count == 2,"two actual call arguments captured")
let first=LocalImageAssistant.captured[0], second=LocalImageAssistant.captured[1]
check(second.userRecords.count == 1,"single current record")
check(!second.turns.contains(where:{$0.text.contains("Mango")}),"prior text absent at model boundary")
check(Set(first.userRecords.map(\\.id)).isDisjoint(with:Set(second.userRecords.map(\\.id))),"prior IDs absent at boundary")
check(second.goal.isEmpty,"private goal absent")
print("PASS: \\(checks) native argument-witness assertions; exact production context-construction and converse call, stub model only")
'''
(r/'tests/prompt-main.swift').write_text(prefix)
voice=(r/'source/ios/BlindAssist/VoiceInput.swift').read_text()
a=voice.index('    func finish() {'); b=voice.index('\n    /// Scene operations',a)
body=voice[a:b]; lines=[]; inside=False
for l in body.splitlines():
 if l.strip()=='#if DEBUG':inside=True;continue
 if l.strip()=='#endif':inside=False;continue
 if not inside:lines.append(l)
body='\n'.join(lines)
ma=voice.index('    func consumeDelivery('); mb=voice.index('\n    }',ma)+6
method=voice[ma:mb]
assert method in voice
h='''import Foundation
var checks=0
func check(_ value: Bool,_ label: String) { checks += 1; if !value { print("FAIL "+label); exit(1) } }
struct Life { var requested=true; var session=UUID() }
struct Utterance { var text="hello"; func deliverable(isEcho:Bool)->String? { isEcho ? nil:text } }
struct Engine { var isRunning=true }
final class Capture {
 var lifecycle=Life(), utterance=Utterance(), engine:Engine?=Engine()
 var canCapture=true, continuous=true, captureGeneration=UUID(), turn=UUID()
 var activeDelivery: CapturedVoiceTurn?, shouldIgnore:((String)->Bool)?, onFinished:((CapturedVoiceTurn)->Void)?
 func beginTurn() { turn=UUID() }
 func cancel() { lifecycle.requested=false; turn=UUID();captureGeneration=UUID();activeDelivery=nil }
'''+method+'\n'+body+'\n}\n'
h+='''
for continuous in [true,false] {
 let capture=Capture();capture.continuous=continuous
 let priorTurn=capture.turn,priorCapture=capture.captureGeneration,priorSession=capture.lifecycle.session
 var delivered:CapturedVoiceTurn?
 capture.onFinished={ value in
   delivered=value
   let changed=CapturedVoiceTurn(id:value.id,session:value.session,capture:value.capture,recognitionTurn:value.recognitionTurn,text:"changed",completedAt:value.completedAt)
   check(!capture.consumeDelivery(changed),"same-ID changed payload rejected")
   for altered in [
     CapturedVoiceTurn(id:value.id,session:UUID(),capture:value.capture,recognitionTurn:value.recognitionTurn,text:value.text,completedAt:value.completedAt),
     CapturedVoiceTurn(id:value.id,session:value.session,capture:UUID(),recognitionTurn:value.recognitionTurn,text:value.text,completedAt:value.completedAt),
     CapturedVoiceTurn(id:value.id,session:value.session,capture:value.capture,recognitionTurn:UUID(),text:value.text,completedAt:value.completedAt),
     CapturedVoiceTurn(id:value.id,session:value.session,capture:value.capture,recognitionTurn:value.recognitionTurn,text:value.text,completedAt:value.completedAt+1)
   ] {check(!capture.consumeDelivery(altered),"same-ID changed ownership/time rejected")}
   check(capture.consumeDelivery(value),"exact callback consumed")
   check(!capture.consumeDelivery(value),"duplicate within callback rejected")
   check(value.recognitionTurn==priorTurn && value.capture==priorCapture && value.session==priorSession,"IDs bound before rotation/cancel")
   check(value.origin == .unverifiedMicrophone,"no speaker promotion")
   check(value.text == "hello","correct transcript")
   let forged=CapturedVoiceTurn(session:value.session,capture:value.capture,recognitionTurn:value.recognitionTurn,text:value.text,completedAt:value.completedAt)
   check(!capture.consumeDelivery(forged),"copied metadata without delivery ID denied")
 }
 capture.finish()
 check(delivered != nil,"manual and continuous still deliver")
 check(!capture.consumeDelivery(delivered!),"late duplicate callback denied")
}
for mode in ["muted","unavailable","echo"] {
 let capture=Capture();var delivered=false
 if mode=="muted" {capture.lifecycle.requested=false}
 if mode=="unavailable" {capture.canCapture=false}
 if mode=="echo" {capture.shouldIgnore={_ in true}}
 capture.onFinished={_ in delivered=true};capture.finish()
 check(!delivered,"no delivery for "+mode)
}
print("PASS: \\(checks) native finish/delivery assertions; exact production finish with platform/recognizer lifecycle stubs")
'''
(r/'tests/delivery-main.swift').write_text(h)
(r/'evidence/native-witness-manifest.json').write_text(json.dumps({'base_nav_sha256':hashlib.sha256(old.encode()).hexdigest(),'staged_nav_sha256':hashlib.sha256(new.encode()).hexdigest(),'staged_voice_sha256':hashlib.sha256(voice.encode()).hexdigest(),'captured_production_call':call,'production_finish':body,'scope':'Exact source fragments with explicit model/Apple/lifecycle stubs, not actual iOS microphone/model execution'},indent=2))
