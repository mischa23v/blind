import Foundation
struct Life { var requested = true; var session = UUID() }
struct Utterance { var text = "captured original"; func deliverable(isEcho: Bool) -> String? { isEcho ? nil : text } }
struct Engine { var isRunning = true }
final class Capture {
 var lifecycle = Life(), utterance = Utterance(), engine: Engine? = Engine()
 var canCapture = true, continuous = true, captureGeneration = UUID(), turn = UUID()
 var activeDelivery: CapturedVoiceTurn?
 var shouldIgnore: ((String) -> Bool)?, onFinished: ((CapturedVoiceTurn) -> Void)?
 func beginTurn() { turn = UUID(); utterance = Utterance(text: "") }
 func cancel() { lifecycle.requested = false; lifecycle.session = UUID(); turn = UUID(); captureGeneration = UUID(); activeDelivery = nil; utterance = Utterance(text: "") }
    func consumeDelivery(_ turn: CapturedVoiceTurn) -> Bool {
        guard activeDelivery == turn else { return false }
        activeDelivery = nil
        return true
    }
    func finish() {
        guard lifecycle.requested, canCapture else { return }
        let text = utterance.deliverable(isEcho: shouldIgnore?(utterance.text) == true)
        // Bind the final transcript before beginTurn/cancel retires ASR identifiers.
        let completed = text.map { CapturedVoiceTurn(session: lifecycle.session,
            capture: captureGeneration, recognitionTurn: turn, text: $0,
            completedAt: ProcessInfo.processInfo.systemUptime) }
        if continuous, engine?.isRunning == true, canCapture { beginTurn() }
        else { cancel() }
        guard let completed else { return }
        activeDelivery = completed
        defer { activeDelivery = nil }
        onFinished?(completed)
    }
}
var checks = 0
func expect(_ v: Bool, _ why: String) { checks += 1; if !v { fatalError(why) } }
for continuous in [false, true] {
 let c = Capture(); c.continuous = continuous
 let session = c.lifecycle.session, capture = c.captureGeneration, recognition = c.turn
 var got: CapturedVoiceTurn?
 c.onFinished = { event in
  got = event
  expect(event.session == session && event.capture == capture && event.recognitionTurn == recognition, "original capture IDs")
  expect(event.text == "captured original" && event.origin == .unverifiedMicrophone, "original words, never elevated")
  let modified = [
    CapturedVoiceTurn(id: event.id, session: UUID(), capture: event.capture, recognitionTurn: event.recognitionTurn, text: event.text, completedAt: event.completedAt),
    CapturedVoiceTurn(id: event.id, session: event.session, capture: UUID(), recognitionTurn: event.recognitionTurn, text: event.text, completedAt: event.completedAt),
    CapturedVoiceTurn(id: event.id, session: event.session, capture: event.capture, recognitionTurn: UUID(), text: event.text, completedAt: event.completedAt),
    CapturedVoiceTurn(id: event.id, session: event.session, capture: event.capture, recognitionTurn: event.recognitionTurn, text: "changed words", completedAt: event.completedAt),
    CapturedVoiceTurn(id: event.id, session: event.session, capture: event.capture, recognitionTurn: event.recognitionTurn, text: event.text, completedAt: event.completedAt + 1)
  ]
  for forged in modified { expect(!c.consumeDelivery(forged), "changed payload denied") }
  expect(c.consumeDelivery(event), "genuine consumed once")
  expect(!c.consumeDelivery(event), "duplicate denied")
 }
 c.finish()
 expect(got != nil, "manual/continuous delivery")
 expect(!c.consumeDelivery(got!), "late replay denied")
 if continuous { expect(c.turn != recognition && c.captureGeneration == capture && c.lifecycle.session == session, "turn rotated without rebinding capture") }
 else { expect(!c.lifecycle.requested && c.captureGeneration != capture && c.lifecycle.session != session, "manual stopped before delivery") }
}
let cancellation = Capture()
cancellation.onFinished = { event in cancellation.cancel(); expect(!cancellation.consumeDelivery(event), "explicit cancellation before consume denied") }
cancellation.finish()
let replay = Capture(); var first: CapturedVoiceTurn?
replay.onFinished = { event in first = event; expect(replay.consumeDelivery(event), "first exact event") }
replay.finish(); replay.utterance = Utterance(text: "new words")
replay.onFinished = { event in expect(!replay.consumeDelivery(first!), "prior event not current after rotation"); expect(replay.consumeDelivery(event), "new event genuine") }
replay.finish()
for mode in ["cancelled", "unavailable", "echo"] {
 let c=Capture(); var delivered=false
 if mode=="cancelled" { c.cancel() }
 if mode=="unavailable" { c.canCapture=false }
 if mode=="echo" { c.shouldIgnore = {_ in true} }
 c.onFinished = {_ in delivered=true}; c.finish(); expect(!delivered, "no invalid delivery")
}
print("PASS: \(checks) independent exact finish/consume source assertions; Apple lifecycle stubbed")
