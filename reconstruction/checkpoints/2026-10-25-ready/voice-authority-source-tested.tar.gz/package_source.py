from pathlib import Path
import tarfile,hashlib,json,subprocess
r=Path('/workspace/shared/blind-voice-authority-stage');live=Path('/workspace/shared/blind-rebuild'); evidence=[]
for rel in ['ios/BlindAssist/NavigationModel.swift','ios/BlindAssist/VoiceInput.swift','tools/test/command-authority.test.mjs']:
 p=r/'tmp/inverse'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((r/'source'/rel).read_bytes())
 subprocess.run(['patch','--batch','-R','-p1','-i',str(r/(Path(rel).name+'.patch'))],cwd=r/'tmp/inverse',check=True,capture_output=True)
 assert p.read_bytes()==(live/rel).read_bytes()
 evidence.append({'file':rel,'inverse_restores_exact_base':True,'base_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'staged_sha256':hashlib.sha256((r/'source'/rel).read_bytes()).hexdigest()})
(r/'evidence/inverse-proof.json').write_text(json.dumps(evidence,indent=2))
allowed=[]
for pattern in ['README.md','*.patch','prepare_stage.py','package_source.py','source/**/*.swift','source/**/*.mjs','tests/**/*.swift','tests/*.py','evidence/*.json','evidence/*.log','model-evaluation/README.md','model-evaluation/LICENSE_NOTICE.md','model-evaluation/smoke_embeddings.py','model-evaluation/requirements.lock.txt','model-evaluation/evidence/*.json','model-evaluation/evidence/*.md','model-evaluation/evidence/*.txt']:
 allowed.extend(p for p in r.glob(pattern) if p.is_file())
allowed=sorted(set(allowed));manifest=[{'path':str(p.relative_to(r)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in allowed]
(r/'public-source-manifest.json').write_text(json.dumps(manifest,indent=2))
with tarfile.open(r/'voice-authority-source-tested.tar.gz','w:gz') as t:
 for p in allowed+[r/'public-source-manifest.json']:t.add(p,arcname=p.relative_to(r))
print('PASS inverse restoration for three patches; public allowlist files',len(allowed),'archive bytes',(r/'voice-authority-source-tested.tar.gz').stat().st_size)
