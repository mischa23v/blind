"""Offline CPU mechanism smoke only. Synthetic, non-speech inputs; never an identity test."""
import argparse, hashlib, json, math, platform, time
from pathlib import Path
import sherpa_onnx

p=argparse.ArgumentParser(); p.add_argument('--model',type=Path,required=True); p.add_argument('--output',type=Path,required=True); a=p.parse_args()
expected='e9848563da86f263117134dfd7ad63c92355b37de492b55e325400c9d9c39012'
blob=a.model.read_bytes(); digest=hashlib.sha256(blob).hexdigest()
assert len(blob)==26530550 and digest==expected
config=sherpa_onnx.SpeakerEmbeddingExtractorConfig(model=str(a.model),num_threads=1,provider='cpu',debug=False)
e=sherpa_onnx.SpeakerEmbeddingExtractor(config)
rate=16000
# Two deterministic non-speech harmonic test signals. No real voice recording.
def tone(f):
 return [0.15*math.sin(2*math.pi*f*i/rate)+0.05*math.sin(2*math.pi*2*f*i/rate) for i in range(3*rate)]
fixtures={'tone_180':tone(180),'tone_270':tone(270),'silence':[0.0]*(3*rate)}
results={}; embeddings={}
for name,samples in fixtures.items():
 runs=[]; vectors=[]
 for _ in range(2):
  s=e.create_stream(); s.accept_waveform(sample_rate=rate,waveform=samples); s.input_finished(); ready=e.is_ready(s)
  start=time.perf_counter(); v=list(e.compute(s)) if ready else []; elapsed=time.perf_counter()-start
  finite=all(math.isfinite(x) for x in v)
  runs.append({'ready':ready,'dimension':len(v),'all_finite':finite,'l2_norm':math.sqrt(sum(x*x for x in v)) if finite else None,'compute_seconds':elapsed})
  vectors.append(v)
 assert all(r['ready'] and r['dimension']==256 and r['all_finite'] for r in runs)
 delta=max(abs(x-y) for x,y in zip(*vectors))
 results[name]={'runs':runs,'repeat_max_absolute_delta':delta}
 embeddings[name]=vectors[0]
def cos(x,y): return sum(a*b for a,b in zip(x,y))/math.sqrt(sum(a*a for a in x)*sum(b*b for b in y))
report={'scope':'Synthetic non-speech mechanism smoke only; no wearer accuracy, language, child, liveness, addressee, iOS, or authorization validation.', 'runtime':sherpa_onnx.__version__,'python':platform.python_version(),'platform':platform.platform(),'provider':'cpu','threads':1,'model_sha256':digest,'model_bytes':len(blob),'input_sample_rate':rate,'input_duration_seconds':3,'results':results,'tone_pair_cosine_not_an_identity_score':cos(embeddings['tone_180'],embeddings['tone_270']),'important_observation':'Even silence and tones produce finite embeddings. Readiness/finite vectors are not evidence of speech, wearer identity, or intent.'}
a.output.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
