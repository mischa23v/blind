# Bounded offline speaker-embedding mechanism evaluation

Executed 2026-10-25, isolated CPU-only Python virtual environment. This is a real upstream model extraction smoke test, not wearer verification. No private/child recordings, microphone capture, enrollments, uploads, paid APIs, live repository edits, global environment changes or iOS implementation were used.

## Result

The official WeSpeaker ResNet34-LM ONNX model (26,530,550 bytes) initializes under sherpa-onnx 2.0.0 and returns 256 finite embedding components for two synthetic harmonic tones and silence. Each input is three seconds at 16 kHz, generated in memory. Two fresh-stream extractions per input are numerically identical in this run (maximum component delta 0). Compute-only timings were 0.149–0.179 seconds on this Linux x86-64 worker with one CPU thread. These are not device latency, memory, power, speech accuracy, Arabic, child, headset or production measurements.

**Critical negative result:** silence and tones also produce ready, finite, nonzero embeddings. Extractor readiness is not VAD, quality validation, liveness, intent, identity or authority. No acceptance threshold was selected and no wearer authority is granted by this evaluation.

## Reproduction

Use an isolated Python 3.12 environment. Install only the two hashed wheels identified in evidence/provenance.json with --no-index --find-links pointing at the local wheel directory. The evaluated package is sherpa-onnx==2.0.0, which requires sherpa-onnx-core==2.0.0. Run smoke_embeddings.py with --model pointing to the official model and --output pointing to a new JSON file. The script asserts model size and upstream SHA-256 before loading, sets provider=cpu and num_threads=1, and saves only scalar evidence, not embeddings or audio. It needs no network while running.

An initial acquisition probe for sherpa-onnx==1.12.15 returned no matching registry artifact; nothing was installed from that probe. The final runtime is the same upstream package at 2.0.0, the release observed in the prior source review. No unrelated fallback was used. Installation was confined to .venv. PyPI artifact hashes were independently compared to registry metadata after retrieval.

## Archive boundaries

Public/final archive allowlist: README.md, LICENSE_NOTICE.md, smoke_embeddings.py, evidence/*.json, evidence/*.md, evidence/*.txt, requirements.lock.txt. Exclude .venv/, private-assets/, all wheels, ONNX weights, binaries, caches, audio and full embeddings. Local assets remain solely for the authorized evaluation; neither they nor the virtual environment are deliverables.

## Remaining gates

No live iOS link/build/integration occurred. Consent-based child/family trials, Arabic/headset robustness, false acceptance/rejection calibration, overlap detection, addressee assessment and replay/liveness evaluation remain absent. The existing unverified-microphone denial of consequential actions must remain unchanged. Physical guidance and private context are not enabled by successful extraction.
