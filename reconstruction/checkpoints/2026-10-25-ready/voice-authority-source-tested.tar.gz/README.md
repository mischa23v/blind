# Staged voice provenance/privacy increment

No live repository writes. Native patches are based on NavigationModel a492b8e4a68c1f5104df9cfde5696f062276a69b38bda44e9477fdc442e16e8d and VoiceInput 31421347396a4cfc52d57b6cfa0d327f9e627d934c52f0536c18dca8048810f9. Apply narrow patches only after reconciling concurrent bridge/perception/memory edits. Do not overlay full staged controller files. evidence/source-transform.json records every exact edit; inverse-proof.json proves reversal restores the baseline bytes. New BlindCore source is source/BlindCore/Sources/BlindCore/VoiceAuthority.swift.

## Implemented in stage

1. Unverified microphone speech cannot clear the selected photo or cancel its owned work before the authority gate. Trusted-input and public clock dispatch behavior is retained.
2. VoiceInput emits CapturedVoiceTurn with capture/session/ASR-turn identifiers bound to final text before recognition rotation. A synchronous full-event, one-use delivery token is consumed by NavigationModel. It is provenance, not voice identity. Delayed use of a callback value fails the delivery check. A future asynchronous verifier must use distinct one-use ownership tickets, not extend this synchronous token.
3. Anonymous microphone conversation explicitly has current-turn-only context. It no longer accumulates prior arbitrary speakers' disclosures or writes anonymous completed replies into shared history. Trusted interface conversation history/profile flow is unchanged. This fixes a privacy boundary at the cost of anonymous conversational continuity; it is not advertised as a completed personal continuous conversation feature. The existing private/trusted conversation path stays available. No previous anonymous history is migrated into trusted history.
4. Core contracts distinguish speaker candidate, addressee evidence, replay evidence and exact turn ownership. Nonfinite/expired/changed-source/changed-text results cannot satisfy ownership. Explicit rejected/not-addressed/replay-suspected evidence denies low-risk admission. Unavailable evidence can support generic nonprivate conversation/time without camera readiness; no candidate combination permits task/physical/private context. Existing raw-onset ordinary interruption policy is intentionally unchanged.

## Actual executed evidence

- 4,352 production-core Swift assertions cover all candidate label combinations/effects, unavailable/replay/late completion/one-use ownership/mute-end-source invalidation contracts, anonymous text and ID isolation, and preservation of trusted dialogue.
- Exact native context-construction and LocalImageAssistant.converse argument capture: 7 assertions. Baseline includes prior authored speaker's text; staged argument excludes earlier text and IDs. The model is a capture stub: no claim of actual disclosure or native Foundation Model execution.
- Exact VoiceInput.finish and delivery-check source: 29 assertions with explicit lifecycle/recognizer/platform stubs, manual and continuous rotation, stale delivery and echo/unavailable rejection. Not actual microphone or Apple SDK execution.
- Selected-photo admission-prefix/helper source witness: baseline has 12 expected assertion failures; staged condition has 42/42 passing. Total run executes 84 assertions (baseline plus proposed). Exact native prefix/helper and real CommandAuthority; platform/private-reference/clock/chat parts are explicit stubs.
- All three patches reverse to exact baseline bytes, and source remains unchanged there.
- Official WeSpeaker ResNet34-LM with stage-local sherpa-onnx 2.0.0 executed six real CPU extractions over three synthetic inputs. 256 finite components and exact repeat consistency. Silence ALSO produces a ready nonzero vector: never treat readiness/vector/score as wearer evidence. model-evaluation includes hashes, licenses and scalar evidence. These are not child, Arabic, headset, replay or iPhone accuracy results.

- Updated command-authority Node source contracts: 12/12 passed, including exact one-use delivery, anonymous isolation, quiet/hazard invariants and selected-photo authorization. These are source assertions, not acoustic tests.

## Still not implemented/proven

A native sherpa runtime/model adapter, audio ring-buffer/preprocessing path to it, enrollment UI/local template storage, calibrated speaker thresholds, child/Arabic/headset quality, addressee classifier, liveness/replay validation, asynchronous native evidence completion, device thermal/latency and supervised physical trials remain open. No new verified-speaker origin exists. Physical/task actions remain denied for microphone input. The core ownership invalidation API is tested but is not advertised as a native asynchronous verifier already wired to every lifecycle event.

## Future native hookup contract

Reuse the official sherpa Swift/C extractor, not a hand-written recognizer. Copy a bounded segment off the existing capture callback using AVAudioConverter for the required sample format; never run inference in the real-time tap. Bind extracted evidence to exact session/capture/recognition-turn/text version and monotonic completion interval. `VoiceEvidenceOwnership.begin` starts a one-use ticket; later results must match and expire. Native lifecycle events must call invalidate on mute/end, source/route changes, capture restart, enrollment deletion and any new accepted segment. Even an enrolledCandidate remains unverified until an independently reviewed calibration/addressee/replay admission decision exists.

Keep private-context receipts separate from acoustic candidate evidence. A future reviewed wearer-context receipt must bind enrolled profile version, active private-output route generation, session owner, exact utterance/intent and expiry. It must be checked before context lookup and again before output. Do not give it all effects by casting it to trustedInterface. This stage's permitsPrivateContext always returns false; trusted interface retains its existing separate profile/history path.

Generic clock/nonphysical questions do not require camera/map/depth. Uncertain input must not change goal, navigation, monitoring, selected photo, report commits or pending approval. Clearly rejected background can be silent once a real classifier is integrated; this stage does not claim to distinguish TV/family acoustically. Preserve independent sensor hazards regardless of microphone mute, inference, ordinary quiet/duck or speaker result. Existing release behavior may still interrupt generic replies on background onset; changing that deserves separately measured latency/usability review.

## Reproduction and packaging

Use tests/main.swift plus real CommandAuthority.swift, AssistantDialogue.swift and staged VoiceAuthority.swift with Swift 6.4.1; exact source-fragment witnesses are generated by tests/make_native_witness.py. TMPDIR and module cache are workspace-local. `tests/photo/main.swift` preserves the reviewer's exact witness. No Apple build was attempted.

Public/source archives use an explicit allowlist. NEVER include tmp/, evidence/cache/, model-evaluation/.venv/, model-evaluation/private-assets/, binary weights/wheels, recordings, credentials or raw embeddings. Public-safe mechanism evidence is synthetic input specifications and scalar summaries, hashes, scripts and license notices only. Native review findings must be reconciled before application.
