from pathlib import Path
import hashlib,difflib,json
live=Path('/workspace/shared/blind-rebuild'); out=Path('/workspace/shared/blind-voice-authority-stage')
changes={}
def stage(rel, edits):
 s=(live/rel).read_text(); old=s
 for a,b in edits:
  assert s.count(a)==1,(rel,a[:100],s.count(a));s=s.replace(a,b)
 target=out/'source'/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_text(s)
 (out/(Path(rel).name+'.patch')).write_text(''.join(difflib.unified_diff(old.splitlines(True),s.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel)))
 restored=s
 for a,b in reversed(edits):
  assert restored.count(b)==1 if b else True
  if b:restored=restored.replace(b,a)
 # Deleted fields have ambiguous empty reverse position; full reconstruction is
 # verified separately by applying patch in an isolated baseline copy.
 changes[rel]={'base_sha256':hashlib.sha256(old.encode()).hexdigest(),'staged_sha256':hashlib.sha256(s.encode()).hexdigest(),'edits':[{'before':a,'after':b} for a,b in edits]}
nav='ios/BlindAssist/NavigationModel.swift'
stage(nav,[
 ('if selectedPhoto.selection != nil { clearExploreSnapshot() }\n        if routeClockInquiry', 'if CommandAuthority.permits(.changeGoal, from: origin), selectedPhoto.selection != nil { clearExploreSnapshot() }\n        if routeClockInquiry'),
 ('    private var unverifiedDialogue = AssistantDialogue()\n    private var unverifiedDialogueGeneration: UInt64?\n',''),
 ('                    self.unverifiedDialogue.record(role: "assistant", text: text)\n','                    // Anonymous turns never enter shared or trusted conversation history.\n'),
 ('        unverifiedDialogue = AssistantDialogue(); unverifiedDialogueGeneration = nil\n',''),
 ('    /// own transient history and cannot call action adapters or commit task updates.','    /// current-turn-only context and cannot call action adapters or commit task updates.'),
 ('        if unverifiedDialogueGeneration != assistantSession.generation {\n            unverifiedDialogue = AssistantDialogue()\n            unverifiedDialogueGeneration = assistantSession.generation\n        }\n',''),
 ('        unverifiedDialogue.record(role: "user", text: text)\n        let dialogue = unverifiedDialogue','        // No speaker binding exists yet: prior microphone speakers are not context.\n        let dialogue = VoiceConversationPrivacy.anonymousTurn(text)'),
 ('        voice.onFinished = { [weak self] text in self?.receiveCompanionUtterance(text, fromVoice: true) }','        voice.onFinished = { [weak self] turn in\n            guard let self, self.voice.consumeDelivery(turn) else { return }\n            self.receiveCompanionUtterance(turn.text, fromVoice: true)\n        }')])
voice='ios/BlindAssist/VoiceInput.swift'
stage(voice,[
 ('    var onFinished: ((String) -> Void)?','    private var activeDelivery: CapturedVoiceTurn?\n    var onFinished: ((CapturedVoiceTurn) -> Void)?\n    /// Only the synchronous callback for this exact capture delivery can enter chat.\n    /// This binds provenance; it does not authenticate the speaker.\n    func consumeDelivery(_ turn: CapturedVoiceTurn) -> Bool {\n        guard activeDelivery == turn else { return false }\n        activeDelivery = nil\n        return true\n    }'),
 ('        let text = utterance.deliverable(isEcho: shouldIgnore?(utterance.text) == true)','        let text = utterance.deliverable(isEcho: shouldIgnore?(utterance.text) == true)\n        // Bind the final transcript before beginTurn/cancel retires ASR identifiers.\n        let completed = text.map { CapturedVoiceTurn(session: lifecycle.session,\n            capture: captureGeneration, recognitionTurn: turn, text: $0,\n            completedAt: ProcessInfo.processInfo.systemUptime) }'),
 ('        guard let text else { return }\n        onFinished?(text)','        guard let completed else { return }\n        activeDelivery = completed\n        defer { activeDelivery = nil }\n        onFinished?(completed)'),
 ('    private func stopCapture() {\n        turn = UUID(); captureGeneration = UUID()','    private func stopCapture() {\n        activeDelivery = nil\n        turn = UUID(); captureGeneration = UUID()')])
(out/'evidence/source-transform.json').write_text(json.dumps(changes,indent=2))
print(json.dumps({k:{x:v[x] for x in ['base_sha256','staged_sha256']} for k,v in changes.items()},indent=2))
