import Foundation
import BlindCore
final class ExtractedScopedReviewController {
 var companionWorkingState = CompanionWorkingState()
 var assistantDialogue = AssistantDialogue()
 var conversationMemoryRevision = UUID()
 var unverifiedConversationID = UUID()
 var unverifiedConversationTask: Task<Void, Never>?
 var unverifiedConversationTimeout: Task<Void, Never>?
 var questionTask: Task<Void, Never>?
 var questionTimeoutTask: Task<Void, Never>?
 var questionIsChat = false
 var busy = false
 var streamedConversationText = ""
 struct Speech { let id = UUID() }
 var conversationSpeech: [Speech] = []
 var activeConversationSpeech: Speech?
 final class Feedback { var stopped: [UUID] = []; func stopRequestedSpeech(_ id: UUID) { stopped.append(id) }; func stopInformation(announceCancellation: Bool) -> Bool { true } }
 let feedback = Feedback()
 var sceneAnswer = "", currentReply = "", assistantQuestion = "", objectiveDraft = ""
 var privacyPurges = 0, persisted = 0, searchRetirements = 0, journeyRetirements = 0
 var requestID = UUID()
 var unverifiedDialogue = AssistantDialogue()
 var unverifiedDialogueGeneration: UInt64?
 struct Tasks { func cancelAll() {} }
 let everydayTasks = Tasks()
 var everydayTicket: String?
 var everydayUtterance = ""
 struct Journey { func eraseHistory(origin: CompanionCommandOrigin) throws {} }
 struct Journeys { func withConnectedJourney(_ body: (Journey) throws -> Void) rethrows { try body(Journey()) } }
 let journeys = Journeys()
 struct Indoor { func cancelRoute() {} }; let indoor = Indoor()
 func clearExploreSnapshot() {}
 func stopReturn() {}
 func cancelDescription() { interruptOrdinaryConversation(origin: .trustedInterface); requestID = UUID(); questionTask?.cancel(); questionTask = nil; busy = false }

 func purgeDebugSessionDiagnostics() { privacyPurges += 1 }
 func persistDialogue() { persisted += 1 }
 func persistWorkingState() { persisted += 1 }
 func retireHeldSearchForPrivacyDeletion() { searchRetirements += 1 }
 func establishedJourneyContextChanged() { journeyRetirements += 1 }
