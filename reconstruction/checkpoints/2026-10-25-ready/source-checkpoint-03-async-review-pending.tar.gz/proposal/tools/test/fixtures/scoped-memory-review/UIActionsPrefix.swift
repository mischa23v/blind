import Foundation
final class ExtractedScopedReviewUIActions {
 let model: ExtractedScopedReviewController
 let selection: CompanionWorkingState.ReviewSelection
 var replacement: String
 var failed = false
 var dismissed = false
 init(model: ExtractedScopedReviewController, selection: CompanionWorkingState.ReviewSelection) {
  self.model = model; self.selection = selection; replacement = selection.report.text
 }
 func dismiss() { dismissed = true }
