import XCTest
import BlindCore
@testable import NativeReviewReplay
final class ScopedReviewTests: XCTestCase {
 func scope(_ id: String) -> CompanionMemoryScope {
  CompanionMemoryScope(map: SpatialMapBinding(mapID: "map-"+id, frameID: "frame", revision: "1"), placeID: "house-"+id, floorID: "floor", roomID: "kitchen", objectInstanceID: "fridge-"+id)!
 }
 func report(_ text: String, into state: inout CompanionWorkingState, time: TimeInterval) -> CompanionWorkingState.ReviewSelection {
  state.record(text, at: Date(timeIntervalSince1970: time))
  if let parsed = CompanionUtterance.parse(text) { _ = state.respond(to: parsed, message: text, now: Date(timeIntervalSince1970: time), arabic: false, sourceID: state.reports.last?.sourceID) }
  return state.reviewSelections.first { $0.sourceID == state.reports.last?.sourceID }!
 }
 func testSR001ArchivedCorrectionRetainsOriginalScopeAndCurrentProgress() throws {
  var s=CompanionWorkingState();s.transitionMemoryScope(scope("A"));_ = report("My milk is in the fridge", into: &s, time: 10)
  s.transitionMemoryScope(scope("B"));_ = report("My milk is in the fridge", into: &s, time: 20)
  s.changeGoal("Make breakfast");s.reportedCompletedSteps=["B step"];s.proposedStep="B proposal"
  let a=s.reviewSelections.first { $0.scope == scope("A") }!; let revision=s.goalRevision
  XCTAssertTrue(s.reviseReviewedSource(a,replacement:"My milk is on the table",at:Date(timeIntervalSince1970:30)))
  XCTAssertEqual(s.goalRevision,revision);XCTAssertEqual(s.reportedCompletedSteps,["B step"]);XCTAssertEqual(s.proposedStep,"B proposal")
  XCTAssertEqual(s.factBook.latest(for:"milk",in:scope("B"))?.place,"in the fridge")
  XCTAssertEqual(s.factBook.latest(for:"milk",in:scope("A"))?.place,"on the table")
  XCTAssertFalse(s.reviewSelections.contains { $0.sourceID == a.sourceID })
  let corrected=s.reviewSelections.first { $0.scope == scope("A") }!;XCTAssertEqual(corrected.report.correctionOrigin?.sourceID,a.sourceID);XCTAssertEqual(corrected.report.correctionOrigin?.reportedAt,a.report.time)
  print("SR-001 authored fixture: same words in A/B; correcting selected A keeps B progress and original A scope.")
 }
 func testSR002StaleSelectionAndRestartRejectBeforeMutation() throws {
  var s=CompanionWorkingState();s.transitionMemoryScope(scope("A"));let old=report("My milk is in the fridge",into:&s,time:10)
  s.transitionMemoryScope(scope("B"));let bytes=try JSONEncoder().encode(s)
  XCTAssertFalse(s.reviseReviewedSource(old,replacement:"My milk is on the table"));XCTAssertEqual(try JSONEncoder().encode(s).count,bytes.count)
  let current=s.reviewSelections.first!;var restarted=try JSONDecoder().decode(CompanionWorkingState.self,from:bytes)
  XCTAssertFalse(restarted.reviseReviewedSource(current,replacement:nil));XCTAssertTrue(restarted.reviseReviewedSource(restarted.reviewSelections.first!,replacement:nil))
 }
 func testSR003InvalidEditIsAtomicAndReplayedReceiptFails() throws {
  var s=CompanionWorkingState();s.transitionMemoryScope(scope("A"));let a=report("My milk is in the fridge",into:&s,time:10)
  XCTAssertFalse(s.reviseReviewedSource(a,replacement:"  "));XCTAssertTrue(s.acceptsReviewSelection(a))
  XCTAssertTrue(s.reviseReviewedSource(a,replacement:nil));XCTAssertFalse(s.reviseReviewedSource(a,replacement:nil))
 }
 func testSR004ControllerDeletionCancelsOnlyConversationAndSameTextBRemains() {
  let c=ExtractedScopedReviewController();c.companionWorkingState.transitionMemoryScope(scope("A"));let a=report("My milk is in the fridge",into:&c.companionWorkingState,time:10)
  c.assistantDialogue.record(role:"user",text:a.report.text,sourceID:a.sourceID)
  c.companionWorkingState.transitionMemoryScope(scope("B"));let b=report("My milk is in the fridge",into:&c.companionWorkingState,time:20)
  c.assistantDialogue.record(role:"user",text:b.report.text,sourceID:b.sourceID)
  let currentA=c.scopedConversationReviews.first { $0.sourceID == a.sourceID }!
  c.questionIsChat=true;c.busy=true;let task=Task<Void,Never> { try? await Task.sleep(nanoseconds:1_000_000_000) };c.questionTask=task
  c.conversationSpeech=[.init()];c.activeConversationSpeech = .init();let request=c.requestID;let memoryRevision=c.conversationMemoryRevision
  XCTAssertTrue(c.reviseScopedConversationRecord(currentA,replacement:nil));XCTAssertTrue(task.isCancelled);XCTAssertFalse(c.busy);XCTAssertNil(c.questionTask)
  XCTAssertTrue(c.conversationSpeech.isEmpty);XCTAssertEqual(c.feedback.stopped.count,1);XCTAssertEqual(c.requestID,request);XCTAssertNotEqual(c.conversationMemoryRevision,memoryRevision)
  XCTAssertEqual(c.searchRetirements,0);XCTAssertEqual(c.journeyRetirements,0);XCTAssertEqual(c.assistantDialogue.userRecords.map(\.sourceID),[b.sourceID])
 }
 func testSR005StaleControllerSelectionHasNoSideEffects() {
  let c=ExtractedScopedReviewController();c.companionWorkingState.transitionMemoryScope(scope("A"));let a=report("My milk is in the fridge",into:&c.companionWorkingState,time:10)
  c.companionWorkingState.transitionMemoryScope(scope("B"));c.busy=true;c.questionIsChat=true;let token=c.conversationMemoryRevision
  XCTAssertFalse(c.reviseScopedConversationRecord(a,replacement:nil));XCTAssertTrue(c.busy);XCTAssertEqual(c.persisted,0);XCTAssertEqual(c.privacyPurges,0);XCTAssertEqual(c.conversationMemoryRevision,token)
 }
 func testSR006ArchivedDeletionDoesNotOrphanNonConversationWork() {
  let c=ExtractedScopedReviewController();c.companionWorkingState.transitionMemoryScope(scope("A"));_ = report("My milk is in the fridge",into:&c.companionWorkingState,time:10)
  c.companionWorkingState.transitionMemoryScope(scope("B"));c.busy=true;c.questionIsChat=false;let task=Task<Void,Never> {};c.questionTask=task;let request=c.requestID
  XCTAssertTrue(c.reviseScopedConversationRecord(c.scopedConversationReviews.first!,replacement:nil));XCTAssertTrue(c.busy);XCTAssertNotNil(c.questionTask);XCTAssertFalse(task.isCancelled);XCTAssertEqual(c.requestID,request)
 }
 func testSR007LossRetiresOnceWithoutInventingIdentity() {
  let c=ExtractedScopedReviewController();c.retireCompanionMemoryScope();XCTAssertEqual(c.persisted,0)
  c.companionWorkingState.transitionMemoryScope(scope("A"));c.companionWorkingState.changeGoal("Make breakfast");c.retireCompanionMemoryScope()
  XCTAssertNil(c.companionWorkingState.memoryScope);XCTAssertEqual(c.companionWorkingState.goal,"Make breakfast");XCTAssertEqual(c.journeyRetirements,1);XCTAssertEqual(c.searchRetirements,1)
  c.retireCompanionMemoryScope();XCTAssertEqual(c.journeyRetirements,1)
 }
 func testSR008ExtractedEditorActionsStayOpenOnStaleSelection() {
  let c=ExtractedScopedReviewController();c.companionWorkingState.transitionMemoryScope(scope("A"));let a=report("My milk is in the fridge",into:&c.companionWorkingState,time:10)
  let ui=ExtractedScopedReviewUIActions(model:c,selection:a);c.companionWorkingState.transitionMemoryScope(scope("B"));ui.replacement="My milk is on the table";ui.save()
  XCTAssertTrue(ui.failed);XCTAssertFalse(ui.dismissed);XCTAssertEqual(c.persisted,0)
  ui.delete();XCTAssertFalse(ui.dismissed);XCTAssertEqual(c.persisted,0)
 }
 func testSR009ExtractedEditorSuccessfulCorrectionAndDeletion() {
  let c=ExtractedScopedReviewController();c.companionWorkingState.transitionMemoryScope(scope("A"));let a=report("My milk is in the fridge",into:&c.companionWorkingState,time:10)
  let ui=ExtractedScopedReviewUIActions(model:c,selection:a);ui.replacement="My milk is on the table";ui.save();XCTAssertTrue(ui.dismissed);XCTAssertFalse(ui.failed)
  let deletion=ExtractedScopedReviewUIActions(model:c,selection:c.scopedConversationReviews.first!);deletion.delete();XCTAssertTrue(deletion.dismissed);XCTAssertTrue(c.scopedConversationReviews.isEmpty)
 }
 func testSR010DeletionRemovesArchivedDerivativesNotOtherScope() {
  var s=CompanionWorkingState();let text="My milk is in the fridge"
  s.transitionMemoryScope(scope("A"));_ = report(text,into:&s,time:10)
  s.apply(.init(goal:"",nextStep:"",completionReport:"",fact:.init(subject:"milk",value:text,quote:text),contextRevision:s.goalRevision),latest:text)
  s.transitionMemoryScope(scope("B"));_ = report(text,into:&s,time:20)
  s.apply(.init(goal:"",nextStep:"",completionReport:"",fact:.init(subject:"milk",value:text,quote:text),contextRevision:s.goalRevision),latest:text)
  XCTAssertTrue(s.reviseReviewedSource(s.reviewSelections.first { $0.scope == scope("A") }!,replacement:nil))
  XCTAssertTrue(s.scopedTaskHistory.filter { $0.scope == scope("A") }.flatMap(\.facts).isEmpty);XCTAssertEqual(s.facts.count,1)
 }
 func testSR011BoundedCorrectionProvenanceAndDialogueDecode() throws {
  var s=CompanionWorkingState();s.transitionMemoryScope(scope("A"));let a=report("My milk is in the fridge",into:&s,time:10)
  XCTAssertTrue(s.reviseReviewedSource(a,replacement:"My milk is on the table",at:Date(timeIntervalSince1970:20)))
  var json=try JSONSerialization.jsonObject(with:JSONEncoder().encode(s)) as! [String:Any];var reports=json["reports"] as! [[String:Any]]
  reports[0]["correctionOrigin"]=["sourceID":String(repeating:"x",count:65)];json["reports"]=reports
  let restored=try JSONDecoder().decode(CompanionWorkingState.self,from:JSONSerialization.data(withJSONObject:json));XCTAssertTrue(restored.scopedTaskHistory.flatMap(\.reports).isEmpty)
  var d=AssistantDialogue();d.record(role:"user",text:"report",sourceID:"source");var dj=try JSONSerialization.jsonObject(with:JSONEncoder().encode(d)) as! [String:Any]
  var records=dj["userRecords"] as! [[String:Any]];records[0]["sourceID"]=String(repeating:"x",count:65);dj["userRecords"]=records
  XCTAssertThrowsError(try JSONDecoder().decode(AssistantDialogue.self,from:JSONSerialization.data(withJSONObject:dj)))
 }

 func testSR012SourceBoundCarriedGoalAndParentAreInvalidated() {
  var s=CompanionWorkingState();s.transitionMemoryScope(scope("A"));let a=report("Find my milk",into:&s,time:10)
  XCTAssertEqual(s.goalSource?.sourceID,a.sourceID);s.transitionMemoryScope(scope("B"))
  let selected=s.reviewSelections.first { $0.sourceID == a.sourceID }!;XCTAssertTrue(s.reviseReviewedSource(selected,replacement:nil))
  XCTAssertTrue(s.goal.isEmpty);XCTAssertNil(s.goalSource);XCTAssertTrue(s.scopedTaskHistory.allSatisfy { $0.goalSource?.sourceID != a.sourceID })
 }
 func testSR013ActualBulkClearInvalidatesEverySelection() throws {
  let c=ExtractedScopedReviewController();c.companionWorkingState.transitionMemoryScope(scope("A"));let a=report("My milk is in the fridge",into:&c.companionWorkingState,time:10)
  c.companionWorkingState.transitionMemoryScope(scope("B"));let b=report("My milk is on the table",into:&c.companionWorkingState,time:20)
  c.assistantDialogue.record(role:"user",text:b.report.text,sourceID:b.sourceID);let prior=c.scopedConversationReviews
  c.clearAssistantConversation();XCTAssertTrue(c.scopedConversationReviews.isEmpty);XCTAssertTrue(c.assistantDialogue.userRecords.isEmpty)
  for receipt in prior { XCTAssertFalse(c.reviseScopedConversationRecord(receipt,replacement:"new")) }
  let text=String(data:try JSONEncoder().encode(c.companionWorkingState),encoding:.utf8)!;XCTAssertFalse(text.contains(a.sourceID));XCTAssertFalse(text.contains(b.sourceID))
 }

}
