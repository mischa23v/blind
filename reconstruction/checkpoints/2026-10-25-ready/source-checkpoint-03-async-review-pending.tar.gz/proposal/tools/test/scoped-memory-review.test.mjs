// Authored ownership/review scenarios. Executes actual production state, controller
// and UI action bodies, not SwiftUI rendering, real recognition or device accuracy.
import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,mkdirSync,mkdtempSync} from 'node:fs';
import {dirname,join,resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {tmpdir} from 'node:os';
import {spawnSync} from 'node:child_process';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'../..');
const read=p=>readFileSync(join(root,p),'utf8');
function section(text,start,end){const a=text.indexOf(start);assert.ok(a>=0,start);const b=text.indexOf(end,a);assert.ok(b>a,end);return text.slice(a,b);}

test('scoped review captures an immutable receipt and fences late conversation publication',()=>{
 const nav=read('ios/BlindAssist/NavigationModel.swift');
 const editor=read('ios/BlindAssist/DashboardView.swift').split('private struct ScopedConversationRecordEditor: View {')[1];
 assert.ok(editor);assert.match(editor,/@State private var selection: CompanionWorkingState.ReviewSelection/);
 assert.match(editor,/_selection = State\(initialValue: selection\)/);assert.doesNotMatch(editor,/onAppear|selection\s*=/);
 assert.match(editor,/if model.reviseScopedConversationRecord\(selection, replacement: nil\) \{ dismiss\(\) \}/);
 assert.equal((nav.match(/self\.conversationMemoryRevision == memoryRevision/g)||[]).length,3);
 const record=section(nav,'    private func recordCompanionMessage(', '    /// Conversation evidence rule');
 assert.match(record,/assistantDialogue.record\(role: "user", text: question, sourceID: companionWorkingState.reports.last\?\.sourceID\)/);
});

test('actual scoped review state controller and UI actions preserve source ownership',{
 skip:!process.env.BLIND_SWIFTC && 'Set BLIND_SWIFTC for actual extracted Swift replay.',timeout:180_000,
},()=>{
 const work=mkdtempSync(join(process.env.BLIND_TEST_SCRATCH||tmpdir(),'blind-scoped-review-'));
 const sourceDir=join(work,'Sources/NativeReviewReplay');const tests=join(work,'Tests/NativeReviewReplayTests');
 mkdirSync(sourceDir,{recursive:true});mkdirSync(tests,{recursive:true});
 const local=read('ios/BlindAssist/LocalImageAssistant.swift');
 writeFileSync(join(sourceDir,'WorkingState.swift'),'import Foundation\nimport BlindCore\n'+section(local,'struct CompanionTaskUpdate:','\n#if canImport(FoundationModels)'));
 const nav=read('ios/BlindAssist/NavigationModel.swift');
 const fixture='tools/test/fixtures/scoped-memory-review/';
 writeFileSync(join(sourceDir,'Controller.swift'),read(fixture+'ControllerPrefix.swift')+
  section(nav,'    var scopedConversationReviews:','    @discardableResult func correctConversationRecord')+
  section(nav,'    private func interruptOrdinaryConversation(','\n    private func unverifiedConversationReply')+
  section(nav,'    func clearAssistantConversation()','    var scopedConversationReviews:')+'\n}\n');
 const ui=read('ios/BlindAssist/DashboardView.swift').split('private struct ScopedConversationRecordEditor: View {')[1];assert.ok(ui);
 writeFileSync(join(sourceDir,'UIActions.swift'),read(fixture+'UIActionsPrefix.swift')+' func save() {\n'+
  section(ui,'                if model.reviseScopedConversationRecord(selection, replacement: replacement)','\n            }.accessibilityIdentifier')+'\n }\n func delete() {\n'+
  section(ui,'                if model.reviseScopedConversationRecord(selection, replacement: nil)','\n            }')+'\n }\n}\n');
 writeFileSync(join(tests,'ScopedReviewTests.swift'),read(fixture+'ScopedReviewTests.swift'));
 writeFileSync(join(work,'Package.swift'),`// swift-tools-version: 5.9\nimport PackageDescription\nlet package = Package(name: "NativeReviewReplay", dependencies: [.package(path: ${JSON.stringify(join(root,'BlindCore'))})], targets: [.target(name: "NativeReviewReplay", dependencies: [.product(name: "BlindCore", package: "BlindCore")]), .testTarget(name: "NativeReviewReplayTests", dependencies: ["NativeReviewReplay", .product(name: "BlindCore", package: "BlindCore")])])\n`);
 const result=spawnSync(join(dirname(process.env.BLIND_SWIFTC),'swift'),['test','--package-path',work,'--jobs','2'],{encoding:'utf8',timeout:175_000,maxBuffer:8*1024*1024});
 const output=(result.stdout||'')+'\n'+(result.stderr||'');writeFileSync(join(work,'execution.log'),output);
 assert.equal(result.status,0,`Replay failed; retained at ${work}\n${output.slice(-12000)}`);
 assert.match(output,/Executed 13 tests, with 0 failures/);
});
