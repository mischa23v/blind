from pathlib import Path
import shutil
s=Path(__file__).parent;o=s/'replay';n=(s/'proposal/ios/BlindAssist/NavigationModel.swift').read_text()
for name in ['AssistantDialogue.swift','CompanionMemoryWriteQueue.swift']:shutil.copyfile(s/'proposal/BlindCore/Sources/BlindCore'/name,o/'Sources/BlindCore'/name)
t=(s/'proposal/ios/BlindAssist/LocalImageAssistant.swift').read_text();a=t.index('struct CompanionTaskUpdate:');b=t.index('\n#if canImport(FoundationModels)',a);(o/'Sources/BlindCore/ExtractedAppWorkingState.swift').write_text('import Foundation\n'+t[a:b])
def section(text,a,b):
 start=text.index(a);return text[start:text.index(b,start)]
properties=section(n,'    @Published var scopedReviewError','    private var conversationSpeech:').replace('@Published ','')
prefix='''import Foundation
final class MemoryStore: @unchecked Sendable {
 let writeOwner = UUID()
 private let lock = NSLock()
 let started = DispatchSemaphore(value: 0), release = DispatchSemaphore(value: 0)
 private var block = false
 func configureBlock() { lock.lock(); block = true; lock.unlock() }
 private var fail = false
 private var count = 0
 private var savedDialogue: Data?, savedState: Data?
 func configureFailure(_ value: Bool) { lock.lock(); fail = value; lock.unlock() }
 var writeCount: Int { lock.lock(); defer { lock.unlock() }; return count }
 func snapshots() -> (Data?, Data?) { lock.lock(); defer { lock.unlock() }; return (savedDialogue, savedState) }
 func saveConversationReview(dialogue: Data, workingState: Data) throws {
  lock.lock(); let blocked = block; block = false; let failing = fail; lock.unlock()
  if blocked { started.signal(); release.wait() }
  if failing { throw CocoaError(.fileWriteUnknown) }
  lock.lock(); savedDialogue = dialogue; savedState = workingState; count += 1; lock.unlock()
 }
}
@MainActor final class ExtractedScopedReviewController {
 struct Places { var memory: MemoryStore? = MemoryStore() }; var places = Places()
 var arabic = false
 var companionWorkingState = CompanionWorkingState()
 var assistantDialogue = AssistantDialogue()
 var unverifiedConversationID = UUID()
 var unverifiedConversationTask: Task<Void, Never>?
 var unverifiedConversationTimeout: Task<Void, Never>?
 var questionTask: Task<Void, Never>?
 var questionTimeoutTask: Task<Void, Never>?
 var questionIsChat = false
 var busy = false
 var streamedConversationText = ""
 struct Speech { let id = UUID() }
 var conversationSpeech: [Speech] = []
 var activeConversationSpeech: Speech?
 final class Feedback { var stopped: [UUID] = []; func stopRequestedSpeech(_ id: UUID) { stopped.append(id) }; func stopInformation(announceCancellation: Bool) -> Bool { true } }
 let feedback = Feedback()
 var sceneAnswer = "", currentReply = "", assistantQuestion = "", objectiveDraft = ""
 var privacyPurges = 0, searchRetirements = 0, journeyRetirements = 0
 var persisted: Int { places.memory?.writeCount ?? 0 }
 var requestID = UUID()
 var testMemoryRevision: UUID { conversationMemoryRevision }
 var unverifiedDialogue = AssistantDialogue()
 var unverifiedDialogueGeneration: UInt64?
 struct Tasks { func cancelAll() {}; func setGoal(_ text: String) {} }; let everydayTasks = Tasks()
 var everydayTicket: String?, everydayUtterance = ""
 struct Journey { func eraseHistory(origin: CompanionCommandOrigin) throws {}; func cancel(origin: CompanionCommandOrigin) throws {} }
 struct Journeys { func withConnectedJourney(_ body: (Journey) throws -> Void) rethrows { try body(Journey()) } }; let journeys = Journeys()
 struct Indoor { func cancelRoute() {} }; let indoor = Indoor()
 struct Output { func revalidate() {} }; let spatialRouteOutput = Output()
 var journeyConversationGoal = "", journeyConversationSourceID: String?, plannedIndoorGoalRevision: String?
 func appendCurrentReport(_ text: String) { recordCompanionMessage(text) }
 func clearExploreSnapshot() {}
 func stopReturn() {}
 func cancelDescription() { interruptOrdinaryConversation(origin: .trustedInterface); requestID = UUID(); questionTask?.cancel(); questionTask = nil; busy = false }
 func purgeDebugSessionDiagnostics() { privacyPurges += 1 }
 func retireHeldSearchForPrivacyDeletion() { searchRetirements += 1 }
 func establishedJourneyContextChanged() { journeyRetirements += 1 }
 func waitForAllMemorySaves() async -> Bool {
  guard let memory = places.memory, let receipt = companionMemoryWriter.retryLatest(owner: memory.writeOwner) else { return false }
  return await companionMemoryWriter.waitForCommit(receipt)
 }
'''
methods=section(n,'    var scopedConversationReviews:','    @discardableResult func correctConversationRecord')
methods+=section(n,'    private func interruptOrdinaryConversation(','\n    private func unverifiedConversationReply')
methods+=section(n,'    func clearAssistantConversation()','    var scopedConversationReviews:')
methods+=section(n,'    private func reconcileWorkingStateOwners()','    @discardableResult func addAssistantInterest')
methods+=section(n,'    @discardableResult private func recordCompanionMessage(','    /// Conversation evidence rule')
methods+='    func commitExplicitGoal(_ text: String) {\n        recordingCompanionTurn = true; recordedCompanionSourceID = nil\n        defer { recordingCompanionTurn = false; recordedCompanionSourceID = nil }\n'+section(n,'        if let goal = ConversationIntent.explicitTaskGoal(text) {','        if handleItemOrLocate(text)')+'        recordCompanionMessage(text)\n    }\n'
(o/'Sources/BlindCore/ExtractedScopedReviewController.swift').write_text(prefix+properties+methods+'\n}\n')
u=(s/'proposal/ios/BlindAssist/DashboardView.swift').read_text().split('private struct ScopedConversationRecordEditor: View {',1)[1]
def action(marker):
 a=u.index(marker);b=u.index('                    saving = false',a)+len('                    saving = false');return u[a:b]
uiprefix='''import Foundation
@MainActor final class ExtractedScopedReviewUIActions {
 let model: ExtractedScopedReviewController
 let selection: CompanionWorkingState.ReviewSelection
 var replacement: String
 var failed = false, dismissed = false, saving = false
 init(model: ExtractedScopedReviewController, selection: CompanionWorkingState.ReviewSelection) {
  self.model = model; self.selection = selection; replacement = selection.report.text
 }
 func dismiss() { dismissed = true }
'''
(o/'Sources/BlindCore/ExtractedScopedReviewUIActions.swift').write_text(uiprefix+' func save() async {\n'+action('                    if await model.reviseScopedConversationRecord(selection, replacement: replacement)')+'\n }\n func delete() async {\n'+action('                    if await model.reviseScopedConversationRecord(selection, replacement: nil)')+'\n }\n}\n')
(s/'controller-prefix-v2.swift').write_text(prefix)
(s/'ui-prefix-v2.swift').write_text(uiprefix)
