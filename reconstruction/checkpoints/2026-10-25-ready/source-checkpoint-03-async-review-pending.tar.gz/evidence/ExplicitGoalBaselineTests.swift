import XCTest
@testable import BlindCore
final class ExplicitGoalBaselineTests: XCTestCase {
 func testSR015OriginalExplicitGoalReportHasSameSource() {
  let c=ExtractedBaselineGoalController();XCTAssertNotNil(ConversationIntent.explicitTaskGoal("Actually help me find my backpack")); XCTAssertNil(CompanionUtterance.parse("Actually help me find my backpack")); c.commitExplicitGoal("Actually help me find my backpack")
  XCTAssertEqual(c.companionWorkingState.goalSource?.sourceID,c.companionWorkingState.reports.last?.sourceID,"Exact original explicit native goal path minted a different source from its reviewable report")
 }
}
