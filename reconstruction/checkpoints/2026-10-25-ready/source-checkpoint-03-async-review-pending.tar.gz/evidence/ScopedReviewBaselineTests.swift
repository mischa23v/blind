import XCTest
@testable import BlindCore
final class ScopedReviewBaselineTests: XCTestCase {
 func testSR000ExistingEditorCannotCorrectSelectedScopedReport() {
  let c=ExtractedNativeMemoryMutations()
  let scope=CompanionMemoryScope(map:.init(mapID:"A",frameID:"A",revision:"1"),placeID:"house-A",floorID:"floor",roomID:"kitchen",objectInstanceID:"fridge-A")!
  c.companionWorkingState.transitionMemoryScope(scope)
  let words="My milk is in the fridge"
  c.companionWorkingState.record(words);c.assistantDialogue.record(role:"user",text:words)
  let selected=c.assistantDialogue.userRecords.last!.id
  XCTAssertTrue(c.correctConversationRecord(id:selected,replacement:"My milk is on the table"),"SR-000 desired behavior fails in exact original native editor/controller: all scoped corrections are refused")
 }
}
