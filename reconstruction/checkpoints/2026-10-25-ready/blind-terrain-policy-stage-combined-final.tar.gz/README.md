# Terrain policy correction: staged only

Root owns ordered application/rebase. No live planner edit. Four paths: one narrow NavigationSurface patch, one new policy source and two new regression test files, listed in verification/source-input-manifest.json.

The old 9cm floor/endpoint allowance is removed. Typed stored-geometry classification rejects rises, drops, slopes, steps, stairs, unknown support/annotations and positive measurement uncertainty. Numerical equality permits arithmetic roundoff only, not traversable-height or sensor-error tolerance. Flat known authored geometry still routes; no result grants current physical clearance. Existing planner, swept body/head collision, cell coverage and source/floor ownership remain in place.

Executed evidence:
- Unmodified baseline: 4 rejecting/flat regressions, 3 expected failures (8cm rise/drop,16cm neighbour discontinuity), flat passes.
- Staged terrain: same regressions plus6 policy cases,10 passed.
- Combined with corrected body profile: full Core 1,181 + actual native store 7 = 1,188 tests passed, zero failures, jobs2. The full compiled source/test SHA256 inventory is in verification/compiled-source-sha256.json.
- One exact patch applies and reverses in isolated scratch.

The old body packet's expected-permit terrain witnesses are historical baseline characterization and intentionally excluded from the combined run. New rejecting regressions replace them. Read research/TERRAIN_POLICY_EVIDENCE.md for primary evidence, semantic boundaries and missing measured providers.

verification/run-tests.sh reproduces combined tests using /workspace/shared/blind-body-profile-stage. Stage patches must be rebased in root's application order, never overwrite newer live full-file snapshots. No personal data, recorded imagery, models, dependencies, builds, database or credentials are included. Apple/device terrain and body/mount calibration remain pending.
