# Stored terrain correction: no demographic footing threshold

2026-10-25, staging only. No live planner edits. This corrects an actual stored-surface policy defect, not sensor detection or child-safe mobility.

## Executed failing-before evidence

`TerrainFootingRegressionTests.swift` was compiled against the unmodified NavigationSurface source preimage. Four tests ran: known flat geometry passed; assertions that an 8cm rise, an 8cm drop and a 16cm adjacent-cell difference should reject all failed. `research/fail-before.log` records 3 failures, exit 1. With the staged source, the exact same four tests pass. Six additional typed policy/collision tests also pass in `research/pass-after.log`.

Old code compared both endpoint height and every swept floor sample against source Y with 0.09m tolerance. That tolerance represented neither measured uncertainty nor an explicit slope/step policy and could flatten meaningful discontinuities. The 16cm test exposes source-relative rather than adjacent support comparison; the 8cm cases start on actual zero-height stored support.

## Minimal correction

- Reuse the existing authored graph planner, floor-owned `NavigationSurface`, full swept cylinder, cell coverage, unknown blocking, overhead clearance, bounds and sample spacing unchanged.
- Replace the 9cm height allowance with a typed stored-terrain assessment. Non-level endpoint or swept support heights reject. This also rejects gradual running slopes, cross slopes and isolated rises/drops anywhere inside the entire body footprint. No new navigation algorithm or component dependency.
- `SurfaceTerrainAnnotation` distinguishes level/rise/drop/slope/step/stairs/unknown. Explicit non-level or unknown annotations cannot be erased by equal endpoint heights. A level annotation cannot override a height difference.
- Optional `floorUncertainty` is kept separate from numerical equality and cannot be used to expand traversable-height tolerance. Any positive, negative or nonfinite uncertainty withholds the level route (negative/nonfinite values also fail surface validation). No calibrated positive allowance is installed.
- Floating-point identity is a few ULPs, capped at one nanometre so large coordinates cannot create a physical step allowance. This is only representational roundoff, not a sensor precision estimate, detectable-height limit, accessible threshold or child gait tolerance. Tests distinguish one nextUp operation from micrometre and larger height changes and reject one ULP at an excessively large coordinate where it represents a meaningful distance.
- Legacy cells with floor/clearance and no annotation still represent authored stored geometry. Exactly flat geometry can remain usable for graph preview; missing measurement uncertainty is explicitly retained as nil, never claimed zero. Missing floor is unknown and impassable. Every assessment has `grantsPhysicalClearance == false`.
- The optional cell fields decode legacy maps without changing their existing meaning. New annotations are serialized with the enclosing geometry, so the existing artifact revision/hash ownership applies. No native pose/floor ownership or body-profile parameter is used as terrain authority. Public producers/consumers must retain these fields; compatibility with older app versions that ignore new fields is not claimed.

## Primary reference and boundary

US Access Board ADA Accessibility Standards §303: https://www.access-board.gov/ada/ . Architectural treatment of changes in level depends on height and edge/ramp shape. That standard is not a personalised safe-step limit and does not establish camera/LiDAR detectability or blind-child gait. No ADA numeric threshold is adopted by this policy.

The anthropometry sources and why age/weight/gender cannot authorize footing are recorded in the separate body-profile evidence. No body demographic can alter this terrain policy.

## Still missing, not simulated as working

Validated support-height uncertainty and floor-plane association; observed resolution/coverage tied to exact capture/time/map; explicit measured edge/ramp/slope classification; running and cross-slope limits supported by a reviewed mobility protocol; loose/slippery surfaces and negative-return coverage; scan/mount/sensor accuracy and latency on intended devices; supervised O&M acceptance for intended users. A flat stored graph does not establish current obstacle-free or safe footing. Fail-closed rejection of noisy/nonflat maps may reduce route availability until those providers exist.

## Review and reproducibility

`verification/run-tests.sh` overlays body-profile and terrain stages onto a copied source tree and runs the full Core suite plus actual native body-store tests with Swift 6.4.1 and jobs=2. It deliberately does not run the old body packet's expected-permit terrain characterization; the rejecting regressions here supersede it. No test fixture is relabelled safe, no private sensor/child data is included, and the live source remains unchanged.
