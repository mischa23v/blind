#!/usr/bin/env bash
set -euo pipefail
stage=$(cd "$(dirname "$0")/.." && pwd)
base=${BLIND_SOURCE_ROOT:-/workspace/shared/blind-rebuild}
body=${BODY_PROFILE_STAGE:-/workspace/shared/blind-body-profile-stage}
work=${TERRAIN_TEST_WORK:-/workspace/shared/blind-terrain-policy-combined-tests}
source /workspace/shared/swift-toolchain/env.sh
export TMPDIR=/workspace/shared/swift-toolchain/tmp CLANG_MODULE_CACHE_PATH="$work/clang-cache" BODY_PROFILE_STAGE="$body"
mkdir -p "$work/Sources/NativeBodyProfile" "$work/Tests/BlindCoreTests" "$work/Tests/NativeBodyProfileTests"
cp -a "$base/BlindCore/Sources/BlindCore" "$work/Sources/"
cp -a "$base/BlindCore/Tests/BlindCoreTests" "$work/Tests/"
cp "$body/BlindCore/Sources/BlindCore/"*.swift "$work/Sources/BlindCore/"
cp "$body/BlindCore/Tests/BlindCoreTests/"*.swift "$work/Tests/BlindCoreTests/"
cp "$stage/BlindCore/Sources/BlindCore/"*.swift "$work/Sources/BlindCore/"
cp "$stage/BlindCore/Tests/BlindCoreTests/"*.swift "$work/Tests/BlindCoreTests/"
cp "$base/ios/BlindAssist/SpatialMapIO.swift" "$body/ios/BlindAssist/BodyProfileStore.swift" "$work/Sources/NativeBodyProfile/"
# Old expected-permit terrain characterization is intentionally NOT copied;
# it is superseded by the actual failing-before/passing-after regressions here.
cp "$body/verification/Tests/BodyProfileStoreTests.swift" "$work/Tests/NativeBodyProfileTests/"
cat > "$work/Package.swift" <<'PACKAGE'
// swift-tools-version: 5.9
import PackageDescription
let package = Package(name: "BodyTerrainVerification", platforms: [.macOS(.v13)], targets: [
.target(name: "BlindCore", resources: [.copy("Resources/guide-prompt.txt")]),
.target(name: "NativeBodyProfile", dependencies: ["BlindCore"]),
.testTarget(name: "BlindCoreTests", dependencies: ["BlindCore"], resources: [.copy("Fixtures")]),
.testTarget(name: "NativeBodyProfileTests", dependencies: ["BlindCore", "NativeBodyProfile"])])
PACKAGE
swift test --package-path "$work" --scratch-path "$work/.build" --jobs 2
