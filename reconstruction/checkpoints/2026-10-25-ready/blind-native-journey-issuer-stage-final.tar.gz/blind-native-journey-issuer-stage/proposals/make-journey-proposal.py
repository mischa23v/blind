from pathlib import Path
import hashlib,json,difflib
base=Path('/workspace/shared/blind-rebuild');stage=Path('/workspace/shared/blind-native-journey-issuer-stage')
changes={
'BlindCore/Sources/BlindCore/ConnectedJourneyCoordinator.swift':('    public var expectedSessionID: UUID? { owner?.sessionID }','''    /// Context comes from this journey's active owner, not IndoorNavigator's preview.
    public var nativeLocalizationContext: NativeLocalizationRouteContext? {
        guard let owner, let installation = owner.installation,
              activeBinding == installation.binding, let goal = snapshot.goal, goal.status == .active,
              let revision = try? installation.registry.map(for: installation.binding) else { return nil }
        return .init(sessionID: owner.sessionID, artifact: installation.artifact,
            revision: revision, goalRevision: goal.revision)
    }
    /// Exact-owner evidence withdrawal: preserve route intent, itinerary, restrictions,
    /// localization session and replay ledger. Actual tracking loss is separate.
    @discardableResult public mutating func withholdNativeEvidence(session: UUID,
        artifact: SpatialMapArtifactIdentity, goalRevision: UUID) -> Bool {
        guard let context = nativeLocalizationContext, context.sessionID == session,
              context.artifact == artifact, context.goalRevision == goalRevision else { return false }
        guard owner?.hasLocalizationEvidence == true || support != nil || armedPortal != nil else { return false }
        owner?.withholdLocalizationEvidence(); support = nil; armedPortal = nil
        rotateOutput(); return true
    }
    public var expectedSessionID: UUID? { owner?.sessionID }'''),
'ios/BlindAssist/ConnectedJourneyRuntime.swift':('    public var expectedSessionID: UUID? { coordinator?.expectedSessionID }','''    public var expectedSessionID: UUID? { coordinator?.expectedSessionID }
    public var nativeLocalizationContext: NativeLocalizationRouteContext? {
        guard !loading, !externalMapPending, !mapValidationBlocked, mapWorkID == nil, !commandBlocked else { return nil }
        return coordinator?.nativeLocalizationContext
    }
    /// Compare session, exact geometry digest and goal BEFORE changing any state.
    /// Repeated absent-evidence frames do not generate retirement/change storms.
    @discardableResult public func withholdNativeEvidence(session: UUID,
        artifact: SpatialMapArtifactIdentity, goalRevision: UUID) -> Bool {
        guard let context = nativeLocalizationContext, context.sessionID == session,
              context.artifact == artifact, context.goalRevision == goalRevision,
              var owner = coordinator else { return false }
        let changed = owner.withholdNativeEvidence(session: session, artifact: artifact, goalRevision: goalRevision)
        guard changed || held != nil || lastEndpoint != nil else { return false }
        coordinator = owner; lastEndpoint = nil
        retireOutput(); onChange?(); return true
    }''')}
patch=[];manifest={}
for path,(needle,replacement) in changes.items():
 p=base/path;old=p.read_text();assert old.count(needle)==1;new=old.replace(needle,replacement)
 if path.endswith('ConnectedJourneyRuntime.swift'):
  portal='                } else if case .portal(_, _, let to)? = coordinator?.currentLeg, sameLocation(endpoint, to) {'
  assert new.count(portal)==1
  new=new.replace(portal,'                } else if case .portal(_, let from, _)? = coordinator?.currentLeg, sameLocation(endpoint, from) {\n                    // Evidence withdrawal discards the old departure receipt but\n                    // retains intent. Only this fresh measured source endpoint\n                    // can rearm it; the old departure is never restored.\n                    try coordinator?.armPortal(now: now, recordedAt: Date())\n                } else if case .portal(_, _, let to)? = coordinator?.currentLeg, sameLocation(endpoint, to) {')
  initial='                    try coordinator?.plan(from: endpoint, now: now)'
  assert new.count(initial)==1
  new=new.replace(initial,initial+'\n                    // An itinerary can begin directly at an authored portal\n                    // source. Associate the fresh source, never crossing guidance.\n                    if case .portal? = coordinator?.currentLeg { try coordinator?.armPortal(now: now, recordedAt: Date()) }')

 manifest[path]=hashlib.sha256(p.read_bytes()).hexdigest()
 (stage/'proposals'/(p.name+'.proposed')).write_text(new)
 patch+=list(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+path,tofile='b/'+path))
(stage/'proposals/connected-owner.patch').write_text(''.join(patch))
(stage/'proposals/journey-base-sha256.json').write_text(json.dumps(manifest,indent=2)+'\n')
