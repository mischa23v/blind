from pathlib import Path
import difflib,json,hashlib
base=Path('/workspace/shared/blind-rebuild'); stage=Path('/workspace/shared/blind-native-journey-issuer-stage')
changes={
'BlindCore/Sources/BlindCore/SpatialLocalizationLease.swift':('    public mutating func restart() {','''    /// Withdraw evidence without changing capture ownership or resetting the replay ledger.
    /// Lifecycle restart/real tracking loss still use restart/loseTracking.
    public var hasEvidence: Bool { accepted != nil }
    public mutating func withholdEvidence() {
        accepted = nil; acceptanceID = nil; acceptedInstallationID = nil
    }
    public mutating func restart() {'''),
'BlindCore/Sources/BlindCore/SpatialRouteOwner.swift':('    public mutating func loseTracking() {','''    /// Evidence absence withdraws physical authority, not route/goal intent.
    public var hasLocalizationEvidence: Bool { localization.hasEvidence }
    public mutating func withholdLocalizationEvidence() { localization.withholdEvidence() }
    public mutating func loseTracking() {'''),
'ios/BlindAssist/RegisteredIndoorNavigation.swift':('    func loseTracking() {','''    /// Compare before mutation: a delayed candidate from A cannot retire newer B.
    /// Preserve session and replay ledger so withdrawing output does not stale the
    /// candidate being measured. True lifecycle loss still uses loseTracking.
    func withholdNativeEvidence(session: UUID, artifact: SpatialMapArtifactIdentity) {
        guard sessionID == session, installation?.artifact == artifact else { return }
        retireOutput(); owner?.withholdLocalizationEvidence(); support = nil
    }
    func loseTracking() {''')}
patch=[]; manifest={}
for path,(needle,replacement) in changes.items():
 p=base/path;old=p.read_text();assert old.count(needle)==1;new=old.replace(needle,replacement)
 manifest[path]=hashlib.sha256(p.read_bytes()).hexdigest()
 (stage/'proposals'/(p.name+'.proposed')).write_text(new)
 patch+=list(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+path,tofile='b/'+path))
(stage/'proposals/scoped-withdrawal.patch').write_text(''.join(patch))
(stage/'proposals/withdrawal-base-sha256.json').write_text(json.dumps(manifest,indent=2)+'\n')
