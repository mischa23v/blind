# Independent clear-only memory integration point (not part of the 12-path patch)

After the memory worker's retireCompanionMemoryScope() implementation is independently frozen and its non-reentrant cancellation semantics verified, the parent may add this single call at the start of NavigationModel.invalidatePerceptionWork(preserveRGBHistoryWork:), adjacent to native evidence invalidation:

    retireCompanionMemoryScope()

This is a clear-only lifecycle-loss hook. It must not mint memory scope from candidate metadata, room labels, saved-map association, requested goal or a selected map. This candidate-only bridge cannot certify current place/floor/room/container/object identity and supplies no positive memory-scope ingress. Do not apply this call before the real method is available. It is intentionally not included in the executable native proposal, source manifest or passing 47-test claim.
