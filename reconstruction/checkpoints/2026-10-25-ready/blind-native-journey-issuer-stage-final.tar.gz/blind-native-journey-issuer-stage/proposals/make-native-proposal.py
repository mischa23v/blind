from pathlib import Path
import difflib,hashlib,json
base=Path('/workspace/shared/blind-rebuild');stage=Path('/workspace/shared/blind-native-journey-issuer-stage')
patch=[];manifest={}
for name in ['IndoorNavigator','NavigationModel']:
 p=base/f'ios/BlindAssist/{name}.swift';old=p.read_text();new=old
 manifest[str(p.relative_to(base))]=hashlib.sha256(p.read_bytes()).hexdigest()
 if name=='IndoorNavigator':
  needle='    var registeredSessionID: UUID? { registered?.sessionID }'
  new=new.replace(needle,needle+'''
    /// Preview ownership only. Never substitute this session for a connected journey.
    var nativePreviewLocalizationContext: NativeLocalizationRouteContext? {
        guard let registered, !registered.ioPending, !registered.ioBlocked,
              let session = registered.sessionID, let installation = registered.installation,
              let revision = try? installation.registry.map(for: installation.binding) else { return nil }
        return .init(sessionID: session, artifact: installation.artifact, revision: revision, goalRevision: nil)
    }
    func withholdNativePreviewEvidence(session: UUID, artifact: SpatialMapArtifactIdentity) {
        registered?.withholdNativeEvidence(session: session, artifact: artifact)
    }
''')
 else:
  needle='    private var observationFrameID = UUID().uuidString'
  new=new.replace(needle,needle+'''
    private var nativeLocalizationMount = UUID()
    // Diagnostic marker only: no measured calibration/error/support provider exists.
    private let nativeLocalizationCalibrationRevision = "unconfigured"
    private lazy var nativeLocalizationRouter = journeys.withConnectedJourney { runtime in
        NativeLocalizationRouter(journey: runtime,
            previewContext: { [weak self] in self?.indoor.nativePreviewLocalizationContext },
            withholdPreview: { [weak self] session, artifact in
                self?.indoor.withholdNativePreviewEvidence(session: session, artifact: artifact)
            })
    }
    private func withNativeLocalization<T>(_ operation: @MainActor (NativeLocalizationRouter) throws -> T) rethrows -> T {
        try MainActor.assumeIsolated {
            let selected: NativeLocalizationRouter.Selection = connectedJourneyOwnsNavigation ? .connectedJourney :
                (indoorGuidanceOwner == .legacyPreview ? .registeredPreview : .none)
            nativeLocalizationRouter.select(selected)
            return try operation(nativeLocalizationRouter)
        }
    }
    private func invalidateNativeLocalization(_ reason: NativeLocalizationNotReady) {
        withNativeLocalization { $0.invalidate(reason) }
    }
    private func offerNativeLocalization(_ frame: ARFrame, now: Double) {
        guard running, cameraAwareness, assistantSession.foregroundActive, !simulation, !places.scanning,
              let arSession = UUID(uuidString: observationFrameID) else {
            invalidateNativeLocalization(.trackingUnavailable); return
        }
        let normal: Bool
        if case .normal = frame.camera.trackingState { normal = true } else { normal = false }
        let transform = frame.camera.transform
        let matrix = (0..<4).flatMap { column in (0..<4).map { row in Double(transform[column][row]) } }
        withNativeLocalization { router in
            router.offer(arSession: arSession, calibrationRevision: nativeLocalizationCalibrationRevision,
                mountRevision: nativeLocalizationMount, capturedAt: frame.timestamp, cameraToWorld: matrix,
                trackingNormal: normal, recovered: places.currentWorldFrame(sessionID: arSession, now: now), now: now)
        }
    }
    private func revalidateNativeLocalization(now: Double) {
        guard let arSession = UUID(uuidString: observationFrameID) else { invalidateNativeLocalization(.ownerChanged); return }
        withNativeLocalization { $0.watchdog(arSession: arSession,
            calibrationRevision: nativeLocalizationCalibrationRevision, mountRevision: nativeLocalizationMount, now: now) }
    }
    func invalidateNativeLocalizationMount(slipped: Bool) {
        nativeLocalizationMount = UUID()
        invalidateNativeLocalization(slipped ? .mountSlip : .mountChanged)
    }
''')
  new=new.replace('if oldValue != fixedBodyMount {','if oldValue != fixedBodyMount {\n                invalidateNativeLocalizationMount(slipped: mountSlipAnnounced)')
  new=new.replace('    private func invalidatePerceptionWork(preserveRGBHistoryWork: Bool = false) {','    private func invalidatePerceptionWork(preserveRGBHistoryWork: Bool = false) {\n        invalidateNativeLocalization(.trackingUnavailable)')
  needle='            self.journeys.withConnectedJourney { $0.revalidate(now: ProcessInfo.processInfo.systemUptime) }'
  assert new.count(needle)==1
  new=new.replace(needle,needle+'\n            self.revalidateNativeLocalization(now: ProcessInfo.processInfo.systemUptime)')
  new=new.replace('    func session(_ session: ARSession, didUpdate frame: ARFrame) {','    func session(_ session: ARSession, didUpdate frame: ARFrame) {\n        // Tracking loss retires selected-owner evidence even on throttled frames.\n        if case .normal = frame.camera.trackingState {} else { invalidateNativeLocalization(.trackingUnavailable) }')
  needle='        let receivedDate = Date()\n        guard FrameTimestampPolicy.isFresh'
  assert new.count(needle)==1
  new=new.replace(needle,'        let receivedDate = Date()\n        // Candidate capture follows urgent sensors; no history writer/LLM dependency.\n        defer { offerNativeLocalization(frame, now: ProcessInfo.processInfo.systemUptime) }\n        guard FrameTimestampPolicy.isFresh')
  needle='    private var indoorGuidanceOwner: IndoorGuidanceOwner = .none'
  assert new.count(needle)==1
  new=new.replace(needle,needle+''' {
        didSet {
            if oldValue != indoorGuidanceOwner { withNativeLocalization { _ in } }
        }
    }''')
 assert old!=new
 (stage/'proposals'/(name+'.swift.proposed')).write_text(new)
 patch+=list(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+str(p.relative_to(base)),tofile='b/'+str(p.relative_to(base))))
(stage/'proposals/native-hookup.patch').write_text(''.join(patch))
(stage/'proposals/base-sha256.json').write_text(json.dumps(manifest,indent=2)+'\n')
