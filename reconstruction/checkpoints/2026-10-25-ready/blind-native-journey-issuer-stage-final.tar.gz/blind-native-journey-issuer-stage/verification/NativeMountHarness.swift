import Foundation
import BlindCore
final class NativeMountHarness {
 struct Sink { var count=0; mutating func breakTracking(){count += 1}; mutating func interruptAmbient(){count += 1}; mutating func invalidatePosition(){count += 1}; mutating func retire(){count += 1}; mutating func reset(){count += 1} }
 var journeys=Sink(), feedback=Sink(), indoor=Sink(), spatialRouteOutput=Sink(), bodyHeadingEstimator=Sink()
 var mountSlipAnnounced=false
 var nativeLocalizationMount=UUID()
 let nativeLocalizationIssuer=NativeLocalizationIssuer()
 func invalidateNativeLocalization(_ reason: NativeLocalizationNotReady){ nativeLocalizationIssuer.invalidate(reason) }
 var descriptionsCancelled=0
 func cancelDescription(){descriptionsCancelled += 1}
var fixedBodyMount = false {
        didSet {
            if oldValue != fixedBodyMount {
                invalidateNativeLocalizationMount(slipped: mountSlipAnnounced)
                journeys.breakTracking()
                cancelDescription(); feedback.interruptAmbient()
                // A changed physical mount retires heading authority, not map history.
                indoor.invalidatePosition(); spatialRouteOutput.retire()
            }
            if fixedBodyMount && !oldValue { mountSlipAnnounced = false; bodyHeadingEstimator.reset() }
        }
    }
func invalidateNativeLocalizationMount(slipped: Bool) {
        nativeLocalizationMount = UUID()
        invalidateNativeLocalization(slipped ? .mountSlip : .mountChanged)
    }
}
