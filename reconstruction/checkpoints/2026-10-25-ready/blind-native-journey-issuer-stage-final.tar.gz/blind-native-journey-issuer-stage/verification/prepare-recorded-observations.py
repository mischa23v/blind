#!/usr/bin/env python3
"""Prepare private local ARKitScenes compatibility input, never copy data into source checkout.
Reads the already-downloaded official fixture. No upstream code executes and no network is used.
Dependencies NumPy/Pillow are already present in the research environment; do not install here.
"""
import argparse, hashlib, json, pathlib, uuid
import numpy as np
from PIL import Image

parser = argparse.ArgumentParser()
parser.add_argument('--dataset', required=True)
parser.add_argument('--output', required=True)
args = parser.parse_args()
root = pathlib.Path(args.dataset).resolve()
out = pathlib.Path(args.output).resolve()
script_root = pathlib.Path(__file__).resolve().parent.parent
if out.is_relative_to(script_root) or out.is_relative_to(pathlib.Path('/workspace/shared/blind-rebuild')):
    raise SystemExit('Recorded derivatives must remain outside source/staging checkout')
provenance = json.loads((root / 'provenance.json').read_text())
assert provenance['documentationCommit'] == '474aaa83d7b1c9080619d8485de2d7c885c01fc5'
assert provenance['annotationCautions']['confirm'] is False
records = json.loads((root / 'matched-frames.json').read_text())['records']
inputs = []
for entry in records:
    assert abs(entry['trajectoryTimestampSeconds'] - entry['frameTimestampSeconds']) <= 0.01
    assets = entry['assets']
    depth = np.asarray(Image.open(root / 'originals' / assets['lowres_depth.zip']))
    confidence = np.asarray(Image.open(root / 'originals' / assets['confidence.zip']))
    # The matching RGB is inspected for shape only, not copied or fed to a model.
    with Image.open(root / 'originals' / assets['lowres_wide.zip']) as rgb:
        assert rgb.size == (depth.shape[1], depth.shape[0])
    width, height, fx, fy, cx, cy = np.loadtxt(root / 'originals' / assets['lowres_wide_intrinsics.zip'])
    assert depth.shape == confidence.shape == (int(height), int(width))
    axis = np.array(entry['rotationAxisAngleRadians'], dtype=float)
    angle = np.linalg.norm(axis)
    # Independent standard Rodrigues formula, following the documented axis-angle convention.
    if angle == 0:
        rotation = np.eye(3)
    else:
        x, y, z = axis / angle
        cross = np.array([[0, -z, y], [z, 0, -x], [-y, x, 0]])
        rotation = np.eye(3) + np.sin(angle)*cross + (1-np.cos(angle))*(cross@cross)
    extrinsic = np.eye(4); extrinsic[:3, :3] = rotation; extrinsic[:3, 3] = entry['translationMeters']
    expected_pose = np.linalg.inv(extrinsic)
    pixels, sampled, invalid = [], 0, 0
    for row in range(0, int(height), 8):
        for column in range(0, int(width), 8):
            sampled += 1
            mm, level = int(depth[row, column]), int(confidence[row, column])
            if mm == 0 or not 0 <= level <= 2:
                invalid += 1; continue
            pixels.append(dict(column=column, row=row, metres=mm/1000.0, confidence=level))
    k = np.array([[fx, 0, cx], [0, fy, cy], [0, 0, 1]])
    checks = []
    for index in sorted(set([0, len(pixels)//2, len(pixels)-1])):
        pixel = pixels[index]; d = pixel['metres']
        camera = np.linalg.inv(k) @ np.array([pixel['column']*d, pixel['row']*d, d])
        world = expected_pose @ np.append(camera, 1)
        checks.append(dict(index=index, point=dict(x=world[0], y=world[1], z=world[2])))
    inputs.append(dict(capturedAt=entry['frameTimestampSeconds'], poseCapturedAt=entry['trajectoryTimestampSeconds'],
        sourceID=assets['lowres_depth.zip'], poseSourceID='originals/lowres_wide.traj@'+str(entry['trajectoryTimestampSeconds']),
        worldToCamera=dict(columns=extrinsic.flatten(order='F').tolist()),
        intrinsics=dict(width=int(width), height=int(height), fx=fx, fy=fy, cx=cx, cy=cy),
        depth=dict(source='arkitScenesAppleDepth', width=int(width), height=int(height), samplingStride=8,
            sampledPixelCount=sampled, invalidPixelCount=invalid, confidenceAvailable=True, pixels=pixels),
        expectedCameraPosition=dict(x=expected_pose[0,3], y=expected_pose[1,3], z=expected_pose[2,3]), expectedPoints=checks))
out.parent.mkdir(parents=True, exist_ok=True)
out.write_text(json.dumps(inputs, separators=(',', ':')))
print(json.dumps(dict(frames=len(inputs), fixtureBytes=out.stat().st_size,
    inputSHA256=hashlib.sha256(out.read_bytes()).hexdigest(),
    annotationStatus='not consumed: unconfirmed/incomplete; not obstacle or clearance truth',
    sourceProvenanceSHA256=hashlib.sha256((root/'provenance.json').read_bytes()).hexdigest()), indent=2))
