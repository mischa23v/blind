#!/usr/bin/env bash
set -euo pipefail
stage=$(cd "$(dirname "$0")/.." && pwd)
base=${BLIND_SOURCE_ROOT:-/workspace/shared/blind-rebuild}
work=${NATIVE_ISSUER_TEST_ROOT:-/workspace/shared/blind-native-journey-issuer-tests}
: "${NATIVE_RECORDED_FIXTURE:?Set path to privately prepared public ARKitScenes frames.json outside source/stage}"
source /workspace/shared/swift-toolchain/env.sh
export HOME=/workspace/shared/swift-toolchain/home TMPDIR=/workspace/shared/blind-test-tmp
export CLANG_MODULE_CACHE_PATH="$work/clang-cache"
mkdir -p "$work/Sources/NativeAdapter" "$work/Tests/NativeEvidenceTests"
cp -R "$base/BlindCore/Sources/BlindCore" "$work/Sources/"
cp "$stage/BlindCore/Sources/BlindCore/"*.swift "$work/Sources/BlindCore/"
cp "$stage/ios/BlindAssist/"*.swift "$work/Sources/NativeAdapter/"
cp "$stage/proposals/SpatialLocalizationLease.swift.proposed" "$work/Sources/BlindCore/SpatialLocalizationLease.swift"
cp "$stage/proposals/SpatialRouteOwner.swift.proposed" "$work/Sources/BlindCore/SpatialRouteOwner.swift"
cp "$stage/proposals/ConnectedJourneyCoordinator.swift.proposed" "$work/Sources/BlindCore/ConnectedJourneyCoordinator.swift"
cp "$stage/proposals/ConnectedJourneyRuntime.swift.proposed" "$work/Sources/NativeAdapter/ConnectedJourneyRuntime.swift"
cp "$stage/proposals/RegisteredIndoorNavigation.swift.proposed" "$work/Sources/NativeAdapter/RegisteredIndoorNavigation.swift"
cp "$base/ios/BlindAssist/SpatialMapIO.swift" "$work/Sources/NativeAdapter/"
cp "$stage/verification/NativeMountHarness.swift" "$work/Sources/NativeAdapter/"
cp "$stage/verification/NativeSelectionHarness.swift" "$work/Sources/NativeAdapter/"
cp "$stage/verification/Tests/NativeEvidenceTests/"*.swift "$work/Tests/NativeEvidenceTests/"
cp "$stage/verification/Package.swift" "$work/Package.swift"
python - "$base" "$stage" "$work" <<'PY'
from pathlib import Path
import hashlib,json,sys
base,stage,work=map(Path,sys.argv[1:])
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(stage/'ios/BlindAssist/NativeLocalizationIssuer.swift')==sha(work/'Sources/NativeAdapter/NativeLocalizationIssuer.swift')
assert sha(stage/'BlindCore/Sources/BlindCore/NativeLocalizationEvidence.swift')==sha(work/'Sources/BlindCore/NativeLocalizationEvidence.swift')
records={str(p.relative_to(work)):sha(p) for p in sorted((work/'Sources').rglob('*.swift'))}
(stage/'verification/compiled-source-sha256.json').write_text(json.dumps(records,indent=2)+'\n')
PY
swift test --package-path "$work" --scratch-path "$work/.build" --jobs 2
