from pathlib import Path
import json,hashlib
stage=Path('/workspace/shared/blind-native-journey-issuer-stage');s=(stage/'proposals/NavigationModel.swift.proposed').read_text()
def extract(needle):
 start=s.index(needle);brace=s.index('{',start);depth=1;end=brace+1
 while depth:
  if s[end]=='{':depth+=1
  elif s[end]=='}':depth-=1
  end+=1
 return s[start:end]
parts=[extract('private func withNativeLocalization<T>'),extract('private enum IndoorGuidanceOwner'),extract('private var indoorGuidanceOwner: IndoorGuidanceOwner'),extract('var connectedJourneyOwnsNavigation: Bool')]
source='''import Foundation
import BlindCore
final class NativeSelectionHarness {
    final class JourneyAccess {
        let connected: ConnectedJourneyRuntime
        init(_ runtime: ConnectedJourneyRuntime) { connected = runtime }
        func withConnectedJourney<T>(_ operation: @MainActor (ConnectedJourneyRuntime) throws -> T) rethrows -> T {
            try MainActor.assumeIsolated { try operation(connected) }
        }
    }
    let journeys: JourneyAccess
    let nativeLocalizationRouter: NativeLocalizationRouter
    init(runtime: ConnectedJourneyRuntime, router: NativeLocalizationRouter) {
        journeys = JourneyAccess(runtime); nativeLocalizationRouter = router
    }
    func poll() { withNativeLocalization { _ in } }
    func choosePreview() { indoorGuidanceOwner = .legacyPreview }
    func chooseJourney() { indoorGuidanceOwner = .connectedJourney }
'''+ '\n'.join(parts)+'\n}\n'
(stage/'verification/NativeSelectionHarness.swift').write_text(source)
(stage/'verification/selection-extraction.json').write_text(json.dumps({'sourceSHA256':hashlib.sha256(s.encode()).hexdigest(),'exactBodiesSHA256':[hashlib.sha256(p.encode()).hexdigest() for p in parts],'scope':'Exact owner-selection method, enum, didSet property and computed property; actual runtime/router, native container dependency only is a test fixture.'},indent=2)+'\n')
