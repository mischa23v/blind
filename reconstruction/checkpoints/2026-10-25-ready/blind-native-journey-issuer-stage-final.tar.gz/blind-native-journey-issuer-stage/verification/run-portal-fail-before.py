from pathlib import Path
import hashlib,json
stage=Path('/workspace/shared/blind-native-journey-issuer-stage');work=Path('/workspace/shared/blind-native-journey-issuer-tests')
s=(stage/'proposals/ConnectedJourneyRuntime.swift.proposed').read_text()
branch='''                } else if case .portal(_, let from, _)? = coordinator?.currentLeg, sameLocation(endpoint, from) {
                    // Evidence withdrawal discards the old departure receipt but
                    // retains intent. Only this fresh measured source endpoint
                    // can rearm it; the old departure is never restored.
                    try coordinator?.armPortal(now: now, recordedAt: Date())
'''
arm='''
                    // An itinerary can begin directly at an authored portal
                    // source. Associate the fresh source, never crossing guidance.
                    if case .portal? = coordinator?.currentLeg { try coordinator?.armPortal(now: now, recordedAt: Date()) }'''
assert s.count(branch)==1 and s.count(arm)==1
before=s.replace(branch,'').replace(arm,'')
# Removing a branch must retain the preceding block's closing brace.
before=before.replace('''                    if case .portal? = coordinator?.currentLeg { try coordinator?.armPortal(now: now, recordedAt: Date()) }
                } else if case .portal(_, _, let to)?''','''                    if case .portal? = coordinator?.currentLeg { try coordinator?.armPortal(now: now, recordedAt: Date()) }
                } else if case .portal(_, _, let to)?''')
(work/'Sources/NativeAdapter/ConnectedJourneyRuntime.swift').write_text(before)
(stage/'verification/portal-fail-before-input.json').write_text(json.dumps({'scope':'only two fresh-source rearming additions removed from staged runtime, same withdrawal implementation retained','beforeSHA256':hashlib.sha256(before.encode()).hexdigest(),'afterSHA256':hashlib.sha256(s.encode()).hexdigest()},indent=2)+'\n')
