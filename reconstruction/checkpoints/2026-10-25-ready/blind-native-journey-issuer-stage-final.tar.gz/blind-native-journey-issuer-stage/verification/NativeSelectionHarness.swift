import Foundation
import BlindCore
final class NativeSelectionHarness {
    final class JourneyAccess {
        let connected: ConnectedJourneyRuntime
        init(_ runtime: ConnectedJourneyRuntime) { connected = runtime }
        func withConnectedJourney<T>(_ operation: @MainActor (ConnectedJourneyRuntime) throws -> T) rethrows -> T {
            try MainActor.assumeIsolated { try operation(connected) }
        }
    }
    let journeys: JourneyAccess
    let nativeLocalizationRouter: NativeLocalizationRouter
    init(runtime: ConnectedJourneyRuntime, router: NativeLocalizationRouter) {
        journeys = JourneyAccess(runtime); nativeLocalizationRouter = router
    }
    func poll() { withNativeLocalization { _ in } }
    func choosePreview() { indoorGuidanceOwner = .legacyPreview }
    func chooseJourney() { indoorGuidanceOwner = .connectedJourney }
private func withNativeLocalization<T>(_ operation: @MainActor (NativeLocalizationRouter) throws -> T) rethrows -> T {
        try MainActor.assumeIsolated {
            let selected: NativeLocalizationRouter.Selection = connectedJourneyOwnsNavigation ? .connectedJourney :
                (indoorGuidanceOwner == .legacyPreview ? .registeredPreview : .none)
            nativeLocalizationRouter.select(selected)
            return try operation(nativeLocalizationRouter)
        }
    }
private enum IndoorGuidanceOwner { case none, connectedJourney, legacyPreview }
private var indoorGuidanceOwner: IndoorGuidanceOwner = .none {
        didSet {
            if oldValue != indoorGuidanceOwner { withNativeLocalization { _ in } }
        }
    }
var connectedJourneyOwnsNavigation: Bool {
        if indoorGuidanceOwner == .connectedJourney { return true }
        guard indoorGuidanceOwner == .none else { return false }
        return journeys.withConnectedJourney { $0.goal != nil || $0.question != nil }
    }
}
