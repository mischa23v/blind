from pathlib import Path
import tempfile,subprocess,hashlib,json,shutil
stage=Path('/workspace/shared/blind-native-journey-issuer-stage');base=Path('/workspace/shared/blind-rebuild')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((stage/'verification/source-input-manifest.json').read_text())
patches=['native-hookup.patch','scoped-withdrawal.patch','connected-owner.patch','xcode-membership.patch']
with tempfile.TemporaryDirectory(prefix='native-issuer-patch-',dir='/workspace/shared/blind-test-tmp') as tmp:
 root=Path(tmp)
 for path,row in manifest.items():
  if row['preimageSHA256'] is None:continue
  assert sha(base/path)==row['preimageSHA256'],path
  dest=root/path;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(base/path,dest)
 for patch in patches:
  subprocess.run(['patch','-p1','--batch'],cwd=root,input=(stage/'proposals'/patch).read_bytes(),check=True,stdout=subprocess.PIPE)
 for path,row in manifest.items():
  if row['preimageSHA256'] is None:
   dest=root/path;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(stage/row['staged'],dest)
  assert sha(root/path)==row['proposedSHA256'],path
 for patch in reversed(patches):
  subprocess.run(['patch','-R','-p1','--batch'],cwd=root,input=(stage/'proposals'/patch).read_bytes(),check=True,stdout=subprocess.PIPE)
 for path,row in manifest.items():
  if row['preimageSHA256'] is not None:assert sha(root/path)==row['preimageSHA256'],path
result={'existingSourceFiles':8,'newSourceFiles':4,'patches':4,'forwardMatchesProposed':True,'reverseMatchesLivePreimages':True,'scope':'Isolated scratch only; no live edits or artifact application.'}
(stage/'verification/patch-roundtrip.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
