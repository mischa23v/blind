import XCTest
@testable import BlindCore
@testable import NativeAdapter

/// ALL positive measurements here are SYNTHETIC plumbing fixtures, not accuracy data.
final class NativeLocalizationEvidenceTests: XCTestCase {
    let digest = String(repeating: "a", count: 64)
    let matrix: [Double] = [1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1]
    func fixture(ar: UUID = UUID(), lease: UUID = UUID(), mount: UUID = UUID(), calibration: String = "synthetic-cal-1") -> (NativeLocalizationCandidate, SpatialMapRevision) {
        let frame = SavedWorldFrame(placeID: UUID().uuidString, revision: UUID().uuidString,
            worldMapSHA256: digest, roomCaptureSHA256: digest, originAnchorID: UUID().uuidString, capturedAt: Date(timeIntervalSince1970: 1))
        let binding = SpatialMapBinding(mapID: "synthetic", frameID: frame.frameID, revision: frame.revision)
        let owner = NativeLocalizationOwner(arSession: ar, registeredSession: lease,
            artifact: .init(binding: binding, sha256: digest), descriptor: frame, calibrationRevision: calibration, mountRevision: mount)
        return (.init(owner: owner, capturedAt: 10, cameraToWorld: matrix, trackingNormal: true),
            .init(binding: binding, nodeID: "synthetic-place", metersPerUnit: 1, floorLevels: ["G":"f"], savedWorldFrame: frame))
    }
    func record(revision: String = "r", at: Double = 10, expiry: Double = 10.4, sha: String? = nil) -> NativeEvidenceRecord {
        .init(sourceID: "SYNTHETIC-only", revision: revision, sha256: sha ?? digest,
              protocolID: "synthetic-test-protocol", datasetID: "synthetic-only", observedAt: at, expiresAt: expiry)
    }
    func measurements(_ c: NativeLocalizationCandidate, missing: Int = -1,
                      supportAt: Double? = nil, expiry: Double = 10.4,
                      error: Double = 0.05, domain: String = "synthetic-domain", floor: String = "f") -> NativeLocalizationMeasurements {
        .init(candidate: c, calibration: missing == 0 ? nil : record(revision: c.owner.calibrationRevision, expiry: expiry),
            support: missing == 1 ? nil : record(at: supportAt ?? c.capturedAt, expiry: expiry),
            errorModel: missing == 2 ? nil : record(at: c.capturedAt, expiry: expiry), operatingDomainID: domain,
            floorID: floor, bodyPosition: Point3(0,1,0), bodyYaw: 0, supportHeight: 0,
            supportHeightError: 0.01, coveredFootprintSHA256: digest, totalPositionError: error, totalHeadingError: 0.01)
    }
    struct SyntheticValidator: NativeLocalizationEvidenceValidator {
        let result: NativeEvidenceValidation
        func validate(_ measurement: NativeLocalizationMeasurements) -> NativeEvidenceValidation { result }
    }
    func begin(_ c: NativeLocalizationCandidate, _ r: SpatialMapRevision) throws -> NativeLocalizationEvidenceGate {
        var gate = NativeLocalizationEvidenceGate()
        try gate.begin(c, installed: r, recovered: c.owner.descriptor, now: 10)
        return gate
    }
    func testSyntheticPairRetainsCaptureEpochTimeAndFullCameraTransform() throws {
        let (c,r) = fixture(); var gate = try begin(c,r)
        let pair = try gate.prepareForBench(measurements(c), currentOwner: c.owner,
            validator: SyntheticValidator(result: .independentlyValidated), now: 10.1)
        XCTAssertEqual(pair.capture.id, c.id); XCTAssertEqual(pair.capture.capturedAt, c.capturedAt)
        XCTAssertEqual(pair.capture.sessionID, c.owner.registeredSession)
        XCTAssertNotEqual(pair.capture.sessionID, c.owner.arSession)
        XCTAssertEqual(pair.support.captureID, c.id); XCTAssertEqual(pair.support.capturedAt, c.capturedAt)
        XCTAssertEqual(pair.expiresAt, 10.4); XCTAssertEqual(gate.reason, .physicalReleaseNotApproved)
        XCTAssertThrowsError(try gate.prepareForBench(measurements(c), currentOwner: c.owner, validator: SyntheticValidator(result: .independentlyValidated), now: 10.1))
    }
    func testMissingInputsRemainDistinct() throws {
        for (missing,reason) in [(0,NativeLocalizationNotReady.missingCalibration),(1,.missingSupport),(2,.missingErrorModel)] {
            let(c,r)=fixture(); var gate=try begin(c,r)
            XCTAssertThrowsError(try gate.prepareForBench(measurements(c,missing:missing),currentOwner:c.owner,validator:SyntheticValidator(result:.independentlyValidated),now:10)) { XCTAssertEqual($0 as? NativeLocalizationNotReady, reason) }
        }
    }
    func testUnvalidatedAndOutOfDomainNeverPass() throws {
        for (status,reason) in [(NativeEvidenceValidation.unvalidated,NativeLocalizationNotReady.unvalidatedEvidence),(.outsideDomain,.outOfDomain)] {
            let(c,r)=fixture(); var gate=try begin(c,r)
            XCTAssertThrowsError(try gate.prepareForBench(measurements(c),currentOwner:c.owner,validator:SyntheticValidator(result:status),now:10)) { XCTAssertEqual($0 as? NativeLocalizationNotReady, reason) }
        }
    }
    func testBothSessionEpochsDigestCalibrationAndMountFenceLateCompletion() throws {
        let(c,r)=fixture(); let o=c.owner
        let changes = [
            NativeLocalizationOwner(arSession:UUID(),registeredSession:o.registeredSession,artifact:o.artifact,descriptor:o.descriptor,calibrationRevision:o.calibrationRevision,mountRevision:o.mountRevision),
            .init(arSession:o.arSession,registeredSession:UUID(),artifact:o.artifact,descriptor:o.descriptor,calibrationRevision:o.calibrationRevision,mountRevision:o.mountRevision),
            .init(arSession:o.arSession,registeredSession:o.registeredSession,artifact:.init(binding:o.artifact.binding,sha256:String(repeating:"b",count:64)),descriptor:o.descriptor,calibrationRevision:o.calibrationRevision,mountRevision:o.mountRevision),
            .init(arSession:o.arSession,registeredSession:o.registeredSession,artifact:o.artifact,descriptor:o.descriptor,calibrationRevision:"new",mountRevision:o.mountRevision),
            .init(arSession:o.arSession,registeredSession:o.registeredSession,artifact:o.artifact,descriptor:o.descriptor,calibrationRevision:o.calibrationRevision,mountRevision:UUID())]
        for owner in changes {
            var gate=try begin(c,r)
            XCTAssertThrowsError(try gate.prepareForBench(measurements(c),currentOwner:owner,validator:SyntheticValidator(result:.independentlyValidated),now:10)) { XCTAssertEqual($0 as? NativeLocalizationNotReady,.ownerChanged) }
        }
    }
    func testChangedMatrixSameIDCannotReplaceOriginal() throws {
        let(c,r)=fixture(); var gate=try begin(c,r); var changed=matrix; changed[12]=3
        let replacement=NativeLocalizationCandidate(id:c.id,owner:c.owner,capturedAt:c.capturedAt,cameraToWorld:changed,trackingNormal:true)
        XCTAssertThrowsError(try gate.prepareForBench(measurements(replacement),currentOwner:c.owner,validator:SyntheticValidator(result:.independentlyValidated),now:10))
    }
    func testFreshnessReplayAndNonfiniteInput() throws {
        let(c,r)=fixture(); var gate=try begin(c,r)
        XCTAssertThrowsError(try gate.begin(c,installed:r,recovered:c.owner.descriptor,now:10))
        for t in [Double.nan,Double.infinity,9,10.6] {
            var next=NativeLocalizationEvidenceGate()
            XCTAssertThrowsError(try next.begin(c,installed:r,recovered:c.owner.descriptor,now:t))
        }
        var next=try begin(c,r)
        XCTAssertThrowsError(try next.prepareForBench(measurements(c),currentOwner:c.owner,validator:SyntheticValidator(result:.independentlyValidated),now:10.6))
    }
    func testSupportTimeBoundsAndExpiryReject() throws {
        let(c,r)=fixture()
        for m in [measurements(c,supportAt:9.9),measurements(c,expiry:9),measurements(c,error:.nan),measurements(c,error:0),measurements(c,domain:"")] {
            var gate=try begin(c,r)
            XCTAssertThrowsError(try gate.prepareForBench(m,currentOwner:c.owner,validator:SyntheticValidator(result:.independentlyValidated),now:10))
        }
    }
    func testNoSavedFrameAndWrongDescriptorNeverAssociate() throws {
        let(c,r)=fixture(); var gate=NativeLocalizationEvidenceGate()
        let imported=SpatialMapRevision(binding:r.binding,nodeID:r.nodeID,metersPerUnit:1,floorLevels:r.floorLevels)
        XCTAssertThrowsError(try gate.begin(c,installed:imported,recovered:c.owner.descriptor,now:10)) { XCTAssertEqual($0 as? NativeLocalizationNotReady,.importedFrameNeedsMeasuredRegistration) }
        XCTAssertThrowsError(try gate.begin(c,installed:r,recovered:fixture().0.owner.descriptor,now:10)) { XCTAssertEqual($0 as? NativeLocalizationNotReady,.descriptorMismatch) }
        XCTAssertThrowsError(try gate.begin(c,installed:r,recovered:nil,now:10))
    }
    func testRestartAndSlipRetirePendingImmediately() throws {
        let(c,r)=fixture(); let issuer=NativeLocalizationIssuer(); var retired=0
        issuer.retireRegisteredOutput={ _ in retired += 1}
        issuer.offer(c,installed:r,recovered:c.owner.descriptor,now:10)
        XCTAssertNotNil(issuer.candidate)
        issuer.invalidate(.mountSlip)
        XCTAssertNil(issuer.candidate); XCTAssertEqual(retired,2)
        XCTAssertThrowsError(try issuer.prepareForBench(measurements(c),currentOwner:c.owner,validator:SyntheticValidator(result:.independentlyValidated),now:10))
        let restart=NativeLocalizationIssuer(); XCTAssertNil(restart.candidate)
    }
    func testNativeWatchdogRetiresWithoutAnotherFrame() {
        let(c,r)=fixture(); let issuer=NativeLocalizationIssuer(); var retired=0
        issuer.retireRegisteredOutput={ _ in retired += 1}
        issuer.offer(c,installed:r,recovered:c.owner.descriptor,now:10)
        issuer.watchdog(currentOwner:c.owner,now:10.6)
        XCTAssertNil(issuer.candidate); XCTAssertEqual(issuer.reason,.staleCandidate); XCTAssertEqual(retired,2)
    }
    func testSyntheticNativeSuccessStillCannotAuthorizeMotion() throws {
        let(c,r)=fixture(); let issuer=NativeLocalizationIssuer(); var retired=0
        issuer.retireRegisteredOutput={ _ in retired += 1}
        issuer.offer(c,installed:r,recovered:c.owner.descriptor,now:10)
        _ = try issuer.prepareForBench(measurements(c),currentOwner:c.owner,validator:SyntheticValidator(result:.independentlyValidated),now:10)
        XCTAssertEqual(issuer.reason,.physicalReleaseNotApproved); XCTAssertNil(issuer.candidate); XCTAssertEqual(retired,2)
    }
    func testEmptyIssuerInvalidationIsIdempotentAndDoesNotRetireUnownedPreview() {
        let issuer=NativeLocalizationIssuer(); var previewRoute=["entrance","exit"]
        issuer.retireRegisteredOutput={ _ in previewRoute=[]}
        issuer.invalidate(.noInstallation); issuer.invalidate(.noRecoveredWorldFrame)
        XCTAssertEqual(previewRoute,["entrance","exit"])
    }

    func testExactNativeMountSetterRotatesEpochAndRetiresSpatialOnly() {
        let mount=NativeMountHarness(); let original=mount.nativeLocalizationMount
        mount.fixedBodyMount=true
        XCTAssertNotEqual(mount.nativeLocalizationMount,original)
        XCTAssertEqual(mount.nativeLocalizationIssuer.reason,.mountChanged)
        XCTAssertEqual(mount.indoor.count,1); XCTAssertEqual(mount.spatialRouteOutput.count,1)
        let fixed=mount.nativeLocalizationMount
        mount.mountSlipAnnounced=true; mount.fixedBodyMount=false
        XCTAssertNotEqual(mount.nativeLocalizationMount,fixed)
        XCTAssertEqual(mount.nativeLocalizationIssuer.reason,.mountSlip)
        let slipped=mount.nativeLocalizationMount; mount.fixedBodyMount=false
        XCTAssertEqual(mount.nativeLocalizationMount,slipped)
    }

    func testDiagnosticInvalidationAndBenchConsumptionCannotResetFrameHighWater() throws {
        let(c,r)=fixture();let issuer=NativeLocalizationIssuer()
        issuer.offer(c,installed:r,recovered:c.owner.descriptor,now:10)
        issuer.offer(c,installed:r,recovered:c.owner.descriptor,now:10)
        XCTAssertEqual(issuer.reason,.replayedCandidate)
        issuer.offer(c,installed:r,recovered:c.owner.descriptor,now:10)
        XCTAssertNil(issuer.candidate);XCTAssertEqual(issuer.reason,.replayedCandidate)
        let next=NativeLocalizationIssuer()
        next.offer(c,installed:r,recovered:c.owner.descriptor,now:10)
        _ = try next.prepareForBench(measurements(c),currentOwner:c.owner,validator:SyntheticValidator(result:.independentlyValidated),now:10)
        next.offer(c,installed:r,recovered:c.owner.descriptor,now:10)
        XCTAssertNil(next.candidate);XCTAssertEqual(next.reason,.replayedCandidate)
    }

}
