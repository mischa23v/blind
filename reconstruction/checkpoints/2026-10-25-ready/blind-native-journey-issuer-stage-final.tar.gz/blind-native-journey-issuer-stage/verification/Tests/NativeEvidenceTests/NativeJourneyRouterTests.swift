import Foundation
import XCTest
@testable import BlindCore
@testable import NativeAdapter

private actor CandidateRuntimeIO: ConnectedJourneyRuntimeIO {
    var data: Data?
    func read() -> Data? { data }
    func write(_ payload: JourneyRuntimeWrite) throws { data = try payload.envelope().encoded() }
}

/// Entirely SYNTHETIC setup, except the actual runtime/coordinator/registered code.
/// This never establishes camera/body calibration or measured device accuracy.
@MainActor final class NativeJourneyRouterTests: XCTestCase {
    typealias F=SpatialIntegrationFixture
    struct Environment {
        let runtime:ConnectedJourneyRuntime
        let preview:RegisteredIndoorNavigation
        let router:NativeLocalizationRouter
        let installation:SpatialMapInstallation
        let descriptor:SavedWorldFrame
        let directory:URL
        let arSession=UUID(), mount=UUID()
    }
    func until(_ predicate: @escaping @MainActor () -> Bool) async throws {
        for _ in 0..<3000 { if predicate(){return};try await Task.sleep(nanoseconds:1_000_000) }
        XCTFail("Timed out waiting for bounded actual runtime");throw JourneyRuntimeError.loading
    }
    func environment(configure:Bool=true) async throws -> Environment {
        let record=NativeLocalizationEvidenceTests(name:"synthetic",testClosure:{_ in}).fixture().0.owner.descriptor
        let binding=SpatialMapBinding(mapID:"fixture-map",frameID:record.frameID,revision:record.revision)
        let revision=SpatialMapRevision(binding:binding,nodeID:"building",metersPerUnit:1,floorLevels:["ground":"floor"],savedWorldFrame:record)
        let bytes=try SpatialMapInstallation.canonicalMapBytes(F.map(revision:record.revision))
        let installation=try SpatialMapInstallation(envelope:.init(snapshot:.init(nodes:F.nodes,maps:[revision],activeBindings:[binding]),binding:binding,mapBytes:bytes,artifactHistory:[.init(binding:binding,sha256:try F.sha256(bytes))]),sha256:F.sha256)
        let runtime=ConnectedJourneyRuntime(io:CandidateRuntimeIO(),sha256:F.sha256)
        runtime.restore();try await until{!runtime.loading}
        try runtime.install(installation);try await until{runtime.pendingMapWorkCount==0 && runtime.pendingWriteCount==0}
        if configure {try runtime.configure(body:F.body,limits:F.limits)}
        try runtime.setDestination(binding:binding,nodeID:"end",origin:.trustedInterface)
        try await until{runtime.pendingWriteCount==0}
        if configure {_ = try runtime.beginLocalization(in:binding)}
        let directory=URL(fileURLWithPath:ProcessInfo.processInfo.environment["TMPDIR"]!).appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at:directory,withIntermediateDirectories:true)
        let preview=RegisteredIndoorNavigation(storage:directory.appendingPathComponent("synthetic.json"),sha256:F.sha256)
        var loaded=false;var failure:Error?
        preview.install(try installation.encoded()){result in if case .failure(let error)=result {failure=error};loaded=true}
        try await until{loaded};if let failure{throw failure}
        try preview.configure(body:F.body,limits:F.limits);try preview.plan(from:"start",to:"end",goal:UUID())
        let previewCapture=capture(session:try XCTUnwrap(preview.sessionID),binding:binding,time:10)
        try preview.accept(previewCapture,floorSupport:F.support(previewCapture),now:10)
        let router=NativeLocalizationRouter(journey:runtime,previewContext:{
            guard let session=preview.sessionID,let map=preview.installation,
                  let revision=try? map.registry.map(for:map.binding) else{return nil}
            return .init(sessionID:session,artifact:map.artifact,revision:revision,goalRevision:nil)
        },withholdPreview:{session,artifact in preview.withholdNativeEvidence(session:session,artifact:artifact)})
        let result=Environment(runtime:runtime,preview:preview,router:router,installation:installation,descriptor:record,directory:directory)
        if configure {
            let value=capture(session:runtime.expectedSessionID!,binding:binding,time:10)
            try runtime.accept(value,support:F.support(value),now:10)
        }
        return result
    }
    func capture(id:UUID=UUID(),session:UUID,binding:SpatialMapBinding,time:Double)->SpatialLocalizationCapture {
        .init(id:id,sessionID:session,binding:binding,floorID:"floor",position:Point3(1,1.3,3),bodyYaw: -.pi/2,
            source:.alignedMapPose,headingSource:.bodyAligned,trackingNormal:true,positionUncertainty:0.05,headingUncertainty:0.05,capturedAt:time)
    }
    func accept(_ e:Environment,time:Double,id:UUID=UUID()) throws {
        let value=capture(id:id,session:try XCTUnwrap(e.runtime.expectedSessionID),binding:e.installation.binding,time:time)
        try e.runtime.accept(value,support:F.support(value),now:time)
    }
    func offer(_ e:Environment,time:Double) {
        e.router.offer(arSession:e.arSession,calibrationRevision:"synthetic-cal-1",mountRevision:e.mount,
            capturedAt:time,cameraToWorld:[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],trackingNormal:true,recovered:e.descriptor,now:time)
    }
    func owner(_ e:Environment)->NativeLocalizationOwner? {
        e.router.currentOwner(arSession:e.arSession,calibrationRevision:"synthetic-cal-1",mountRevision:e.mount)
    }
    func ready() async throws -> Environment {
        let e=try await environment();try await until{e.runtime.pendingWriteCount==0}
        try accept(e,time:10.1);return e
    }
    func testSelectedJourneyMissingEvidenceWithdrawsOnlyJourneyAndDoesNotStorm() async throws {
        let e=try await ready();defer{try? FileManager.default.removeItem(at:e.directory)}
        let ticket=try e.runtime.next(now:10.1),previewPose=e.preview.currentPose(now:10.1)?.id
        let snapshot=e.runtime.snapshot,session=e.runtime.expectedSessionID
        var retired=0,changed=0;e.runtime.onOutputRetired={retired += 1};e.runtime.onChange={changed += 1}
        e.router.select(.connectedJourney);offer(e,time:10.2)
        let candidate=try XCTUnwrap(e.router.candidate)
        XCTAssertEqual(candidate.owner.registeredSession,session);XCTAssertNotEqual(candidate.owner.registeredSession,e.preview.sessionID)
        XCTAssertEqual(candidate.owner.selection.kind,.connectedJourney);XCTAssertEqual(candidate.owner.selection.goalRevision,e.runtime.goal?.revision)
        XCTAssertEqual(e.router.reason,.missingCalibration);XCTAssertFalse(e.runtime.permits(ticket.route,now:10.2))
        XCTAssertEqual(e.preview.currentPose(now:10.2)?.id,previewPose)
        XCTAssertEqual(e.runtime.snapshot,snapshot);XCTAssertEqual(e.runtime.expectedSessionID,session)
        XCTAssertThrowsError(try e.runtime.saveReference(origin:.trustedInterface,now:10.2));XCTAssertTrue(e.runtime.durable)
        for i in 1...100{offer(e,time:10.2+Double(i)/1000)}
        XCTAssertEqual(retired,1);XCTAssertEqual(changed,1)
        e.router.invalidate(.trackingUnavailable);e.router.invalidate(.trackingUnavailable)
        XCTAssertEqual(retired,1);XCTAssertEqual(changed,1);XCTAssertEqual(e.preview.currentPose(now:10.3)?.id,previewPose)
        // Exact session's accepted capture high-water survives withdrawal.
        XCTAssertThrowsError(try accept(e,time:10.1))
    }
    func testUnconfiguredSelectedJourneyNeverFallsBackToReadyPreview() async throws {
        let e=try await environment(configure:false);defer{try? FileManager.default.removeItem(at:e.directory)}
        let preview=e.preview.currentPose(now:10)?.id
        e.router.select(.connectedJourney)
        for _ in 0..<10{offer(e,time:10.2);e.router.invalidate(.noConfiguredSession)}
        XCTAssertNil(e.router.candidate);XCTAssertNil(owner(e));XCTAssertEqual(e.preview.currentPose(now:10.2)?.id,preview)
        XCTAssertNil(e.runtime.expectedSessionID);XCTAssertThrowsError(try e.runtime.next(now:10.2))
    }
    func testExactRuntimeSessionDigestAndGoalCASPreservesNewerEvidenceAndEndpoint() async throws {
        let e=try await ready();defer{try? FileManager.default.removeItem(at:e.directory)}
        let context=try XCTUnwrap(e.runtime.nativeLocalizationContext),ticket=try e.runtime.next(now:10.1)
        var changed=0;e.runtime.onChange={changed += 1}
        XCTAssertFalse(e.runtime.withholdNativeEvidence(session:UUID(),artifact:context.artifact,goalRevision:context.goalRevision!))
        XCTAssertFalse(e.runtime.withholdNativeEvidence(session:context.sessionID,artifact:.init(binding:context.artifact.binding,sha256:String(repeating:"b",count:64)),goalRevision:context.goalRevision!))
        XCTAssertFalse(e.runtime.withholdNativeEvidence(session:context.sessionID,artifact:context.artifact,goalRevision:UUID()))
        XCTAssertTrue(e.runtime.permits(ticket.route,now:10.1));XCTAssertEqual(changed,0)
        XCTAssertNoThrow(try e.runtime.saveReference(origin:.trustedInterface,now:10.1)) // rejected CAS did not clear endpoint
        try await until{e.runtime.pendingWriteCount==0}
        XCTAssertTrue(e.runtime.withholdNativeEvidence(session:context.sessionID,artifact:context.artifact,goalRevision:context.goalRevision!))
        XCTAssertFalse(e.runtime.withholdNativeEvidence(session:context.sessionID,artifact:context.artifact,goalRevision:context.goalRevision!))
        XCTAssertThrowsError(try e.runtime.saveReference(origin:.trustedInterface,now:10.1));XCTAssertTrue(e.runtime.durable)
    }
    func testLateSameOwnerCompletionAndGoalChangeCannotConsumeB() async throws {
        let e=try await ready();defer{try? FileManager.default.removeItem(at:e.directory)}
        e.router.select(.connectedJourney);offer(e,time:10.2);let a=try XCTUnwrap(e.router.candidate)
        offer(e,time:10.3);let b=try XCTUnwrap(e.router.candidate);try accept(e,time:10.3,id:b.id)
        let ticket=try e.runtime.next(now:10.3)
        let helper=NativeLocalizationEvidenceTests(name:"synthetic",testClosure:{_ in})
        let validator=NativeLocalizationEvidenceTests.SyntheticValidator(result:.independentlyValidated)
        XCTAssertThrowsError(try e.router.prepareForBench(helper.measurements(a,floor:"floor"),arSession:e.arSession,calibrationRevision:"synthetic-cal-1",mountRevision:e.mount,validator:validator,now:10.3))
        XCTAssertEqual(e.router.candidate,b);XCTAssertTrue(e.runtime.permits(ticket.route,now:10.3))
        let pair=try e.router.prepareForBench(helper.measurements(b,floor:"floor"),arSession:e.arSession,calibrationRevision:"synthetic-cal-1",mountRevision:e.mount,validator:validator,now:10.3)
        XCTAssertEqual(pair.owner,b.owner);XCTAssertEqual(pair.owner.selection.kind,.connectedJourney)
        XCTAssertFalse(e.runtime.permits(ticket.route,now:10.3));XCTAssertEqual(e.router.reason,.physicalReleaseNotApproved)
        // New goal within unchanged localization session is a distinct owner.
        let old=b.owner
        try e.runtime.setDestination(binding:e.installation.binding,nodeID:"middle",origin:.trustedInterface)
        try await until{e.runtime.pendingWriteCount==0};try accept(e,time:10.35)
        let current=try XCTUnwrap(e.runtime.nativeLocalizationContext)
        XCTAssertNotEqual(current.goalRevision,old.selection.goalRevision)
        XCTAssertFalse(e.runtime.withholdNativeEvidence(session:old.registeredSession,artifact:old.artifact,goalRevision:old.selection.goalRevision!))
        offer(e,time:10.36);let c=try XCTUnwrap(e.router.candidate);try accept(e,time:10.36,id:c.id)
        let newGoalTicket=try e.runtime.next(now:10.36)
        XCTAssertThrowsError(try e.router.prepareForBench(helper.measurements(a,floor:"floor"),arSession:e.arSession,calibrationRevision:"synthetic-cal-1",mountRevision:e.mount,validator:validator,now:10.36))
        XCTAssertEqual(e.router.candidate,c);XCTAssertTrue(e.runtime.permits(newGoalTicket.route,now:10.36))
        XCTAssertNoThrow(try e.runtime.saveReference(origin:.trustedInterface,now:10.36))
    }
    func testOwnerSwitchAndReturnRotatesSelectionNotLocalizationSession() async throws {
        let e=try await ready();defer{try? FileManager.default.removeItem(at:e.directory)}
        e.router.select(.connectedJourney);offer(e,time:10.2);let a=try XCTUnwrap(e.router.candidate)
        e.router.select(.registeredPreview);offer(e,time:10.25);let b=try XCTUnwrap(e.router.candidate)
        XCTAssertEqual(b.owner.registeredSession,e.preview.sessionID);XCTAssertEqual(b.owner.selection.kind,.registeredPreview)
        XCTAssertNotEqual(a.owner.selection.epoch,b.owner.selection.epoch)
        let previewCapture=capture(id:b.id,session:b.owner.registeredSession,binding:b.owner.artifact.binding,time:10.25)
        try e.preview.accept(previewCapture,floorSupport:F.support(previewCapture),now:10.25)
        let helper=NativeLocalizationEvidenceTests(name:"synthetic",testClosure:{_ in})
        let validator=NativeLocalizationEvidenceTests.SyntheticValidator(result:.independentlyValidated)
        XCTAssertThrowsError(try e.router.prepareForBench(helper.measurements(a,floor:"floor"),arSession:e.arSession,calibrationRevision:"synthetic-cal-1",mountRevision:e.mount,validator:validator,now:10.25))
        XCTAssertEqual(e.preview.currentPose(now:10.25)?.id,b.id);XCTAssertEqual(e.router.candidate,b)
        e.router.select(.connectedJourney);offer(e,time:10.3);let c=try XCTUnwrap(e.router.candidate)
        XCTAssertEqual(c.owner.registeredSession,a.owner.registeredSession);XCTAssertNotEqual(c.owner.selection.epoch,a.owner.selection.epoch)
        XCTAssertThrowsError(try e.router.prepareForBench(helper.measurements(a,floor:"floor"),arSession:e.arSession,calibrationRevision:"synthetic-cal-1",mountRevision:e.mount,validator:validator,now:10.3))
        XCTAssertEqual(e.router.candidate,c)
    }
    func testExactNativeSelectionMethodsSelectJourneyAndRespectExplicitPreview() async throws {
        let e=try await ready();defer{try? FileManager.default.removeItem(at:e.directory)}
        let selection=NativeSelectionHarness(runtime:e.runtime,router:e.router)
        selection.poll();XCTAssertEqual(e.router.selection,.connectedJourney)
        offer(e,time:10.2);let a=try XCTUnwrap(e.router.candidate)
        selection.choosePreview();XCTAssertEqual(e.router.selection,.registeredPreview)
        offer(e,time:10.25);XCTAssertEqual(e.router.candidate?.owner.registeredSession,e.preview.sessionID)
        selection.chooseJourney();XCTAssertEqual(e.router.selection,.connectedJourney)
        offer(e,time:10.3);XCTAssertEqual(e.router.candidate?.owner.registeredSession,e.runtime.expectedSessionID)
        XCTAssertNotEqual(e.router.candidate?.owner.selection.epoch,a.owner.selection.epoch)
    }
    func testOldSessionWatchdogCannotWithdrawNewJourneyPoseEndpointOrOutput() async throws {
        let e=try await ready();defer{try? FileManager.default.removeItem(at:e.directory)}
        e.router.select(.connectedJourney);offer(e,time:10.2);let a=try XCTUnwrap(e.router.candidate)
        e.runtime.cameraRestarted();XCTAssertNotEqual(e.runtime.expectedSessionID,a.owner.registeredSession)
        try accept(e,time:10.3);let ticket=try e.runtime.next(now:10.3)
        var retired=0,changed=0;e.runtime.onOutputRetired={retired += 1};e.runtime.onChange={changed += 1}
        e.router.watchdog(arSession:UUID(),calibrationRevision:"synthetic-cal-1",mountRevision:e.mount,now:10.3)
        XCTAssertNil(e.router.candidate);XCTAssertEqual(e.router.reason,.ownerChanged)
        XCTAssertTrue(e.runtime.permits(ticket.route,now:10.3));XCTAssertEqual(retired,0);XCTAssertEqual(changed,0)
        XCTAssertNoThrow(try e.runtime.saveReference(origin:.trustedInterface,now:10.3))
    }

    func testFirstMissingRecoveryAndExplicitLossWithdrawCurrentOwnerWithoutCandidate() async throws {
        let e=try await ready();defer{try? FileManager.default.removeItem(at:e.directory)}
        let old=try e.runtime.next(now:10.1),preview=e.preview.currentPose(now:10.1)?.id
        e.router.select(.connectedJourney);XCTAssertNil(e.router.candidate)
        var retired=0;e.runtime.onOutputRetired={retired += 1}
        e.router.offer(arSession:e.arSession,calibrationRevision:"synthetic-cal-1",mountRevision:e.mount,capturedAt:10.2,cameraToWorld:[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],trackingNormal:true,recovered:nil,now:10.2)
        XCTAssertNil(e.router.candidate);XCTAssertEqual(e.router.reason,.noRecoveredWorldFrame)
        XCTAssertFalse(e.runtime.permits(old.route,now:10.2));XCTAssertEqual(retired,1)
        XCTAssertThrowsError(try e.runtime.saveReference(origin:.trustedInterface,now:10.2));XCTAssertTrue(e.runtime.durable)
        XCTAssertEqual(e.preview.currentPose(now:10.2)?.id,preview)
        try accept(e,time:10.3);let fresh=try e.runtime.next(now:10.3)
        e.router.invalidate(.trackingUnavailable);e.router.invalidate(.trackingUnavailable)
        XCTAssertFalse(e.runtime.permits(fresh.route,now:10.3));XCTAssertEqual(retired,3) // accept retires old output once; explicit loss once.
        XCTAssertEqual(e.preview.currentPose(now:10.3)?.id,preview)
    }

}
