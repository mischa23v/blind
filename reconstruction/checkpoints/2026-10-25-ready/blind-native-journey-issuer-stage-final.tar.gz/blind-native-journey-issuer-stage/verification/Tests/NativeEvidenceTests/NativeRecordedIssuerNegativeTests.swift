import XCTest
@testable import BlindCore
@testable import NativeAdapter

final class NativeRecordedIssuerNegativeTests: XCTestCase {
    struct Input: Decodable {
        struct Expected: Decodable { let index: Int; let point: Point3 }
        let capturedAt, poseCapturedAt: Double
        let sourceID, poseSourceID: String
        let worldToCamera: NativeCameraTransform
        let intrinsics: NativeCameraIntrinsics
        let depth: NativeDepthObservation
        let expectedCameraPosition: Point3
        let expectedPoints: [Expected]
    }
    func testAll100RealRecordedFramesWithholdAuthorityAndRetainHistory() throws {
        let path = try XCTUnwrap(ProcessInfo.processInfo.environment["NATIVE_RECORDED_FIXTURE"], "Explicit local public-fixture input required; not silently skipped")
        let inputs = try JSONDecoder().decode([Input].self,from:Data(contentsOf:URL(fileURLWithPath:path)))
        XCTAssertEqual(inputs.count,100)
        let session=UUID(); var history=NativeObservationHistory(); let issuer=NativeLocalizationIssuer()
        // A synthetic owner only lets the test attempt the boundary. It is NOT
        // claimed to be recorded calibration/map evidence; installed/recovered are nil.
        let synthetic=NativeLocalizationEvidenceTests(name: "synthetic-owner", testClosure: { _ in }).fixture().0.owner
        var withheld=0, comparisons=0
        for input in inputs {
            let pinholePose=try input.worldToCamera.inverted()
            XCTAssertLessThan(try pinholePose.applying(to:Point3(0,0,0)).distance(to:input.expectedCameraPosition),1e-9)
            let record=NativeObservationRecord(sessionID:session,coordinateFrameID:"recorded-arkitscenes:47333462",
                producer:.arkitScenesRecorded,sourceID:input.sourceID,capturedAt:input.capturedAt,
                poseCapturedAt:input.poseCapturedAt,poseSourceID:input.poseSourceID,receivedAt:nil,observedAt:nil,
                tracking:.notRecorded,cameraConvention:.pinholeRightDownForward,cameraToSessionWorld:pinholePose,
                intrinsics:input.intrinsics,depth:input.depth,omitted:["wearerCalibrationNotRecorded","supportGroundTruthNotRecorded"])
            try record.validate(); try history.append(record)
            let points=try input.depth.worldPoints(intrinsics:input.intrinsics,cameraToWorld:pinholePose,convention:.pinholeRightDownForward)
            for expected in input.expectedPoints {
                XCTAssertLessThan(points[expected.index].distance(to:expected.point),1e-8); comparisons += 1
            }
            // Explicit pinhole-to-ARKit basis conversion: C_AR = C_pinhole * diag(1,-1,-1,1).
            // Recorded uptime remains recorded time; no device-now authority is implied.
            var arColumns=pinholePose.columns
            for i in 4..<12 { arColumns[i] = -arColumns[i] }
            issuer.offer(.init(owner:synthetic,capturedAt:input.capturedAt,cameraToWorld:arColumns,trackingNormal:false),
                installed:nil,recovered:nil,now:input.capturedAt)
            XCTAssertNil(issuer.candidate); XCTAssertEqual(issuer.reason,.noInstallation); withheld += 1
            XCTAssertTrue(record.isHistoryOnly); XCTAssertNil(record.mapTarget)
        }
        XCTAssertEqual(withheld,100); XCTAssertEqual(comparisons,300)
        XCTAssertFalse(history.records.isEmpty)
        XCTAssertEqual(history.records.count + history.evictedRecordCount,100)
        XCTAssertLessThanOrEqual(history.payloadByteCount,NativeObservationHistory.maximumBytes)
        let encoded=try JSONEncoder().encode(history)
        let restored=try JSONDecoder().decode(NativeObservationHistory.self,from:encoded)
        XCTAssertEqual(restored,history)
        XCTAssertTrue(restored.records.allSatisfy(\.isHistoryOnly))
        print("Recorded negative replay: 100/100 withheld, \(restored.records.count) retained history records round-tripped, \(restored.evictedRecordCount) bounded evictions, 300 depth projection comparisons; no wearer/support/calibration truth.")
    }
}
