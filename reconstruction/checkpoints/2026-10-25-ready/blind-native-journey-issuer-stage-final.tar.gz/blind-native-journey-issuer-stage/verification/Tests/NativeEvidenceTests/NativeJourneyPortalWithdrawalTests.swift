import Foundation
import XCTest
@testable import BlindCore
@testable import NativeAdapter

private actor PortalRuntimeIO:ConnectedJourneyRuntimeIO {
    func read()->Data?{nil}
    func write(_ payload:JourneyRuntimeWrite)throws{_ = try payload.envelope().encoded()}
}
@MainActor final class NativeJourneyPortalWithdrawalTests:XCTestCase {
    typealias F=ConnectedFixture
    func until(_ predicate:@escaping @MainActor()->Bool)async throws{
        for _ in 0..<3000{if predicate(){return};try await Task.sleep(nanoseconds:1_000_000)}
        XCTFail("Actual portal runtime did not settle");throw JourneyRuntimeError.loading
    }
    func setup(startAtPortal:Bool=false)async throws->ConnectedJourneyRuntime{
        let runtime=ConnectedJourneyRuntime(io:PortalRuntimeIO(),sha256:F.sha256)
        runtime.restore();try await until{!runtime.loading}
        let catalog=try F.catalog()
        for installation in catalog.installations.values{try runtime.install(installation,portals:catalog.portals)}
        try await until{runtime.pendingMapWorkCount==0 && runtime.pendingWriteCount==0}
        try runtime.configure(body:F.body,limits:F.limits)
        try runtime.setDestination(binding:F.b,nodeID:"p",origin:.trustedInterface)
        try await until{runtime.pendingWriteCount==0}
        _ = try runtime.beginLocalization(in:F.a)
        _ = try observe(runtime,F.endpoint(F.a,startAtPortal ? "p":"s"),time:1)
        try await until{runtime.pendingWriteCount==0}
        return runtime
    }
    @discardableResult func observe(_ runtime:ConnectedJourneyRuntime,_ endpoint:JourneyEndpoint,time:Double)throws->UUID{
        let position=try F.catalog().node(endpoint).position
        let capture=SpatialLocalizationCapture(sessionID:try XCTUnwrap(runtime.expectedSessionID),binding:endpoint.binding,floorID:endpoint.floorID,roomID:endpoint.roomID,position:.init(position.x,1.3,position.z),bodyYaw: -.pi/2,source:.alignedMapPose,headingSource:.bodyAligned,trackingNormal:true,positionUncertainty:0.05,headingUncertainty:0.05,capturedAt:time)
        try runtime.accept(capture,support:SpatialIntegrationFixture.support(capture),now:time)
        return capture.id
    }
    func reachSource(_ runtime:ConnectedJourneyRuntime)async throws->UUID{
        _ = try observe(runtime,F.endpoint(F.a,"s"),time:1.1)
        _ = try observe(runtime,F.endpoint(F.a,"m"),time:1.2)
        let id=try observe(runtime,F.endpoint(F.a,"p"),time:1.3)
        try await until{runtime.pendingWriteCount==0}
        return id
    }
    func testFreshSourceRearmsAfterWithdrawalWithoutReusingOldDeparture()async throws{
        let runtime=try await setup();let old=try await reachSource(runtime)
        let context=try XCTUnwrap(runtime.nativeLocalizationContext),goal=runtime.goal?.revision
        XCTAssertTrue(runtime.withholdNativeEvidence(session:context.sessionID,artifact:context.artifact,goalRevision:context.goalRevision!))
        XCTAssertEqual(runtime.goal?.revision,goal);XCTAssertThrowsError(try runtime.next(now:1.3))
        let fresh=try observe(runtime,F.endpoint(F.a,"p"),time:1.4);XCTAssertNotEqual(fresh,old)
        _ = try runtime.beginLocalization(in:F.b)
        _ = try observe(runtime,F.endpoint(F.b,"s"),time:1.5)
        let event=try XCTUnwrap(runtime.snapshot.events.last{$0.kind == .portalEndpointsAssociated})
        XCTAssertEqual(event.portalDepartureCaptureID,fresh);XCTAssertNotEqual(event.portalDepartureCaptureID,old)
        XCTAssertEqual(runtime.goal?.revision,goal)
    }
    func testWithheldDepartureCannotBeReusedByDirectDestination()async throws{
        let runtime=try await setup();_ = try await reachSource(runtime)
        let context=try XCTUnwrap(runtime.nativeLocalizationContext)
        XCTAssertTrue(runtime.withholdNativeEvidence(session:context.sessionID,artifact:context.artifact,goalRevision:context.goalRevision!))
        _ = try runtime.beginLocalization(in:F.b)
        XCTAssertThrowsError(try observe(runtime,F.endpoint(F.b,"s"),time:1.5))
        XCTAssertTrue(runtime.snapshot.events.filter{$0.kind == .portalEndpointsAssociated}.isEmpty)
    }
    func testInitialPlanAtPortalSourceArmsOnlyFreshSource()async throws{
        let runtime=try await setup(startAtPortal:true)
        let departure=try observe(runtime,F.endpoint(F.a,"p"),time:1.1)
        XCTAssertThrowsError(try runtime.next(now:1.1)) // No crossing instructions.
        _ = try runtime.beginLocalization(in:F.b)
        _ = try observe(runtime,F.endpoint(F.b,"s"),time:1.2)
        let event=try XCTUnwrap(runtime.snapshot.events.last{$0.kind == .portalEndpointsAssociated})
        XCTAssertEqual(event.portalDepartureCaptureID,departure)
    }
    func testRepeatedSourceTimestampCannotRenewPortalDepartureReceipt()async throws{
        let runtime=try await setup(startAtPortal:true)
        _ = try observe(runtime,F.endpoint(F.a,"p"),time:1.1)
        let oldSession=runtime.expectedSessionID
        XCTAssertThrowsError(try observe(runtime,F.endpoint(F.a,"p"),time:1.1))
        XCTAssertNotEqual(runtime.expectedSessionID,oldSession)
        _ = try runtime.beginLocalization(in:F.b)
        _ = try observe(runtime,F.endpoint(F.b,"s"),time:1.2)
        XCTAssertTrue(runtime.snapshot.events.filter{$0.kind == .portalEndpointsAssociated}.isEmpty)
    }

}
