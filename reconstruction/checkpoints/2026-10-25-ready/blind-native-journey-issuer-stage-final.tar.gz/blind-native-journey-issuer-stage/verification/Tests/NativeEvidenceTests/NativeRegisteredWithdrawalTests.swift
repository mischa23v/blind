import Foundation
import XCTest
@testable import BlindCore
@testable import NativeAdapter

final class NativeRegisteredWithdrawalTests: XCTestCase {
    typealias F=SpatialIntegrationFixture
    func prepared() throws -> (RegisteredIndoorNavigation,NativeLocalizationCandidate,SpatialMapRevision,URL) {
        let synthetic=NativeLocalizationEvidenceTests(name:"fixture",testClosure:{_ in}).fixture()
        let binding=SpatialMapBinding(mapID:"fixture-map",frameID:synthetic.0.owner.descriptor.frameID,revision:synthetic.0.owner.descriptor.revision)
        let revision=SpatialMapRevision(binding:binding,nodeID:"building",metersPerUnit:1,floorLevels:["ground":"floor"],savedWorldFrame:synthetic.0.owner.descriptor)
        let bytes=try SpatialMapInstallation.canonicalMapBytes(F.map(revision:synthetic.0.owner.descriptor.revision))
        let artifact=SpatialMapArtifactIdentity(binding:binding,sha256:try F.sha256(bytes))
        let installation=try SpatialMapInstallation(envelope:.init(snapshot:.init(nodes:F.nodes,maps:[revision],activeBindings:[binding]),binding:binding,mapBytes:bytes,artifactHistory:[artifact]),sha256:F.sha256)
        let directory=URL(fileURLWithPath:ProcessInfo.processInfo.environment["TMPDIR"]!).appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at:directory,withIntermediateDirectories:true)
        let nav=RegisteredIndoorNavigation(storage:directory.appendingPathComponent("map.json"),sha256:F.sha256)
        let done=expectation(description:"real async install"); var failure:Error?
        nav.install(try installation.encoded()) { result in if case .failure(let e)=result {failure=e};done.fulfill() }
        wait(for:[done],timeout:15); if let failure {throw failure}
        try nav.configure(body:F.body,limits:F.limits)
        let session=try XCTUnwrap(nav.sessionID)
        let owner=NativeLocalizationOwner(arSession:UUID(),registeredSession:session,artifact:artifact,descriptor:synthetic.0.owner.descriptor,calibrationRevision:"synthetic-cal-1",mountRevision:UUID())
        let c=NativeLocalizationCandidate(owner:owner,capturedAt:10.1,cameraToWorld:synthetic.0.cameraToWorld,trackingNormal:true)
        try nav.plan(from:"start",to:"end",goal:UUID())
        let capture=SpatialLocalizationCapture(sessionID:session,binding:binding,floorID:"floor",position:Point3(1,1.3,3),bodyYaw: -.pi/2,source:.alignedMapPose,headingSource:.bodyAligned,trackingNormal:true,positionUncertainty:0.1,headingUncertainty:0.1,capturedAt:10)
        try nav.accept(capture,floorSupport:F.support(capture),now:10)
        return (nav,c,revision,directory)
    }
    func testActualNativeOfferWithdrawsPoseAndTicketWithoutSelfStalingOrLosingRoute() throws {
        let(nav,c,r,path)=try prepared();defer{try? FileManager.default.removeItem(at:path)}
        let ticket=try nav.next(now:10), session=nav.sessionID, route=nav.route.map(\.id)
        let issuer=NativeLocalizationIssuer()
        issuer.retireRegisteredOutput={ owner in nav.withholdNativeEvidence(session:owner.registeredSession,artifact:owner.artifact) }
        issuer.offer(c,installed:r,recovered:c.owner.descriptor,now:10.1)
        XCTAssertEqual(nav.sessionID,session);XCTAssertEqual(nav.route.map(\.id),route)
        XCTAssertNil(nav.currentPose(now:10.1));XCTAssertFalse(nav.permits(ticket,now:10.1))
        XCTAssertEqual(issuer.candidate?.owner.registeredSession,nav.sessionID)
        // Replay ledger was not reset by withholding.
        let duplicate=SpatialLocalizationCapture(sessionID:session!,binding:c.owner.artifact.binding,floorID:"floor",position:Point3(1,1.3,3),bodyYaw:0,source:.alignedMapPose,headingSource:.bodyAligned,trackingNormal:true,positionUncertainty:0.1,headingUncertainty:0.1,capturedAt:10)
        XCTAssertThrowsError(try nav.accept(duplicate,floorSupport:F.support(duplicate),now:10.1))
    }
    func testStaleARetirementCannotMutateNewBSessionOrDigest() throws {
        let(nav,c,r,path)=try prepared();defer{try? FileManager.default.removeItem(at:path)}
        let issuer=NativeLocalizationIssuer()
        issuer.retireRegisteredOutput={ owner in nav.withholdNativeEvidence(session:owner.registeredSession,artifact:owner.artifact) }
        issuer.offer(c,installed:r,recovered:c.owner.descriptor,now:10.1)
        nav.loseTracking();let newSession=try XCTUnwrap(nav.sessionID)
        let capture=SpatialLocalizationCapture(sessionID:newSession,binding:c.owner.artifact.binding,floorID:"floor",position:Point3(1,1.3,3),bodyYaw:0,source:.alignedMapPose,headingSource:.bodyAligned,trackingNormal:true,positionUncertainty:0.1,headingUncertainty:0.1,capturedAt:11)
        try nav.accept(capture,floorSupport:F.support(capture),now:11)
        let newer=NativeLocalizationOwner(arSession:UUID(),registeredSession:newSession,artifact:c.owner.artifact,descriptor:c.owner.descriptor,calibrationRevision:c.owner.calibrationRevision,mountRevision:c.owner.mountRevision)
        issuer.watchdog(currentOwner:newer,now:11)
        XCTAssertEqual(issuer.reason,.ownerChanged)
        nav.withholdNativeEvidence(session:c.owner.registeredSession,artifact:c.owner.artifact)
        XCTAssertEqual(nav.currentPose(now:11)?.id,capture.id);XCTAssertEqual(nav.sessionID,newSession)
        nav.withholdNativeEvidence(session:newSession,artifact:.init(binding:c.owner.artifact.binding,sha256:String(repeating:"b",count:64)))
        XCTAssertEqual(nav.currentPose(now:11)?.id,capture.id)
        nav.withholdNativeEvidence(session:newSession,artifact:c.owner.artifact)
        XCTAssertNil(nav.currentPose(now:11));XCTAssertEqual(nav.sessionID,newSession)
    }
    func testLateSameOwnerACompletionCannotConsumeOrRetireNewerB() throws {
        let(nav,a,r,path)=try prepared();defer{try? FileManager.default.removeItem(at:path)}
        let issuer=NativeLocalizationIssuer()
        issuer.retireRegisteredOutput={ owner in nav.withholdNativeEvidence(session:owner.registeredSession,artifact:owner.artifact) }
        let b=NativeLocalizationCandidate(owner:a.owner,capturedAt:10.2,cameraToWorld:a.cameraToWorld,trackingNormal:true)
        issuer.offer(a,installed:r,recovered:a.owner.descriptor,now:10.1)
        issuer.offer(b,installed:r,recovered:b.owner.descriptor,now:10.2)
        let measuredB=SpatialLocalizationCapture(id:b.id,sessionID:b.owner.registeredSession,binding:b.owner.artifact.binding,floorID:"floor",position:Point3(1,1.3,3),bodyYaw:0,source:.alignedMapPose,headingSource:.bodyAligned,trackingNormal:true,positionUncertainty:0.1,headingUncertainty:0.1,capturedAt:b.capturedAt)
        try nav.accept(measuredB,floorSupport:F.support(measuredB),now:10.2)
        let synthetic=NativeLocalizationEvidenceTests(name:"fixture",testClosure:{_ in})
        let validator=NativeLocalizationEvidenceTests.SyntheticValidator(result:.independentlyValidated)
        XCTAssertThrowsError(try issuer.prepareForBench(synthetic.measurements(a,floor:"floor"),currentOwner:a.owner,validator:validator,now:10.2)) { XCTAssertEqual($0 as? NativeLocalizationNotReady,.supersededCandidate) }
        XCTAssertEqual(issuer.candidate,b);XCTAssertEqual(nav.currentPose(now:10.2)?.id,b.id)
        let pair=try issuer.prepareForBench(synthetic.measurements(b,floor:"floor"),currentOwner:b.owner,validator:validator,now:10.2)
        XCTAssertEqual(pair.capture.id,b.id)
        XCTAssertNil(nav.currentPose(now:10.2)) // Bench consumption explicitly withdraws, never releases.
    }

}
