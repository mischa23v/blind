// swift-tools-version: 5.9
import PackageDescription
let package = Package(name: "NativeEvidenceExtraction", targets: [
 .target(name: "BlindCore", resources: [.copy("Resources/guide-prompt.txt")]),
 .target(name: "NativeAdapter", dependencies: ["BlindCore"]),
 .testTarget(name: "NativeEvidenceTests", dependencies: ["BlindCore", "NativeAdapter"])])
