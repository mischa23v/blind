from pathlib import Path
import hashlib,json
stage=Path('/workspace/shared/blind-native-journey-issuer-stage'); root=Path('/workspace/shared/blind-native-journey-issuer-tests')
s=(stage/'proposals/NavigationModel.swift.proposed').read_text()
def extract(needle):
 start=s.index(needle); brace=s.index('{',start); depth=1; end=brace+1
 while depth:
  if s[end]=='{':depth+=1
  elif s[end]=='}':depth-=1
  end+=1
 return s[start:end]
prop=extract('@Published var fixedBodyMount = false').replace('@Published ','')
method=extract('func invalidateNativeLocalizationMount(slipped: Bool)')
result='''import Foundation
import BlindCore
final class NativeMountHarness {
 struct Sink { var count=0; mutating func breakTracking(){count += 1}; mutating func interruptAmbient(){count += 1}; mutating func invalidatePosition(){count += 1}; mutating func retire(){count += 1}; mutating func reset(){count += 1} }
 var journeys=Sink(), feedback=Sink(), indoor=Sink(), spatialRouteOutput=Sink(), bodyHeadingEstimator=Sink()
 var mountSlipAnnounced=false
 var nativeLocalizationMount=UUID()
 let nativeLocalizationIssuer=NativeLocalizationIssuer()
 func invalidateNativeLocalization(_ reason: NativeLocalizationNotReady){ nativeLocalizationIssuer.invalidate(reason) }
 var descriptionsCancelled=0
 func cancelDescription(){descriptionsCancelled += 1}
'''+prop+'\n'+method+'\n}\n'
(root/'Sources/NativeAdapter/NativeMountHarness.swift').write_text(result)
(stage/'verification/NativeMountHarness.swift').write_text(result)
(stage/'verification/extraction.json').write_text(json.dumps({'nativeIssuer':hashlib.sha256((stage/'ios/BlindAssist/NativeLocalizationIssuer.swift').read_bytes()).hexdigest(),'proposedNavigationModel':hashlib.sha256(s.encode()).hexdigest(),'mountPropertyExactExceptPublishedAttribute':hashlib.sha256(prop.encode()).hexdigest(),'mountInvalidationMethodExact':hashlib.sha256(method.encode()).hexdigest(),'scope':'Actual extracted method/property bodies; dependency sinks are test doubles, not Apple SDK execution.'},indent=2)+'\n')
