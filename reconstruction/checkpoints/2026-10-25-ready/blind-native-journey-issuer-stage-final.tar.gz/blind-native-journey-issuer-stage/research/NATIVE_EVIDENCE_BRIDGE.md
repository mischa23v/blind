Historical baseline v1 record. For current selected-owner integration, use CONNECTED_OWNER_EVIDENCE_BRIDGE.md and README.md.

# Native saved-frame evidence bridge: staged, physical release closed

## Result

This stage adds a candidate-only ARKit/RoomPlan evidence adapter, not a localizer or SLAM implementation. No live source was edited. Two minimal patches accompany the new Core/native source files. Exact source hashes and full proposed snapshots support merge/review without overwriting concurrent work.

The latest executable run is `test-final-reviewed.log`: 18 tests passed, zero failures. These comprise synthetic contract/ownership tests, the exact native issuer and actual registered adapter/async storage code, exact extracted mount setter/helper bodies with dependency sinks, and one real recorded 100-frame negative/history replay. Native hookup syntax parse and patch dry-runs passed. Apple SDK compilation, ARKit callbacks and device measurements were NOT executed.

## Native integration

- `NativeLocalizationEvidence.swift` retains the full camera-to-world rigid transform, original capture ID/time, distinct AR-session and registered-session epochs, exact artifact digest/binding, exact saved-world descriptor, calibration revision and mount epoch.
- `NativeLocalizationIssuer.swift` is main-owner controlled. Production offers diagnostic candidates only; no production `acceptRegisteredCapture` call exists. Missing calibration withdraws executable registered pose/output immediately. Ordinary conversation, independent hazard processing and observation persistence remain separate.
- `proposals/native-hookup.patch` adds exact installed metadata access, AR frame capture after urgent sensor handling, tracking-loss invalidation before frame throttling, watchdog ownership/expiry checks, lifecycle invalidation and actual mount-change/slip setter calls. Imported maps without exact saved-world-frame identity explicitly require measured registration. Room labels/GPS/normal tracking never supply authority.
- `proposals/scoped-withdrawal.patch` adds narrow evidence withdrawal to SpatialLocalizationLease, SpatialRouteOwner and RegisteredIndoorNavigation. Exact registered session plus artifact must match before mutation. Withdrawal clears pose/support/output but preserves route intent, session identity and anti-replay high-water. A stale callback for A cannot retire newer B, and withdrawing missing evidence cannot self-stale the candidate. Actual lifecycle tracking loss still rotates ownership through existing paths.
- Diagnostic invalidation and bench-result consumption preserve per-owner candidate high-water. Genuine owner changes fence old completion; restart restores no candidate.

## Evidence contract and remaining adapter boundary

NativeLocalizationMeasurements is a narrow input from a FUTURE trusted local measurement producer. It carries calibration/support/error-model source IDs, revisions, SHA-256 references, protocol/dataset IDs, current-clock observation/expiry times, operating-domain ID, exact floor identity, uncertainty-expanded full-footprint coverage digest, body position/yaw, support height/error and total conservative positional/angular error.

References are NOT validation. An independently reviewed NativeLocalizationEvidenceValidator must resolve the records, verify their hashes and source trust, measured camera-to-body extrinsics/body envelope conventions, floor/support coverage, applicable domain, timing, alignment and independently established conservative combined error. There is no production implementation. Unvalidated, missing, stale, wrong-epoch, inconsistent, out-of-domain or out-of-map-floor input is rejected. The bridge does not compute fake error bounds or use confidence constants as accuracy.

Even successful preparation remains explicitly `physicalReleaseNotApproved`. The native bench method returns its pair for tests and immediately withdraws output; it never installs that pair. Actual sensor/calibration producer, imported-map measured registration, scientific error model/support observer, Apple SDK build and independent device verification remain open. Same-world artifact association proves neither physical alignment accuracy nor current free space. No physical direction/reach/handling/mobility is enabled.

## Real recorded evidence, separately from synthetic positives

Reused public ARKitScenes scene 47333462, pinned docs 474aaa83d7b1c9080619d8485de2d7c885c01fc5. Existing preparation script was reused without downloads, dependencies, weights or upstream execution. Dataset and derivatives stay outside source/stage. `recorded-preparation.json` records the 4,240,458-byte derivative hash 06afbeba277e24c8cf971f9da1e7ee098772c3380af7e46f48997d3b4a917b12 and source provenance hash.

The recorded test inverts recorded world-to-camera extrinsics, retains full rotation, compares 100 camera positions and 300 backprojected depth points against the preparation output, and explicitly converts pinhole to ARKit basis at the attempted candidate boundary. It deliberately supplies no native saved-map installation or recovered descriptor and no wearer/support/calibration ground truth. All 100 frames withhold authority. This is a negative interface/history replay, NOT a live localization test or motion-ticket production success.

All 100 observations entered the existing bounded history; 49 remain and 51 are explicitly evicted by the existing 2 MiB/64-record bounds. The retained history round-trips exactly. This run does not retest SQLite durability; earlier observation persistence evidence remains separate. No measured original tracking state is invented. All positive pose/calibration/support/uncertainty fixtures are clearly synthetic plumbing, not real-data accuracy proof. The captured ARKit trajectory/mesh are not independent ground truth.

Official source/license pointers:
- https://developer.apple.com/documentation/arkit/arcamera
- https://developer.apple.com/documentation/arkit/saving-and-loading-world-data
- https://developer.apple.com/videos/play/wwdc2023/10192/
- https://github.com/apple-aiml-research/ARKitScenes/blob/474aaa83d7b1c9080619d8485de2d7c885c01fc5/DATA.md
- https://github.com/apple-aiml-research/ARKitScenes/blob/474aaa83d7b1c9080619d8485de2d7c885c01fc5/LICENSE
Apple's data license is distinct from code licenses; this source archive redistributes no recorded images/depth/trajectory derivatives. Upstream reputation is not integration/accuracy evidence.

## Review corrections and reproducibility

Independent review identified broad preview-route cancellation, stale A retiring newer B, self-stale candidates caused by post-capture epoch rotation, and replay high-water reset after diagnostic invalidation. A later same-owner A→B→late-A completion could consume/retire B; obsolete completions now reject without mutating the newer candidate. Each issue was corrected and covered with regressions; the actual registered adapter verifies session stability, ticket/pose withdrawal, route preservation, replay rejection and newer-owner isolation. No physical calibration gap was papered over.

Initial failures are retained: read-only compiler cache path (corrected to shared cache), XCTest fixture construction, an incorrect expectation that bounded history retained all 100 records, and the initially omitted native SpatialMapIO extraction dependency. Do not read their logs as latest status. Final 18 tests passed.

Reproduce with existing official Swift 6.4.1, jobs 2, scratch under /workspace/shared, no installs:
1. Prepare frames outside stage using verification/prepare-recorded-observations.py and existing public fixture.
2. Set NATIVE_RECORDED_FIXTURE to that private/local frames.json.
3. Run verification/run-extracted-tests.sh. It copies exact code into an isolated package and records compiled-source hashes.

The tests under verification/Tests require the generated NativeAdapter target; they are not drop-in BlindCoreTests files. Proposed complete native snapshots are review/extraction inputs, not permission to overwrite other workers' NavigationModel/IndoorNavigator changes. Apply only the narrow diffs after checking base hashes and rerunning aggregate tests.

## Unfinished release gates

Independent surveyed pose/heading/support reference; measured camera/body calibration and slip detection; operating-domain/error model; full footprint/current corridor coverage; imported-map registration; cross-floor transition evidence; native SDK compilation and relocalization callbacks; real delayed output cancellation; latency/thermal/battery; qualified supervised adult/child protocols. No device accuracy, safe solo use or physical release claim is made.
