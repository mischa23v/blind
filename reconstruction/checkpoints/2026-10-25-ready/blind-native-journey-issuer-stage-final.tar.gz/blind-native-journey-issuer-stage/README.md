# Candidate-only native bridge: connected-owner integration checkpoint

Successor to immutable source archive 03024f00724719c2a5e126705b3e0e023897716d609633a831d8078212317502. Staging only: no live source edits. Four new source files plus eight narrow existing-file changes are listed in verification/source-input-manifest.json. Apply only the four patches and new files after parent-owned ordered rebase, not full stale proposed snapshots.

ConnectedJourneyRuntime is the sole physical route owner. This bridge now uses its actual requested localization session, installed artifact and goal. Explicit registered preview is separate, never a fallback when the journey is unavailable. Neither receives production physical captures from this adapter. No calibrated provider or positive memory scope is manufactured.

Latest verification: 47 tests passed, zero failures in research/test-final-reviewed-connected-owner.log. This includes all 17 preexisting actual runtime tests (only test-module import changed), the prior 18 evidence/recorded/registered tests, eight selected-owner/native-entry regressions and four portal recovery regressions. Public recorded 100-frame replay withholds all 100; retained bounded history remains 49 with 51 explicit evictions. Positive fixtures are synthetic plumbing only.

Four native syntax-parse configurations passed. All four patches apply and reverse in isolated scratch to the exact eight live preimages; the four added files are absent from live. Native app project membership is generated with the existing generator and unchanged options. Apple SDK compilation and device validation remain pending.

Read research/CONNECTED_OWNER_EVIDENCE_BRIDGE.md for behavior, review fixes, precise limits and reproduction. Baseline v1 reports/logs are explicitly historical. Public packet contains code, synthetic tests and metadata only: no private chat, user photographs, personal calibration, raw sensor data, recorded-image/depth/trajectory derivatives, model weights, databases or build outputs.
