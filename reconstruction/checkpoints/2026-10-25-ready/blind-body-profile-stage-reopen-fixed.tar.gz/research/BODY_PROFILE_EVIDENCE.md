# Optional local body profile and collision preview

Staged only, 2026-10-25. No live files edited or pushed. Sources reviewed before implementation; no anthropometric data, private examples, models or new dependencies downloaded.

## Primary evidence and decisions

- CDC/NCHS, *Anthropometric Reference Data for Children and Adults: United States, August 2021–August 2023*, published 2025: https://www.ncbi.nlm.nih.gov/books/NBK620758/?report=reader . It reports distributions of separately measured dimensions by sex and age, not individual full-body collision bounds. We do not turn a population mean/percentile into a per-person safety guarantee or confuse self-described gender with the survey's sex variable.
- CDC/NIOSH, *Anthropometry and Work: An Overview*, 2024: https://www.cdc.gov/niosh/anthropometry/about/ . Substantial variation matters in fit and protective design. Inference: optional age/weight/gender cannot defensibly fix an individual's maximum breadth, depth, limb movement or carried equipment geometry.
- CDC, *Anthropometry Procedures Manual*, 2021: https://wwwn.cdc.gov/nchs/data/nhanes/public/2021/manuals/2021-Anthropometry-Procedures-Manual-508.pdf . The measurement protocol controls positioning, landmark and recording errors. A helper's typed measurement is therefore reported provenance, not a calibrated scanner or zero-error sensor.

These sources inform a small adapter, not an invented anthropometric estimator. The existing generic 0.3m radius/1.8m height stays a labelled preview placeholder where individual dimensions are unknown. Reported height overrides preview height; fresh measured dimensions replace older reports/estimates. A later report conservatively expands retained measured bounds instead of shrinking or relabelling them. No age/weight/gender-to-width formula is supplied. Missing uncertainty remains nil. No source is a validation of this app.

## Implemented contract

- Optional age in years, self-described gender, weight in kilograms and height in metres, with centimetre/inch/pound conversion helpers and finite/range validation. Bounds are input sanity limits, not population coverage or health advice.
- Distinct estimated/reported/measured dimensions, provenance, timestamp, optional uncertainty and association with geometry revision. Measurement-basis ownership is separate from output revision. Retained measurement timestamps/provenance/basis IDs never change on a later report; delayed recordings require exact geometry-revision CAS. Maximum full-body width/depth cover more than torso. Bounding cylinder uses rectangle half-diagonal, not half-width; it does not grant a sideways squeeze.
- Chest camera right/up/forward metadata is body-relative from floor below body centre, not an AR pose, floor support or body-heading transform. Horizontal mount offset expands camera-centred preview conservatively; unknown offsets remain missing evidence.
- Radial/overhead equipment extensions explicitly include clothing, hands, backpack, carried objects and cane sweep. Unknown is not zero certainty. Unsupported large envelopes return nil instead of clamping smaller.
- Preview produces only rejected or unknown. No profile or measured-label field creates collision clearance, physical guidance, native pose, guardian verification or voice authority. The NativeLocalizationEvidence calibration revision remains unconfigured until a real validated provider exists.
- Growth/height/weight/mount/equipment edits invalidate retained dimension association; replacing dimensions rotates geometry revision. Gender-only edits retain geometry and unrelated tasks. Name/audience/trusted memory are not read or edited.
- `SpatialRouteOwner.invalidateBodyProfile` rotates body and localization sessions, retires route/tickets and rejects old in-flight captures, without promoting the preview into authoritative body configuration.
- Native helper destination in existing preferences; no home-tab clutter/new task mode. Separate local profile file uses iOS complete protection, backup exclusion before data write, atomic write, bounded load/decode and scoped deletion. The existing SpatialMapIO worker keeps JSON and disk work off main, with one process-wide production writer, bounded pending work, exact generation/CAS, rollback and non-droppable deletion barrier. UI retirement occurs before enqueue and status is published only for its current operation. Read-only reopenings wait/coalesce behind an admitted save; stale rejected writers cannot cancel current writes. Timestamp rollback is rejected even with a current basis/output CAS. No public-map, cloud, log or model-prompt path is added. The profile is for the app's current wearer, not identity recognition or multi-wearer enrollment.
- Native geometry-save/deletion callback unconditionally calls `invalidateNativeLocalizationMount(slipped: false)` even if fixedBodyMount is already false, plus existing journey tracking break and registered-position invalidation. This depends on the independently reviewed native bridge patch being applied first. Never replace the literal unconfigured calibration with profile metadata.

## Remaining providers and acceptance

Actual body scan provider; measured uncertainty/coverage and expiry policy; current equipment/dynamic limb coverage; chest-to-body transform and mount-slip calibration; independent body heading; map-aligned pose error; floor support; live obstruction/terrain coverage; device-specific spatial and latency validation; bilingual helper copy/VoiceOver device usability review. None is established by these unit tests or a saved age/height.

A body profile can initialize an approximate model for preview, but cannot prove a route clear. On-device settings entry, complete-protection behavior, backup exclusion and actual native SDK compilation must be checked on Apple hardware. Portable store tests exercise actual source's non-iOS branch, not iOS data protection.

## Terrain defect found during this work: OPEN

Current `NavigationSurface.permitsValidatedLeg` accepts endpoint height and each swept cell floor within 0.09m of source Y. Its comment says rises/drops reject, but executable witnesses show:
1. A sharp 0.08m rise is accepted.
2. A sharp 0.08m drop is accepted.
3. Adjacent floor cells at -0.08m and +0.08m relative to source Y are accepted, despite their 0.16m difference.

The third witness does not claim that a real pose would be at the support height of either cell. It demonstrates the surface routine itself lacks adjacent-cell transition analysis and can authorize an authored stored leg before current support validation. The 8cm witness does start on actual zero support. Body age, stature, weight and margin do not fix these footing semantics.

Primary accessibility reference: US Access Board ADA Standards §303 https://www.access-board.gov/ada/#ada-303 . Architectural level-change treatment depends on height and edge/ramp shape; it is not a universal safe child step threshold or iPhone detectability test. We do NOT substitute an ADA numeric threshold for sensor calibration.

Proposed separate terrain contract, not silently applied here:
- Typed evidence for support intervals/uncertainty, adjacent height changes, running and cross-slope, discontinuity edges, observation resolution/coverage/time/source and actual floor identity.
- Distinct outcomes for level candidate, rise, drop, ramp/slope, stairs and unknown. Compare adjacent support intervals in travel direction and the whole swept footprint, not only to route origin Y. Sensor noise tolerance must never be interpreted as allowed traversable rise.
- No positive footing when edge/ramp class, uncertainty, support, loose/slippery surfaces or coverage is unknown. Downhill/uphill/cross-slope and negative depth/missing return require their own provider evaluation. Small undetected objects remain a coverage limitation, not absence evidence.
- Policy must be validated for intended users with O&M review and supervised benign fixtures; do not infer gait or allowable step from demographics. Separate surface fit from body collision and live hazard gates.

The two terrain tests are labelled known-defect characterization, not desired regression behavior or proof of safety. The shared NavigationSurface implementation is intentionally unchanged pending root-owned terrain work.
