import XCTest
import BlindCore
/// Characterization of an OPEN defect, not desired safe behavior. Remove/update
/// these expected permits when the separately reviewed terrain policy is fixed.
final class BodyProfileTerrainWitnessTests: XCTestCase {
    func testCurrentPlannerAdmitsEightCentimetreStepUpAndDown() throws {
        for rise in [0.08, -0.08] {
            var cells = Array(repeating: SurfaceCell(floor: 0, clearance: 3), count: 10000)
            for z in 50..<100 { for x in 0..<100 { cells[z * 100 + x].floor = rise } }
            let surface = NavigationSurface(level: "synthetic", origin: .init(0,0,0), resolution: 0.1,
                width: 100, depth: 100, cells: cells)
            XCTAssertTrue(surface.permitsLeg(from: .init(5,0,3), to: .init(5,rise,7)),
                "Known 9 cm tolerance defect: numerical acceptance is not safe footing")
        }
    }
    func testCurrentPlannerAdmitsSixteenCentimetreNeighbourDifference() {
        var cells = Array(repeating: SurfaceCell(floor: -0.08, clearance: 3), count: 10000)
        for z in 50..<100 { for x in 0..<100 { cells[z * 100 + x].floor = 0.08 } }
        let surface = NavigationSurface(level: "synthetic", origin: .init(0,0,0), resolution: 0.1,
            width: 100, depth: 100, cells: cells)
        XCTAssertTrue(surface.permitsLeg(from: .init(5,0,3), to: .init(5,0,7)),
            "Floor comparison is against source Y, not adjacent cells; known defect")
    }
}
