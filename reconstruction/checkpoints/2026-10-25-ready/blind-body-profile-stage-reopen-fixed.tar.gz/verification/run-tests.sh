#!/usr/bin/env bash
set -euo pipefail
stage=$(cd "$(dirname "$0")/.." && pwd)
base=${BLIND_SOURCE_ROOT:-/workspace/shared/blind-rebuild}
work=${BODY_PROFILE_WORK:-/workspace/shared/blind-body-profile-tests}
source /workspace/shared/swift-toolchain/env.sh
export TMPDIR=/workspace/shared/swift-toolchain/tmp HOME=/workspace/shared/swift-toolchain/home
export CLANG_MODULE_CACHE_PATH="$work/clang-cache" BODY_PROFILE_STAGE="$stage"
mkdir -p "$work/Sources/NativeBodyProfile" "$work/Tests/NativeBodyProfileTests"
cp -a "$base/BlindCore/Sources/BlindCore" "$work/Sources/"
cp -a "$base/BlindCore/Tests/BlindCoreTests" "$work/Tests/"
cp "$stage/BlindCore/Sources/BlindCore/"*.swift "$work/Sources/BlindCore/"
cp "$stage/BlindCore/Tests/BlindCoreTests/"*.swift "$work/Tests/BlindCoreTests/"
cp "$base/ios/BlindAssist/SpatialMapIO.swift" "$work/Sources/NativeBodyProfile/"
cp "$stage/ios/BlindAssist/BodyProfileStore.swift" "$work/Sources/NativeBodyProfile/"
cp "$stage/verification/Tests/"*.swift "$work/Tests/NativeBodyProfileTests/"
cat > "$work/Package.swift" <<'PACKAGE'
// swift-tools-version: 5.9
import PackageDescription
let package = Package(name: "BodyProfileVerification", platforms: [.macOS(.v13)], targets: [
.target(name: "BlindCore", resources: [.copy("Resources/guide-prompt.txt")]),
.target(name: "NativeBodyProfile", dependencies: ["BlindCore"]),
.testTarget(name: "BlindCoreTests", dependencies: ["BlindCore"], resources: [.copy("Fixtures")]),
.testTarget(name: "NativeBodyProfileTests", dependencies: ["BlindCore", "NativeBodyProfile"])])
PACKAGE
swift test --package-path "$work" --scratch-path "$work/.build" --jobs 2 --filter 'BodyProfile|SpatialRouteOwnerTests|NavigationSurfaceTests'
swiftc -frontend -parse "$stage/ios/BlindAssist/BodyProfileStore.swift" "$stage/ios/BlindAssist/BodyProfileSettingsView.swift" "$stage/ios/BlindAssist/DashboardView.swift"
