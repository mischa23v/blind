import XCTest
@testable import BlindCore
#if canImport(BlindAssist)
@testable import BlindAssist
#endif

/// Executes the unmodified Foundation native store copied into this test target.
/// Apple ARFrame capture and iOS file protection still require SDK/device validation.
final class RecordedRouteStoreTests: XCTestCase {
    final class Clock: @unchecked Sendable {
        let lock = NSLock(); private var value = 0.0
        func read() -> Double { lock.lock(); defer { lock.unlock() }; return value }
        func set(_ n: Double) { lock.lock(); value = n; lock.unlock() }
    }
    func record(session: UUID, time: Double) -> NativeObservationRecord {
        var c = NativeCameraTransform.identity.columns; c[12] = time * 0.1
        return .init(sessionID: session, coordinateFrameID: "native-fixture", producer: .arkit,
            sourceID: "capture-\(time)", capturedAt: time, receivedAt: time, observedAt: Date(), tracking: .normal,
            cameraConvention: .arKitRightUpBack, cameraToSessionWorld: .init(columns: c),
            intrinsics: .init(width: 2, height: 2, fx: 1, fy: 1, cx: 1, cy: 1), depth: nil)
    }
    func snapshot(_ store: RecordedRouteStore) -> RecordedRouteStore.Snapshot? {
        let done = expectation(description: "snapshot"); var snapshot: RecordedRouteStore.Snapshot?
        store.preview { snapshot = $0; done.fulfill() }; wait(for: [done], timeout: 3); return snapshot
    }
    func testChunkPersistenceRestartAndLocalClear() throws {
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: directory) }
        let url = directory.appendingPathComponent("ignored.json"), clock = Clock(), session = UUID()
        let store = RecordedRouteStore(url: url, now: clock.read); store.begin(sessionID: session)
        clock.set(60)
        for i in 0..<31 {
            let record = record(session: session, time: Double(i)*0.21)
            store.offer(sessionID: session, at: record.capturedAt) { record }
            _ = snapshot(store) // Drain queue; no assumption that arbitrary frame tasks all admit.
        }
        store.stop(); let first = try XCTUnwrap(snapshot(store))
        XCTAssertEqual(first.durableSampleCount, 31); XCTAssertEqual(first.volatileSampleCount, 0)
        let files = try FileManager.default.contentsOfDirectory(at: directory, includingPropertiesForKeys: nil)
        XCTAssertGreaterThan(files.count, 1); XCTAssertLessThanOrEqual(files.count, 4)
        let restored = RecordedRouteStore(url: url, now: clock.read)
        let retained = try XCTUnwrap(snapshot(restored))
        XCTAssertEqual(retained.preview?.reverseSamples.count, 31)
        XCTAssertTrue(retained.preview?.gaps.contains(.restarted) == true)
        let cleared = expectation(description: "cleared")
        restored.clear { XCTAssertTrue($0); cleared.fulfill() }; wait(for: [cleared], timeout: 3)
        XCTAssertFalse(FileManager.default.fileExists(atPath: directory.path))
        XCTAssertNil(snapshot(restored)?.preview)
    }
    func testAggregateCapacityNeverWritesAnArchiveThatCannotReopen() throws {
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: directory) }
        let url = directory.appendingPathComponent("ignored.json"), clock = Clock(), session = UUID()
        let initial = RecordedRouteStore(url: url, now: clock.read)
        initial.begin(sessionID: session); clock.set(60)
        let first = record(session: session, time: 0)
        initial.offer(sessionID: session, at: 0) { first }; _ = snapshot(initial); initial.stop(); _ = snapshot(initial)
        let files = try FileManager.default.contentsOfDirectory(at: directory, includingPropertiesForKeys: [.fileSizeKey])
        let bytes = try files.reduce(0) { $0 + (try $1.resourceValues(forKeys: [.fileSizeKey]).fileSize ?? 0) }
        XCTAssertGreaterThan(bytes, 0)
        let limit = bytes + 1
        let store = RecordedRouteStore(url: url, maximumArchiveBytes: limit, now: clock.read)
        store.begin(sessionID: UUID()); clock.set(120)
        let newSession = UUID(); store.begin(sessionID: newSession)
        let second = record(session: newSession, time: 0.3)
        store.offer(sessionID: newSession, at: 0.3) { second }; _ = snapshot(store)
        store.stop(); let result = try XCTUnwrap(snapshot(store))
        XCTAssertEqual(result.durableSampleCount, 1)
        XCTAssertEqual(result.volatileSampleCount, 1)
        XCTAssertTrue(result.persistenceCapacityReached)
        XCTAssertFalse(result.persistenceFailed)
        let reopened = RecordedRouteStore(url: url, maximumArchiveBytes: limit, now: clock.read)
        let recovered = try XCTUnwrap(snapshot(reopened))
        XCTAssertFalse(recovered.loadFailed); XCTAssertEqual(recovered.durableSampleCount, 1)
    }
    func testReadAndClearAdmissionRemainBoundedWhileExtractionIsHeld() throws {
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: directory) }
        let store = RecordedRouteStore(url: directory.appendingPathComponent("ignored.json")), session = UUID()
        store.begin(sessionID: session)
        let entered = DispatchSemaphore(value: 0), release = DispatchSemaphore(value: 0)
        store.offer(sessionID: session, at: 0) { entered.signal(); _ = release.wait(timeout: .now()+3); return self.record(session: session, time: 0) }
        XCTAssertEqual(entered.wait(timeout: .now()+3), .success)
        let firstRead = expectation(description: "admitted read")
        store.preview { _ in firstRead.fulfill() }
        for _ in 0..<50 { store.preview { XCTAssertTrue($0.busy) } }
        let firstClear = expectation(description: "admitted clear")
        store.clear { XCTAssertTrue($0); firstClear.fulfill() }
        for _ in 0..<50 { store.clear { XCTAssertFalse($0) }; store.stop(); store.begin(sessionID: session) }
        release.signal(); wait(for: [firstRead, firstClear], timeout: 3)
        XCTAssertNil(snapshot(store)?.preview)
    }
    func testSameSessionBeginCreatesBoundaryAndQueuedReadIsWithheldAfterClear() throws {
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: directory) }
        let store = RecordedRouteStore(url: directory.appendingPathComponent("ignored.json")), session = UUID()
        store.begin(sessionID: session)
        let first = record(session: session, time: 0)
        store.offer(sessionID: session, at: 0) { first }; _ = snapshot(store)
        store.begin(sessionID: session)
        let second = record(session: session, time: 0.3)
        store.offer(sessionID: session, at: 0.3) { second }
        XCTAssertEqual(snapshot(store)?.preview?.reverseSamples.first?.boundaryBefore, .restarted)
        let stale = expectation(description: "stale read cannot publish private samples")
        store.preview { result in XCTAssertNil(result.preview); XCTAssertTrue(result.busy); stale.fulfill() }
        // Hold main delivery while the worker reaches publication. clear invalidates
        // the generation synchronously, not only when its delete reaches the queue.
        Thread.sleep(forTimeInterval: 0.05)
        var rejected = false; store.preview { rejected = $0.busy }; XCTAssertTrue(rejected)
        let cleared = expectation(description: "clear")
        store.clear { XCTAssertTrue($0); cleared.fulfill() }
        wait(for: [stale, cleared], timeout: 3)
    }
    func testFailedClearRetiresHistoryAndFencesBeginUntilExplicitRetry() throws {
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: directory) }
        let clock = Clock(), canDelete = Clock(), session = UUID()
        let store = RecordedRouteStore(url: directory.appendingPathComponent("ignored.json"), now: clock.read, removeDirectory: { url in
            guard canDelete.read() > 0 else { throw CocoaError(.fileWriteNoPermission) }
            try FileManager.default.removeItem(at: url)
        })
        store.begin(sessionID: session); clock.set(60)
        let first = record(session: session, time: 0)
        store.offer(sessionID: session, at: 0) { first }; XCTAssertNotNil(snapshot(store)?.preview)
        let failed = expectation(description: "failed erase")
        store.clear { XCTAssertFalse($0); failed.fulfill() }; wait(for: [failed], timeout: 3)
        store.begin(sessionID: session)
        let later = record(session: session, time: 0.3)
        store.offer(sessionID: session, at: 0.3) { later }
        let fenced = try XCTUnwrap(snapshot(store))
        XCTAssertNil(fenced.preview); XCTAssertTrue(fenced.loadFailed); XCTAssertTrue(fenced.persistenceFailed)
        canDelete.set(1)
        let retry = expectation(description: "explicit erase retry")
        store.clear { XCTAssertTrue($0); retry.fulfill() }; wait(for: [retry], timeout: 3)
        XCTAssertFalse(snapshot(store)?.loadFailed ?? true)
    }
    func testOversizedActualChunkIsRejectedWithoutPublishingPartialHistory() throws {
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: directory) }
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        try Data(repeating: 32, count: 131_073).write(to: directory.appendingPathComponent("00000000.json"))
        let store = RecordedRouteStore(url: directory.appendingPathComponent("ignored.json"))
        let result = try XCTUnwrap(snapshot(store))
        XCTAssertTrue(result.loadFailed); XCTAssertNil(result.preview)
    }
    func testClearAdmissionSlotStaysHeldUntilMainCompletion() {
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        let store = RecordedRouteStore(url: directory.appendingPathComponent("ignored.json"))
        let done = expectation(description: "first clear callback")
        store.clear { XCTAssertTrue($0); done.fulfill() }
        Thread.sleep(forTimeInterval: 0.05)
        for _ in 0..<50 { store.clear { XCTAssertFalse($0) } }
        wait(for: [done], timeout: 3)
    }
    func testColdBudgetVolatileReceiptAndRejectedOldCaptureAfterClear() throws {
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: directory) }
        let clock = Clock(), session = UUID(), store = RecordedRouteStore(url: directory.appendingPathComponent("ignored.json"), now: clock.read)
        store.begin(sessionID: session)
        let record = record(session: session, time: 0)
        store.offer(sessionID: session, at: 0) { record }
        let pending = try XCTUnwrap(snapshot(store))
        XCTAssertEqual(pending.volatileSampleCount, 1); XCTAssertEqual(pending.durableSampleCount, 0)
        let entered = DispatchSemaphore(value: 0), release = DispatchSemaphore(value: 0)
        store.offer(sessionID: session, at: 1) { entered.signal(); _ = release.wait(timeout: .now()+3); return self.record(session: session, time: 1) }
        XCTAssertEqual(entered.wait(timeout: .now()+3), .success)
        let cleared = expectation(description: "clear fences late extraction")
        store.clear { XCTAssertTrue($0); cleared.fulfill() }; release.signal(); wait(for: [cleared], timeout: 3)
        XCTAssertNil(snapshot(store)?.preview)
    }
}
