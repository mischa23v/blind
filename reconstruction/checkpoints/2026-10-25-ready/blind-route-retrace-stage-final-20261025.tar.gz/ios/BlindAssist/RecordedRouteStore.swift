import Foundation
import BlindCore

/// Private bounded trail persistence. All encoding and file IO run off the sensor loop.
/// One admitted capture at a time prevents unbounded frame/write queue accumulation.
final class RecordedRouteStore: @unchecked Sendable {
    private let queue = DispatchQueue(label: "blind.recorded-route", qos: .utility)
    private let lock = NSLock()
    private var busy = false
    private var flushPending = false
    private var readPending = false
    private var clearPending = false
    private var trackingWasLost = false
    private var restartPending = false
    private var persistenceFailed = false
    private var sessionID: UUID?
    private var generation = UUID()
    private var lastAccepted = -Double.infinity
    private var history = RecordedRouteHistory()
    private var loaded = false
    private var loadFailed = false
    private var lastSaved = -Double.infinity
    private var durableSampleCount = 0
    private var chunkCount = 0
    private var totalDurableBytes = 0
    private var persistenceCapacityReached = false
    private var budgetDeferred = false
    private let maximumArchiveBytes: Int
    private var budget: NativeObservationDurabilityBudget
    private let now: () -> Double
    private let removeDirectory: (URL) throws -> Void
    private struct Chunk: Codable {
        let historyID: UUID
        let startIndex: Int
        let samples: [RecordedRouteSample]
    }
    private let url: URL
    init(url: URL? = nil, maximumArchiveBytes: Int = RecordedRouteHistory.maximumBytes, now: @escaping () -> Double = { ProcessInfo.processInfo.systemUptime },
         removeDirectory: @escaping (URL) throws -> Void = { try FileManager.default.removeItem(at: $0) }) {
        precondition(maximumArchiveBytes > 0 && maximumArchiveBytes <= RecordedRouteHistory.maximumBytes)
        self.maximumArchiveBytes = maximumArchiveBytes
        self.now = now; self.removeDirectory = removeDirectory
        budget = NativeObservationDurabilityBudget(configuration: try! .init(bytesPerInterval: 524_288, intervalSeconds: 60, burstBytes: 131_072), now: now())
        self.url = url ?? FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("RecordedRoutes", isDirectory: true).appendingPathComponent("camera-path.json")
    }
    func begin(sessionID: UUID) {
        lock.lock(); self.sessionID = sessionID; generation = UUID(); lastAccepted = -.infinity; restartPending = true; lock.unlock()

    }
    func stop() {
        lock.lock(); sessionID = nil; generation = UUID()
        guard !flushPending else { lock.unlock(); return }; flushPending = true; lock.unlock()
        queue.async {
            defer { self.lock.lock(); self.flushPending = false; self.lock.unlock() }
            self.history.interrupt()
            do { try self.save(); self.persistenceFailed = false } catch { self.persistenceFailed = true }
        }
    }
    func breakContinuity() {
        lock.lock(); trackingWasLost = true; lock.unlock()
    }
    func offer(sessionID: UUID, at time: Double, extract: @escaping () throws -> NativeObservationRecord) {
        lock.lock()
        if time.isFinite && time < lastAccepted { trackingWasLost = true; lastAccepted = -.infinity }
        guard self.sessionID == sessionID, time.isFinite, time >= 0, !busy,
              time - lastAccepted >= 0.2 else { lock.unlock(); return }
        busy = true; lastAccepted = time; let token = generation; lock.unlock()
        queue.async {
            defer { self.lock.lock(); self.busy = false; self.lock.unlock() }
            self.lock.lock(); let current = self.generation == token && self.sessionID == sessionID; self.lock.unlock()
            guard current else { return }
            self.load()
            guard !self.loadFailed else { return }
            do {
                let record = try extract()
                guard record.sessionID == sessionID, record.capturedAt == time else { return }
                // Recheck after extraction. An old capture cannot revive erased history.
                self.lock.lock(); let stillCurrent = self.generation == token; self.lock.unlock()
                guard stillCurrent else { return }
                self.lock.lock(); let trackingLost = self.trackingWasLost; self.trackingWasLost = false; let restarted = self.restartPending; self.restartPending = false; self.lock.unlock()
                if restarted {
                    self.lastSaved = -.infinity
                    if !self.history.samples.isEmpty { self.history.interrupt(.restarted) }
                }
                if trackingLost { self.history.interrupt(.trackingLost) }
                try self.history.observe(record)
                if time - self.lastSaved >= 5 {
                    do { try self.save(); self.lastSaved = time; self.persistenceFailed = false }
                    catch { self.persistenceFailed = true }
                }
            } catch RecordedRouteError.capacityReached { /* Retain explicit terminal capacity receipt. */ }
            catch { self.history.interrupt(.trackingLost) }
        }
    }
    struct Snapshot {
        let preview: RecordedRoutePreview?
        let persistenceFailed: Bool
        let loadFailed: Bool
        let durableSampleCount: Int
        let volatileSampleCount: Int
        let busy: Bool
        let capacityReached: Bool
        let persistenceCapacityReached: Bool
        let budgetDeferred: Bool
    }
    func preview(_ completion: @escaping (Snapshot) -> Void) {
        lock.lock()
        guard !readPending else {
            lock.unlock()
            completion(Snapshot(preview: nil, persistenceFailed: false, loadFailed: false, durableSampleCount: 0, volatileSampleCount: 0, busy: true, capacityReached: false, persistenceCapacityReached: false, budgetDeferred: false))
            return
        }
        readPending = true; let token = generation; lock.unlock()
        queue.async {
            self.load()
            let result = Snapshot(preview: try? self.history.preview(), persistenceFailed: self.persistenceFailed, loadFailed: self.loadFailed,
                durableSampleCount: self.durableSampleCount, volatileSampleCount: self.history.samples.count - self.durableSampleCount, busy: false, capacityReached: self.history.capacityExceeded,
                persistenceCapacityReached: self.persistenceCapacityReached, budgetDeferred: self.budgetDeferred)
            DispatchQueue.main.async {
                self.lock.lock(); let current = token == self.generation; self.readPending = false; self.lock.unlock()
                if current { completion(result) }
                else { completion(Snapshot(preview: nil, persistenceFailed: false, loadFailed: false,
                    durableSampleCount: 0, volatileSampleCount: 0, busy: true, capacityReached: false,
                    persistenceCapacityReached: false, budgetDeferred: false)) }
            }
        }
    }
    func clear(_ completion: @escaping (Bool) -> Void) {
        lock.lock()
        guard !clearPending else { lock.unlock(); completion(false); return }
        clearPending = true; generation = UUID(); sessionID = nil; lock.unlock()
        let finish: (Bool) -> Void = { result in
            DispatchQueue.main.async {
                self.lock.lock(); self.clearPending = false; self.lock.unlock()
                completion(result)
            }
        }
        queue.async {
            // Retire live private samples before attempting disk erasure. A failed
            // clear fences recording/reload for this owner until explicit retry.
            self.history = .init(); self.durableSampleCount = 0; self.loaded = true; self.loadFailed = true
            do {
                if FileManager.default.fileExists(atPath: self.url.deletingLastPathComponent().path) { try self.removeDirectory(self.url.deletingLastPathComponent()) }
                self.history = .init(); self.durableSampleCount = 0; self.chunkCount = 0; self.totalDurableBytes = 0; self.persistenceCapacityReached = false; self.budgetDeferred = false; self.loaded = true; self.loadFailed = false; self.persistenceFailed = false; self.lastSaved = -.infinity
                finish(true)
            } catch { self.persistenceFailed = true; finish(false) }
        }
    }
    private func load() {
        guard !loaded else { return }; loaded = true
        let directory = url.deletingLastPathComponent()
        guard FileManager.default.fileExists(atPath: directory.path) else { return }
        do {
            guard let iterator = FileManager.default.enumerator(at: directory, includingPropertiesForKeys: [.fileSizeKey],
                options: [.skipsSubdirectoryDescendants, .skipsHiddenFiles]) else { throw RecordedRouteError.invalidArchive }
            var files: [URL] = []
            for case let file as URL in iterator {
                guard files.count < 1000, file.pathExtension == "json" else { throw RecordedRouteError.invalidArchive }
                files.append(file)
            }
            files.sort { $0.lastPathComponent < $1.lastPathComponent }
            var samples: [RecordedRouteSample] = [], historyID: UUID?
            var totalBytes = 0
            for file in files {
                guard try file.resourceValues(forKeys: [.isRegularFileKey]).isRegularFile == true else { throw RecordedRouteError.invalidArchive }
                let handle = try FileHandle(forReadingFrom: file)
                let data: Data
                do { data = try handle.read(upToCount: 131_073) ?? Data(); try handle.close() }
                catch { try? handle.close(); throw error }
                guard !data.isEmpty, data.count <= 131_072 else { throw RecordedRouteError.invalidArchive }
                totalBytes += data.count
                guard totalBytes <= maximumArchiveBytes else { throw RecordedRouteError.invalidArchive }
                let chunk = try JSONDecoder().decode(Chunk.self, from: data)
                guard chunk.startIndex == samples.count, !chunk.samples.isEmpty, chunk.samples.count <= 25,
                      historyID.map({ $0 == chunk.historyID }) ?? true,
                      file.lastPathComponent == String(format: "%08d.json", chunk.startIndex) else { throw RecordedRouteError.invalidArchive }
                historyID = chunk.historyID; samples += chunk.samples
                guard samples.count <= RecordedRouteHistory.maximumSamples else { throw RecordedRouteError.invalidArchive }
            }
            if let historyID { history = try RecordedRouteHistory(id: historyID, archivedSamples: samples) }
            durableSampleCount = samples.count; chunkCount = files.count; totalDurableBytes = totalBytes
        } catch { loadFailed = true } // Never silently overwrite unreadable history.
    }
    private func save() throws {
        guard loaded, !loadFailed, durableSampleCount < history.samples.count else { return }
        var directory = url.deletingLastPathComponent()
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        var values = URLResourceValues(); values.isExcludedFromBackup = true
        try directory.setResourceValues(values)
        #if os(iOS)
        try FileManager.default.setAttributes([.protectionKey: FileProtectionType.completeUntilFirstUserAuthentication], ofItemAtPath: directory.path)
        #endif
        // Immutable <=25-sample chunks, <=4 writes per call, no whole-ring rewrite.
        // Token budget survives session changes/deletion; failures spend credit.
        for _ in 0..<4 {
            guard durableSampleCount < history.samples.count else { budgetDeferred = false; return }
            guard chunkCount < 1000 else { persistenceCapacityReached = true; return }
            let end = min(history.samples.count, durableSampleCount + 25)
            let data = try JSONEncoder().encode(Chunk(historyID: history.id, startIndex: durableSampleCount,
                samples: Array(history.samples[durableSampleCount..<end])))
            guard data.count <= 131_072 else { throw RecordedRouteError.invalidArchive }
            guard totalDurableBytes <= maximumArchiveBytes - data.count else { persistenceCapacityReached = true; return }
            guard budget.charge(bytes: data.count, now: now()) == .admitted else { budgetDeferred = true; return }
            budgetDeferred = false
            let destination = directory.appendingPathComponent(String(format: "%08d.json", durableSampleCount))
            #if os(iOS)
            try data.write(to: destination, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
            #else
            try data.write(to: destination, options: [.atomic])
            #endif
            durableSampleCount = end; chunkCount += 1; totalDurableBytes += data.count
        }
    }
}
