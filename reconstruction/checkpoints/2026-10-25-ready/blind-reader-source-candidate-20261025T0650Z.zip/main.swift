import Foundation
 enum ReadingTool: CaseIterable { case liveText, document, barcode, light }
 enum Hazard { case observing, uncertain, urgent;var isUrgent:Bool {self == .urgent} }
 struct Detection { var hazard: Hazard = .observing }
 struct Session { var generation:UInt64=1; var foregroundActive=true,shouldRunCamera=true,mayRespond=true,privateAudioHeld=false }
 enum Tracking { case normal, limited }
 struct Matrix { var columns=(SIMD4<Float>(0,0,0,0),SIMD4<Float>(0,0,0,0),SIMD4<Float>(0,0,1,0),SIMD4<Float>(0,0,0,1)) }
 struct Camera { var trackingState:Tracking = .normal;var transform=Matrix() }
 struct Frame { var timestamp=ProcessInfo.processInfo.systemUptime;var camera=Camera() }
 typealias ARFrame=Frame
 struct ARSession { var currentFrame:Frame?=Frame() }
 enum Orientation { case portrait, landscape }
 class Scene {}
 class UIWindowScene: Scene { var interfaceOrientation:Orientation = .portrait }
 class UIApplication { static let shared=UIApplication(); var connectedScenes:[Scene]=[UIWindowScene()] }
public enum FrameTimestampPolicy {
    public static func isFresh(capturedAt: Double, receivedAt: Double) -> Bool {
        capturedAt.isFinite && receivedAt.isFinite && capturedAt >= 0 &&
            receivedAt >= capturedAt && receivedAt - capturedAt <= 0.5
    }
}

 struct Places { var scanning=false }
 struct Feedback { func stopInformation(announceCancellation: Bool)->Bool {true} }
import Foundation

/// Request identity, not tool equality, owns asynchronous reading work. This also fences
/// Stop -> restart of the same tool. Durations are policy bounds, not measured device latency.
public struct ReadingWorkSession: Sendable {
    public private(set) var token = UUID()
    public private(set) var active = false
    public init() {}
    @discardableResult public mutating func begin() -> UUID {
        token = UUID(); active = true; return token
    }
    public mutating func cancel() { token = UUID(); active = false }
    public func owns(_ candidate: UUID) -> Bool { active && token == candidate }
    public func accepts(_ candidate: UUID, capturedAt: Double, now: Double) -> Bool {
        owns(candidate) && capturedAt.isFinite && now.isFinite && now >= capturedAt && now - capturedAt < 0.5
    }
}


 struct Point3 { var x:Double=0,y:Double=0,z:Double=0;init(_ x:Double=0,_ y:Double=0,_ z:Double=0){self.x=x;self.y=y;self.z=z} }
 struct Document { mutating func reset(){} }
 struct LiveTextReader {}
 struct Journeys {mutating func breakTracking(){} }
 final class NativeWitness {
 var running=true,simulation=false,arabic=false,readingInFlight=false,cameraAwareness=true
 var readingTask:Task<Void,Never>?;var documentOrigin:Point3?;var documentChunks:[String]=[];var documentSpeechID:UUID?;var journeys=Journeys()
 var session=ARSession(),requestID=UUID(),passiveObservationGeneration=UUID();var poseStable=true
 func visualCapturePoseAllowed(origin:Point3,forward:Point3)->Bool {poseStable}
 var places=Places(),assistantSession=Session(),detection=Detection(),feedback=Feedback(),readingWork=ReadingWorkSession(),documentStability=Document()
 var readingTool:ReadingTool?,lastReadingLook:Double=0,readingStarted:Double=0,lastDocumentGuidance:String?,lastLightLevel:String?
 var liveTextReader=LiveTextReader(),spoken:[String]=[]
 func cancelDescription(){readingTool=nil;readingWork.cancel()}
 func speakOperation(_ text:String){spoken.append(text)}
 func startReadingTool(_ tool: ReadingTool) {
        // Switching tools invalidates model, currency, colour, face and earlier reader work first.
        cancelDescription()
        _ = feedback.stopInformation(announceCancellation: false)
        #if BLIND_FAMILIAR_PEOPLE
        familiarPeople.cancelSearchForNewGoal()
        #endif
        guard readingCameraAllowed() else {
            speakOperation(arabic ? "أحتاج كاميرا جاهزة وتنبيهات مستقرة لهذا. شغّل الكاميرا أولاً." : "I need a ready camera and stable monitoring for that. Turn the camera on first.")
            return
        }
        readingWork.begin()
        readingTool = tool; readingInFlight = false; lastReadingLook = -.infinity
        readingStarted = ProcessInfo.processInfo.systemUptime
        liveTextReader = LiveTextReader(); lastDocumentGuidance = nil; documentStability.reset(); lastLightLevel = nil
        let intro: String
        switch tool {
        case .liveText: intro = arabic ? "أقرأ النص الذي أراه. قل: أوقف القراءة، للتوقف." : "Reading text as I see it. Say stop reading to stop."
        case .document: intro = arabic ? "أتحقق من الصفحة." : "I'm checking the page."
        case .barcode: intro = arabic ? "أبحث عن رمز المنتج." : "I'm checking for a product code."
        case .light: intro = arabic ? "كاشف الضوء يعمل. الصفير أسرع كلما زاد الضوء." : "Light detector on. Faster beeps mean more light."
        }
        speakOperation(intro)
    }
 func stopReadingTool(announce: Bool) {
        let hadDocumentSpeech = documentSpeechID != nil
        readingWork.cancel(); readingTask?.cancel(); readingTask = nil
        readingTool = nil; readingInFlight = false; documentStability.reset(); documentOrigin = nil
        documentChunks = []; documentSpeechID = nil
        // Invalidate ownership before synchronous interruption callbacks can run.
        if hadDocumentSpeech { _ = feedback.stopInformation(announceCancellation: false) }
        if announce {
            _ = feedback.stopInformation(announceCancellation: false)
            // Speech onset or command dispatch may already have cancelled the reader.
            speakOperation(arabic ? "توقفت القراءة." : "Stopped reading.")
        }
    }
 func rawTracking(_ frame:ARFrame){ 
        // Tracking loss retires the issuer even when this frame is throttled below.
        if case .normal = frame.camera.trackingState {} else {
            journeys.breakTracking()
            // Retire old OCR even if depth was already unavailable and the hazard
            // category does not change. This runs before frame throttling.
            if readingTool != nil { stopReadingTool(announce: false) }
        }
         }
 func completeDocument(_ capture:ReadingCapture)->Bool {
 let callback:()->Bool = { [weak self] in guard let self, self.readingWork.owns(capture.token) else { return false }
            self.readingInFlight = false; self.readingTask = nil
            guard !Task.isCancelled, self.readingTool == .document, self.readingCaptureAllowed(capture) else {
                self.documentStability.reset(); return false
            }
             return true }
 return callback()
 }
 func readingCameraAllowed() -> Bool {
        let now = ProcessInfo.processInfo.systemUptime
        guard assistantSession.shouldRunCamera, assistantSession.mayRespond, cameraAwareness,
              assistantSession.foregroundActive, !assistantSession.privateAudioHeld,
              running, !simulation, !places.scanning, !detection.hazard.isUrgent,
              let frame = session.currentFrame,
              FrameTimestampPolicy.isFresh(capturedAt: frame.timestamp, receivedAt: now),
              UIApplication.shared.connectedScenes.compactMap({ $0 as? UIWindowScene }).contains(where: { $0.interfaceOrientation == .portrait }) else { return false }
        if case .normal = frame.camera.trackingState { return true }
        return false
    }
struct ReadingCapture {
        let token: UUID
        let request: UUID
        let generation: UUID
        let sessionGeneration: UInt64
        let capturedAt: Double
        let origin: Point3
        let forward: Point3
    }
func readingCapture(frame: ARFrame) -> ReadingCapture? {
        guard readingCameraAllowed(), case .normal = frame.camera.trackingState,
              FrameTimestampPolicy.isFresh(capturedAt: frame.timestamp, receivedAt: ProcessInfo.processInfo.systemUptime) else { return nil }
        let transform = frame.camera.transform
        return ReadingCapture(token: readingWork.token, request: requestID, generation: passiveObservationGeneration,
            sessionGeneration: assistantSession.generation, capturedAt: frame.timestamp,
            origin: Point3(Double(transform.columns.3.x), Double(transform.columns.3.y), Double(transform.columns.3.z)),
            forward: Point3(-Double(transform.columns.2.x), -Double(transform.columns.2.y), -Double(transform.columns.2.z)))
    }
func readingCaptureAllowed(_ capture: ReadingCapture) -> Bool {
        readingCameraAllowed() && assistantSession.generation == capture.sessionGeneration &&
        requestID == capture.request && passiveObservationGeneration == capture.generation &&
        readingWork.accepts(capture.token, capturedAt: capture.capturedAt, now: ProcessInfo.processInfo.systemUptime) &&
        visualCapturePoseAllowed(origin: capture.origin, forward: capture.forward)
    }
 }
 var checks=0,failures=0
 func check(_ ok:Bool,_ name:String){checks += 1;if !ok{failures += 1;print("FAIL: \(name)")}}
 for tool in ReadingTool.allCases {
 let rgb=NativeWitness();rgb.detection.hazard = .uncertain;rgb.startReadingTool(tool)
 check(rgb.readingTool == tool,"Fresh RGB-only request should admit nonspatial reader \(tool)")
 let spatial=NativeWitness();spatial.startReadingTool(tool)
 check(spatial.readingTool == tool,"Observing positive control \(tool)")
 let hazard=NativeWitness();hazard.detection.hazard = .urgent;hazard.startReadingTool(tool)
 check(hazard.readingTool == nil,"Urgent hazard blocks reader \(tool)")
 let background=NativeWitness();background.assistantSession.foregroundActive=false;background.startReadingTool(tool)
 check(background.readingTool == nil,"Background blocks reader \(tool)")
 }
 for mode in 0..<9 {
 let m=NativeWitness()
 if mode==0 {m.session.currentFrame=nil}
 if mode==1 {m.session.currentFrame?.timestamp -= 5}
 if mode==2 {m.session.currentFrame?.camera.trackingState = .limited}
 if mode==3 {m.assistantSession.privateAudioHeld=true}
 if mode==4 {m.cameraAwareness=false}
 if mode==5 {m.assistantSession.shouldRunCamera=false}
 if mode==6 {m.assistantSession.mayRespond=false}
 if mode==7 {m.places.scanning=true}
 if mode==8 {m.simulation=true}
 m.startReadingTool(.liveText)
 if true {check(m.readingTool == nil,"Invalid RGB/private/camera state blocks reader")}
 }
 
 for mode in 0..<6 {
 let m=NativeWitness();m.startReadingTool(.document)
 let capture=m.readingCapture(frame:Frame())!
 m.readingInFlight=true
 if mode==1 {m.stopReadingTool(announce:false);m.startReadingTool(.document);m.readingInFlight=true}
 if mode==2 {m.assistantSession.foregroundActive=false}
 if mode==3 {m.assistantSession.privateAudioHeld=true}
 if mode==4 {m.requestID=UUID()}
 if mode==5 {m.passiveObservationGeneration=UUID()}
 check(m.completeDocument(capture) == (mode==0),"Actual delayed document continuation rechecks lifecycle/capture owner")
 if mode==1 {check(m.readingInFlight,"Old stop/restart callback cannot clear new in-flight owner")}
 }
 do {
 let m=NativeWitness();m.startReadingTool(.document)
 let old=NativeWitness.ReadingCapture(token:m.readingWork.token,request:m.requestID,generation:m.passiveObservationGeneration,sessionGeneration:m.assistantSession.generation,capturedAt:ProcessInfo.processInfo.systemUptime-1,origin:Point3(),forward:Point3())
 check(!m.completeDocument(old),"Document OCR past existing0.5s lease cannot deliver")
 }
 do {
 let m=NativeWitness();m.detection.hazard = .uncertain;m.startReadingTool(.liveText)
 let a=Frame();let capture=m.readingCapture(frame:a)!
 m.rawTracking(a)
 check(m.readingCaptureAllowed(capture),"Normal RGB with unavailable depth retains deferred request")
 var loss=Frame();loss.camera.trackingState = .limited;m.rawTracking(loss)
 m.session.currentFrame=Frame()
 check(!m.readingCaptureAllowed(capture),"Transient raw tracking loss before throttle retires deferred A despite normal recovered B")
 check(m.readingTool == nil,"Tracking loss uses existing reader cancellation, not false continued reading")
 }
 for mode in 0..<4 {
 let m=NativeWitness();m.startReadingTool(.liveText);var source=Frame()
 if mode==1 {source.camera.trackingState = .limited}
 if mode==2 {source.timestamp -= 5}
 if mode==3 {source.timestamp += 5}
 check((m.readingCapture(frame:source) != nil) == (mode==0),"Source frame independently requires normal tracking and freshness despite fresh normal current frame")
 }
 for mode in 0..<8 {
 let m=NativeWitness();m.startReadingTool(.liveText)
 let capture=NativeWitness.ReadingCapture(token:m.readingWork.token,request:m.requestID,generation:m.passiveObservationGeneration,sessionGeneration:m.assistantSession.generation,capturedAt:ProcessInfo.processInfo.systemUptime - (mode==1 ? 5:0),origin:Point3(),forward:Point3())
 if mode==2 {m.requestID=UUID()}
 if mode==3 {m.passiveObservationGeneration=UUID()}
 if mode==4 {m.assistantSession.generation += 1}
 if mode==5 {m.readingWork.cancel()}
 if mode==6 {m.poseStable=false}
 if mode==7 {m.detection.hazard = .urgent}
 check(m.readingCaptureAllowed(capture) == (mode==0),"Exact RGB capture ownership, freshness and pose")
 }
 
 print("\(checks) actual native start checks; \(failures) expected RGB failures")
 exit(failures == 0 ? 0:1)
