from pathlib import Path
import difflib
r=Path('/workspace/shared/blind-reader-stage');s=(r/'native-preimage.swift').read_text();n=s
# Keep depth-only loss from cancelling RGB reading ownership; full invalidation still does.
a='if currencyActive || (!preserveRGBHistoryWork && colorActive) || readingTool != nil || currencyRetake.isPending { cancelDescription() }'
b='if currencyActive || (!preserveRGBHistoryWork && (colorActive || readingTool != nil)) || currencyRetake.isPending { cancelDescription() }'
assert n.count(a)==1;n=n.replace(a,b)
a='        updateBackgroundPerception(frame: frame, observation: pose, nonspatialOnly: true)';assert n.count(a)==1;n=n.replace(a,'        updateReadingTool(frame: frame)\n'+a)
a='''        guard running, !simulation, !places.scanning, assistantSession.foregroundActive,
              detection.hazard == .observing else {''';assert n.count(a)==1;n=n.replace(a,'        guard readingCameraAllowed() else {')
a='''        let observation: Observation
        let mapRevision: UUID
        let alignmentRevision: UUID'''
start=n.index('    private struct ReadingCapture {');end=n.index('    private func updateReadingTool(',start)
old=n[start:end]
new='''    /// Nonspatial reading requires a fresh tracked RGB camera, not depth/floor/map validity.
    /// Shared session/privacy and urgent sensor warnings still own admission.
    private func readingCameraAllowed() -> Bool {
        let now = ProcessInfo.processInfo.systemUptime
        guard assistantSession.shouldRunCamera, assistantSession.mayRespond, cameraAwareness,
              assistantSession.foregroundActive, !assistantSession.privateAudioHeld,
              running, !simulation, !places.scanning, !detection.hazard.isUrgent,
              let frame = session.currentFrame,
              FrameTimestampPolicy.isFresh(capturedAt: frame.timestamp, receivedAt: now),
              UIApplication.shared.connectedScenes.compactMap({ $0 as? UIWindowScene }).contains(where: { $0.interfaceOrientation == .portrait }) else { return false }
        if case .normal = frame.camera.trackingState { return true }
        return false
    }

    private struct ReadingCapture {
        let token: UUID
        let request: UUID
        let generation: UUID
        let sessionGeneration: UInt64
        let capturedAt: Double
        let origin: Point3
        let forward: Point3
    }

    private func readingCapture(frame: ARFrame) -> ReadingCapture? {
        guard readingCameraAllowed(), case .normal = frame.camera.trackingState,
              FrameTimestampPolicy.isFresh(capturedAt: frame.timestamp, receivedAt: ProcessInfo.processInfo.systemUptime) else { return nil }
        let transform = frame.camera.transform
        return ReadingCapture(token: readingWork.token, request: requestID, generation: passiveObservationGeneration,
            sessionGeneration: assistantSession.generation, capturedAt: frame.timestamp,
            origin: Point3(Double(transform.columns.3.x), Double(transform.columns.3.y), Double(transform.columns.3.z)),
            forward: Point3(-Double(transform.columns.2.x), -Double(transform.columns.2.y), -Double(transform.columns.2.z)))
    }

    private func readingCaptureAllowed(_ capture: ReadingCapture) -> Bool {
        readingCameraAllowed() && assistantSession.generation == capture.sessionGeneration &&
        requestID == capture.request && passiveObservationGeneration == capture.generation &&
        readingWork.accepts(capture.token, capturedAt: capture.capturedAt, now: ProcessInfo.processInfo.systemUptime) &&
        visualCapturePoseAllowed(origin: capture.origin, forward: capture.forward)
    }

'''
n=n[:start]+new+n[end:]
a='''              readingWork.active, assistantSession.foregroundActive, running, !simulation,
              detection.hazard == .observing, !voice.awaitingUtterance, feedback.speechPriority == nil else { return }'''
b='''              readingWork.active, readingCameraAllowed(),
              !voice.awaitingUtterance, feedback.speechPriority == nil else { return }'''
assert n.count(a)==1;n=n.replace(a,b)
a='if case .normal = frame.camera.trackingState {} else { journeys.breakTracking() }'
b='''if case .normal = frame.camera.trackingState {} else {
            journeys.breakTracking()
            // Retire old OCR even if depth was already unavailable and the hazard
            // category does not change. This runs before frame throttling.
            if readingTool != nil { stopReadingTool(announce: false) }
        }'''
assert n.count(a)==1;n=n.replace(a,b)
(r/'candidate.swift').write_text(n);(r/'reader.patch').write_text(''.join(difflib.unified_diff(s.splitlines(True),n.splitlines(True),fromfile='a/ios/BlindAssist/NavigationModel.swift',tofile='b/ios/BlindAssist/NavigationModel.swift')))
