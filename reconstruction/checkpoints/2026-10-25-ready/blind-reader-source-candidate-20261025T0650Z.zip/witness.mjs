import {readFileSync,writeFileSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
import assert from 'node:assert/strict';
const root='/workspace/shared/blind-reader-stage';
const native=readFileSync('/workspace/shared/blind-reader-stage/native-preimage.swift','utf8');
function fn(sig){let start=native.indexOf(sig);assert.ok(start>=0);let brace=native.indexOf('{',start),depth=0;for(let i=brace;i<native.length;i++){if(native[i]==='{')depth++;if(native[i]==='}'&&!--depth)return native.slice(start,i+1);}throw Error(sig);}
const start=fn('func startReadingTool(');
const rgb=fn('private func updateNonspatialObjectMemory(');
assert.ok(!rgb.includes('updateReadingTool('),'RGB callback currently does not tick explicit reader');
const harness=`import Foundation
 enum ReadingTool: CaseIterable { case liveText, document, barcode, light }
 enum Hazard { case observing, uncertain, urgent }
 struct Detection { var hazard: Hazard = .observing }
 struct Session { var foregroundActive=true }
 struct Places { var scanning=false }
 struct Feedback { func stopInformation(announceCancellation: Bool)->Bool {true} }
 struct Work { var active=false;mutating func begin(){active=true} }
 struct Document { mutating func reset(){} }
 struct LiveTextReader {}
 final class NativeWitness {
 var running=true,simulation=false,arabic=false,readingInFlight=false
 var places=Places(),assistantSession=Session(),detection=Detection(),feedback=Feedback(),readingWork=Work(),documentStability=Document()
 var readingTool:ReadingTool?,lastReadingLook:Double=0,readingStarted:Double=0,lastDocumentGuidance:String?,lastLightLevel:String?
 var liveTextReader=LiveTextReader(),spoken:[String]=[]
 func cancelDescription(){readingTool=nil;readingWork.active=false}
 func speakOperation(_ text:String){spoken.append(text)}
 ${start}
 }
 var checks=0,failures=0
 func check(_ ok:Bool,_ name:String){checks += 1;if !ok{failures += 1;print("FAIL: \\(name)")}}
 for tool in ReadingTool.allCases {
 let rgb=NativeWitness();rgb.detection.hazard = .uncertain;rgb.startReadingTool(tool)
 check(rgb.readingTool == tool,"Fresh RGB-only request should admit nonspatial reader \\(tool)")
 let spatial=NativeWitness();spatial.startReadingTool(tool)
 check(spatial.readingTool == tool,"Observing positive control \\(tool)")
 let hazard=NativeWitness();hazard.detection.hazard = .urgent;hazard.startReadingTool(tool)
 check(hazard.readingTool == nil,"Urgent hazard blocks reader \\(tool)")
 let background=NativeWitness();background.assistantSession.foregroundActive=false;background.startReadingTool(tool)
 check(background.readingTool == nil,"Background blocks reader \\(tool)")
 }
 print("\\(checks) actual native start checks; \\(failures) expected RGB failures")
 exit(failures == 4 ? 0:1)
`;
writeFileSync(root+'/main.swift',harness);writeFileSync(root+'/native-preimage.swift',native);
execFileSync('/workspace/shared/swift-toolchain/install/swift-6.4.1-RELEASE-debian13/usr/bin/swiftc',['-j','2','-module-cache-path',root+'/cache',root+'/main.swift','-o',root+'/witness'],{stdio:'inherit'});
execFileSync(root+'/witness',[],{stdio:'inherit'});
