import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile, readdir, writeFile, mkdir } from 'node:fs/promises';
import { resolve, join } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { createHash } from 'node:crypto';
const stage = resolve(fileURLToPath(new URL('..', import.meta.url)));
const repo = process.env.BLIND_REPO ?? '/workspace/shared/blind-rebuild';
const read = path => readFile(join(stage, path), 'utf8');
const adapter = await read('native/NativeARObservationAdapter.swift');
const pipeline = await read('Sources/BlindCore/NativeObservationPipeline.swift');
const bridge = await read('native/NativeARObservationBridge.swift');
const model = await read('native-proposal/ios/BlindAssist/NavigationModel.swift');

test('native extraction reuses the existing sensor feed without image/model/new-session calls', () => {
  assert.doesNotMatch(adapter, /capturedImage|session\.run|Task\s*\{|VisionService|generateResponse/);
  assert.match(adapter, /frame\.camera\.transform/); assert.match(adapter, /frame\.camera\.intrinsics/);
  assert.match(adapter, /frame\.sceneDepth/); assert.match(adapter, /context\.sessionID/);
  assert.match(adapter, /supportsSceneReconstruction\(\.meshWithClassification\)/);
  assert.match(adapter, /supportsSceneReconstruction\(\.mesh\)/);
  assert.match(model, /NativeARObservationAdapter\.configureObservedGeometry\(configuration\)/);
});
test('anchor, vertex, depth and face work have explicit bounds before copying', () => {
  assert.match(adapter, /anchorSnapshot\.prefix\(128\)\.filter/);
  assert.match(adapter, /anchors\.prefix\(32\)/); assert.match(adapter, /remainingVertices = 2048/);
  assert.match(adapter, /min\(512, maximumVertices \/ 3\)/);
  assert.match(adapter, /originalSurfaceCount: inspectionTruncated \? nil/);
  assert.match(adapter, /while \(\(width \+ step - 1\) \/ step\).* > 1024/);
  assert.match(adapter, /source\.offset \+ \(source\.count - 1\) \* source\.stride \+ 12 <= source\.buffer\.length/);
  assert.match(adapter, /source\.offset \+ \(source\.count - 1\) \* source\.stride \+ 1 <= source\.buffer\.length/);
  assert.doesNotMatch(adapter, /geometry\.classificationOf\(/);
});
test('producer admission is one-slot and bounded before scheduling', () => {
  const offer = pipeline.slice(pipeline.indexOf('@discardableResult public func offer'), pipeline.indexOf('public func stop'));
  assert.ok(offer.indexOf('lock.try()') < offer.indexOf('queue.async'));
  assert.ok(offer.indexOf('guard !busy') < offer.indexOf('queue.async'));
  assert.match(offer, /current\(token\), fresh\(capturedAt\)/);
  assert.match(pipeline, /guard !controlPending/); assert.match(pipeline, /guard !readPending/);
  assert.match(pipeline, /lockContentionDropsCounted = false/);
});
test('raw history has no model-memory or localization-lease export', async () => {
  assert.match(bridge, /memory\.makeNativeObservationStore\(\)/);
  assert.doesNotMatch(bridge, /saveValue|deleteValue|memory\.value\(/);
  assert.doesNotMatch(bridge, /acceptRegisteredCapture|SpatialLocalizationCapture|SpatialOutputLease|readHistory/);
  const retrieval = await readFile(join(repo, 'BlindCore/Sources/BlindCore/CompanionMemoryRetrieval.swift'), 'utf8');
  assert.doesNotMatch(retrieval, /native-observations|NativeObservationHistory/);
});
test('capture hook is deferred and existing camera lifecycle retires the consumer', () => {
  assert.match(model, /defer \{\s*if running, !simulation, !places\.scanning, assistantSession\.foregroundActive, cameraAwareness,[\s\S]*nativeObservations\.offer/);
  assert.match(model, /private func stopCameraMonitoring\(\) \{\s*nativeObservations\.stop\(\)/);
  assert.match(model, /func sessionWasInterrupted\(_ session: ARSession\) \{\s*nativeObservations\.stop\(\)/);
  assert.match(model, /nativeObservations\.stop\(\)\s*places\.startScan/);
});
test('privacy entry fences precede the asynchronous writer and item success is asynchronous', () => {
  for (const name of ['clearObservedObjects', 'deletePlace', 'forgetRoom', 'forgetItem']) {
    const start = model.indexOf(`func ${name}(`);
    const purge = model.indexOf('nativeObservations.clearHistory', start);
    assert.ok(model.indexOf('invalidatePerceptionWork()', start) < purge, name);
    assert.ok(model.indexOf('purgeDebugSessionDiagnostics()', start) < purge, name);
  }
  assert.match(model, /func forgetItem\(_ item: RememberedItem, completion:/);
  assert.match(model, /self\.itemMemoryRevision == deletionRevision/);
  assert.match(model, /forgetItem\(saved\) \{[\s\S]*success, self\.requestID == deletionRequest/);
});
test('actual project generator includes both native files in the source build phase', async () => {
  const { generateProject } = await import(pathToFileURL(join(repo, 'tools/generate-xcode-project.mjs')).href);
  const files = [...new Set([...(await readdir(join(repo, 'ios/BlindAssist'))).filter(f => f.endsWith('.swift')),
    'NativeARObservationAdapter.swift', 'NativeARObservationBridge.swift'])].sort();
  const project = generateProject(files);
  for (const file of ['NativeARObservationAdapter.swift', 'NativeARObservationBridge.swift']) {
    const buildID = createHash('sha256').update(`build:${file}`).digest('hex').slice(0,24).toUpperCase();
    assert.match(project, new RegExp(`${buildID} = \\{ isa = PBXBuildFile`));
    assert.ok(project.includes(`BlindAssist/${file}`));
    assert.ok(project.match(/isa = PBXSourcesBuildPhase[^}]+/g).some(phase => phase.includes(buildID)));
  }
  await mkdir(join(stage, 'native-proposal/ios/BlindAssist.xcodeproj'), { recursive: true });
  await writeFile(join(stage, 'native-proposal/ios/BlindAssist.xcodeproj/project.pbxproj'), project);
});

test('durability is incremental and does not own the extraction slot or history reader', async () => {
  const history = await read('Sources/BlindCore/NativeObservation.swift');
  assert.match(history, /payloadByteCount/); assert.match(history, /encodedRecords/);
  assert.doesNotMatch(pipeline, /history\.encoded\(|storage\.save/);
  assert.match(pipeline, /writer\.async/); assert.match(pipeline, /queue\.async/);
  assert.match(pipeline, /writeInFlight/); assert.match(pipeline, /pendingBatchReplacements/);
  assert.match(pipeline, /volatileRecordIDs/); assert.match(pipeline, /logicalBytesSubmitted/);
});
test('raw observation SQL uses a separate GRDB file, not the ordinary memory writer', async () => {
  const memory = await read('BlindMemory/Sources/BlindMemory/MemoryStore.swift');
  const store = await read('BlindMemory/Sources/BlindMemory/NativeObservationStore.swift');
  assert.match(memory, /path \+ "\.native-observations\.sqlite"/);
  assert.match(store, /DatabaseQueue\(path: path/);
  assert.doesNotMatch(store, /INSERT INTO memoryValue|UPDATE memoryValue/);
  assert.doesNotMatch(memory, /case "native-observations"/);
});

test('default raw durability budget is separate and Release has no unbounded native selection', async () => {
  const policy = await read('Sources/BlindCore/NativeObservationDurabilityBudget.swift');
  assert.match(policy, /validatedBytesPerInterval: 131_072, intervalSeconds: 60, burstBytes: 131_072/);
  assert.match(pipeline, /durability: DurabilityPolicy = \.budgeted\(\.provisionalDefault\)/);
  assert.match(pipeline, /#if DEBUG\s*\/\/\/ Verification only;[\s\S]*case unboundedForTesting/);
  assert.doesNotMatch(bridge, /unboundedForTesting/);
  assert.doesNotMatch(policy, /Date\(|TimeZone|Timer|Dispatch/);
  assert.match(policy, /highWater/);
});
test('budget exhaustion has one freshest pending record, no timer queue and explicit volatile reasons', () => {
  assert.match(pipeline, /private var pending: \(token: UUID, record: NativeObservationEncodedRecord\)\?/);
  assert.doesNotMatch(pipeline, /asyncAfter|DispatchWorkItem|Timer\(|DispatchSource/);
  assert.match(pipeline, /case pending, budgetExhausted, oversizedRecord, clockUnavailable, writeFailed/);
  assert.match(pipeline, /budgetClockInvalidationPending/);
  assert.match(pipeline, /logicalBytesSubmitted \+= candidate\.record\.encodedBytes/);
  const clear = pipeline.slice(pipeline.indexOf('public func clear('), pipeline.indexOf('public func readSnapshot'));
  assert.doesNotMatch(clear, /budget\.charge|budget =|durability =/);
});
