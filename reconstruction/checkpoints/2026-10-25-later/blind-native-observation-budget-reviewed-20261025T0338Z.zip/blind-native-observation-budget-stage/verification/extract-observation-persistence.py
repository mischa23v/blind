#!/usr/bin/env python3
"""Extract exact platform-independent bridge persistence code, never a mock backend."""
from pathlib import Path
import argparse
import hashlib
import json

root = Path(__file__).resolve().parent.parent
source_path = root / 'native/NativeARObservationBridge.swift'
output_path = root / 'Sources/NativeObservationPersistenceAdapter/NativeObservationPersistenceAdapter.extracted.swift'
manifest_path = root / 'verification/persistence-extraction.json'
source = source_path.read_text()


def extract(signature):
    start = source.index(signature)
    opening = source.index('{', start + len(signature) - 1)
    depth, index = 1, opening + 1
    # These two extracted regions contain no brace-bearing Swift string literals.
    # Fail closed if that assumption changes rather than silently extracting a stub.
    while depth:
        if index >= len(source):
            raise ValueError('Unterminated source region: ' + signature)
        if source[index] == '"':
            index += 1
            while index < len(source):
                if source[index] == '\\':
                    index += 2
                    continue
                if source[index] == '"':
                    break
                index += 1
        elif source[index:index + 2] == '//':
            index = source.index('\n', index)
        elif source[index] == '{':
            depth += 1
        elif source[index] == '}':
            depth -= 1
        index += 1
    return source[start:index]


owner = extract('    private final class ObservationStoreOwner {')
storage = extract('    private static func storage(_ memory: MemoryStore) -> NativeObservationStorage {')
public_storage = storage.replace('    private static func storage(', '    public static func storage(', 1)
output = '''import BlindCore
import BlindMemory
import Foundation

// Verification-only public shell. Owner and storage implementation below are extracted
// from native/NativeARObservationBridge.swift. Only storage access is widened for tests.
public final class NativeObservationPersistenceAdapter {
''' + owner + '\n' + public_storage + '\n}\n'
sha = lambda text: hashlib.sha256(text.encode()).hexdigest()
manifest = json.dumps({
    'source': str(source_path.relative_to(root)),
    'source_sha256': sha(source),
    'owner_region_sha256': sha(owner),
    'storage_region_sha256': sha(storage),
    'generated': str(output_path.relative_to(root)),
    'generated_sha256': sha(output),
    'changes': ['Wrap extracted members in a verification-only public class.',
                'Change storage method access from private to public.'],
}, indent=2) + '\n'
parser = argparse.ArgumentParser()
parser.add_argument('--check', action='store_true', help='Verify extraction without changing files.')
args = parser.parse_args()
if args.check:
    if output_path.read_text() != output or manifest_path.read_text() != manifest:
        raise SystemExit('Persistence extraction is stale; rerun this script.')
    print('Persistence extraction matches exact bridge source: ' + sha(output))
else:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(output)
    manifest_path.write_text(manifest)
    print('Extracted bridge persistence: ' + sha(output))
