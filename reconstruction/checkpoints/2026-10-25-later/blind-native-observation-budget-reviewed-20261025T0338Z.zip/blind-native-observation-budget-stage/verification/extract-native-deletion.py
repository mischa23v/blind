#!/usr/bin/env python3
from pathlib import Path
import hashlib
root=Path(__file__).resolve().parent.parent
source=(root/'native-proposal/ios/BlindAssist/NativeMapping.swift').read_text()
def extract(signature):
    start=source.index(signature); position=source.index('{',start+len(signature)-1); level=1; end=position+1
    while level:
        if source[end]=='{':level+=1
        elif source[end]=='}':level-=1
        end+=1
    return source[start:end]
revision='    private var mapLifecycleRevision = UUID()\n' if 'private var mapLifecycleRevision' in source else ''
body='''import Foundation
// Verification-only platform shell. Methods below are extracted exactly from the proposal.
final class NativeMapping {
    var active = false
    var status = ""
    var clearObservationHistory: ((@escaping (Bool) -> Void) -> Void)?
    private let storage: URL
    init(storage: URL) { self.storage = storage }
    private func refreshExport() {}
    private func purgeDebugSessionDiagnostics() {}
'''+revision+'\n'.join(extract(x) for x in ['    func deleteMap() {','    private func deleteMapFiles() {','    func start() {','    func stop() {'])+'\n}\n'
(root/'Sources/NativeObservationDeletionAdapter/NativeMapping.extracted.swift').write_text(body)
print('NativeMapping proposal SHA256 '+hashlib.sha256(source.encode()).hexdigest())
source=(root/'native-proposal/ios/BlindAssist/NavigationModel.swift').read_text()
body='''import Foundation
// Verification-only shell. Public deletion entry methods below are exact production-proposal text.
struct SavedPlace { let id: UUID }
struct RememberedItem { let key: String }
final class Places { var memory: Int? = 1 }
struct Recovery { mutating func reset() {} }
final class NativeHistory {
    var pending: ((Bool) -> Void)?
    func clearHistory(memory: Int?, completion: @escaping (Bool) -> Void) { pending = completion }
}
final class NavigationModel {
    let nativeObservations = NativeHistory()
    let places = Places()
    var recognizedPlace: SavedPlace?
    var awaitingPlace: SavedPlace?
    var learningItem: RememberedItem?
    var placeRecovery = Recovery()
    var placeRecoveryQuestion = ""
    var itemMemoryRevision = UUID()
    var perceptionRevision = UUID()
    var cluesInvalidated = false
    var cancelled = false
    var debugPurges = 0
    var destructiveCalls = 0
    var failures = 0
    var arabic = false
    func purgeDebugSessionDiagnostics() { debugPurges += 1 }
    func invalidatePerceptionWork() { perceptionRevision = UUID() }
    func invalidateAutomaticRoomClues() { cluesInvalidated = true }
    func invalidateRecognizedRoom() {}
    func cancelDescription() { cancelled = true }
    func say(_ text: String) { failures += 1 }
    private func clearObservedObjectsAfterNativePurge() { destructiveCalls += 1 }
    private func deletePlaceAfterNativePurge(_ place: SavedPlace) { destructiveCalls += 1 }
    private func forgetRoomAfterNativePurge(_ id: String) { destructiveCalls += 1 }
    private func forgetItemAfterNativePurge(_ item: RememberedItem) -> Bool { destructiveCalls += 1; return true }
'''+ '\n'.join(extract(x) for x in ['    func clearObservedObjects() {','    func deletePlace(_ place: SavedPlace) {','    func forgetRoom(_ id: String) {','    func forgetItem(_ item: RememberedItem, completion: @escaping (Bool) -> Void = { _ in }) {'])+'\n}\n'
(root/'Sources/NativeObservationDeletionAdapter/NavigationPrivacy.extracted.swift').write_text(body)
print('NavigationModel proposal SHA256 '+hashlib.sha256(source.encode()).hexdigest())
