#!/usr/bin/env python3
"""Reproduce the exact old-patch/new-base proof in an external temporary directory.

Usage: python check-rebase-preservation.py /path/to/original/reviewed/stage
Never modifies the original stage, current stage, or live checkout.
"""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import sys
import tempfile

stage = Path(__file__).resolve().parent.parent
old = Path(sys.argv[1]).resolve()
expected_base = '0e80e0f3a55c6d6121237bd0bbbcf96fb5de3977d658ede7674fbc53ac4b9ffc'
base_hash = hashlib.sha256((stage / 'native-baseline/ios/BlindAssist/NavigationModel.swift').read_bytes()).hexdigest()
assert base_hash == expected_base, 'Wrong photo-plus-clock baseline'

def payload(path):
    return [line for line in path.read_text().splitlines()
            if line[:1] in '+-' and not line.startswith(('---', '+++'))]

assert payload(old / 'native-integration.patch') == payload(stage / 'native-integration.patch')
results = {}
with tempfile.TemporaryDirectory(prefix='blind-observation-rebase-proof-') as temporary:
    probe = Path(temporary)
    shutil.copytree(stage / 'native-baseline', probe, dirs_exist_ok=True)
    for flags in [ ['--check'], [] ]:
        subprocess.run(['git', 'apply', *flags, str(old / 'native-integration.patch')], cwd=probe, check=True)
    for path in json.loads((stage / 'native-proposal-manifest.json').read_text()):
        proposed = (stage / 'native-proposal' / path).read_bytes()
        assert (probe / path).read_bytes() == proposed, path
        results[path] = hashlib.sha256(proposed).hexdigest()
print(json.dumps({
    'status': 'PASS; staged only',
    'newPhotoClockNavigationBaseSHA256': base_hash,
    'originalReviewedObservationPatchAppliesWithoutConflict': True,
    'originalReviewedPatchProducesByteIdenticalProposals': True,
    'observationAddRemovePayloadUnchanged': True,
    'proposedSHA256': results,
}, indent=2))
