import Foundation
var state: UInt64 = 0x31415926
func next() -> UInt64 {
    state = state &* 6_364_136_223_846_793_005 &+ 1_442_695_040_888_963_407
    return state
}
let configurations: [(Int, Double, Int)] = [(131072, 60, 131072), (4093, 0.7, 12345), (3, 0.1, 37), (2097152, 0.001, 2097152), (1, 86400, 1)]
for faults in [false, true] {
    for (index, config) in configurations.enumerated() {
        var bucket = NativeObservationDurabilityBudget(configuration: try .init(bytesPerInterval: config.0, intervalSeconds: config.1, burstBytes: config.2), now: 0)
        var highWater = 0.0
        print("config,\(faults ? "faults" : "monotonic")-\(index),\(config.0),\(config.1),\(config.2)")
        for iteration in 0..<10000 {
            let now: Double
            switch faults ? next() % 10 : 9 {
            case 0: now = .nan
            case 1: now = .infinity
            case 2: now = -1
            case 3: now = max(0, highWater - Double(next() % 5001) / 12345 * config.1)
            case 4: now = 0
            case 5: now = highWater
            default: now = highWater + Double(next() % 5001) / 12345 * config.1
            }
            if now.isFinite && now >= 0 { highWater = max(highWater, now) }
            let cost = iteration % 113 == 0 ? 0 : Int(next() % UInt64(config.2 + 1)) + 1
            let decision = bucket.charge(bytes: cost, now: now)
            print("sample,\(now),\(cost),\(decision),\(bucket.availableByteCredit)")
        }
    }
}
