from fractions import Fraction
import math
import sys
count = 0
admitted_count = 0
fault_count = 0
for line in open(sys.argv[1]):
    row = line.strip().split(',')
    if row[0] == 'config':
        _, index, byte_count, interval, burst = row
        rate = Fraction(int(byte_count)) / Fraction(float(interval))
        capacity = Fraction(int(burst))
        high_water = Fraction(0)
        recovery = False
        ideal = Fraction(0)
        continue
    _, time, cost, decision, available = row
    numeric_time = float(time)
    cost = int(cost)
    expected = None
    if not math.isfinite(numeric_time) or numeric_time < 0:
        ideal = Fraction(0)
        recovery = True
        expected = 'invalidClock'
    else:
        current = Fraction(numeric_time)
        if current < high_water:
            ideal = Fraction(0)
            recovery = True
            expected = 'invalidClock'
        elif recovery:
            high_water = current
            recovery = False
            expected = 'invalidClock'
        else:
            ideal = min(capacity, ideal + (current - high_water) * rate)
            high_water = current
            if cost <= 0:
                expected = 'invalidSize'
            elif cost > capacity:
                expected = 'oversizedRecord'
            elif ideal < cost:
                expected = 'insufficientCredit'
    if expected is not None:
        assert decision == expected, (index, count, decision, expected)
    else:
        assert decision in ('admitted', 'insufficientCredit'), (index, count, decision)
    if decision == 'admitted':
        assert ideal >= cost, (index, count, 'over-admitted')
        ideal -= cost
        admitted_count += 1
    if decision == 'invalidClock':
        fault_count += 1
    actual = Fraction(float(available))
    assert 0 <= actual <= ideal <= capacity, (index, count, actual, ideal)
    count += 1
print(f'PASS: {count} optimized Swift samples bounded by exact rational token-bucket oracle across 5 configurations, with and without clock faults; {admitted_count} admissions and {fault_count} invalid-clock decisions.')
