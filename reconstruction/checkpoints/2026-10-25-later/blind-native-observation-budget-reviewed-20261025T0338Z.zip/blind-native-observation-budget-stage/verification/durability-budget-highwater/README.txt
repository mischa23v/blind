High-water repair verification

20/20 focused Swift XCTest cases passed in an isolated package, jobs=1.
100000 optimized Swift samples passed an exact-rational arithmetic/state
oracle across five configurations, both monotonic and adversarial clocks.
The repaired original review probe no longer replays a refill after either
rollback or NaN followed by a lower timestamp.

The policy preserves a monotonic high-water mark through clock faults.
It clears credit, rejects timestamps below the high-water mark, and uses
only the first caught-up valid timestamp as a new origin (without refill).
Future forward time alone earns credit.

Reproducible isolated package and executable artifacts:
/tmp/native-observation-budget-highwater.jN0TIx/repaired
/tmp/native-observation-budget-highwater.jN0TIx/oracle-driver
/tmp/native-observation-budget-highwater.jN0TIx/oracle-samples.csv
/tmp/native-observation-budget-highwater.jN0TIx/repaired-probe

To repeat the oracle, compile the current policy together with a copy of
numeric-oracle-driver.swift named main.swift using swiftc -O, capture its
stdout, then run python3 check-oracle.py <captured-output.csv>.
A Foundation-free Swift standalone Linux probe additionally needs -lm.
The oracle samples remain external; their SHA-256/path is preserved here.

These are isolated policy results, not full-project integration, physical
storage amplification, battery, energy, or on-device measurements.
