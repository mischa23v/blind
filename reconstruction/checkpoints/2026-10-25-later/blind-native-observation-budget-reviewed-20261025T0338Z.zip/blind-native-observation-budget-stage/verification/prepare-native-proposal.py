#!/usr/bin/env python3
"""Generate staged diff from exact current source; never edit the active checkout."""
from pathlib import Path
import difflib, hashlib, json
repo = Path('/workspace/shared/blind-rebuild')
stage = Path(__file__).resolve().parent.parent
base = stage/'native-baseline'; proposal = stage/'native-proposal'
base.mkdir(exist_ok=True); proposal.mkdir(exist_ok=True)
expected_bases = {
    'ios/BlindAssist/NavigationModel.swift': '0e80e0f3a55c6d6121237bd0bbbcf96fb5de3977d658ede7674fbc53ac4b9ffc',
    'ios/BlindAssist/NativeMapping.swift': '5f41d4cedda028a797e45f584594ac3ca0e2148a8c2d7534cf145c4cd69584df',
    'ios/BlindAssist/IndoorNavigator.swift': '49d22518874ead33dc98d25154775f2d5c89152f71b0fb9c88de256a656bd818',
}
# Fail before writing anything if another owner has changed a shared source.
for path, expected in expected_bases.items():
    assert hashlib.sha256((repo/path).read_bytes()).hexdigest() == expected, ('Base changed; coordinate a narrow rebase', path)
manifest={}
def change(path, edit):
    old=(repo/path).read_text(); new=edit(old)
    assert new != old, path
    (base/path).parent.mkdir(parents=True,exist_ok=True); (proposal/path).parent.mkdir(parents=True,exist_ok=True)
    (base/path).write_text(old); (proposal/path).write_text(new)
    manifest[path]={'baseSHA256':hashlib.sha256(old.encode()).hexdigest(),'proposedSHA256':hashlib.sha256(new.encode()).hexdigest()}
    return ''.join(difflib.unified_diff(old.splitlines(keepends=True),new.splitlines(keepends=True),fromfile='a/'+path,tofile='b/'+path))
def replace(s,a,b,count=1):
    assert s.count(a)==count,(a,s.count(a)); return s.replace(a,b)
def nav(s):
    s=replace(s,'    let mapping = NativeMapping()','    let mapping = NativeMapping()\n    private let nativeObservations = NativeARObservationBridge()')
    s=replace(s,'        places.onScanFinished = { [weak self] in', '''        mapping.clearObservationHistory = { [weak self] completion in
            guard let self else { completion(false); return }
            self.nativeObservations.clearHistory(memory: self.places.memory, completion: completion)
        }
        indoor.clearObservationHistory = { [weak self] completion in
            guard let self else { completion(false); return }
            self.nativeObservations.clearHistory(memory: self.places.memory, completion: completion)
        }
        places.onScanFinished = { [weak self] in''')
    s=replace(s,'                self.session.run(configuration)\n                if self.buildPrivateMap', '''                NativeARObservationAdapter.configureObservedGeometry(configuration)
                if let sessionID = UUID(uuidString: self.observationFrameID) {
                    self.nativeObservations.begin(sessionID: sessionID, memory: self.places.memory)
                }
                self.session.run(configuration)
                if self.buildPrivateMap''')
    s=replace(s,'        session.delegate = self; session.run(configuration, options:', '        NativeARObservationAdapter.configureObservedGeometry(configuration)\n        nativeObservations.begin(sessionID: worldSessionID, memory: places.memory)\n        session.delegate = self; session.run(configuration, options:')
    s=replace(s,'    private func stopCameraMonitoring() {','    private func stopCameraMonitoring() {\n        nativeObservations.stop()')
    s=replace(s,'        let receivedAt = ProcessInfo.processInfo.systemUptime\n        guard FrameTimestampPolicy.isFresh', '        let receivedAt = ProcessInfo.processInfo.systemUptime\n        let receivedDate = Date()\n        guard FrameTimestampPolicy.isFresh')
    s=replace(s,'        lastProcessed = frame.timestamp; lastFrameWallTime = frame.timestamp', '''        // Deferred until the existing sensor/hazard callback has completed. This only
        // admits one utility job; it never samples depth, writes SQL or invokes a model here.
        defer {
            if running, !simulation, !places.scanning, assistantSession.foregroundActive, cameraAwareness,
               let nativeSessionID = UUID(uuidString: observationFrameID) {
                nativeObservations.offer(frame, sessionID: nativeSessionID,
                    mapTarget: indoor.registeredObservationMapTarget, receivedAt: receivedAt, receivedDate: receivedDate)
            }
        }
        lastProcessed = frame.timestamp; lastFrameWallTime = frame.timestamp''')
    for signature in ['    func session(_ session: ARSession, didFailWithError error: Error) {','    func sessionWasInterrupted(_ session: ARSession) {']:
        s=replace(s,signature,signature+'\n        nativeObservations.stop()')
    s=replace(s,'        places.startScan(session: session, name: name, compare:', '        nativeObservations.stop()\n        places.startScan(session: session, name: name, compare:')
    # Reuse existing privacy controls. Geometry has no reliable room assignment, so erase the
    # whole bounded observation window rather than guess which raw points belong to a room.
    for public, private, args, invocation in [
      ('clearObservedObjects','clearObservedObjectsAfterNativePurge','',''),
      ('deletePlace','deletePlaceAfterNativePurge','_ place: SavedPlace','place'),
      ('forgetRoom','forgetRoomAfterNativePurge','_ id: String','id')]:
        signature=f'    func {public}({args}) {{'
        fences = '''
        #if DEBUG
        purgeDebugSessionDiagnostics()
        #endif
        invalidatePerceptionWork()
'''
        if public in ['deletePlace', 'forgetRoom']:
            fences += '        invalidateAutomaticRoomClues()\n'
        if public == 'deletePlace':
            fences += '''        if recognizedPlace?.id == place.id { recognizedPlace = nil; invalidateRecognizedRoom() }
        if awaitingPlace?.id == place.id { awaitingPlace = nil; placeRecovery.reset(); placeRecoveryQuestion = "" }
'''
        wrapper=signature+fences+f'''
        nativeObservations.clearHistory(memory: places.memory) {{ [weak self] success in
            guard let self else {{ return }}
            guard success else {{
                self.say(self.arabic ? "لم يكتمل حذف سجل هندسة المشاهدات. أعد المحاولة." : "Observed geometry history could not be deleted. Please retry.")
                return
            }}
            self.{private}({invocation})
        }}
    }}
    private func {private}({args}) {{'''
        s=replace(s,signature,wrapper)
    s=replace(s,'            case .remember(let name):\n                let room = companion.currentRoom','            case .remember(let name):\n                itemMemoryRevision = UUID()\n                let room = companion.currentRoom')
    s=replace(s,'    @discardableResult func forgetItem(_ item: RememberedItem) -> Bool {', '''    func forgetItem(_ item: RememberedItem, completion: @escaping (Bool) -> Void = { _ in }) {
        #if DEBUG
        purgeDebugSessionDiagnostics()
        #endif
        itemMemoryRevision = UUID()
        invalidatePerceptionWork()
        cancelDescription()
        if learningItem?.key == item.key { learningItem = nil }
        let deletionRevision = itemMemoryRevision
        nativeObservations.clearHistory(memory: places.memory) { [weak self] success in
            guard let self else { completion(false); return }
            guard self.itemMemoryRevision == deletionRevision else { completion(false); return }
            guard success else {
                self.say(self.arabic ? "لم يكتمل حذف سجل هندسة المشاهدات. أعد المحاولة." : "Observed geometry history could not be deleted. Please retry.")
                completion(false); return
            }
            completion(self.forgetItemAfterNativePurge(item))
        }
    }
    private func forgetItemAfterNativePurge(_ item: RememberedItem) -> Bool {''')
    s=replace(s,'''                let saved = items.find(name)
                if let saved, !forgetItem(saved) { return true }
                let removed = saved != nil
                say(removed ? (arabic ? "نسيت \(name)." : "Forgot your \(name).") : (arabic ? "لا يوجد \(name) محفوظ." : "No saved \(name) to forget."))''', '''                guard let saved = items.find(name) else {
                    say(arabic ? "لا يوجد \(name) محفوظ." : "No saved \(name) to forget."); return true
                }
                let deletionRequest = requestID
                forgetItem(saved) { [weak self] success in
                    guard let self, success, self.requestID == deletionRequest else { return }
                    self.say(self.arabic ? "نسيت \(name)." : "Forgot your \(name).")
                }''')
    s=replace(s,'if companion.memory.rooms[roomID] != nil { forgetRoom(roomID) }', 'if companion.memory.rooms[roomID] != nil { forgetRoomAfterNativePurge(roomID) }')
    return s
def native_map(s):
    s=replace(s,'    private var lastFrame = -Double.infinity','    var clearObservationHistory: ((@escaping (Bool) -> Void) -> Void)?\n    private var mapLifecycleRevision = UUID()\n    private var lastFrame = -Double.infinity')
    s=replace(s,'        #endif\n        guard !active else { return }\n        do {', '''        #endif
        guard !active else { return }
        let expectedRevision = mapLifecycleRevision
        if let clearObservationHistory {
            clearObservationHistory { [weak self] success in
                guard let self else { return }
                // Check ownership before success OR failure can affect a newer map/UI.
                guard !self.active, self.mapLifecycleRevision == expectedRevision else { return }
                guard success else { self.status = "Observed geometry history could not be deleted. Please retry."; return }
                self.deleteMapFiles()
            }
        } else { deleteMapFiles() }
    }
    private func deleteMapFiles() {
        do {''')
    s=replace(s,'    func start() {','    func start() {\n        mapLifecycleRevision = UUID()')
    s=replace(s,'    func stop() {','    func stop() {\n        mapLifecycleRevision = UUID()')
    return s
def indoor(s):
    s=replace(s,'    var onSpatialOutputRetired: (() -> Void)?','    var onSpatialOutputRetired: (() -> Void)?\n    var clearObservationHistory: ((@escaping (Bool) -> Void) -> Void)?\n    /// Selected storage target only, never coordinate alignment or current-location evidence.\n    var registeredObservationMapTarget: SpatialMapBinding? { registered?.installation?.binding }')
    s=replace(s,'''        do {
            if FileManager.default.fileExists(atPath: storage.path) { try FileManager.default.removeItem(at: storage) }''','''        invalidatePosition()
        let expectedRevision = revision
        if let clearObservationHistory {
            clearObservationHistory { [weak self] success in
                guard let self else { return }
                guard self.revision == expectedRevision else { return }
                guard success else { self.message = self.t("Observed geometry history could not be deleted. Please retry.", "لم يكتمل حذف سجل هندسة المشاهدات. أعد المحاولة."); return }
                self.deleteMapFiles()
            }
        } else { deleteMapFiles() }
    }
    private func deleteMapFiles() {
        do {
            if FileManager.default.fileExists(atPath: storage.path) { try FileManager.default.removeItem(at: storage) }''')
    return s
patch=''
for path,edit in [('ios/BlindAssist/NavigationModel.swift',nav),('ios/BlindAssist/NativeMapping.swift',native_map),('ios/BlindAssist/IndoorNavigator.swift',indoor)]:patch+=change(path,edit)
(stage/'native-integration.patch').write_text(patch)
(stage/'native-proposal-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest,indent=2))
