import Foundation
import BlindCore
struct Input: Decodable {
    struct Expected: Decodable { let index: Int; let point: Point3 }
    let capturedAt, poseCapturedAt: Double
    let sourceID, poseSourceID: String
    let worldToCamera: NativeCameraTransform
    let intrinsics: NativeCameraIntrinsics
    let depth: NativeDepthObservation
    let expectedCameraPosition: Point3
    let expectedPoints: [Expected]
}
let path = CommandLine.arguments.dropFirst().first ?? ""
let inputs = try JSONDecoder().decode([Input].self, from: Data(contentsOf: URL(fileURLWithPath: path)))
let session = UUID() // Local replay ownership only, not a claimed original device session identifier.
var history = NativeObservationHistory(), pointCount = 0, comparisons = 0
var submittedBytes = 0, transactions = 0, newBytes = 0
for input in inputs {
    let pose = try input.worldToCamera.inverted()
    guard try pose.applying(to: Point3(0,0,0)).distance(to: input.expectedCameraPosition) < 1e-9 else { fatalError("Extrinsic inversion mismatch") }
    comparisons += 1
    let record = NativeObservationRecord(sessionID: session, coordinateFrameID: "recorded-arkitscenes:47333462",
        producer: .arkitScenesRecorded, sourceID: input.sourceID, capturedAt: input.capturedAt,
        poseCapturedAt: input.poseCapturedAt, poseSourceID: input.poseSourceID, receivedAt: nil, observedAt: nil,
        tracking: .notRecorded, cameraConvention: .pinholeRightDownForward, cameraToSessionWorld: pose,
        intrinsics: input.intrinsics, depth: input.depth, omitted: ["meshNotInFrameReplay", "annotationsUnconfirmedIncomplete"])
    try record.validate()
    let points = try input.depth.worldPoints(intrinsics: input.intrinsics, cameraToWorld: pose, convention: record.cameraConvention)
    guard points.allSatisfy(\.isFinite), record.isHistoryOnly, record.mapTarget == nil,
          record.unavailableEvidence.contains("poseCovariance") else { fatalError("Recorded observation contract mismatch") }
    for expected in input.expectedPoints {
        guard points[expected.index].distance(to: expected.point) < 1e-8 else { fatalError("Pinhole convention/projection mismatch") }
        comparisons += 1
    }
    pointCount += points.count
    newBytes += try JSONEncoder().encode(record).count
    try history.append(record) { submittedBytes += $0.count; transactions += 1 }
}
let restored = try NativeObservationHistory(data: history.encoded())
guard restored == history, restored.records.allSatisfy(\.isHistoryOnly) else { fatalError("History roundtrip mismatch") }
print("Recorded compatibility: \(inputs.count) frames, \(pointCount) finite sampled points, \(comparisons) independent NumPy transform/projection comparisons, \(history.records.count) bounded historical records (\(history.evictedRecordCount) explicit evictions). No localization/accuracy/clearance claim.")

print("LEGACY_RECORDED_METRICS transactions=\(transactions) logicalSubmittedBytes=\(submittedBytes) encodedNewRecordBytes=\(newBytes)")
