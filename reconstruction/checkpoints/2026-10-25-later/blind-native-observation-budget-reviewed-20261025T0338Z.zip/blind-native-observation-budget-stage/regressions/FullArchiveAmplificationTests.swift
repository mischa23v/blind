import XCTest
import BlindCore
final class FullArchiveAmplificationTests: XCTestCase {
    func testPersistenceWritesOnlyNewRecordBytes() throws {
        let session = UUID()
        var history = NativeObservationHistory(), transactions = 0, submittedBytes = 0, newRecordBytes = 0
        for n in 1...100 {
            let record = NativeObservationRecord(sessionID: session, coordinateFrameID: "session-world", producer: .arkit,
                sourceID: "synthetic-cost-witness", capturedAt: Double(n), receivedAt: Double(n)+0.1,
                observedAt: Date(timeIntervalSince1970: 1000), tracking: .normal,
                cameraConvention: .arKitRightUpBack, cameraToSessionWorld: .identity,
                intrinsics: .init(width: 4, height: 4, fx: 4, fy: 4, cx: 2, cy: 2), depth: nil)
            newRecordBytes += try JSONEncoder().encode(record).count
            try history.append(record) { submittedBytes += $0.count; transactions += 1 }
        }
        print("LEGACY WITNESS: records=100 transactions=\(transactions) logicalSubmittedBytes=\(submittedBytes) encodedNewRecordBytes=\(newRecordBytes)")
        XCTAssertEqual(submittedBytes, newRecordBytes, "Expected failing legacy witness: old sink rewrites retained payloads")
    }
}
