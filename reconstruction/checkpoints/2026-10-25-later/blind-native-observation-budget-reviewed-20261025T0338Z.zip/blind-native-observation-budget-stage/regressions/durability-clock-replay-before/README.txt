Historical failing policy, preserved before high-water repair.

Reproduction: initialize at 0, spend the default 131072-byte burst at 60,
observe rollback to 0, then charge the same burst at 60 again. The prior
policy admits the second burst over an already-consumed clock span.
NaN followed by a lower recovery origin reproduces the same refill replay.
probe.swift and probe-output.log preserve the reviewer's exact reproduction.

NativeObservationDurabilityBudget.swift and
NativeObservationDurabilityBudgetTests.swift are exact pre-repair source.
AdversarialDurabilityBudgetTests.swift is the expanded 20-test suite run
against that old policy: 3011 assertion failures, exit status 1. Repeated
replay attempts account for the large assertion count.

Full repetitive failure log (retained outside the deliverable):
/tmp/native-observation-budget-highwater.jN0TIx/before/adversarial-tests.log
Its SHA-256 is preserved in external-adversarial-log.sha256.
Independent failing package:
/tmp/native-observation-budget-highwater.jN0TIx/regression

This historical package/test result is not the repaired implementation.
The repair preserves a monotonic high-water mark, clears credit after a
clock fault, rejects lower timestamps, and grants no refill on the first
recovery timestamp at or beyond the high-water mark.
