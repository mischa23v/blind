import Foundation
import XCTest
@testable import NativeObservationDeletionAdapter
final class NativeMapDeletionTests: XCTestCase {
    func testDelayedOldDeletionCannotDeleteMapAfterRestartAndStop() throws {
        let storage = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at: storage, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: storage) }
        let file = storage.appendingPathComponent("personal.db")
        try Data("old-map".utf8).write(to: file)
        let mapping = NativeMapping(storage: storage)
        var pending: ((Bool) -> Void)?
        mapping.clearObservationHistory = { pending = $0 }
        mapping.deleteMap()
        XCTAssertNotNil(pending)
        mapping.start()
        try Data("new-map".utf8).write(to: file)
        mapping.stop()
        pending?(true)
        XCTAssertEqual(try Data(contentsOf: file), Data("new-map".utf8))
    }
    func testFailedPurgeKeepsMapAndReportsFailure() throws {
        let storage = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at: storage, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: storage) }
        let file = storage.appendingPathComponent("personal.db")
        try Data("map".utf8).write(to: file)
        let mapping = NativeMapping(storage: storage)
        mapping.clearObservationHistory = { $0(false) }; mapping.deleteMap()
        XCTAssertTrue(FileManager.default.fileExists(atPath: file.path))
        XCTAssertTrue(mapping.status.contains("could not"))
    }
    func testMatchingPurgeDeletesOriginalMap() throws {
        let storage = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at: storage, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: storage) }
        let file = storage.appendingPathComponent("personal.db")
        try Data("map".utf8).write(to: file)
        let mapping = NativeMapping(storage: storage)
        mapping.clearObservationHistory = { $0(true) }; mapping.deleteMap()
        XCTAssertFalse(FileManager.default.fileExists(atPath: file.path))
    }
    func testStalePurgeFailureCannotOverwriteNewMapStatus() {
        let mapping = NativeMapping(storage: FileManager.default.temporaryDirectory)
        var pending: ((Bool) -> Void)?
        mapping.clearObservationHistory = { pending = $0 }; mapping.deleteMap()
        mapping.start(); mapping.stop(); mapping.status = "new-map-state"
        pending?(false)
        XCTAssertEqual(mapping.status, "new-map-state")
    }

}
