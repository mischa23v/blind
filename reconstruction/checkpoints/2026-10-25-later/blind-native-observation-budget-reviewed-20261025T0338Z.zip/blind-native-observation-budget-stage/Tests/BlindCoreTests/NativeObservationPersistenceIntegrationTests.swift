import XCTest
import BlindCore
import BlindMemory
import GRDB
import NativeObservationPersistenceAdapter

/// Uses the real pipeline, exact extracted native bridge persistence methods, and
/// actual pinned GRDB/SQLite. No fake store or copied production database engine.
final class NativeObservationPersistenceIntegrationTests: XCTestCase {
    private var directories: [URL] = []
    override func tearDownWithError() throws {
        for directory in directories { try FileManager.default.removeItem(at: directory) }
    }
    private func path() throws -> String {
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        directories.append(directory)
        return directory.appendingPathComponent("ordinary-memory.sqlite").path
    }
    private func record(session: UUID, time: Double) -> NativeObservationRecord {
        NativeObservationRecord(sessionID: session, coordinateFrameID: "session-world", producer: .arkit,
            sourceID: "integration-synthetic", capturedAt: time, receivedAt: time + 0.1,
            observedAt: Date(timeIntervalSince1970: 1_700_000_000 + time), tracking: .normal,
            cameraConvention: .arKitRightUpBack, cameraToSessionWorld: .identity,
            intrinsics: NativeCameraIntrinsics(width: 4, height: 4, fx: 4, fy: 4, cx: 2, cy: 2), depth: nil)
    }
    private func begin(_ pipeline: NativeObservationPipeline, storage: NativeObservationStorage, session: UUID,
                       expected: NativeObservationPipeline.Outcome = .ready) {
        let done = expectation(description: "real bridge restore")
        pipeline.begin(sessionID: session, storage: storage) { outcome in
            XCTAssertEqual(outcome, expected)
            done.fulfill()
        }
        wait(for: [done], timeout: 3)
    }
    private func observe(_ record: NativeObservationRecord, with pipeline: NativeObservationPipeline) {
        let done = expectation(description: "volatile record admitted")
        XCTAssertTrue(pipeline.offer(sessionID: record.sessionID, capturedAt: record.capturedAt, extract: { record }) {
            XCTAssertEqual($0, .observed)
            done.fulfill()
        })
        wait(for: [done], timeout: 3)
    }
    private func snapshot(_ pipeline: NativeObservationPipeline) throws -> NativeObservationSnapshot {
        let done = expectation(description: "pipeline snapshot")
        var result: NativeObservationSnapshot?
        XCTAssertTrue(pipeline.readSnapshot { result = $0; done.fulfill() })
        wait(for: [done], timeout: 3)
        return try XCTUnwrap(result)
    }
    private func eventually(_ predicate: () -> Bool, file: StaticString = #filePath, line: UInt = #line) {
        let deadline = Date().addingTimeInterval(3)
        while !predicate(), Date() < deadline { Thread.sleep(forTimeInterval: 0.005) }
        XCTAssertTrue(predicate(), file: file, line: line)
    }
    private func clear(_ pipeline: NativeObservationPipeline, storage: NativeObservationStorage,
                       expected: NativeObservationPipeline.Outcome = .cleared) {
        let done = expectation(description: "real bridge clear")
        pipeline.clear(storage: storage) { XCTAssertEqual($0, expected); done.fulfill() }
        wait(for: [done], timeout: 3)
    }

    func testExactBridgeRowsSurviveRestartWithOriginalClockDomains() throws {
        let path = try path(), session = UUID()
        let memory = try MemoryStore(path: path, profile: "owner")
        let storage = NativeObservationPersistenceAdapter.storage(memory)
        XCTAssertFalse(FileManager.default.fileExists(atPath: path + ".native-observations.sqlite"))
        let pipeline = NativeObservationPipeline(durability: .unboundedForTesting, now: { 2.5 })
        begin(pipeline, storage: storage, session: session)
        let first = record(session: session, time: 1), second = record(session: session, time: 2)
        observe(first, with: pipeline)
        eventually { pipeline.statistics().committedRecords == 1 }
        observe(second, with: pipeline)
        eventually { pipeline.statistics().committedRecords == 2 }
        let before = try snapshot(pipeline)
        XCTAssertEqual(before.history.records, [first, second])
        XCTAssertEqual(before.durableRecordIDs, Set([first.id, second.id]))
        XCTAssertTrue(before.volatileRecordIDs.isEmpty)
        let disk = try memory.makeNativeObservationStore().load()
        XCTAssertEqual(disk.rows.map(\.payload), before.history.encodedRecords.map(\.payload))
        XCTAssertEqual(disk.rows.map(\.capturedAt), [1, 2])
        pipeline.stop()

        let nextSession = UUID()
        let reopenedMemory = try MemoryStore(path: path, profile: "owner")
        let reopenedStorage = NativeObservationPersistenceAdapter.storage(reopenedMemory)
        let restarted = NativeObservationPipeline(durability: .unboundedForTesting, now: { 0.5 })
        begin(restarted, storage: reopenedStorage, session: nextSession)
        let restored = try snapshot(restarted)
        XCTAssertEqual(restored.history, before.history)
        XCTAssertEqual(restored.durableRecordIDs, before.durableRecordIDs)
        let afterReboot = record(session: nextSession, time: 0.25)
        observe(afterReboot, with: restarted)
        eventually { restarted.statistics().committedRecords == 1 }
        let complete = try snapshot(restarted)
        XCTAssertEqual(complete.history.records, [first, second, afterReboot])
        XCTAssertEqual(complete.history.records.map(\.capturedAt), [1, 2, 0.25])
        XCTAssertEqual(complete.history.records.map(\.receivedAt), [1.1, 2.1, 0.35])
        XCTAssertEqual(complete.history.records.map(\.observedAt), [first.observedAt, second.observedAt, afterReboot.observedAt])
        XCTAssertEqual(try reopenedMemory.makeNativeObservationStore().load().rows.map(\.payload), complete.history.encodedRecords.map(\.payload))
        restarted.stop()
    }

    func testRealSQLTransactionFailureKeepsVolatileHistoryAndDurableRowsUnchanged() throws {
        let path = try path(), session = UUID(), memory = try MemoryStore(path: path)
        let storage = NativeObservationPersistenceAdapter.storage(memory)
        let pipeline = NativeObservationPipeline(durability: .unboundedForTesting, now: { 2.5 })
        begin(pipeline, storage: storage, session: session)
        let first = record(session: session, time: 1), second = record(session: session, time: 2)
        observe(first, with: pipeline)
        eventually { pipeline.statistics().committedRecords == 1 }
        let durable = try memory.makeNativeObservationStore()
        let before = try durable.load()
        let sql = try DatabaseQueue(path: path + ".native-observations.sqlite")
        try sql.write { db in
            try db.execute(sql: """
                CREATE TRIGGER failObservationTransaction AFTER INSERT ON nativeObservation BEGIN
                    SELECT RAISE(ABORT,'injected real observation write failure');
                END;
                """)
        }
        observe(second, with: pipeline)
        eventually { pipeline.statistics().writeFailures == 1 }
        let live = try snapshot(pipeline)
        XCTAssertEqual(live.history.records, [first, second])
        XCTAssertEqual(live.durableRecordIDs, [first.id])
        XCTAssertEqual(live.volatileRecordIDs, [second.id])
        XCTAssertEqual(try durable.load(), before)
        let statistics = pipeline.statistics()
        XCTAssertEqual(statistics.attemptedTransactions, 2)
        XCTAssertEqual(statistics.committedTransactions, 1)
        XCTAssertEqual(statistics.committedRecords, 1)
        XCTAssertEqual(statistics.committedPayloadBytes, try NativeObservationEncodedRecord(first).encodedBytes)
        XCTAssertEqual(statistics.logicalBytesSubmitted, try NativeObservationEncodedRecord(first).encodedBytes + NativeObservationEncodedRecord(second).encodedBytes)
        Thread.sleep(forTimeInterval: 0.03)
        XCTAssertEqual(pipeline.statistics().attemptedTransactions, 2)
        pipeline.stop()
    }

    func testRealBridgeClearDeletesOnlyDedicatedProfileHistory() throws {
        let path = try path(), session = UUID(), memory = try MemoryStore(path: path, profile: "owner")
        let ordinary = Data("ordinary companion preference".utf8)
        try memory.saveValue(namespace: "companion", id: "keep", payload: ordinary)
        let storage = NativeObservationPersistenceAdapter.storage(memory)
        let pipeline = NativeObservationPipeline(durability: .unboundedForTesting, now: { 2.5 })
        begin(pipeline, storage: storage, session: session)
        let captured = record(session: session, time: 1)
        observe(captured, with: pipeline)
        eventually { pipeline.statistics().committedRecords == 1 }
        let otherProfile = try NativeObservationStore(path: path + ".native-observations.sqlite", profile: "other")
        let encoded = try NativeObservationEncodedRecord(captured)
        _ = try otherProfile.append([NativeObservationRow(id: captured.id.uuidString, sessionID: session.uuidString,
            capturedAt: captured.capturedAt, payload: encoded.payload)])
        clear(pipeline, storage: storage)
        XCTAssertEqual(try memory.value(namespace: "companion", id: "keep"), ordinary)
        XCTAssertTrue(try memory.makeNativeObservationStore().load().rows.isEmpty)
        XCTAssertEqual(try otherProfile.load().rows.map(\.payload), [encoded.payload])
        let cleared = try snapshot(pipeline)
        XCTAssertTrue(cleared.history.records.isEmpty)
        XCTAssertTrue(cleared.durableRecordIDs.isEmpty)
        XCTAssertEqual(cleared.durableEvictedRecordCount, 0)
        XCTAssertFalse(pipeline.offer(sessionID: session, capturedAt: 2, extract: { captured }))
        let ordinarySQL = try DatabaseQueue(path: path)
        XCTAssertFalse(try ordinarySQL.read { try $0.tableExists("nativeObservation") })
    }

    func testCorruptTypedPayloadFailsRestoreWithoutOverwritingRows() throws {
        let path = try path(), session = UUID(), memory = try MemoryStore(path: path)
        let durable = try memory.makeNativeObservationStore()
        let corrupt = NativeObservationRow(id: UUID().uuidString, sessionID: session.uuidString,
            capturedAt: 1, payload: Data("not a typed historical record".utf8))
        _ = try durable.append([corrupt])
        let before = try durable.load()
        let storage = NativeObservationPersistenceAdapter.storage(memory)
        XCTAssertThrowsError(try storage.load())
        let pipeline = NativeObservationPipeline(durability: .unboundedForTesting, now: { 2.5 })
        begin(pipeline, storage: storage, session: session, expected: .storageFailed)
        XCTAssertTrue(try snapshot(pipeline).history.records.isEmpty)
        XCTAssertFalse(pipeline.offer(sessionID: session, capturedAt: 2, extract: {
            XCTFail("Failed restore must disable offers")
            return self.record(session: session, time: 2)
        }))
        XCTAssertEqual(pipeline.statistics().attemptedTransactions, 0)
        XCTAssertEqual(try durable.load(), before)
    }

    func testTypedPayloadMetadataMismatchFailsRestoreWithoutOverwritingRows() throws {
        let session = UUID(), captured = record(session: session, time: 1)
        let encoded = try NativeObservationEncodedRecord(captured)
        let mismatches = [
            NativeObservationRow(id: UUID().uuidString, sessionID: session.uuidString, capturedAt: 1, payload: encoded.payload),
            NativeObservationRow(id: captured.id.uuidString, sessionID: UUID().uuidString, capturedAt: 1, payload: encoded.payload),
            NativeObservationRow(id: captured.id.uuidString, sessionID: session.uuidString, capturedAt: 1.5, payload: encoded.payload)
        ]
        for mismatch in mismatches {
            let path = try path(), memory = try MemoryStore(path: path), durable = try memory.makeNativeObservationStore()
            _ = try durable.append([mismatch])
            let before = try durable.load()
            let storage = NativeObservationPersistenceAdapter.storage(memory)
            XCTAssertThrowsError(try storage.load())
            let pipeline = NativeObservationPipeline(durability: .unboundedForTesting, now: { 2.5 })
            begin(pipeline, storage: storage, session: session, expected: .storageFailed)
            XCTAssertTrue(try snapshot(pipeline).history.records.isEmpty)
            XCTAssertFalse(pipeline.offer(sessionID: session, capturedAt: 2, extract: { captured }))
            XCTAssertEqual(pipeline.statistics().attemptedTransactions, 0)
            XCTAssertEqual(try durable.load(), before)
        }
    }

    func testRealSQLClearFailurePreservesRowsAndKeepsPipelineDisabled() throws {
        let path = try path(), session = UUID(), memory = try MemoryStore(path: path)
        let storage = NativeObservationPersistenceAdapter.storage(memory)
        let pipeline = NativeObservationPipeline(durability: .unboundedForTesting, now: { 2.5 })
        begin(pipeline, storage: storage, session: session)
        let captured = record(session: session, time: 1)
        observe(captured, with: pipeline)
        eventually { pipeline.statistics().committedRecords == 1 }
        let before = try memory.makeNativeObservationStore().load()
        let sql = try DatabaseQueue(path: path + ".native-observations.sqlite")
        try sql.write { db in
            try db.execute(sql: """
                CREATE TRIGGER failObservationClear BEFORE DELETE ON nativeObservation BEGIN
                    SELECT RAISE(ABORT,'injected real observation delete failure');
                END;
                """)
        }
        clear(pipeline, storage: storage, expected: .clearFailed)
        XCTAssertEqual(try memory.makeNativeObservationStore().load(), before)
        XCTAssertEqual(try snapshot(pipeline).history.records, [captured])
        XCTAssertFalse(pipeline.offer(sessionID: session, capturedAt: 2, extract: { captured }))
        try sql.write { db in try db.execute(sql: "DROP TRIGGER failObservationClear") }
        clear(pipeline, storage: storage)
        XCTAssertTrue(try memory.makeNativeObservationStore().load().rows.isEmpty)
    }
}
