import Foundation
import XCTest
@testable import NativeObservationDeletionAdapter
final class NativePrivacyDeletionTests: XCTestCase {
    func testBlockedObservationPurgeImmediatelyRetiresExistingCallbacks() {
        let model = NavigationModel(), old = model.perceptionRevision
        model.clearObservedObjects()
        XCTAssertNotEqual(model.perceptionRevision, old)
        XCTAssertEqual(model.destructiveCalls, 0)
        #if DEBUG
        XCTAssertEqual(model.debugPurges, 1)
        #endif
        model.nativeObservations.pending?(false)
        XCTAssertEqual(model.destructiveCalls, 0); XCTAssertEqual(model.failures, 1)
        XCTAssertNotEqual(model.perceptionRevision, old)
    }
    func testRoomDeleteRetiresRecognitionBeforeBlockedPurge() {
        let model = NavigationModel(), place = SavedPlace(id: UUID()), old = model.perceptionRevision
        model.recognizedPlace = place; model.awaitingPlace = place
        model.deletePlace(place)
        XCTAssertNotEqual(model.perceptionRevision, old); XCTAssertTrue(model.cluesInvalidated)
        XCTAssertNil(model.recognizedPlace); XCTAssertNil(model.awaitingPlace); XCTAssertEqual(model.destructiveCalls, 0)
        model.nativeObservations.pending?(true)
        XCTAssertEqual(model.destructiveCalls, 1)
    }
    func testForgetRoomInvalidatesBeforeFailureAndDoesNotClaimSuccess() {
        let model = NavigationModel(), old = model.perceptionRevision
        model.forgetRoom("room")
        XCTAssertNotEqual(model.perceptionRevision, old); XCTAssertTrue(model.cluesInvalidated)
        model.nativeObservations.pending?(false)
        XCTAssertEqual(model.destructiveCalls, 0); XCTAssertEqual(model.failures, 1)
    }
    func testItemForgetCompletesOnlyAfterHistoryPurgeAndCancelsOldWork() {
        let model = NavigationModel(), item = RememberedItem(key: "cup"), old = model.perceptionRevision
        model.learningItem = item; var result: Bool?
        model.forgetItem(item) { result = $0 }
        XCTAssertNil(result); XCTAssertNil(model.learningItem); XCTAssertTrue(model.cancelled)
        XCTAssertNotEqual(model.perceptionRevision, old); XCTAssertEqual(model.destructiveCalls, 0)
        model.nativeObservations.pending?(true)
        XCTAssertEqual(result, true); XCTAssertEqual(model.destructiveCalls, 1)
    }
    func testItemPurgeFailureNeverReportsSuccessfulForget() {
        let model = NavigationModel(); var result: Bool?
        model.forgetItem(RememberedItem(key: "cup")) { result = $0 }
        model.nativeObservations.pending?(false)
        XCTAssertEqual(result, false); XCTAssertEqual(model.destructiveCalls, 0)
    }
    func testOldItemPurgeCannotEraseNewlyRelearnedItem() {
        let model = NavigationModel(); var result: Bool?
        model.forgetItem(RememberedItem(key: "cup")) { result = $0 }
        // Existing beginLearningItem/remember paths rotate this exact ownership revision.
        model.itemMemoryRevision = UUID()
        model.nativeObservations.pending?(true)
        XCTAssertEqual(result, false); XCTAssertEqual(model.destructiveCalls, 0)
    }
    func testOldItemPurgeFailureCannotOverwriteNewerState() {
        let model = NavigationModel(); var result: Bool?
        model.forgetItem(RememberedItem(key: "cup")) { result = $0 }
        model.itemMemoryRevision = UUID()
        model.nativeObservations.pending?(false)
        XCTAssertEqual(result, false); XCTAssertEqual(model.failures, 0)
    }

}
