import XCTest
import BlindCore
import BlindMemory
import GRDB
import NativeObservationPersistenceAdapter

final class NativeObservationBudgetPipelineTests: XCTestCase {
    typealias Clock = NativeObservationPipelineTests.Clock
    typealias Store = NativeObservationPipelineTests.Store
    func record(session: UUID, time: Double, vertices: Int = 1100) -> NativeObservationRecord {
        let points = (0..<vertices).map { n in Point3(Double(n)/7.0000003, Double(n)/11.0000007, Double(n)/13.0000009) }
        let surface = NativeSurfaceObservation(sourceID: "measured-test-mesh", kind: .arkitMesh, localToSessionWorld: .identity,
            vertices: points, originalVertexCount: points.count)
        return NativeObservationRecord(sessionID: session, coordinateFrameID: "session-world", producer: .arkit,
            sourceID: "synthetic-budget-fixture", capturedAt: time, receivedAt: time + 0.1,
            observedAt: Date(timeIntervalSince1970: 1000), tracking: .normal,
            cameraConvention: .arKitRightUpBack, cameraToSessionWorld: .identity,
            intrinsics: .init(width: 4, height: 4, fx: 4, fy: 4, cx: 2, cy: 2), depth: nil,
            surfaces: vertices == 0 ? [] : [surface], originalSurfaceCount: vertices == 0 ? 0 : 1)
    }
    func begin(_ pipeline: NativeObservationPipeline, storage: NativeObservationStorage, session: UUID) {
        let done = expectation(description: "ready")
        pipeline.begin(sessionID: session, storage: storage) { XCTAssertEqual($0, .ready); done.fulfill() }
        wait(for: [done], timeout: 3)
    }
    func observe(_ row: NativeObservationRecord, pipeline: NativeObservationPipeline) {
        let done = expectation(description: "full-rate volatile acceptance")
        XCTAssertTrue(pipeline.offer(sessionID: row.sessionID, capturedAt: row.capturedAt, extract: { row }) {
            XCTAssertEqual($0, .observed); done.fulfill()
        })
        wait(for: [done], timeout: 3)
    }
    func snapshot(_ pipeline: NativeObservationPipeline) -> NativeObservationSnapshot {
        let done = expectation(description: "live read"), box = SnapshotBox()
        XCTAssertTrue(pipeline.readSnapshot { box.value = $0; done.fulfill() })
        wait(for: [done], timeout: 2); return box.value!
    }
    final class SnapshotBox: @unchecked Sendable { var value: NativeObservationSnapshot? }
    func drained(_ pipeline: NativeObservationPipeline) {
        let deadline = Date().addingTimeInterval(3)
        while snapshot(pipeline).writeInFlight, Date() < deadline { Thread.sleep(forTimeInterval: 0.001) }
        XCTAssertFalse(snapshot(pipeline).writeInFlight)
    }
    func clear(_ pipeline: NativeObservationPipeline, storage: NativeObservationStorage) {
        let done = expectation(description: "unbudgeted privacy clear")
        pipeline.clear(storage: storage) { XCTAssertEqual($0, .cleared); done.fulfill() }
        wait(for: [done], timeout: 3)
    }
    func testDefaultColdStartKeepsFullRateVolatileHistoryAndFreshestReason() throws {
        let clock = Clock(0), store = Store(), session = UUID(), pipeline = NativeObservationPipeline(now: { clock.read() })
        begin(pipeline, storage: store.backend, session: session)
        var latest: NativeObservationRecord!
        for n in 0...20 {
            let t = Double(n) * 0.5; clock.set(t); latest = record(session: session, time: t)
            observe(latest, pipeline: pipeline); drained(pipeline)
        }
        let size = try NativeObservationEncodedRecord(latest).encodedBytes
        XCTAssertGreaterThan(size, 65_536); XCTAssertLessThan(size, 131_072)
        let live = snapshot(pipeline)
        XCTAssertEqual(live.history.records.count, 21); XCTAssertEqual(live.volatileRecordIDs.count, 21)
        XCTAssertEqual(live.pendingRecordCount, 1); XCTAssertEqual(live.volatileReasons[latest.id], .budgetExhausted)
        XCTAssertEqual(live.history.records.last?.capturedAt, 10); XCTAssertEqual(store.writes, 0)
        XCTAssertEqual(pipeline.statistics().observed, 21); XCTAssertEqual(pipeline.statistics().droppedBusy, 0)
        clock.set(60); let current = record(session: session, time: 60)
        observe(current, pipeline: pipeline); drained(pipeline)
        XCTAssertEqual(store.history.records.map(\.capturedAt), [60])
        XCTAssertEqual(snapshot(pipeline).durableRecordIDs, [current.id])
    }
    func testPayloadAndTransactionBudgetsDoNotThrottleLiveAcceptance() throws {
        let config = try NativeObservationDurabilityBudget.Configuration(bytesPerInterval: 4096, intervalSeconds: 60, burstBytes: 4096)
        let clock = Clock(0), store = Store(), session = UUID()
        let pipeline = NativeObservationPipeline(durability: .budgeted(config), now: { clock.read() })
        begin(pipeline, storage: store.backend, session: session)
        var minimumSize = Int.max
        for n in 0...600 {
            let t = Double(n) * 0.5; clock.set(t); let row = record(session: session, time: t, vertices: 0)
            minimumSize = min(minimumSize, try NativeObservationEncodedRecord(row).encodedBytes)
            observe(row, pipeline: pipeline); drained(pipeline)
        }
        let stats = pipeline.statistics()
        XCTAssertEqual(stats.observed, 601); XCTAssertEqual(stats.droppedBusy, 0)
        XCTAssertLessThanOrEqual(stats.logicalBytesSubmitted, 4096 * 5) // empty cold start, 300 s accrual
        XCTAssertLessThanOrEqual(stats.attemptedTransactions, (4096 * 5) / minimumSize)
        XCTAssertEqual(stats.committedPayloadBytes, stats.logicalBytesSubmitted)
        XCTAssertGreaterThan(stats.budgetDeferrals, 0)
        let live = snapshot(pipeline)
        XCTAssertEqual(live.history.records.count, 64); XCTAssertLessThanOrEqual(live.volatileReasons.count, 64)
        XCTAssertLessThanOrEqual(live.pendingRecordCount, 1)
    }
    func testFailedWriteConsumesCreditAndClearNeverRefillsIt() throws {
        let clock = Clock(0), store = Store(), session = UUID(), pipeline = NativeObservationPipeline(now: { clock.read() })
        begin(pipeline, storage: store.backend, session: session); clock.set(60); store.failAppend = true
        let failed = record(session: session, time: 60); observe(failed, pipeline: pipeline); drained(pipeline)
        XCTAssertEqual(pipeline.statistics().attemptedTransactions, 1); XCTAssertEqual(pipeline.statistics().writeFailures, 1)
        XCTAssertEqual(snapshot(pipeline).volatileReasons[failed.id], .writeFailed)
        let charged = pipeline.statistics().logicalBytesSubmitted
        XCTAssertEqual(charged, try NativeObservationEncodedRecord(failed).encodedBytes)
        clock.set(60.5); observe(record(session: session, time: 60.5), pipeline: pipeline); drained(pipeline)
        XCTAssertEqual(pipeline.statistics().attemptedTransactions, 1)
        let creditBeforeClear = pipeline.statistics().availableDurabilityByteCredit
        clear(pipeline, storage: store.backend)
        XCTAssertEqual(store.deletes, 1); XCTAssertTrue(snapshot(pipeline).history.records.isEmpty)
        XCTAssertEqual(pipeline.statistics().availableDurabilityByteCredit, creditBeforeClear)
        store.failAppend = false; let next = UUID(); begin(pipeline, storage: store.backend, session: next)
        clock.set(61); observe(record(session: next, time: 61), pipeline: pipeline); drained(pipeline)
        XCTAssertEqual(pipeline.statistics().attemptedTransactions, 1)
        XCTAssertEqual(pipeline.statistics().logicalBytesSubmitted, charged)
    }
    func testCameraStopBeginAndNewPipelineCannotMintRestartCredit() {
        let clock = Clock(0), store = Store(), first = UUID(), pipeline = NativeObservationPipeline(now: { clock.read() })
        begin(pipeline, storage: store.backend, session: first); clock.set(60)
        observe(record(session: first, time: 60), pipeline: pipeline); drained(pipeline)
        XCTAssertEqual(store.writes, 1); pipeline.stop()
        let next = UUID(); begin(pipeline, storage: store.backend, session: next)
        clock.set(60.5); observe(record(session: next, time: 60.5), pipeline: pipeline); drained(pipeline)
        XCTAssertEqual(store.writes, 1)
        let restart = NativeObservationPipeline(now: { clock.read() }), third = UUID()
        begin(restart, storage: store.backend, session: third)
        clock.set(61); observe(record(session: third, time: 61), pipeline: restart); drained(restart)
        XCTAssertEqual(restart.statistics().attemptedTransactions, 0); XCTAssertEqual(store.writes, 1)
    }
    func testOversizedFullGeometryStaysVolatileAndDoesNotReplaceEligiblePending() throws {
        let clock = Clock(0), store = Store(), session = UUID(), pipeline = NativeObservationPipeline(now: { clock.read() })
        begin(pipeline, storage: store.backend, session: session)
        let eligible = record(session: session, time: 0); observe(eligible, pipeline: pipeline); drained(pipeline)
        clock.set(1); let oversized = record(session: session, time: 1, vertices: 2048)
        XCTAssertGreaterThan(try NativeObservationEncodedRecord(oversized).encodedBytes, 131_072)
        observe(oversized, pipeline: pipeline); drained(pipeline)
        let live = snapshot(pipeline)
        XCTAssertEqual(live.history.records.last?.surfaces.first?.vertices.count, 2048)
        XCTAssertEqual(live.volatileReasons[oversized.id], .oversizedRecord)
        XCTAssertEqual(live.pendingRecordCount, 1); XCTAssertEqual(store.writes, 0)
        clock.set(60); let oversizedAgain = record(session: session, time: 60, vertices: 2048)
        observe(oversizedAgain, pipeline: pipeline); drained(pipeline)
        XCTAssertEqual(store.writes, 0); XCTAssertEqual(snapshot(pipeline).pendingRecordCount, 0)
        XCTAssertEqual(snapshot(pipeline).volatileReasons[eligible.id], .expiredBeforeWrite)
        XCTAssertEqual(pipeline.statistics().oversizedVolatileRecords, 2)
    }
    func testRejectedRollbackAndNonfiniteClockSamplesInvalidateDurabilityCredit() {
        let clock = Clock(0), store = Store(), session = UUID(), pipeline = NativeObservationPipeline(now: { clock.read() })
        begin(pipeline, storage: store.backend, session: session); clock.set(60)
        observe(record(session: session, time: 60), pipeline: pipeline); drained(pipeline)
        XCTAssertEqual(store.writes, 1)
        clock.set(59)
        XCTAssertFalse(pipeline.offer(sessionID: session, capturedAt: 61, extract: { self.record(session: session, time: 61) }))
        clock.set(61); let recovered = record(session: session, time: 61)
        observe(recovered, pipeline: pipeline); drained(pipeline)
        XCTAssertEqual(snapshot(pipeline).volatileReasons[recovered.id], .clockUnavailable)
        XCTAssertEqual(pipeline.statistics().availableDurabilityByteCredit, 0); XCTAssertEqual(store.writes, 1)
        clock.set(.nan)
        XCTAssertFalse(pipeline.offer(sessionID: session, capturedAt: 62, extract: { self.record(session: session, time: 62) }))
        clock.set(120); observe(record(session: session, time: 120), pipeline: pipeline); drained(pipeline)
        XCTAssertEqual(pipeline.statistics().availableDurabilityByteCredit, 0); XCTAssertEqual(store.writes, 1)
        XCTAssertEqual(pipeline.statistics().durabilityClockFailures, 2)
    }
    func testWriterClockAndFreshnessUseOneCoherentSample() {
        final class SequenceClock: @unchecked Sendable {
            let lock = NSLock(); var calls = 0
            func read() -> Double {
                lock.lock(); defer { lock.unlock() }
                let sequence: [Double] = [0, 60, 60, 60, 60, 60, 59, 61]
                let value = sequence[min(calls, sequence.count-1)]; calls += 1; return value
            }
            var count: Int { lock.lock(); defer { lock.unlock() }; return calls }
        }
        let clock = SequenceClock(), store = Store(), session = UUID()
        let pipeline = NativeObservationPipeline(now: { clock.read() })
        begin(pipeline, storage: store.backend, session: session)
        observe(record(session: session, time: 59), pipeline: pipeline); drained(pipeline)
        // The old writer made a second freshness read (59 after sampling60),
        // latched rollback, then still charged at60. Admission must use one sample.
        XCTAssertEqual(clock.count, 6)
        XCTAssertEqual(store.writes, 1)
        XCTAssertFalse(pipeline.offer(sessionID: session, capturedAt: 60.5,
            extract: { self.record(session: session, time: 60.5) }))
        observe(record(session: session, time: 61), pipeline: pipeline); drained(pipeline)
        XCTAssertEqual(store.writes, 1)
        XCTAssertEqual(pipeline.statistics().durabilityClockFailures, 1)
    }
    func testInvalidFrameTimestampDoesNotInvalidateValidClockCredit() {
        let clock = Clock(0), store = Store(), session = UUID(), pipeline = NativeObservationPipeline(now: { clock.read() })
        begin(pipeline, storage: store.backend, session: session); clock.set(60)
        observe(record(session: session, time: 60), pipeline: pipeline); drained(pipeline)
        clock.set(60.25)
        XCTAssertFalse(pipeline.offer(sessionID: session, capturedAt: 100, extract: { self.record(session: session, time: 100) }))
        XCTAssertFalse(pipeline.offer(sessionID: session, capturedAt: 10, extract: { self.record(session: session, time: 10) }))
        clock.set(60.5); observe(record(session: session, time: 60.5, vertices: 0), pipeline: pipeline); drained(pipeline)
        XCTAssertEqual(store.writes, 2)
        XCTAssertEqual(pipeline.statistics().durabilityClockFailures, 0)
    }
    func testBlockedWriterCoalescesOneFreshRecordAndClearInvalidatesItWithoutBudgetDelay() {
        let clock = Clock(0), store = Store(), session = UUID(), pipeline = NativeObservationPipeline(now: { clock.read() })
        begin(pipeline, storage: store.backend, session: session); clock.set(60)
        let entered = expectation(description: "actual writer function held"), release = DispatchSemaphore(value: 0)
        store.onAppend = { entered.fulfill(); _ = release.wait(timeout: .now() + 5) }
        observe(record(session: session, time: 60), pipeline: pipeline); wait(for: [entered], timeout: 2)
        for n in 1...10 { let t = 60 + Double(n)*0.5; clock.set(t); observe(record(session: session, time: t), pipeline: pipeline) }
        XCTAssertEqual(snapshot(pipeline).history.records.count, 11); XCTAssertEqual(snapshot(pipeline).pendingRecordCount, 1)
        XCTAssertEqual(pipeline.statistics().observed, 11); XCTAssertEqual(pipeline.statistics().attemptedTransactions, 1)
        let cleared = expectation(description: "clear barrier")
        pipeline.clear(storage: store.backend) { XCTAssertEqual($0, .cleared); cleared.fulfill() }
        store.onAppend = nil; release.signal(); wait(for: [cleared], timeout: 3)
        XCTAssertTrue(store.history.records.isEmpty); XCTAssertTrue(snapshot(pipeline).history.records.isEmpty)
        XCTAssertEqual(snapshot(pipeline).pendingRecordCount, 0); XCTAssertEqual(store.writes, 1)
        let next = UUID(); begin(pipeline, storage: store.backend, session: next)
        clock.set(65.5); observe(record(session: next, time: 65.5), pipeline: pipeline); drained(pipeline)
        XCTAssertEqual(store.writes, 1) // clearing did not refund the already-attempted payload
    }
    func testRealGRDBBudgetedBridgeChargesAttemptsAndClearPreservesOrdinaryMemory() throws {
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: directory) }
        let path = directory.appendingPathComponent("memory.sqlite").path
        let memory = try MemoryStore(path: path), storage = NativeObservationPersistenceAdapter.storage(memory)
        let ordinary = Data("keep ordinary memory".utf8); try memory.saveValue(namespace: "companion", id: "kept", payload: ordinary)
        let clock = Clock(0), session = UUID(), pipeline = NativeObservationPipeline(now: { clock.read() })
        begin(pipeline, storage: storage, session: session); clock.set(60)
        let committed = record(session: session, time: 60); observe(committed, pipeline: pipeline); drained(pipeline)
        XCTAssertEqual(try memory.makeNativeObservationStore().load().rows.count, 1)
        let sql = try DatabaseQueue(path: path + ".native-observations.sqlite")
        try sql.write { try $0.execute(sql: "CREATE TRIGGER failBudgetedAppend AFTER INSERT ON nativeObservation BEGIN SELECT RAISE(ABORT,'budgeted failure'); END") }
        clock.set(120); let failed = record(session: session, time: 120); observe(failed, pipeline: pipeline); drained(pipeline)
        XCTAssertEqual(pipeline.statistics().attemptedTransactions, 2); XCTAssertEqual(pipeline.statistics().committedTransactions, 1)
        XCTAssertEqual(pipeline.statistics().logicalBytesSubmitted, try NativeObservationEncodedRecord(committed).encodedBytes + NativeObservationEncodedRecord(failed).encodedBytes)
        XCTAssertEqual(snapshot(pipeline).volatileReasons[failed.id], .writeFailed)
        XCTAssertEqual(try memory.makeNativeObservationStore().load().rows.count, 1)
        clear(pipeline, storage: storage)
        XCTAssertTrue(try memory.makeNativeObservationStore().load().rows.isEmpty)
        XCTAssertEqual(try memory.value(namespace: "companion", id: "kept"), ordinary)
    }
}
