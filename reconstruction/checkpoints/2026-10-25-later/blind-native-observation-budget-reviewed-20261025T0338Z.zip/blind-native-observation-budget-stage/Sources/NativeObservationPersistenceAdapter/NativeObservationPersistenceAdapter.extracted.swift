import BlindCore
import BlindMemory
import Foundation

// Verification-only public shell. Owner and storage implementation below are extracted
// from native/NativeARObservationBridge.swift. Only storage access is widened for tests.
public final class NativeObservationPersistenceAdapter {
    private final class ObservationStoreOwner {
        let memory: MemoryStore
        var store: NativeObservationStore?
        init(_ memory: MemoryStore) { self.memory = memory }
        func get() throws -> NativeObservationStore {
            if let store { return store }
            let opened = try memory.makeNativeObservationStore(); store = opened; return opened
        }
    }
    public static func storage(_ memory: MemoryStore) -> NativeObservationStorage {
        let owner = ObservationStoreOwner(memory)
        return NativeObservationStorage(load: {
            let snapshot = try owner.get().load()
            let rows = try snapshot.rows.map { row in
                let entry = try NativeObservationEncodedRecord(payload: row.payload)
                guard entry.id.uuidString == row.id, entry.sessionID.uuidString == row.sessionID,
                      entry.capturedAt == row.capturedAt else { throw NativeObservationError.invalidMetadata }
                return entry
            }
            return try NativeObservationHistory(records: rows, evictedRecordCount: snapshot.evictedRecordCount)
        }, append: { records in
            let result = try owner.get().append(records.map {
                NativeObservationRow(id: $0.id.uuidString, sessionID: $0.sessionID.uuidString,
                    capturedAt: $0.capturedAt, payload: $0.payload)
            })
            let ids = result.retainedIDs.compactMap(UUID.init(uuidString:))
            guard ids.count == result.retainedIDs.count else { throw NativeObservationError.invalidArchive }
            return NativeObservationStorage.Commit(retainedIDs: Set(ids), evictedRecordCount: result.evictedRecordCount,
                insertedRecordCount: result.insertedRecordCount, insertedPayloadBytes: result.insertedPayloadBytes)
        }, delete: { try owner.get().clear() })
    }
}
