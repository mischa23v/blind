import Foundation
// Verification-only shell. Public deletion entry methods below are exact production-proposal text.
struct SavedPlace { let id: UUID }
struct RememberedItem { let key: String }
final class Places { var memory: Int? = 1 }
struct Recovery { mutating func reset() {} }
final class NativeHistory {
    var pending: ((Bool) -> Void)?
    func clearHistory(memory: Int?, completion: @escaping (Bool) -> Void) { pending = completion }
}
final class NavigationModel {
    let nativeObservations = NativeHistory()
    let places = Places()
    var recognizedPlace: SavedPlace?
    var awaitingPlace: SavedPlace?
    var learningItem: RememberedItem?
    var placeRecovery = Recovery()
    var placeRecoveryQuestion = ""
    var itemMemoryRevision = UUID()
    var perceptionRevision = UUID()
    var cluesInvalidated = false
    var cancelled = false
    var debugPurges = 0
    var destructiveCalls = 0
    var failures = 0
    var arabic = false
    func purgeDebugSessionDiagnostics() { debugPurges += 1 }
    func invalidatePerceptionWork() { perceptionRevision = UUID() }
    func invalidateAutomaticRoomClues() { cluesInvalidated = true }
    func invalidateRecognizedRoom() {}
    func cancelDescription() { cancelled = true }
    func say(_ text: String) { failures += 1 }
    private func clearObservedObjectsAfterNativePurge() { destructiveCalls += 1 }
    private func deletePlaceAfterNativePurge(_ place: SavedPlace) { destructiveCalls += 1 }
    private func forgetRoomAfterNativePurge(_ id: String) { destructiveCalls += 1 }
    private func forgetItemAfterNativePurge(_ item: RememberedItem) -> Bool { destructiveCalls += 1; return true }
    func clearObservedObjects() {
        #if DEBUG
        purgeDebugSessionDiagnostics()
        #endif
        invalidatePerceptionWork()

        nativeObservations.clearHistory(memory: places.memory) { [weak self] success in
            guard let self else { return }
            guard success else {
                self.say(self.arabic ? "لم يكتمل حذف سجل هندسة المشاهدات. أعد المحاولة." : "Observed geometry history could not be deleted. Please retry.")
                return
            }
            self.clearObservedObjectsAfterNativePurge()
        }
    }
    func deletePlace(_ place: SavedPlace) {
        #if DEBUG
        purgeDebugSessionDiagnostics()
        #endif
        invalidatePerceptionWork()
        invalidateAutomaticRoomClues()
        if recognizedPlace?.id == place.id { recognizedPlace = nil; invalidateRecognizedRoom() }
        if awaitingPlace?.id == place.id { awaitingPlace = nil; placeRecovery.reset(); placeRecoveryQuestion = "" }

        nativeObservations.clearHistory(memory: places.memory) { [weak self] success in
            guard let self else { return }
            guard success else {
                self.say(self.arabic ? "لم يكتمل حذف سجل هندسة المشاهدات. أعد المحاولة." : "Observed geometry history could not be deleted. Please retry.")
                return
            }
            self.deletePlaceAfterNativePurge(place)
        }
    }
    func forgetRoom(_ id: String) {
        #if DEBUG
        purgeDebugSessionDiagnostics()
        #endif
        invalidatePerceptionWork()
        invalidateAutomaticRoomClues()

        nativeObservations.clearHistory(memory: places.memory) { [weak self] success in
            guard let self else { return }
            guard success else {
                self.say(self.arabic ? "لم يكتمل حذف سجل هندسة المشاهدات. أعد المحاولة." : "Observed geometry history could not be deleted. Please retry.")
                return
            }
            self.forgetRoomAfterNativePurge(id)
        }
    }
    func forgetItem(_ item: RememberedItem, completion: @escaping (Bool) -> Void = { _ in }) {
        #if DEBUG
        purgeDebugSessionDiagnostics()
        #endif
        itemMemoryRevision = UUID()
        invalidatePerceptionWork()
        cancelDescription()
        if learningItem?.key == item.key { learningItem = nil }
        let deletionRevision = itemMemoryRevision
        nativeObservations.clearHistory(memory: places.memory) { [weak self] success in
            guard let self else { completion(false); return }
            guard self.itemMemoryRevision == deletionRevision else { completion(false); return }
            guard success else {
                self.say(self.arabic ? "لم يكتمل حذف سجل هندسة المشاهدات. أعد المحاولة." : "Observed geometry history could not be deleted. Please retry.")
                completion(false); return
            }
            completion(self.forgetItemAfterNativePurge(item))
        }
    }
}
