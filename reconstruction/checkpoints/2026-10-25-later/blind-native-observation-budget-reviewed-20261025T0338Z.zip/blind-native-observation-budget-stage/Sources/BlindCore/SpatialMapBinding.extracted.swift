import Foundation

// Exact production type extracted for this isolated test target; do not copy into the app.
public struct SpatialMapBinding: Codable, Equatable, Hashable, Sendable {
    public let mapID: String
    public let frameID: String
    public let revision: String
    public init(mapID: String, frameID: String, revision: String) {
        self.mapID = mapID; self.frameID = frameID; self.revision = revision
    }
}

