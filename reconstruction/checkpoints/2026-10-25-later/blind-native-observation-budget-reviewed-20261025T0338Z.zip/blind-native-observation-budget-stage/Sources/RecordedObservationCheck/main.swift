import Foundation
import BlindCore
import BlindMemory
import NativeObservationPersistenceAdapter

struct Input: Decodable {
    struct Expected: Decodable { let index: Int; let point: Point3 }
    let capturedAt, poseCapturedAt: Double
    let sourceID, poseSourceID: String
    let worldToCamera: NativeCameraTransform
    let intrinsics: NativeCameraIntrinsics
    let depth: NativeDepthObservation
    let expectedCameraPosition: Point3
    let expectedPoints: [Expected]
}
final class ReplayClock: @unchecked Sendable {
    let lock = NSLock(); var value: Double
    init(_ value: Double) { self.value = value }
    func read() -> Double { lock.lock(); defer { lock.unlock() }; return value }
    func set(_ time: Double) { lock.lock(); value = time; lock.unlock() }
}
func wait(_ semaphore: DispatchSemaphore) {
    guard semaphore.wait(timeout: .now() + 5) == .success else { fatalError("Recorded verification callback timed out") }
}
func snapshot(_ pipeline: NativeObservationPipeline) -> NativeObservationSnapshot {
    let done = DispatchSemaphore(value: 0)
    var result: NativeObservationSnapshot?
    guard pipeline.readSnapshot({ result = $0; done.signal() }) else { fatalError("Unexpected overlapping verification read") }
    wait(done); return result!
}
func drain(_ pipeline: NativeObservationPipeline) {
    let deadline = Date().addingTimeInterval(5)
    while snapshot(pipeline).writeInFlight {
        guard Date() < deadline else { fatalError("Durability verification job timed out") }
        Thread.sleep(forTimeInterval: 0.001)
    }
}
let arguments = CommandLine.arguments
let modes = ["--unbudgeted-compatibility", "--budgeted-cold", "--budgeted-warm"]
guard arguments.count == 4, modes.contains(arguments[3]) else {
    fatalError("Usage: RecordedObservationCheck external-frames.json private-output-directory --unbudgeted-compatibility|--budgeted-cold|--budgeted-warm")
}
let mode = arguments[3], unbudgeted = mode == "--unbudgeted-compatibility"
let inputs = try JSONDecoder().decode([Input].self, from: Data(contentsOf: URL(fileURLWithPath: arguments[1])))
guard inputs.count == 100 else { fatalError("This bounded compatibility fixture must contain exactly100 frames") }
let output = URL(fileURLWithPath: arguments[2], isDirectory: true).standardizedFileURL
let sourceRoots = ["/workspace/shared/blind-rebuild", "/workspace/shared/blind-native-observation"]
guard !sourceRoots.contains(where: { output.path == $0 || output.path.hasPrefix($0 + "/") ||
    (output.path.hasPrefix($0) && !output.path.hasPrefix("/workspace/shared/blind-native-observation-replay-private")) }) else {
    fatalError("Recorded derivatives must stay outside source/staging")
}
try FileManager.default.createDirectory(at: output, withIntermediateDirectories: true)
let databasePath = output.appendingPathComponent("recorded-" + UUID().uuidString + ".sqlite").path
let normalMemory = try MemoryStore(path: databasePath), store = try normalMemory.makeNativeObservationStore()
let session = UUID() // Local replay ownership, not a fabricated original device session identifier.
let preAccrual = mode == "--budgeted-warm" ? 60.0 : 0.0
let clock = ReplayClock(inputs[0].capturedAt - preAccrual)
let pipeline = NativeObservationPipeline(now: { clock.read() })
if !unbudgeted {
    let ready = DispatchSemaphore(value: 0)
    pipeline.begin(sessionID: session, storage: NativeObservationPersistenceAdapter.storage(normalMemory)) {
        guard $0 == .ready else { fatalError("Recorded restore failed") }; ready.signal()
    }
    wait(ready)
}
var allHistory = NativeObservationHistory(), allRecords: [UUID: NativeObservationRecord] = [:]
var pointCount = 0, comparisons = 0, recordBytes: [Int] = []
var logicalSubmittedBytes = 0, insertedPayloadBytes = 0, transactions = 0, admittedFrames = 0
for input in inputs {
    let pose = try input.worldToCamera.inverted()
    guard try pose.applying(to: Point3(0,0,0)).distance(to: input.expectedCameraPosition) < 1e-9 else { fatalError("Extrinsic inversion mismatch") }
    comparisons += 1
    let record = NativeObservationRecord(sessionID: session, coordinateFrameID: "recorded-arkitscenes:47333462",
        producer: .arkitScenesRecorded, sourceID: input.sourceID, capturedAt: input.capturedAt,
        poseCapturedAt: input.poseCapturedAt, poseSourceID: input.poseSourceID, receivedAt: nil, observedAt: nil,
        tracking: .notRecorded, cameraConvention: .pinholeRightDownForward, cameraToSessionWorld: pose,
        intrinsics: input.intrinsics, depth: input.depth, omitted: ["meshNotInFrameReplay", "annotationsUnconfirmedIncomplete"])
    try record.validate()
    let points = try input.depth.worldPoints(intrinsics: input.intrinsics, cameraToWorld: pose, convention: record.cameraConvention)
    guard points.allSatisfy(\.isFinite), record.isHistoryOnly, record.mapTarget == nil,
          record.unavailableEvidence.contains("poseCovariance") else { fatalError("Recorded evidence contract mismatch") }
    for expected in input.expectedPoints {
        guard points[expected.index].distance(to: expected.point) < 1e-8 else { fatalError("Pinhole projection mismatch") }
        comparisons += 1
    }
    pointCount += points.count; allRecords[record.id] = record
    let encoded = try allHistory.append(record); recordBytes.append(encoded.encodedBytes)
    if unbudgeted {
        // Clearly test-only direct compatibility mode. It deliberately bypasses live
        // admission and budget and must never be described as production cadence/cost.
        logicalSubmittedBytes += encoded.encodedBytes
        let result = try store.append([.init(id: encoded.id.uuidString, sessionID: session.uuidString,
            capturedAt: encoded.capturedAt, payload: encoded.payload)])
        transactions += 1; insertedPayloadBytes += result.insertedPayloadBytes; admittedFrames += 1
        guard result.insertedRecordCount == 1 else { fatalError("Expected one incremental row") }
    } else {
        clock.set(input.capturedAt)
        let observed = DispatchSemaphore(value: 0)
        if pipeline.offer(sessionID: session, capturedAt: input.capturedAt, extract: { record }, completion: {
            guard $0 == .observed else { fatalError("Recorded volatile admission failed") }; observed.signal()
        }) {
            wait(observed); drain(pipeline); admittedFrames += 1
        }
    }
}
let live = unbudgeted ? nil : snapshot(pipeline)
if !unbudgeted {
    let stats = pipeline.statistics(); logicalSubmittedBytes = stats.logicalBytesSubmitted
    insertedPayloadBytes = stats.committedPayloadBytes; transactions = stats.committedTransactions
    let elapsed = inputs.last!.capturedAt - inputs.first!.capturedAt + preAccrual
    guard Double(logicalSubmittedBytes) <= 131_072 * elapsed / 60,
          stats.observed == admittedFrames, stats.droppedBusy == 0,
          live!.pendingRecordCount <= 1 else { fatalError("Budget/volatile acceptance contract failed") }
}
let reopenedMemory = try MemoryStore(path: databasePath)
let durable = try reopenedMemory.makeNativeObservationStore().load()
let restored = try NativeObservationHistory(records: durable.rows.map { row in
    let entry = try NativeObservationEncodedRecord(payload: row.payload)
    guard entry.id.uuidString == row.id, entry.sessionID.uuidString == row.sessionID, entry.capturedAt == row.capturedAt,
          allRecords[entry.id] == entry.record else { fatalError("Persisted original evidence/identity/time changed") }
    return entry
}, evictedRecordCount: durable.evictedRecordCount)
if unbudgeted {
    guard restored == allHistory, logicalSubmittedBytes == recordBytes.reduce(0, +), insertedPayloadBytes == logicalSubmittedBytes else {
        fatalError("Unbudgeted incremental compatibility/accounting mismatch")
    }
} else {
    guard Set(restored.records.map(\.id)) == live!.durableRecordIDs,
          restored.payloadByteCount == insertedPayloadBytes, restored.evictedRecordCount == 0 else { fatalError("Budgeted reopened rows mismatch") }
    pipeline.stop()
}
print("Recorded \(mode):100 frames, \(pointCount) finite points, \(comparisons) comparisons, \(admittedFrames) admitted, \(restored.records.count) durable. No device/localization/clearance claim.")
let report: [String: Any] = ["mode": mode, "frames": inputs.count, "finiteSampledPoints": pointCount,
    "independentComparisons": comparisons, "encodedBytesPerRecord": recordBytes, "logicalSubmittedBytes": logicalSubmittedBytes,
    "committedPayloadBytes": insertedPayloadBytes, "successfulAppendTransactions": transactions,
    "admittedFrames": admittedFrames, "retainedRecords": restored.records.count, "retainedPayloadBytes": restored.payloadByteCount,
    "durableEvictions": restored.evictedRecordCount, "volatileLiveRecords": live?.history.records.count ?? 0,
    "volatileOnlyRecords": live?.volatileRecordIDs.count ?? 0,
    "originalCaptureSpanSeconds": inputs.last!.capturedAt - inputs.first!.capturedAt,
    "simulatedPreObservationAccrualSeconds": preAccrual,
    "costMeaning": "logical payload only; injected recorded monotonic clock, not physical SQLite/flash IO, device latency, or energy"]
print("RECORDED_METRICS " + String(decoding: try JSONSerialization.data(withJSONObject: report, options: [.sortedKeys]), as: UTF8.self))
