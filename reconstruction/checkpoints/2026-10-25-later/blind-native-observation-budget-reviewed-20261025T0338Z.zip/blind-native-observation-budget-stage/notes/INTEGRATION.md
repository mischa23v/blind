# Native observation ingestion: current budgeted staging proposal

No live checkout edits or push. Parent owns application and the later spatial async-IO merge. This stage supersedes the earlier whole-archive and incremental-only proposals; never apply their memory patches over this one.

## Scope and authority

The existing foreground ARFrame callback supplies actual full camera-to-session-world pose, capture/receipt time, session/frame IDs, intrinsics, sparse depth and optional ordinal confidence, and bounded observed plane/mesh snapshots. Selected map binding is ownership metadata only: points stay in their ARKit session frame. Camera heading is not body heading. Anchor snapshots do not invent original per-vertex observation times.

NativeARObservationAdapter retains its caps: 128 inspected anchors before filtering/sorting,32 surfaces,2,048 total surface vertices,512 sampled triangles per considered mesh, and 1,024 depth samples. Format/count/offset/stride/buffer checks precede reads. Missing/invalid depth or classification stays unavailable. The default supported-hardware configuration requests meshWithClassification or mesh within the existing permitted foreground session, with no new UI, camera session or model request. This adds unmeasured ARKit work; it is not zero overhead.

All records remain history-only. Body calibration, floor identity, pose covariance, map alignment, target association and complete corridor coverage are unavailable. There is no conversion to a localization capture, route lease, current object location or motion authorization. Ordinary model-memory retrieval never consumes these rows.

## Volatile observations and budgeted durability

The unchanged maximum 2 Hz raw-history admission is separate from the existing urgent sensor/hazard loop. One synchronously admitted extraction slot bounds retained ARFrames. Volatile history keeps 64 records and 2 MiB of encoded payload with cached per-record sizes. A blocked writer or exhausted budget does not hold that slot or the history-read queue. Geometry is never truncated to fit the durability budget.

The production default is a configurable monotonic token bucket:128 KiB per 60 seconds, maximum128 KiB credit/burst. Credit starts empty, including on process restart. The same budget survives camera stop/begin and privacy clear. A high-water clock fence discards credit after invalid/rollback samples and does not replay refill over previously seen clock ranges. Configuration is immutable; replacing a pipeline starts empty rather than granting a burst.

There is one active durability job and one freshest size-eligible pending record, no timer or delayed-work queue. A newer oversized record remains fully volatile with an explicit reason and does not replace an older still-eligible pending record. Insufficient credit leaves the candidate pending until another observation or an active-write completion permits a fresh check. Original capture age/session/generation are checked again at persistence; stopped, superseded or expired records do not become new facts.

A 42.4KB record needs roughly 19.4 seconds of valid cold-start accrual. Stopping sooner leaves it volatile. Failed SQL attempts consume byte credit, are not refunded, and do not trigger a tight retry loop. Snapshots distinguish acknowledged durable IDs from volatile IDs/reasons; counters distinguish coalescing, budget/size/clock deferral, encoding, attempted/committed bytes, failed writes and evictions. These counters remain in memory, not per-frame SQL writes.

This is a token bucket, not a strict rolling-window quota: over an arbitrary warmed interval T, raw attempted payload is bounded by 128 KiB +(128 KiB/60s)*T; from an empty cold start the bound is refill alone. That is 180 MiB per 24 hours from cold start, or 180.125 MiB over a warmed 24-hour interval, under a valid monotonic clock. These are engineering payload bounds, not physical SQLite/flash writes, battery or all-day performance measurements. See DURABILITY_POLICY.md.

## Existing GRDB and privacy

NativeObservationStore uses the unchanged pinned GRDB 7.11.1 engine and a dedicated .native-observations.sqlite file/DatabaseQueue next to ordinary memory in its existing private directory. Construction occurs on the utility durability queue. It is not a new database engine, not a copied database and not another connection competing for the ordinary memory file's writer lock.

Each bounded transaction inserts only new immutable record rows and performs oldest-insertion quota eviction using cached encoded lengths. A bounded metadata preflight rejects overfilled/corrupt stored state before materializing payloads or beginning inserts. Typed restoration checks row ID/session/time against the encoded record. Failed writes preserve durable rows while live observations remain explicitly volatile. Restart restores committed rows only. Durable eviction metadata shares the append transaction; no per-frame drop-counter transaction is added. The 2 MiB retained-payload quota is not a physical database/WAL-size or total-RAM guarantee.

The reviewed shared native privacy proposals are unchanged. Debug/perception/recognition cancellation remains synchronous. Clear invalidates capture/pending work immediately and runs after any already-entered observation transaction, bypassing the byte budget. Failure stays disabled and reports failure. Successful clear cannot be followed by an old pending write. Item/room/place/map deletion waits for that purge before completing its original destructive operation; existing revision ownership prevents stale callbacks deleting newer items/maps. Canonical room, item, journey and map persistence is not budgeted or evicted by this raw-history policy.

## Current source mapping and apply order

1. Add three production Core files: NativeObservation.swift, NativeObservationPipeline.swift, NativeObservationDurabilityBudget.swift. Add NativeObservationTests.swift, NativeObservationPipelineTests.swift and NativeObservationDurabilityBudgetTests.swift to the Core test target; keep the cross-package budget/privacy/bridge tests in their declared verification harness rather than copying undeclared Memory/adapter dependencies into Core; the isolated package and copied Geometry/SpatialMapBinding are verification scaffolding, NOT production replacements.
2. Add native/NativeARObservationAdapter.swift and NativeARObservationBridge.swift to ios/BlindAssist.
3. Apply memory-integration.patch only to its matching MemoryStore baseline. Add BlindMemory/Sources/BlindMemory/NativeObservationStore.swift and SQL/native_observations.sql, plus NativeObservationStorageTests.swift. Keep the GRDB pin. The SQL is for the dedicated observation database; do not register the superseded v5 whole-blob migration in ordinary memory.
4. Apply native-integration.patch only against recorded base hashes. NavigationModel base is 0e80e0f3a55c6d6121237bd0bbbcf96fb5de3977d658ede7674fbc53ac4b9ffc; photo-plus-clock rebased proposal is 5e2d404c19e7da5490391f5471dfcd47d7c3528e1dacfaa6e95dde58367274db. NativeMapping and IndoorNavigator proposals are unchanged from the reviewed final-clock rebase. The original observation patch still produces byte-identical proposals on that base.
5. Regenerate the actual Xcode project after adding files. Do not overlay the staged project preview or whole shared native files onto newer source. Preserve final clock/memory/debug/spatial changes.
6. Spatial async map IO follows this increment, rebased over its purge hooks. That merge and final live aggregate are separate review gates.
7. NativeObservationDeletionAdapter and NativeObservationPersistenceAdapter are extracted verification shells, NOT app target files. Their scripts verify exact production method regions. The RecordedObservationCheck executable and its unbudgeted mode are test-only. Production Release has no unbounded pipeline policy case; the native bridge always uses the budgeted default.
8. Run final aggregate/source/native-hosted checks and independent overlap review. Portable execution and syntax parse are not an Apple SDK/device build or physical acceptance.

## Evidence and provenance

Final counts/hashes are recorded in SOURCE_MANIFEST.json and verification logs. Earlier whole-archive failures and incremental-only 37.244× write-volume reduction remain historical witnesses, not current default-cadence measurements. Three recorded modes distinguish unbudgeted compatibility from cold and warmed default-budget behavior. Recorded originals/derivatives and SQLite outputs remain outside this stage/repository.

Official ARKitScenes scene 47333462 uses loader/docs pin 474aaa83d7b1c9080619d8485de2d7c885c01fc5. World-to-camera extrinsics are inverted, and +Z-forward/+Y-down pinhole coordinates remain distinct from live ARKit -Z-forward/+Y-up. Frame and nearest-pose timestamps stay separate. Annotations are unconfirmed/incomplete and not obstacle/clearance truth; no recorded covariance/body calibration/map-floor alignment exists.

Reused APIs: https://developer.apple.com/documentation/arkit/arframe/scenedepth ; https://developer.apple.com/documentation/arkit/argeometrysource ; https://developer.apple.com/documentation/arkit/armeshgeometry/classification ; https://developer.apple.com/documentation/arkit/visualizing-and-interacting-with-a-reconstructed-scene . Existing DepthProjection, RoomPlan and RTAB-Map code/pins are retained, not replaced with invented recognition, mapping or SLAM.

Apple SDK typechecking, ARKit/Metal/CoreVideo behavior, on-device file protection, actual model/speech/hazard interference, accuracy, mounting, flash amplification, thermal/battery use and sustained operation remain unverified. No independent-use safety or completed persistent world-model claim follows from this checkpoint.
