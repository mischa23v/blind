# Verification ledger for the budgeted checkpoint

Current terminal evidence:
- verification/budget-integration-final.log: 81 XCTest, zero failures. Includes 20 pure policy cases,10 budgeted pipeline/integration cases,19 history/geometry cases,15 other pipeline cases,6 exact bridge+actual GRDB cases and11 extracted native privacy/deletion cases.
- verification/memory-budget-final.log: 35 actual BlindMemory/GRDB 7.11.1 cases, zero failures;16 original cases unchanged plus 19 new row/quota/restore/isolation cases.
- verification/clock-native-budget-overlap.log: 16 exact  extracted native clock cases on the photo-plus-clock rebase. Generated clock callback text is byte-identical before/after observation hooks.
- verification/source-contracts-budget.log: 11 source/project-generation checks. verification/photo-clock-overlap-source-contracts.log: 56 clock/photo/debug/everyday checks.
- verification/core-release-build.log:portable Release BlindCore build. DEBUG-only unbounded test policy is absent in Release. verification/native-parse.log:Release and DEBUG/RTAB/familiar syntax on five native files, not Apple SDK typechecking.
- verification/recorded-{unbudgeted-compatibility,budgeted-cold,budgeted-warm}.log and recorded-budget-modes.json:explicitly separated actual GRDB recorded modes, source/projection checks and reopened-repository equivalence. No killed-process or power-loss proof.
- verification/durability-budget-highwater: 20 focused cases and 100,000 exact-rational oracle samples with clock faults; the reviewer independently reran the oracle. These numerical samples are not device-runtime measurements.
- verification/rebase-preservation.json and persistence-extraction.json:exact shared-source and native-persistence extraction lineage.

Preserved failures/history:
- deletion-repro-before.log:original delayed map deletion removed a newer recreated file.
- legacy-amplification-failure.log and legacy-recorded-cost.log:old whole-archive payload amplification.
- regressions/durability-clock-replay-before plus budget-clock-replay-before.log:original clock rollback/nonfinite refill replay; source and full external failure-log hash/path preserved.
- pipeline-clock-window-before.log and regressions/PipelineClockWindow.before.swift:one coherent-clock regression failed 4 assertions before atomic admission repair.
- photo-clock-overlap-source-contracts-before-project-regeneration.log:overlap fixture had added native source files but a stale copied project; regenerating the stage-only project fixed the contract without weakening it.
- Older core-tests, core-tests-initial, budget-integration-initial, clock-native-callbacks and related copied logs are historical runs, not the authoritative current counts above.

Source-only archive excludes binaries, build caches, real sensor assets, dataset derivatives and SQLite files. Recorded data and replay databases stay in external private workspace locations. Final live aggregate, subsequent async IndoorNavigator merge, Apple SDK/device accuracy and performance acceptance remain parent/device work.
