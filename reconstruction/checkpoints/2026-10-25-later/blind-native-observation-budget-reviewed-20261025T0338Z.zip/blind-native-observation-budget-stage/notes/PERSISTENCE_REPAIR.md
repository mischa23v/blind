# Historical incremental-only repair record

This document records the verified incremental-only checkpoint preserved at blind-native-observation-incremental-verified-20261025T0304Z.zip (SHA-25626e4ae29a2a3bd50294aa88bb30c62577943093e2e8ed03fba41436307983139). Its unbudgeted rate and multi-record pending batch are NOT the current production proposal. Current behavior/apply instructions are in INTEGRATION.md and DURABILITY_POLICY.md. The legacy/incremental byte comparisons remain valid historical evidence.

# Incremental observation durability repair, staged only

Application of the previous checkpoint was held after a second cost/noninterference review. Its frozen ZIP and original code remain unchanged outside this stage. This repair is not an all-day performance acceptance or permission to apply.

## Reproduced failures and boundaries

The prior implementation encoded and saved the entire retained archive for each admitted frame, up to 2 MiB at 2 Hz. Its application-payload bound was 4 MiB/s, 14.0625 GiB/hour or 337.5 GiB/day before SQLite amplification. Those figures are arithmetic code bounds, not measurements of device flash or battery.

The failing executable synthetic witness processed 100 small records: 52,576 bytes of new record data caused 2,314,070 logical archive bytes in 100 saves. The unchanged original implementation on the official 100-frame ARKitScenes fixture submitted 157,959,083 logical archive bytes for 4,241,169 bytes of new records in 100 saves. Both original result logs and witness sources are retained. Dataset geometry and database derivatives are not packaged.

Utility dispatch also failed to isolate the old writer: its shared places.memory DatabaseQueue was used by synchronous main-thread ordinary-memory calls. A long observation transaction could make those calls wait on GRDB's writer.sync. This is a different problem from camera-frame admission and from physical device resource cost.

## Replacement data flow

1. The existing permitted camera callback still offers at most two observations per second after urgent sensor processing. One synchronous extraction slot bounds retained ARFrames. Depth/mesh sampling caps, provenance and unavailable fields are unchanged.
2. Each valid record is encoded once. NativeObservationEncodedRecord caches its immutable bytes and byte count. NativeObservationHistory maintains up to 64 records and 2 MiB of payload using cached sizes. Appending does not encode the ring or re-encode old records.
3. Volatile history and its bounded read callback stay on the extraction/history queue. A database writer cannot hold this frame slot or read queue. Failed writes do not discard useful live history.
4. A separate durability queue has one active write and one coalesced pending batch, each bounded by the same 64-record/2-MiB limits. It holds immutable record bytes, never pending ARFrames or per-record completion closures. When blocked, successive offers replace that one pending snapshot; live observations continue and normal ring evictions remain explicit.
5. Before SQL admission, generation/session ownership and original capture age are checked again. Expired pending records are skipped, not given renewed timestamps. A failed transaction does not trigger a busy retry loop; a later admitted observation may retry still-fresh records.
6. Snapshots separately expose retained durable IDs and volatile IDs. Statistics distinguish encoded bytes, submitted logical bytes, attempted and committed transactions, committed payload bytes/records, failed writes, pending-batch replacements, age/ownership omissions and evictions before durable confirmation. A transaction already admitted to SQLite cannot be forcibly cancelled. A stale completion cannot mark another session's live history durable.

## Existing GRDB, separate writer/file

BlindMemory continues to pin GRDB 7.11.1. NativeObservationStore is a small dedicated GRDB repository, not another database engine or SLAM implementation. MemoryStore.makeNativeObservationStore constructs it on the durability queue at the ordinary memory path plus .native-observations.sqlite, in the existing private AssistantMemory directory. It uses a distinct SQLite file and DatabaseQueue, not a second connection to the ordinary memory file.

The new schema stores one immutable row per record, its original ID/session/time and cached encoded byte count, plus an exact profile-scoped eviction count. In one transaction, append inserts only new rows, checks identical duplicates without rewriting them, then evicts oldest insertion rows to meet count and payload quotas. It never rewrites the retained payload ring. Empty operations, malformed metadata, conflicting duplicates, out-of-order capture times, quota violations and counter exhaustion are explicit failures. Rollback preserves the previous durable rows.

A bounded metadata preflight runs inside the same read/write transaction before payload fetches or inserts. It uses a maximum-count-plus-one sentinel, checked byte totals and SQLite length metadata to reject an externally overfilled/corrupt database without materializing arbitrary historical payloads. Restoring typed records additionally validates the serialized record and its exact row identity/time in the native bridge.

No native-observations blob permission remains in ordinary MemoryStore retrieval. No model context, prompt, speech, localization capture or route lease consumes this store.

## Privacy, restart and failure

The already-reviewed NavigationModel, NativeMapping and IndoorNavigator privacy wrappers are unchanged from the final-clock rebase. Debug/perception/recognition cancellation stays synchronous. Item/room/map actions then wait for raw-history clear before completing their original destructive operation, with the existing item/map ownership fences.

Clear immediately invalidates capture and pending durability, then deletes on the same serial durability queue after any transaction already inside SQLite. Successful completion cannot be followed by an old pending write. A failed clear stays disabled and reports failure; it does not claim history disappeared. A bounded control slot prevents repeated clear/begin callbacks from queueing unlimited work.

Restart restores only committed rows. Uncommitted/failed observations are explicitly volatile and are not claimed to survive process termination. Durable map/room/item stores remain separate; evicting this short raw window does not mean those learned records were forgotten. None of this constitutes persistent world mapping.

## Verification and limits

The final verification manifest/logs will identify the exact terminal counts. Dedicated actual-GRDB tests already cover row-level byte accounting, unchanged-row update prevention, transactional rollback, count/byte quotas, restart, profile isolation, malformed restoration and main-thread normal-memory completion while an actual observation transaction is held. Core tests cover blocked-writer live admission/reads, bounded coalescing, original timestamps, volatile-on-failure, stop/restart and privacy barriers. The extracted native bridge persistence methods and actual recorded replay provide additional cross-package checks.

The main-thread test proves removal of the shared application writer lock. It does not prove zero shared CPU, disk, kernel, thermal or scheduling contention. ARKit scene reconstruction/classification is still default-on only on supported hardware within the existing permitted foreground camera session; its added runtime cost is unmeasured.

Incremental persistence removes history-window amplification, not all volume. Under the unchanged maximum 2-MiB new-record limit and 2-Hz admission policy, a pathological stream of entirely new maximum-sized records can still submit 4 MiB/s. Actual fixture totals are reported separately. An enforceable lower durability-volume ceiling would require an explicit byte-budget/selection policy that retains full-rate volatile observations and honestly marks nonpersisted records. No such policy is silently substituted for this incremental repair.

The 2-MiB quota is retained encoded payload, not a physical database/WAL/file-size limit or total process-memory measurement. Apple SDK typechecking, native sensor accuracy, filesystem protection behavior, actual callback scheduling, flash amplification, battery, thermal load and all-day operation remain unverified. Missing pose covariance, body calibration, floor identity, map alignment, target association and corridor coverage stay unavailable. No motion authority is created.
