# Source-only preservation scope

This archive is a staged proposal, not a live apply. It contains app-owned Swift and SQL sources, narrow patches, exact shared-source preimages/proposals, portable verification scaffolding, test sources, result logs, hashes, and implementation notes.

It contains no ARKitScenes images, depth arrays, trajectory matrices, annotations, geometry fixtures or derived SQLite databases. Recorded data, private replay input and replay databases stay outside the archive. Included recorded evidence is aggregate counts, encoded record sizes, provenance hashes and test outcomes only. No manufacturer documentation is copied; API references are links. The existing BlindMemory license and dependency pins are retained, but third-party GRDB or SQLite implementation source is not vendored here.

It contains no user conversation export, credentials, environment files, compiled output, caches or installed dependencies. Packaging checks enforce a text/source extension allowlist, UTF-8/no-NUL content, no build directories/symlinks, and common credential signatures. This is a bounded content audit, not a guarantee against every possible secret pattern.

The final SOURCE_MANIFEST.json inventories every payload file; SHA256SUMS covers that manifest and its payload. The archive's own hash is recorded separately to avoid a self-referential checksum. Parent owns private repository preservation, exact-base application and final aggregate validation.
