// swift-tools-version: 5.9
import PackageDescription
let package = Package(name: "NativeObservationCheckpoint", products: [.library(name: "BlindCore", targets: ["BlindCore"])],
    dependencies: [.package(path: "BlindMemory")],
    targets: [.target(name: "BlindCore"), .target(name: "NativeObservationDeletionAdapter"), .target(name: "NativeObservationPersistenceAdapter", dependencies: ["BlindCore", .product(name: "BlindMemory", package: "BlindMemory")]), .executableTarget(name: "RecordedObservationCheck", dependencies: ["BlindCore", "NativeObservationPersistenceAdapter", .product(name: "BlindMemory", package: "BlindMemory")]),
              .testTarget(name: "BlindCoreTests", dependencies: ["BlindCore", "NativeObservationDeletionAdapter", "NativeObservationPersistenceAdapter", .product(name: "BlindMemory", package: "BlindMemory")])])
