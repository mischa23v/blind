// swift-tools-version: 5.9
import PackageDescription
let package = Package(name: "ConnectedJourneyCheckpoint", products: [.library(name: "BlindCore", targets: ["BlindCore"])], targets: [.target(name: "BlindCore"), .target(name: "NativeJourneyAdapter", dependencies: ["BlindCore"]), .target(name: "NativeQuietReplay", dependencies: ["BlindCore"]), .testTarget(name: "NativeQuietReplayTests", dependencies: ["NativeQuietReplay", "BlindCore"]), .testTarget(name: "BlindCoreTests", dependencies: ["BlindCore", "NativeJourneyAdapter"])])
