from pathlib import Path
import difflib, hashlib, json, sys
root=Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parents[1]
base=(root/'native-baseline/NavigationModel.swift').read_text()
new=base.replace('private var interruptedSearch = InterruptedObjectSearch()', 'private var interruptedSearch = InterruptedObjectSearch()\n    private var heldSearchIntent = HeldSearchIntent()')
old='    func stopDescriptions() { cancelDescription(); voice.endManualTurn(); feedback.interruptAmbient(); ambientDescriptions = false }'
replacement='''    func stopDescriptions() {
        let pending = objectSearch ?? interruptedSearch.restore(goalRevision: companionWorkingState.goalRevision,
            generation: assistantSession.generation, now: ProcessInfo.processInfo.systemUptime)
        heldSearchIntent.hold(target: pending?.target ?? trackedTarget?.query,
            goalRevision: companionWorkingState.goalRevision, origin: .trustedInterface)
        interruptedSearch.cancel()
        cancelDescription(); voice.endManualTurn(); feedback.interruptAmbient(); ambientDescriptions = false
    }
    func resumeDescriptions() {
        ambientDescriptions = true
        heldSearchIntent.resume(origin: .trustedInterface)
        resumeHeldSearchIfPossible()
    }
    private func resumeHeldSearchIfPossible() {
        guard assistantSession.state == .active, running, !busy, !voice.awaitingUtterance,
              !assistantSession.privateAudioHeld, feedback.speechPriority == nil,
              conversationSpeech.isEmpty, objectSearch == nil, readingTool == nil,
              !currencyActive, !colorActive, let frame = session.currentFrame else { return }
        guard let target = heldSearchIntent.takeForFreshSearch(goalRevision: companionWorkingState.goalRevision,
            freshViewAvailable: captureObjectView(frame) != nil,
            nativeResourceIdle: objectSearchNativeLease == nil) else { return }
        objectSearch = ObjectSearch(target: target, now: ProcessInfo.processInfo.systemUptime)
        continueSearch()
    }'''
photo_old = old.replace('{ cancelDescription();', '{ clearExploreSnapshot(); cancelDescription();')
if new.count(photo_old) == 1:
    old = photo_old
    replacement = replacement.replace('    func stopDescriptions() {\n', '    func stopDescriptions() {\n        clearExploreSnapshot()\n')
assert new.count(old)==1
new=new.replace(old,replacement)
assert new.count('case .resume: ambientDescriptions = true')==1
new=new.replace('case .resume: ambientDescriptions = true','case .resume: resumeDescriptions()')
# Existing ordinary-question suspension remains bounded. A deliberate hold is a
# different intent and cannot auto-restore that search on a later camera frame.
old='''    private func resumeInterruptedSearchIfPossible() {
        guard assistantSession.state == .active'''
assert new.count(old)==1
new=new.replace(old,'''    private func resumeInterruptedSearchIfPossible() {
        guard !heldSearchIntent.held, assistantSession.state == .active''')
# Retry only the retained intent when the already-running camera supplies a fresh
# frame and the previous native operation has really released its resource slot.
old='''        resumeInterruptedSearchIfPossible()
        continueSearch()'''
assert new.count(old)==2
new=new.replace(old,'''        resumeHeldSearchIfPossible()
        resumeInterruptedSearchIfPossible()
        continueSearch()''')
# Explicit new task/cancel and conversation end must not revive an old held search.
new=new.replace('''        case .cancel:
            everydayTasks.cancelAll(); everydayTicket = nil; everydayUtterance = ""''','''        case .cancel:
            heldSearchIntent.cancel()
            everydayTasks.cancelAll(); everydayTicket = nil; everydayUtterance = ""''')
new=new.replace('''    func endConversation() {
        voiceRoomScan.cancel()''','''    func endConversation() {
        heldSearchIntent.cancel()
        voiceRoomScan.cancel()''')
# The child-first home uses a separate toggle entry, not AssistantControl.parse.
old = '            ambientDescriptions = true\n            speakOperation(arabic ? "سأصف ما يتغير حولك."'
assert new.count(old) == 1
new = new.replace(old, '            resumeDescriptions()\n            speakOperation(arabic ? "سأصف ما يتغير حولك."')
# A newly requested search supersedes a held request even if canonical goal text
# happens to be unchanged. A remembered detector result is never resumed.
for signature in ['    private func findWithSensors(_ name: String, question: String) -> Bool {',
                  '    private func locate(_ target: String, question: String) -> Bool {']:
    assert new.count(signature) == 1
    new = new.replace(signature, signature + '\n        heldSearchIntent.cancel()')
# Privacy deletion retires held target text and its asynchronous authority BEFORE
# fallible storage, while leaving the native operation lease owned by its callback.
privacy_helper = """    private func retireHeldSearchForPrivacyDeletion() {
        heldSearchIntent.cancel(); interruptedSearch.cancel()
        objectSearch?.cancel(); objectSearch = nil; trackedTarget = nil
        searchInFlight = false; trackLookInFlight = false
    }
"""
anchor = '    func clearAssistantConversation() {'
assert new.count(anchor) == 1
new = new.replace(anchor, privacy_helper + anchor)
for signature in ['    func clearAssistantConversation() {',
                  '    func forgetConversationRecord(id: String) {',
                  '    @discardableResult func correctConversationRecord(id: String, replacement: String) -> Bool {',
                  '    func clearObservedObjects() {',
                  '    private func removeObservedHistory(category: String? = nil, room: String? = nil) throws {',
                  '    @discardableResult func forgetItem(_ item: RememberedItem) -> Bool {',
                  '    func forgetRoomPictures(_ id: String) {',
                  '    func deletePlace(_ place: SavedPlace) {',
                  '    func forgetRoom(_ id: String) {']:
    assert new.count(signature) == 1
    new = new.replace(signature, signature + '\n        retireHeldSearchForPrivacyDeletion()')
(root/'native-proposal/NavigationModel.swift').write_text(new)
diff=''.join(difflib.unified_diff(base.splitlines(True),new.splitlines(True),fromfile='a/ios/BlindAssist/NavigationModel.swift',tofile='b/ios/BlindAssist/NavigationModel.swift'))
(root/'patches/NavigationModel-quiet-search.patch').write_text(diff)
(root/'evidence/quiet-proposal-preimage.json').write_text(json.dumps({'path':'ios/BlindAssist/NavigationModel.swift','preimage_sha256':hashlib.sha256(base.encode()).hexdigest(),'proposal_sha256':hashlib.sha256(new.encode()).hexdigest(),'status':'staging only; requires ordered live-preimage rebase'},indent=2)+'\n')
