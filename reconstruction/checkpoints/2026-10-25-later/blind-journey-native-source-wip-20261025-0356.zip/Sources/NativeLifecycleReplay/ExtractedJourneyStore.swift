import Foundation
import NativeJourneyAdapter
import BlindCore

final class JourneyStore: ObservableObject {
    @Published private(set) var saved: [Journey] = []
    @Published private(set) var distance = 0.0
    @Published private(set) var message = ""
    private let connectedIO: (any ConnectedJourneyRuntimeIO)?
    private let journeySHA256: SpatialMapSHA256
    private lazy var connected = MainActor.assumeIsolated {
        ConnectedJourneyRuntime(io: connectedIO ?? FoundationJourneyRuntimeIO(url: directory.appendingPathComponent("connected-state.json")),
            sha256: journeySHA256)
    }
    func withConnectedJourney<T>(_ operation: @MainActor (ConnectedJourneyRuntime) throws -> T) rethrows -> T {
        try MainActor.assumeIsolated { try operation(connected) }
    }
    private var recorder: JourneyRecorder?
    private var directory: URL
    var current: Journey? { recorder?.journey }
    init(connectedIO: (any ConnectedJourneyRuntimeIO)? = nil, journeySHA256: @escaping SpatialMapSHA256 = RegisteredIndoorNavigation.platformSHA256) {
        self.connectedIO = connectedIO; self.journeySHA256 = journeySHA256
        directory = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("Journeys", isDirectory: true)
        do {
            try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
            var values = URLResourceValues(); values.isExcludedFromBackup = true
            try directory.setResourceValues(values)
            #if os(iOS)
            try FileManager.default.setAttributes([.protectionKey: FileProtectionType.completeUntilFirstUserAuthentication], ofItemAtPath: directory.path)
            #endif
            saved = try FileManager.default.contentsOfDirectory(at: directory, includingPropertiesForKeys: nil)
                .filter { $0.pathExtension == "json" && $0.lastPathComponent != "connected-state.json" }.compactMap {
                    guard let data = try? Data(contentsOf: $0) else { return nil }
                    return try? JSONDecoder().decode(Journey.self, from: data)
                }.sorted { $0.createdAt > $1.createdAt }
        } catch { message = "Journey storage unavailable." }
        withConnectedJourney { runtime in
            runtime.onChange = { [weak self] in self?.objectWillChange.send() }
            runtime.restore()
        }
    }
    func begin() { withConnectedJourney { $0.cameraRestarted() }; finish(); recorder = JourneyRecorder(); distance = 0 }
    func observe(_ observation: Observation) {
        recorder?.observe(camera: observation.camera, time: observation.timestamp, tracking: observation.trackingNormal)
        if let recorder { distance = recorder.distance }
    }
    func breakTracking() { withConnectedJourney { $0.cameraRestarted() }; recorder?.breakTracking() }
    func finish() {
        withConnectedJourney { $0.cameraRestarted() }
        guard let recorder else { return }
        self.recorder = nil
        guard !recorder.journey.points.isEmpty else { return }
        do {
            try JSONEncoder().encode(recorder.journey).write(to: url(for: recorder.journey), options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
            saved.insert(recorder.journey, at: 0); message = "Journey saved on this phone."
        } catch { message = "Journey could not be saved." }
    }
    func url(for journey: Journey) -> URL { directory.appendingPathComponent("\(journey.id).json") }
    #if DEBUG
    private var debugPurgePending = false
    private var debugLastPurgeSucceeded: Bool?
    private func purgeDebugSessionDiagnostics() {
        guard !debugPurgePending else { return }
        debugPurgePending = true
        DebugSessionLog.purgeForPrivacyClear { [weak self] success in
            DispatchQueue.main.async { [weak self] in
                self?.debugPurgePending = false
                self?.debugLastPurgeSucceeded = success
                DebugNativeSessionTrace.reportPurgeResult(success)
            }
        }
    }
    #endif
    func delete(_ journey: Journey) {
        #if DEBUG
        purgeDebugSessionDiagnostics()
        #endif
        do { try FileManager.default.removeItem(at: url(for: journey)); saved.removeAll { $0.id == journey.id } }
        catch { message = "Journey could not be deleted." }
    }
}


@propertyWrapper struct Published<T> { var wrappedValue: T; init(wrappedValue:T) { self.wrappedValue = wrappedValue } }
protocol ObservableObject {}
extension ObservableObject { var objectWillChange: ChangePublisher { .init() } }
struct Journey: Codable { let id = UUID(); let createdAt = Date(); var points: [Int] = [] }
struct Observation { var camera = Point3(0,0,0); var timestamp = 0.0; var trackingNormal = true }
struct JourneyRecorder { var journey = Journey(); var distance = 0.0; mutating func observe(camera:Point3,time:Double,tracking:Bool) {}; mutating func breakTracking() {} }
enum DebugSessionLog { static func purgeForPrivacyClear(_ completion: (Bool)->Void) { completion(true) } }
enum DebugNativeSessionTrace { static func reportPurgeResult(_ success:Bool) {} }
enum RegisteredIndoorNavigation { static func platformSHA256(_ bytes:Data) throws -> String { throw JourneyRuntimeError.storageUnavailable } }
