import Foundation
import BlindCore

// EXPLICIT DEPENDENCY FAKES. Native methods below are extracted without editing
// their bodies. This harness tests control flow, not Vision/ARKit/VoiceOver.
struct ObjectSearch {
    var target: String; var startedAt: Double; var active = true
    init(target: String, now: Double) { self.target = target; startedAt = now }
    mutating func cancel() { active = false }
}
struct TrackedTarget { var query: String }
struct InterruptedObjectSearch {
    var pending: ObjectSearch?
    mutating func restore(goalRevision: String, generation: UInt64, now: Double) -> ObjectSearch? { defer { pending = nil }; return pending }
    mutating func cancel() { pending = nil }
}
struct Work { var id = UUID(); var key = "item"; func cancel() {} ; func clear() {}; func cancelRequested() {} }
final class Feedback {
    var alertActive = true; var stoppedInformation = 0; var interruptedAmbient = 0
    var speechPriority: SpeechPriority?
    var canSpeakAmbient = true
    func stopRequestedSpeech(_ id: UUID) {}
    func stopInformation(announceCancellation: Bool) -> Bool { stoppedInformation += 1; return true }
    func interruptAmbient() { interruptedAmbient += 1 }
}
final class Voice { var awaitingUtterance = false; var microphoneActive = true; func endManualTurn() {} }
struct WorkingState {
    var goalRevision = "goal-A", goal = "bathroom"
    mutating func suspendGoal() -> Bool { true }
    mutating func resumeGoal() -> Bool { true }
    mutating func changeGoal(_ next: String) { goal = next }
}
enum AssistantTaskControl { case pause, resume, cancel }
struct EverydayTasks {
    enum State { case active, paused, idle }
    var state: State = .active
    mutating func pause() { state = .paused }
    mutating func resume() { state = .active }
    mutating func cancelAll() { state = .idle }
}
struct Dialogue { mutating func setGoal(_ value: String) {} }
final class Indoor {
    var route = ["bedroom", "hall", "bathroom"]
    var replans = 0
    func cancelRoute() { route = [] }
}
struct SessionState {
    enum State { case active, muted, ended }
    var state: State = .active; var generation: UInt64 = 1; var privateAudioHeld = false
}
struct CameraSession { var currentFrame: Int? = 1 }
enum Detail { case minimal, balanced, detailed }
enum AssistantControl {
    case quiet, resume, moreDetail, lessDetail, moreInformation, lessInformation, repeatDescription
    static func parse(_ text: String) -> Self? { text == "quiet" ? .quiet : text == "resume" ? .resume : nil }
}
typealias AssistantDialogue = Dialogue
typealias CompanionWorkingState = WorkingState
enum MemoryError: Error { case missing }
struct RememberedItem { let key: String; let name: String }
struct Items: Codable { mutating func forget(_ name: String) {} }
struct Memory { func saveValue(namespace: String, id: String, payload: Data) throws {} }
struct Places { var memory: Memory? = nil }
struct ItemAppearance { func forget(_ key: String) -> Bool { true } }
struct RoomRecall { func forget(room: String) -> Bool { true } }
struct ChangePublisher { func send() {} }
final class QuietHarness {
    var objectSearch: ObjectSearch? = .init(target: "my backpack", now: 1)
    var trackedTarget: TrackedTarget?
    var heldSearchIntent = HeldSearchIntent(), interruptedSearch = InterruptedObjectSearch()
    var companionWorkingState = WorkingState(), assistantSession = SessionState(), session = CameraSession()
    var feedback = Feedback(), voice = Voice()
    var routeGoal = "bathroom", route = ["bedroom", "hall", "bathroom"]
    var running = true, freshView = true, ambientDescriptions = true
    var searchStarts = 0, objectSearchNativeLease: UUID?
    var unverifiedConversationID = UUID(), requestID = UUID(), exploreRequest = UUID()
    var unverifiedConversationTask: Work?, unverifiedConversationTimeout: Work?, requestedColorSpeech: Work?
    var preserveScanConfirmationOnce = false, everydayRetry = Work(), currencyRetake = Work(), colorInspectionWork = Work()
    var everydayRetryTicketID: UUID?, everydayRetryRequestID: UUID?, exploreTask: Work?
    var searchInFlight = false, trackLookInFlight = false, lookupInFlight = false
    var conversationSpeech: [String] = [], conversationEvidenceCaptures: [String] = []
    var requestedVisualDialogue: Work?, activeConversationSpeech: Work?, questionTimeoutTask: Work?, questionTask: Work?
    var streamedConversationText = "", currencyActive = false, colorActive = false
    var requestedColorWork: Work?, pendingQuestion: Work?, readingTool: Work?
    var busy = false, questionIsAutomatic = false, questionIsChat = false
    var detail: Detail = .balanced, wordsPerMinute = 120, message = "", arabic = false
    func cancelVoiceRoomScanConfirmation() {}
    func cancelContextualCapabilities() {}
    func stopReadingTool(announce: Bool) { readingTool = nil }
    func captureObjectView(_ frame: Int) -> Int? { freshView ? frame : nil }
    func continueSearch() { searchStarts += 1 }
    func repeatDescription() {}
    func speakOperation(_ text: String) -> Bool { true }
    var unverifiedDialogue = Dialogue(), unverifiedDialogueGeneration: UInt64?
    var assistantQuestion = "", itemMemoryRevision = UUID(), learningItem: Work?
    var places = Places(), itemAppearance = ItemAppearance(), items = Items(), roomRecall = RoomRecall()
    var objectWillChange = ChangePublisher()
    func invalidatePerceptionWork() {}
    func invalidateAutomaticRoomClues() {}
    func removeObservedHistory(category: String? = nil, room: String? = nil) throws {}
    func say(_ text: String) {}
    func purgeDebugSessionDiagnostics() {}

    var everydayTasks = EverydayTasks(), assistantDialogue = Dialogue(), indoor = Indoor()
    var everydayTicket: UUID?, everydayUtterance = "", objectiveDraft = "", sceneAnswer = "", currentReply = ""
    var returning = true
    func stopReturn() { returning = false }
    func persistWorkingState() {}
    func persistDialogue() {}
    func speakRequested(_ value: String) -> Bool { true }
    func routeEverydayTask(_ value: String) -> Bool { false }
    func handleItemOrLocate(_ value: String) -> Bool { false }


    func cancelDescription() {
        unverifiedConversationID = UUID()
        unverifiedConversationTask?.cancel(); unverifiedConversationTask = nil
        unverifiedConversationTimeout?.cancel(); unverifiedConversationTimeout = nil
        if !preserveScanConfirmationOnce { cancelVoiceRoomScanConfirmation() }
        preserveScanConfirmationOnce = false
        cancelContextualCapabilities()
        if let speech = requestedColorSpeech {
            requestedColorSpeech = nil; feedback.stopRequestedSpeech(speech.id)
        }
        everydayRetry.cancel(); everydayRetryTicketID = nil; everydayRetryRequestID = nil
        currencyRetake.clear()
        stopReadingTool(announce: false)
        exploreRequest = UUID(); exploreTask?.cancel(); exploreTask = nil
        searchInFlight = false; trackLookInFlight = false; lookupInFlight = false
        conversationSpeech.removeAll()
        conversationEvidenceCaptures.removeAll()
        requestedVisualDialogue = nil
        if activeConversationSpeech != nil {
            activeConversationSpeech = nil
            _ = feedback.stopInformation(announceCancellation: false)
        }
        streamedConversationText = ""
        questionTimeoutTask?.cancel(); questionTimeoutTask = nil
        objectSearch?.cancel(); objectSearch = nil; trackedTarget = nil
        currencyActive = false
        colorActive = false
        colorInspectionWork.cancelRequested(); requestedColorWork = nil
        pendingQuestion = nil
        requestID = UUID(); questionTask?.cancel(); questionTask = nil; busy = false; questionIsAutomatic = false
        questionIsChat = false
    }
    func stopDescriptions() {
        let pending = objectSearch ?? interruptedSearch.restore(goalRevision: companionWorkingState.goalRevision,
            generation: assistantSession.generation, now: ProcessInfo.processInfo.systemUptime)
        heldSearchIntent.hold(target: pending?.target ?? trackedTarget?.query,
            goalRevision: companionWorkingState.goalRevision, origin: .trustedInterface)
        interruptedSearch.cancel()
        cancelDescription(); voice.endManualTurn(); feedback.interruptAmbient(); ambientDescriptions = false
    }
    @discardableResult func handleAssistantControl(_ text: String) -> Bool {
        guard let control = AssistantControl.parse(text) else { return false }
        switch control {
        case .quiet: stopDescriptions()
        case .resume: resumeDescriptions()
        case .moreDetail: detail = detail == .minimal ? .balanced : .detailed
        case .lessDetail: detail = detail == .detailed ? .balanced : .minimal
        case .moreInformation: wordsPerMinute = min(1800, wordsPerMinute + 60)
        case .lessInformation: wordsPerMinute = max(30, wordsPerMinute - 60)
        case .repeatDescription: repeatDescription(); return true
        }
        message = arabic ? "تم تحديث إعدادات الوصف." : "Description settings updated."
        _ = speakOperation(message)
        return true
    }
    func toggleHomeDescriptions() {
        if ambientDescriptions {
            stopDescriptions()
            speakOperation(arabic ? "سأتوقف عن الوصف. تبقى تنبيهات المسار مفعلة." : "I'll be quiet. Path alerts stay on.")
        } else {
            resumeDescriptions()
            speakOperation(arabic ? "سأصف ما يتغير حولك." : "I'll describe changes around you.")
        }
    }
    func handleConversationTaskControl(_ control: AssistantTaskControl) {
        switch control {
        case .pause:
            everydayTasks.pause(); everydayTicket = nil
            let suspended = companionWorkingState.suspendGoal() || everydayTasks.state == .paused
            sceneAnswer = suspended ? (arabic ? "أوقفت المهمة مؤقتاً. يمكننا التحدث عن شيء آخر." : "I've paused that task. We can talk about something else.") : (arabic ? "لا توجد مهمة جارية لإيقافها." : "There is no active task to pause.")
        case .resume:
            everydayTasks.resume()
            let resumed = companionWorkingState.resumeGoal() || everydayTasks.state == .active
            sceneAnswer = resumed ? (arabic ? "استعدت هدفك السابق. سأتحقق من المعلومات الحالية قبل المتابعة." : "I've restored your previous goal. Current conditions still need checking.") : (arabic ? "لا توجد مهمة موقوفة يمكن استعادتها الآن." : "There is no paused task I can resume right now.")
        case .cancel:
            heldSearchIntent.cancel()
            everydayTasks.cancelAll(); everydayTicket = nil; everydayUtterance = ""
            companionWorkingState.changeGoal("")
            sceneAnswer = arabic ? "ألغيت المهمة الحالية." : "I've cancelled the current task."
        }
        assistantDialogue.setGoal(companionWorkingState.goal)
        objectiveDraft = companionWorkingState.goal
        stopReturn(); indoor.cancelRoute()
        persistWorkingState(); persistDialogue()
        currentReply = sceneAnswer
        if assistantSession.state == .active { _ = speakRequested(sceneAnswer) }
        if case .resume = control, !everydayUtterance.isEmpty, everydayTasks.state == .active {
            let request = everydayUtterance
            if !routeEverydayTask(request) { _ = handleItemOrLocate(request) }
        }
    }
    func clearAssistantConversation() {
        retireHeldSearchForPrivacyDeletion()
        #if DEBUG
        purgeDebugSessionDiagnostics()
        #endif
        #if BLIND_FAMILIAR_PEOPLE
        familiarPeople.cancelSearchForNewGoal()
        #endif
        everydayTasks.cancelAll(); everydayTicket = nil; everydayUtterance = ""
        cancelDescription(); _ = feedback.stopInformation(announceCancellation: false); stopReturn(); indoor.cancelRoute()
        unverifiedDialogue = AssistantDialogue(); unverifiedDialogueGeneration = nil
        assistantDialogue = AssistantDialogue(); objectiveDraft = ""; persistDialogue()
        companionWorkingState = CompanionWorkingState(); persistWorkingState()
        sceneAnswer = ""; currentReply = ""; assistantQuestion = ""
    }
    @discardableResult func forgetItem(_ item: RememberedItem) -> Bool {
        retireHeldSearchForPrivacyDeletion()
        #if DEBUG
        purgeDebugSessionDiagnostics()
        #endif
        itemMemoryRevision = UUID()
        invalidatePerceptionWork()
        cancelDescription()
        if learningItem?.key == item.key { learningItem = nil }
        do {
            guard let memory = places.memory, itemAppearance.forget(item.key) else { throw MemoryError.missing }
            var updated = items; updated.forget(item.name)
            try memory.saveValue(namespace: "items", id: "all", payload: JSONEncoder().encode(updated))
            try removeObservedHistory(category: item.name)
            items = updated
            objectWillChange.send(); return true
        } catch {
            say(arabic ? "لم يكتمل الحذف. أعد المحاولة عند توفر التخزين." : "Deletion could not finish. Retry when storage is available.")
            return false
        }
    }
    func forgetRoomPictures(_ id: String) {
        retireHeldSearchForPrivacyDeletion()
        #if DEBUG
        purgeDebugSessionDiagnostics()
        #endif
        invalidateAutomaticRoomClues()
        invalidatePerceptionWork()
        guard roomRecall.forget(room: id) else {
            say(arabic ? "تعذر حذف صور الغرفة. أعد المحاولة." : "Room pictures could not be deleted. Please retry."); return
        }
        objectWillChange.send()
    }
    func resumeDescriptions() {
        ambientDescriptions = true
        heldSearchIntent.resume(origin: .trustedInterface)
        resumeHeldSearchIfPossible()
    }
    func resumeHeldSearchIfPossible() {
        guard assistantSession.state == .active, running, !busy, !voice.awaitingUtterance,
              !assistantSession.privateAudioHeld, feedback.speechPriority == nil,
              conversationSpeech.isEmpty, objectSearch == nil, readingTool == nil,
              !currencyActive, !colorActive, let frame = session.currentFrame else { return }
        guard let target = heldSearchIntent.takeForFreshSearch(goalRevision: companionWorkingState.goalRevision,
            freshViewAvailable: captureObjectView(frame) != nil,
            nativeResourceIdle: objectSearchNativeLease == nil) else { return }
        objectSearch = ObjectSearch(target: target, now: ProcessInfo.processInfo.systemUptime)
        continueSearch()
    }
    func retireHeldSearchForPrivacyDeletion() {
        heldSearchIntent.cancel(); interruptedSearch.cancel()
        objectSearch?.cancel(); objectSearch = nil; trackedTarget = nil
        searchInFlight = false; trackLookInFlight = false
    }
}
