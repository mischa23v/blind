import Foundation
import BlindCore

/// STAGED native Foundation persistence adapter. Its actor owns all file access;
/// never call it from the hazard sink or wait synchronously on the main thread.
/// A main-thread integration MUST immediately retire its exact route-speech/beacon
/// attempt before enqueueing any goal/cancel/hold/catalog mutation, then revalidate
/// returned tickets immediately before dispatch and on the output watchdog.
/// This actor does not supply calibrated native poses or connect the current UI.
public actor ConnectedJourneyStore {
    public typealias Writer = @Sendable (Data, URL) throws -> Void
    private let storage: URL
    private let writer: Writer
    private var coordinator: ConnectedJourneyCoordinator
    private var started = false

    public init(storage: URL, catalog: ConnectedJourneyCatalog, body: BodyEnvelope,
                limits: SpatialLocalizationLimits, writer: @escaping Writer = { try ConnectedJourneyStore.protectedAtomicWrite($0, $1) }) throws {
        self.storage = storage; self.writer = writer
        coordinator = try .init(catalog: catalog, body: body, limits: limits)
    }
    /// A missing file is a new journey. A malformed/read-failed file is an error,
    /// never silently replaced with an empty journey or a guessed current pose.
    public func restore(catalog: ConnectedJourneyCatalog, body: BodyEnvelope,
                        limits: SpatialLocalizationLimits) throws -> ConnectedJourneySnapshot {
        guard !started else { throw SpatialInstallationError.historyRewrite }
        started = true
        coordinator.loseTracking()
        guard FileManager.default.fileExists(atPath: storage.path) else { return coordinator.snapshot }
        let handle = try FileHandle(forReadingFrom: storage)
        defer { try? handle.close() }
        let data = try handle.read(upToCount: ConnectedJourneySnapshot.maximumBytes + 1) ?? Data()
        let snapshot = try ConnectedJourneySnapshot(data: data)
        coordinator = try .init(catalog: catalog, body: body, limits: limits, snapshot: snapshot)
        return snapshot
    }
    /// Serial non-suspending transaction body. The candidate remains in memory as
    /// unsaved on failure; a retry writes the latest intent, never the old goal.
    public func transact<Value: Sendable>(_ operation: @Sendable
        (inout ConnectedJourneyCoordinator, (Data) throws -> Void) throws -> Value) throws -> Value {
        started = true
        let storage = storage, writer = writer
        return try operation(&coordinator) { try writer($0, storage) }
    }
    public func snapshot() -> ConnectedJourneySnapshot { coordinator.snapshot }
    public func currentPose(now: Double) -> SpatialLocalizationCapture? { coordinator.currentPose(now: now) }
    public func permits(_ ticket: ConnectedJourneyRouteTicket, now: Double) -> Bool { coordinator.permits(ticket, now: now) }
    /// User-authorized privacy deletion, not map withdrawal. Persist cancellation
    /// first so a failed remove cannot leave a successfully saved active intention.
    public func deleteHistory(origin: CompanionCommandOrigin, recordedAt: Date,
                              catalog: ConnectedJourneyCatalog, body: BodyEnvelope,
                              limits: SpatialLocalizationLimits) throws {
        let storage = storage, writer = writer
        try coordinator.cancel(origin: origin, recordedAt: recordedAt) { try writer($0, storage) }
        coordinator.loseTracking()
        if FileManager.default.fileExists(atPath: storage.path) { try FileManager.default.removeItem(at: storage) }
        coordinator = try .init(catalog: catalog, body: body, limits: limits)
    }
    public static func protectedAtomicWrite(_ data: Data, _ storage: URL) throws {
        guard data.count <= ConnectedJourneySnapshot.maximumBytes else { throw ConnectedJourneyError.invalidHistory }
        var directory = storage.deletingLastPathComponent()
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        #if os(iOS)
        var values = URLResourceValues(); values.isExcludedFromBackup = true
        try directory.setResourceValues(values)
        try FileManager.default.setAttributes([.protectionKey: FileProtectionType.completeUntilFirstUserAuthentication], ofItemAtPath: directory.path)
        #endif
        try data.write(to: storage, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
    }
}
