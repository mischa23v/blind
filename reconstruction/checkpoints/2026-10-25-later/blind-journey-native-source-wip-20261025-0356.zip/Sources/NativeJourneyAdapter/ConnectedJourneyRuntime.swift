import Foundation
import BlindCore

public enum JourneyRuntimeError: Error, Equatable {
    case loading, noRegisteredMap, storageUnavailable, superseded, tooLarge, invalidEnvelope
}

/// Existing installation envelopes plus typed journey history in one local atomic
/// record. Exact geometry bytes are reused, never reconstructed from old poses.
public struct JourneyRuntimeEnvelope: Codable, Sendable {
    public static let maximumBytes = 8_000_000
    public let schemaVersion: Int
    public let journey: ConnectedJourneySnapshot
    public let installations: [Data]
    public let portals: [JourneyPortal]
    public init(journey: ConnectedJourneySnapshot, installations: [Data], portals: [JourneyPortal]) {
        schemaVersion = 1; self.journey = journey; self.installations = installations; self.portals = portals
    }
    public func encoded() throws -> Data {
        try journey.validate()
        guard schemaVersion == 1, installations.count <= 32, portals.count <= 128,
              installations.reduce(0, { $0 + $1.count }) <= Self.maximumBytes else { throw JourneyRuntimeError.tooLarge }
        let encoder = JSONEncoder(); encoder.outputFormatting = [.sortedKeys]
        let data = try encoder.encode(self)
        guard data.count <= Self.maximumBytes else { throw JourneyRuntimeError.tooLarge }
        return data
    }
    public init(data: Data) throws {
        guard data.count <= Self.maximumBytes else { throw JourneyRuntimeError.tooLarge }
        self = try JSONDecoder().decode(Self.self, from: data)
        _ = try encoded()
    }
}

/// Immutable values are captured cheaply on the main owner. Geometry encoding is
/// deferred to the IO executor, never performed on a goal/cancel/hazard turn.
public struct JourneyRuntimeWrite: Sendable {
    public let journey: ConnectedJourneySnapshot
    public let installations: [SpatialMapInstallation]
    public let portals: [JourneyPortal]
    public func envelope() throws -> JourneyRuntimeEnvelope {
        .init(journey: journey, installations: try installations.map { try $0.encoded() }, portals: portals)
    }
}

public protocol ConnectedJourneyRuntimeIO: Sendable {
    func read() async throws -> Data?
    func write(_ payload: JourneyRuntimeWrite) async throws
}

/// File work is isolated from the synchronous native owner. The owner admits at
/// most one active write and one latest pending snapshot, so actor IO does not
/// acquire an unbounded mailbox from frame/goal updates.
public actor FoundationJourneyRuntimeIO: ConnectedJourneyRuntimeIO {
    private let url: URL
    public init(url: URL) { self.url = url }
    public func read() throws -> Data? {
        guard FileManager.default.fileExists(atPath: url.path) else { return nil }
        let file = try FileHandle(forReadingFrom: url); defer { try? file.close() }
        return try file.read(upToCount: JourneyRuntimeEnvelope.maximumBytes + 1)
    }
    public func write(_ payload: JourneyRuntimeWrite) throws {
        let data = try payload.envelope().encoded()
        var directory = url.deletingLastPathComponent()
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        #if os(iOS)
        var values = URLResourceValues(); values.isExcludedFromBackup = true
        try directory.setResourceValues(values)
        try FileManager.default.setAttributes([.protectionKey: FileProtectionType.completeUntilFirstUserAuthentication], ofItemAtPath: directory.path)
        #endif
        try data.write(to: url, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
    }
}

/// Main-owner lifecycle bridge. It retires executable output BEFORE asynchronous
/// IO, restores only durable knowledge, and never manufactures localization limits
/// or measurements. Without explicit calibrated-adapter configuration it still
/// saves destinations/history but cannot issue a physical route ticket.
@MainActor public final class ConnectedJourneyRuntime {
    public private(set) var snapshot = ConnectedJourneySnapshot()
    public private(set) var loading = false
    public private(set) var durable = false
    public private(set) var status = "Journey history is opening. Live location is unknown."
    public private(set) var storageError = false
    public var onOutputRetired: (() -> Void)?
    public var onClarificationRetired: ((UUID) -> Void)?
    public var onChange: (() -> Void)?
    public var goal: JourneyGoal? { snapshot.goal }
    public var question: JourneyReturnQuestion? { coordinator?.currentQuestion }
    public var expectedSessionID: UUID? { coordinator?.expectedSessionID }
    public var pendingWriteCount: Int { (writing == nil ? 0 : 1) + (pending == nil ? 0 : 1) }
    private let io: any ConnectedJourneyRuntimeIO
    private let sha256: SpatialMapSHA256
    private var coordinator: ConnectedJourneyCoordinator?
    private var catalog: ConnectedJourneyCatalog?
    private var body: BodyEnvelope?
    private var limits: SpatialLocalizationLimits?
    private var version = UUID()
    private var writing: UUID?
    private var pending: (UUID, JourneyRuntimeWrite)?
    private var latestWrite: JourneyRuntimeWrite?
    private var loadID: UUID?
    private var pendingInstallation: (SpatialMapInstallation, [JourneyPortal])?
    private var commandBlocked = false
    private var externalMapPending = false
    private var eraseAfterRestore = false
    private var mapWorkID: UUID?
    private var mapRevision = UUID()
    private var pendingMapWork: (UUID, SpatialFrameRegistry, [SpatialMapBinding: SpatialMapInstallation], [JourneyPortal])?
    private var requestedMaps: [SpatialMapBinding: SpatialMapInstallation] = [:]
    private var requestedRegistry: SpatialFrameRegistry?
    private var requestedPortals: [JourneyPortal] = []
    public var pendingMapWorkCount: Int { (mapWorkID == nil ? 0 : 1) + (pendingMapWork == nil ? 0 : 1) }
    private var cancelAfterRestore = false
    private var held: ConnectedJourneyRouteTicket?
    private var lastEndpoint: JourneyEndpoint?
    private var pendingStartOrigin: CompanionCommandOrigin?
    private var clarificationLedger = SpeechDeliveryLedger()
    private var clarificationToken: UUID?
    private var clarificationReceipt: JourneyClarificationReceipt?

    public init(io: any ConnectedJourneyRuntimeIO, sha256: @escaping SpatialMapSHA256) {
        self.io = io; self.sha256 = sha256
    }
    public func restore() {
        guard loadID == nil, latestWrite == nil, coordinator == nil else { return }
        retire(); loading = true; let id = UUID(); loadID = id
        Task { [weak self, io, sha256] in
            do {
                let data = try await io.read()
                
                // Decoding/verifying installations is executed away from the main
                // owner. Only immutable validated values cross back for publication.
                let restored = try await Task.detached(priority: .utility) { () -> (JourneyRuntimeEnvelope?, ConnectedJourneyCatalog?) in
                    guard let data else { return (nil, nil) }
                    let envelope = try JourneyRuntimeEnvelope(data: data)
                    let maps = try envelope.installations.map { try SpatialMapInstallation(data: $0, sha256: sha256) }
                    guard let first = maps.first else {
                        guard envelope.portals.isEmpty else { throw JourneyRuntimeError.invalidEnvelope }
                        return (envelope, nil)
                    }
                    return (envelope, try ConnectedJourneyCatalog(registry: first.registry, installations: maps, portals: envelope.portals))
                }.value
                guard let self, self.loadID == id else { return }
                self.loading = false; self.storageError = false
                if let envelope = restored.0 { self.snapshot = envelope.journey }
                self.catalog = restored.1
                self.requestedMaps = restored.1?.installations ?? [:]
                self.requestedRegistry = restored.1?.registry
                self.requestedPortals = restored.1?.portals ?? []
                try self.rebuildCoordinator()
                self.latestWrite = self.writePayload()
                self.durable = true; self.status = "Journey intent restored. Live location is unknown."
                if let installation = self.pendingInstallation {
                    self.pendingInstallation = nil; try self.install(installation.0, portals: installation.1)
                }
                if self.eraseAfterRestore { self.eraseAfterRestore = false; try self.eraseHistory(origin: .trustedInterface) }
                else if self.cancelAfterRestore { self.cancelAfterRestore = false; try self.cancel(origin: .trustedInterface) }
                self.loadID = nil; self.onChange?()
            } catch {
                guard let self, self.loadID == id else { return }
                self.loading = false; self.loadID = nil; self.storageError = true; self.durable = false
                self.status = "Journey history could not be opened. No guidance is available."
                self.onChange?()
            }
        }
    }
    /// Installs source-known artifacts after the existing native atomic map import
    /// succeeds. A queued initial installation is one latest value, not a FIFO.
    public func install(_ installation: SpatialMapInstallation, portals: [JourneyPortal] = []) throws {
        retire(); coordinator?.loseTracking()
        if loading { pendingInstallation = (installation, portals); return }
        guard !storageError else { throw JourneyRuntimeError.storageUnavailable }
        requestedMaps[installation.binding] = installation
        requestedRegistry = installation.registry
        if !portals.isEmpty { requestedPortals = portals }
        scheduleCatalog()
    }
    public func withdrawMap(_ binding: SpatialMapBinding) throws {
        retire(); coordinator?.loseTracking()
        guard let registry = requestedRegistry ?? catalog?.registry else { return }
        let old = registry.snapshot
        requestedRegistry = try SpatialFrameRegistry(snapshot: .init(nodes: old.nodes, maps: old.maps,
            activeBindings: old.activeBindings.filter { $0 != binding }, links: old.links, transitions: old.transitions))
        requestedMaps.removeValue(forKey: binding)
        requestedPortals.removeAll { $0.from.binding == binding || $0.to.binding == binding }
        scheduleCatalog()
    }
    private func scheduleCatalog() {
        guard let registry = requestedRegistry else { return }
        let id = UUID(); mapRevision = id
        let input = (id, registry, requestedMaps, requestedPortals)
        if mapWorkID != nil { pendingMapWork = input } else { startCatalog(input) }
        status = "Registered map update is pending. Guidance is paused."; onChange?()
    }
    private func startCatalog(_ input: (UUID, SpatialFrameRegistry, [SpatialMapBinding: SpatialMapInstallation], [JourneyPortal])) {
        mapWorkID = input.0
        let previous = catalog?.registry
        Task { [weak self] in
            let result = await Task.detached(priority: .utility) { () -> Result<ConnectedJourneyCatalog, Error> in
                Result {
                    if var previous { try previous.update(snapshot: input.1.snapshot) }
                    let maps = try input.2.values.filter { input.1.snapshot.activeBindings.contains($0.binding) }.map { map in
                        try SpatialMapInstallation(envelope: .init(snapshot: input.1.snapshot, binding: map.binding,
                            mapBytes: map.envelope.mapBytes, artifactHistory: map.envelope.artifactHistory,
                            restrictions: map.envelope.restrictions), sha256: { bytes in
                                guard bytes == map.envelope.mapBytes else { throw SpatialInstallationError.artifactMismatch }
                                return map.artifact.sha256
                            })
                    }
                    let available = Set(maps.map(\.binding))
                    return try ConnectedJourneyCatalog(registry: input.1, installations: maps,
                        portals: input.3.filter { available.contains($0.from.binding) && available.contains($0.to.binding) })
                }
            }.value
            guard let self, self.mapWorkID == input.0 else { return }
            self.mapWorkID = nil
            if let next = self.pendingMapWork { self.pendingMapWork = nil; self.startCatalog(next); return }
            guard self.mapRevision == input.0 else { return }
            do {
                let next = try result.get()
                // Publication uses the LATEST intent, not a snapshot captured before
                // asynchronous map preparation. It cannot resurrect a cancelled goal.
                if var owner = self.coordinator { try owner.replaceCatalog(next); self.coordinator = owner }
                self.catalog = next
                if self.coordinator == nil { try self.rebuildCoordinator() }
                self.requestedMaps = next.installations; self.requestedRegistry = next.registry
                self.requestedPortals = next.portals
                self.externalMapPending = false
                try self.enqueueSave()
                self.status = "Registered maps retained. Fresh location is required."
            } catch {
                self.commandBlocked = true; self.status = "Map update could not be accepted. Guidance is paused."
            }
            self.onChange?()
        }
    }
    public func configure(body: BodyEnvelope, limits: SpatialLocalizationLimits) throws {
        retire(); self.body = body; self.limits = limits; try rebuildCoordinator()
    }
    public func setDestination(binding: SpatialMapBinding, nodeID: String, origin: CompanionCommandOrigin) throws {
        guard CommandAuthority.permits(.changeGoal, from: origin) else { throw ConnectedJourneyError.unauthorized }
        retire(); commandBlocked = true
        let endpoint = try endpoint(binding: binding, nodeID: nodeID)
        try mutate { try $0.setDestination(endpoint, origin: origin, recordedAt: Date(), persist: { _ in }) }
        pendingStartOrigin = origin; commandBlocked = false
        status = "Destination retained while saving. Current location is required before guidance."; onChange?()
    }
    public func hold(origin: CompanionCommandOrigin) throws {
        try mutate { try $0.hold(origin: origin, persist: { _ in }) }
        status = "Journey paused. Its destination is retained."; onChange?()
    }
    public func resume(origin: CompanionCommandOrigin) throws {
        try mutate { try $0.resume(origin: origin, persist: { _ in }) }
        coordinator?.loseTracking() // Retain intent, discard the held executable plan.
        status = "Journey resumed. Fresh location is required before guidance."; onChange?()
    }
    public func cancel(origin: CompanionCommandOrigin) throws {
        guard CommandAuthority.permits(.cancelTaskOrNavigation, from: origin) else { throw ConnectedJourneyError.unauthorized }
        retire(); pendingStartOrigin = nil
        if loading { cancelAfterRestore = true; return }
        if coordinator != nil { try mutate { try $0.cancel(origin: origin, recordedAt: Date(), persist: { _ in }) } }
        else {
            snapshot.goal?.status = .cancelled; snapshot.returnClarificationPending = false
            try enqueueSave()
        }
        status = "Journey cancelled."; onChange?()
    }
    public func eraseHistory(origin: CompanionCommandOrigin) throws {
        guard origin == .trustedInterface else { throw ConnectedJourneyError.unauthorized }
        retire(); pendingStartOrigin = nil; commandBlocked = true
        if loading { eraseAfterRestore = true; cancelAfterRestore = false; return }
        snapshot = ConnectedJourneySnapshot(); try rebuildCoordinator(); try enqueueSave()
        status = "Journey history is being erased."; onChange?()
    }
    public func mapOwnershipWithdrawn() { externalMapPending = true; cameraRestarted() }
    public func mapRemovalSettled(_ binding: SpatialMapBinding?) throws {
        if let binding { try withdrawMap(binding) }
        else { externalMapPending = false; cameraRestarted() }
    }
    public func cameraRestarted() { retire(); lastEndpoint = nil; coordinator?.loseTracking(); status = "Destination retained. Live location is unknown."; onChange?() }
    public func beginLocalization(in binding: SpatialMapBinding) throws -> UUID {
        retireOutput(); lastEndpoint = nil; guard var owner = coordinator else { throw JourneyRuntimeError.noRegisteredMap }
        defer { coordinator = owner }
        return try owner.beginLocalization(in: binding)
    }
    /// No caller in current ARKit code can manufacture this contract. This entry is
    /// for a calibrated issuer and executable synthetic tests, never a room label.
    public func accept(_ capture: SpatialLocalizationCapture, support: SpatialFloorSupport, now: Double) throws {
        retireOutput(); guard var owner = coordinator else { throw JourneyRuntimeError.noRegisteredMap }
        do { try owner.accept(capture, support: support, now: now) }
        catch { coordinator = owner; throw error }
        coordinator = owner
        if let endpoint = currentEndpoint(capture: capture, support: support) {
            lastEndpoint = endpoint
            if snapshot.start == nil, let origin = pendingStartOrigin {
                try mutate(retireClarification: false) { try $0.markStart(at: endpoint, origin: origin, now: now, recordedAt: Date(), persist: { _ in }) }
                pendingStartOrigin = nil
            }
            if canOutput, snapshot.goal?.status == .active, !snapshot.returnClarificationPending {
                if coordinator?.currentLeg == nil, let target = snapshot.goal?.target.endpoint, sameLocation(endpoint, target) {
                    try mutate(retireClarification: false) { try $0.completeAtGoal(now: now, recordedAt: Date(), persist: { _ in }) }
                } else if case .local(_, let to)? = coordinator?.currentLeg, sameLocation(endpoint, to) {
                    try mutate(retireClarification: false) { try $0.completeLocalLeg(now: now, recordedAt: Date(), persist: { _ in }) }
                    if case .portal? = coordinator?.currentLeg { try coordinator?.armPortal(now: now, recordedAt: Date()) }
                } else if case .portal(_, _, let to)? = coordinator?.currentLeg, sameLocation(endpoint, to) {
                    try mutate(retireClarification: false) { try $0.completePortal(now: now, recordedAt: Date(), persist: { _ in }) }
                    try coordinator?.prepareLocalLeg(now: now)
                } else if coordinator?.currentLeg == nil {
                    try coordinator?.plan(from: endpoint, now: now)
                } else {
                    // The existing owner verifies proximity before advancing. A
                    // non-waypoint sample is not arrival and leaves the plan alone.
                    try? coordinator?.advanceWaypoint(now: now)
                }
            }
        }
        onChange?()
    }
    private var canOutput: Bool { !loading && !externalMapPending && mapWorkID == nil && durable && !storageError && !commandBlocked }
    public func next(now: Double) throws -> ConnectedJourneyRouteTicket {
        guard canOutput, let coordinator else { throw JourneyRuntimeError.storageUnavailable }
        let ticket = try coordinator.next(now: now); held = ticket; return ticket
    }
    public func permits(_ ticket: SpatialRouteTicket, now: Double) -> Bool {
        guard canOutput, let held,
              held.route.routeID == ticket.routeID, held.route.goalRevision == ticket.goalRevision,
              held.route.spatial == ticket.spatial else { return false }
        return coordinator?.permits(held, now: now) == true
    }
    public func revalidate(now: Double) { if let held, !permits(held.route, now: now) { retireOutput() } }
    public func saveReference(origin: CompanionCommandOrigin, now: Double) throws {
        guard let lastEndpoint else { throw ConnectedJourneyError.awaitingLocalization }
        try mutate { try $0.saveReference(at: lastEndpoint, origin: origin, now: now, recordedAt: Date(), persist: { _ in }) }
    }
    public func requestReturn(origin: CompanionCommandOrigin, arabic: Bool) throws -> JourneyReturnRequest {
        var request: JourneyReturnRequest?
        try mutate { request = try $0.requestReturn(origin: origin, arabic: arabic, recordedAt: Date(), persist: { _ in }) }
        commandBlocked = false
        return request!
    }
    public func beginClarificationSpeech(_ question: JourneyReturnQuestion) -> Bool {
        guard self.question?.id == question.id else { return false }
        clarificationToken = clarificationLedger.begin(text: question.text, priority: .information,
            destination: .requested(question.id), transport: .synthesized)?.token
        return clarificationToken != nil
    }
    public func clarificationSpeechFinished(id: UUID, text: String, outcome: NarrationDelivery, now: Double) -> Bool {
        guard question?.id == id, question?.text == text, let token = clarificationToken,
              let completion = clarificationLedger.finish(token: token, outcome: outcome, now: now) else { return false }
        clarificationToken = nil
        clarificationReceipt = try? coordinator?.recordClarificationDelivery(completion, now: now)
        return true
    }
    public func resolveReturn(_ choice: JourneyReturnQuestion.Choice, origin: CompanionCommandOrigin, now: Double) throws {
        guard let receipt = clarificationReceipt else { throw ConnectedJourneyError.clarificationNotDelivered }
        clarificationReceipt = nil
        try mutate { try $0.resolveReturn(choice, receipt: receipt, origin: origin, now: now, recordedAt: Date(), persist: { _ in }) }
        commandBlocked = false
    }
    public func retryPersistence() throws { guard let latestWrite else { throw JourneyRuntimeError.storageUnavailable }; queue(latestWrite) }
    private func endpoint(binding: SpatialMapBinding, nodeID: String) throws -> JourneyEndpoint {
        guard let catalog, let installed = catalog.installations[binding],
              let node = installed.map.nodes.first(where: { $0.id == nodeID }),
              let record = try? catalog.registry.map(for: binding), let floor = record.floorLevels[node.level] else { throw JourneyRuntimeError.noRegisteredMap }
        let root = catalog.registry.snapshot.nodes.first { $0.id == record.nodeID }
        return .init(binding: binding, floorID: floor, nodeID: nodeID, roomID: root?.kind == .room ? root?.id : nil)
    }
    private func sameLocation(_ observed: JourneyEndpoint, _ target: JourneyEndpoint) -> Bool {
        observed.binding == target.binding && observed.floorID == target.floorID && observed.nodeID == target.nodeID &&
            (target.roomID == nil || observed.roomID == target.roomID)
    }
    private func currentEndpoint(capture: SpatialLocalizationCapture, support: SpatialFloorSupport) -> JourneyEndpoint? {
        guard let catalog, let map = catalog.installations[capture.binding]?.map,
              let record = try? catalog.registry.map(for: capture.binding) else { return nil }
        let candidates = map.nodes.filter { record.floorLevels[$0.level] == capture.floorID &&
            hypot($0.position.x - capture.position.x, $0.position.z - capture.position.z) + capture.positionUncertainty <= 0.35 &&
            abs($0.position.y - support.height) <= 0.09 }
        guard candidates.count == 1 else { return nil }
        return .init(binding: capture.binding, floorID: capture.floorID, nodeID: candidates[0].id, roomID: capture.roomID)
    }
    private func rebuildCoordinator() throws {
        guard let catalog else { coordinator = nil; return }
        coordinator = try .init(catalog: catalog, body: body, limits: limits, snapshot: snapshot)
    }
    private func mutate(retireClarification: Bool = true, _ operation: (inout ConnectedJourneyCoordinator) throws -> Void) throws {
        if retireClarification { retire() } else { retireOutput() }
        guard !loading, var owner = coordinator else { throw JourneyRuntimeError.noRegisteredMap }
        do { try operation(&owner); coordinator = owner; snapshot = owner.snapshot; try enqueueSave() }
        catch { coordinator = owner; snapshot = owner.snapshot; durable = false; onChange?(); throw error }
    }
    private func writePayload() -> JourneyRuntimeWrite {
        .init(journey: snapshot, installations: catalog?.installations.values.sorted { $0.binding.mapID < $1.binding.mapID } ?? [], portals: catalog?.portals ?? [])
    }
    private func enqueueSave() throws {
        let payload = writePayload(); latestWrite = payload; queue(payload)
    }
    private func queue(_ payload: JourneyRuntimeWrite) {
        retireOutput(); durable = false; storageError = false
        let ticket = UUID(); version = ticket
        if writing != nil { pending = (ticket, payload); onChange?(); return }
        startWrite(ticket, payload)
    }
    private func startWrite(_ ticket: UUID, _ payload: JourneyRuntimeWrite) {
        writing = ticket
        Task { [weak self, io] in
            var error: Error?
            do { try await io.write(payload) } catch let failure { error = failure }
            guard let self, self.writing == ticket else { return }
            self.writing = nil
            if let pending = self.pending { self.pending = nil; self.startWrite(pending.0, pending.1) }
            else if error == nil, ticket == self.version { self.durable = true; self.storageError = false }
            else { self.durable = false; self.storageError = true; self.status = "Journey changes are not saved. Guidance is paused." }
            self.onChange?()
        }
    }
    private func retireOutput() { held = nil; onOutputRetired?() }
    private func retire() {
        retireOutput()
        if let question { onClarificationRetired?(question.id) }
        if let token = clarificationToken { _ = clarificationLedger.finish(token: token, outcome: .interrupted, now: 0) }
        clarificationToken = nil; clarificationReceipt = nil
    }
}
