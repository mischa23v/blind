from pathlib import Path
import shutil,subprocess,json,hashlib
root=Path(__file__).resolve().parents[1];live=Path('/workspace/shared/blind-rebuild');out=root/'node-projection'
ignored={'.git','.build','node_modules','artifacts','.env','.swiftpm'}
for src in live.rglob('*'):
 rel=src.relative_to(live)
 if not src.is_file() or any(x in ignored for x in rel.parts):continue
 dst=out/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
node=out/'node_modules'
if not node.exists():node.symlink_to(live/'node_modules',target_is_directory=True)
for name in ['ConnectedJourney.swift','ConnectedJourneyCatalog.swift','ConnectedJourneyCoordinator.swift','HeldSearchIntent.swift']:
 shutil.copy2(root/'Sources/BlindCore'/name,out/'BlindCore/Sources/BlindCore'/name)
# Apply only the narrow quiet/search delta into the disposable CURRENT-source copy.
# Never copy the older whole NativeModel proposal over the photo/observation work.
# Re-express the exact bounded method edits against the current source in a
# separate proposal root. This preserves the new photo clearExploreSnapshot call
# without changing the frozen official earlier-preimage patch.
proposal=root/'quiet-current-projection'
for name in ['native-baseline','native-proposal','patches','evidence']:(proposal/name).mkdir(parents=True,exist_ok=True)
shutil.copy2(out/'ios/BlindAssist/NavigationModel.swift',proposal/'native-baseline/NavigationModel.swift')
subprocess.run(['python3',str(root/'verification/prepare-quiet-proposal.py'),str(proposal)],check=True)
patch=proposal/'patches/NavigationModel-quiet-search.patch'
subprocess.run(['patch','--fuzz=0','--dry-run','-p1','-i',str(patch)],cwd=out,check=True)
subprocess.run(['patch','--fuzz=0','-p1','-i',str(patch)],cwd=out,check=True)
shutil.copy2(root/'Sources/NativeJourneyAdapter/ConnectedJourneyStore.swift',out/'ios/BlindAssist/ConnectedJourneyStore.swift')
(root/'evidence/node-projection-source.json').write_text(json.dumps({'live_native_sha256':hashlib.sha256((live/'ios/BlindAssist/NavigationModel.swift').read_bytes()).hexdigest(),'projected_native_sha256':hashlib.sha256((out/'ios/BlindAssist/NavigationModel.swift').read_bytes()).hexdigest(),'status':'Disposable regression projection, not a live rebase/apply.'},indent=2)+'\n')
