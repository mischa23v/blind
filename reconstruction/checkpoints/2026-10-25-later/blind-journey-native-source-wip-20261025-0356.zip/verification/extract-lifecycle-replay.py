from pathlib import Path
import re,json,hashlib
root=Path(__file__).resolve().parents[1];native=root/'native-lifecycle/native-proposal';out=root/'Sources/NativeLifecycleReplay'
text=(native/'NavigationModel.swift').read_text()
def method(name):
 start=re.search(r'^    (?:@discardableResult )?(?:private )?func '+name+r'\(',text,re.M).start()
 body=text.index('{',start);depth=1;end=body+1
 while depth:
  if text[end]=='{':depth+=1
  if text[end]=='}':depth-=1
  end+=1
 return text[start:end].replace('private func ','func ')
names=['cancelDescription','stopDescriptions','resumeDescriptions','resumeHeldSearchIfPossible','handleAssistantControl','toggleHomeDescriptions','handleConversationTaskControl','routeConnectedJourneyCommand','startReturn','configureConnectedJourney','acceptConnectedJourneyCapture','persistWorkingState','establishedJourneyContextChanged']
stubs=(root/'verification/quiet-stubs.swift.txt').read_text().replace('import BlindCore','import BlindCore\nimport NativeJourneyAdapter')
stubs=stubs.replace('final class QuietHarness {','final class LifecycleHarness {\n    let journeys: JourneyStore\n    init(journeys: JourneyStore) { self.journeys = journeys }\n    var returnStatus = ""\n    var journeyConversationGoal = "bathroom"\n    var journeyConversationSourceID: String?\n    var plannedIndoorGoalRevision: String?\n    var spatialRouteOutput = TestRouteOutput()\n    func clearExploreSnapshot() {}')
stubs=stubs.replace('func speakRequested(_ value: String) -> Bool', 'func speakRequested(_ value: String, speechID: UUID? = nil) -> Bool')
# Stub declarations may already name a legacy startReturn that is now extracted.
stubs=stubs.replace('    func persistWorkingState() {}\n','')
stubs=stubs.replace('struct WorkingState {','struct TestSource: Codable { var sourceID: String }\nstruct TestRouteOutput { func revalidate() {} }\nstruct WorkingState: Codable {\n    var goalSource: TestSource?')
stubs=re.sub(r'    func startReturn\([^\n]*\n','',stubs)
(out/'ExtractedLifecycleMethods.swift').write_text(stubs+'\n'+'\n'.join(method(n) for n in names)+'\n}\n')
store=(native/'JourneyStore.swift').read_text().replace('import Combine','import NativeJourneyAdapter')
# Linux cannot import Combine/UIKit. All substitutions below are explicit platform
# and unrelated raw-recorder fakes; the connected store bridge/method bodies are exact.
platform='''
@propertyWrapper struct Published<T> { var wrappedValue: T; init(wrappedValue:T) { self.wrappedValue = wrappedValue } }
protocol ObservableObject {}
extension ObservableObject { var objectWillChange: ChangePublisher { .init() } }
struct Journey: Codable { let id = UUID(); let createdAt = Date(); var points: [Int] = [] }
struct Observation { var camera = Point3(0,0,0); var timestamp = 0.0; var trackingNormal = true }
struct JourneyRecorder { var journey = Journey(); var distance = 0.0; mutating func observe(camera:Point3,time:Double,tracking:Bool) {}; mutating func breakTracking() {} }
enum DebugSessionLog { static func purgeForPrivacyClear(_ completion: (Bool)->Void) { completion(true) } }
enum DebugNativeSessionTrace { static func reportPurgeResult(_ success:Bool) {} }
enum RegisteredIndoorNavigation { static func platformSHA256(_ bytes:Data) throws -> String { throw JourneyRuntimeError.storageUnavailable } }
'''
# Darwin-only file protection setup is separately syntax parsed in the unchanged source.
store=store.replace('            try FileManager.default.setAttributes([.protectionKey: FileProtectionType.completeUntilFirstUserAuthentication], ofItemAtPath: directory.path)','''            #if os(iOS)
            try FileManager.default.setAttributes([.protectionKey: FileProtectionType.completeUntilFirstUserAuthentication], ofItemAtPath: directory.path)
            #endif''')
(out/'ExtractedJourneyStore.swift').write_text(store+'\n'+platform)
(root/'evidence/native-lifecycle-extraction.json').write_text(json.dumps({'native':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in native.glob('*.swift')},'methods':names,'scope':'Exact native lifecycle method bodies + actual JourneyStore bridge + real runtime/Core. Explicit platform/raw recorder and unrelated UI fakes. No Apple SDK, live pose issuer or audio rendering.'},indent=2)+'\n')
