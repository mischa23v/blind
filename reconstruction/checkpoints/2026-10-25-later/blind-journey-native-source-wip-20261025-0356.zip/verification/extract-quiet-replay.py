from pathlib import Path
import hashlib,json,sys,re
root=Path(__file__).resolve().parents[1]
mode=sys.argv[1] if len(sys.argv)>1 else 'proposal'
source=root/('native-baseline' if mode=='baseline' else 'native-proposal')/'NavigationModel.swift'
text=source.read_text()
def method(name):
 start=re.search(r'^    (?:@discardableResult )?(?:private )?func '+name+r'\(',text,re.M).start()
 body=text.index('{',start); depth=1; end=body+1
 while depth:
  if text[end]=='{':depth+=1
  if text[end]=='}':depth-=1
  end+=1
 return text[start:end].replace('private func ','func ')
names=['cancelDescription','stopDescriptions','handleAssistantControl','toggleHomeDescriptions','handleConversationTaskControl','clearAssistantConversation','forgetItem','forgetRoomPictures']
if mode!='baseline':names+=['resumeDescriptions','resumeHeldSearchIfPossible','retireHeldSearchForPrivacyDeletion']
methods='\n'.join(method(n) for n in names)
stubs=(root/'verification/quiet-stubs.swift.txt').read_text()
(root/'Sources/NativeQuietReplay/ExtractedQuietMethods.swift').write_text(stubs+'\n'+methods+'\n}\n')
(root/f'evidence/quiet-{mode}-extraction.json').write_text(json.dumps({'source':str(source),'sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'methods':names,'scope':'Exact extracted native method bodies; dependencies are explicit fakes, not Apple runtime.'},indent=2)+'\n')
