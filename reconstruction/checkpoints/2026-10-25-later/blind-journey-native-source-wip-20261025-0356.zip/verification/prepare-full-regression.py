from pathlib import Path
import shutil
root=Path(__file__).resolve().parents[1]; live=Path('/workspace/shared/blind-rebuild'); dest=root/'full-regression/BlindCore'
shutil.copytree(live/'BlindCore',dest,dirs_exist_ok=True,ignore=shutil.ignore_patterns('.build'))
for name in ['ConnectedJourney.swift','ConnectedJourneyCatalog.swift','ConnectedJourneyCoordinator.swift','HeldSearchIntent.swift']:
 shutil.copy2(root/'Sources/BlindCore'/name,dest/'Sources/BlindCore'/name)
for name in ['ConnectedJourneyTests.swift','ConnectedJourneyFailureTests.swift','HeldSearchIntentTests.swift']:
 shutil.copy2(root/'Tests/BlindCoreTests'/name,dest/'Tests/BlindCoreTests'/name)
# Store and extracted native tests run separately in the focused package; this
# projection exercises the entire existing Core suite unchanged plus new Core cases.
