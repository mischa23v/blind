#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
source /workspace/shared/swift-toolchain/env.sh
export HOME="$PWD/.home" XDG_CACHE_HOME="$PWD/.cache" CLANG_MODULE_CACHE_PATH="$PWD/.cache/clang" SWIFTPM_MODULECACHE_OVERRIDE="$PWD/.cache/swift" TMPDIR="$PWD/.tmp"
mkdir -p "$HOME" "$XDG_CACHE_HOME" "$TMPDIR"
python3 verification/prepare-quiet-proposal.py
python3 verification/extract-quiet-replay.py proposal
swift test --jobs 2
swiftc -frontend -parse native-proposal/NavigationModel.swift native-proposal/ConnectedJourneyStore.swift
swiftc -frontend -parse -D DEBUG -D BLIND_FAMILIAR_PEOPLE native-proposal/NavigationModel.swift native-proposal/ConnectedJourneyStore.swift
