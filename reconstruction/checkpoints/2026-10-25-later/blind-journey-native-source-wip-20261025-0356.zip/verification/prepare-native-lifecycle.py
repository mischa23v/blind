from pathlib import Path
import difflib,hashlib,json
root=Path(__file__).resolve().parents[1]; stage=root/'native-lifecycle'
def read(name):return (stage/'native-baseline'/name).read_text()
def put(name,s):
 (stage/'native-proposal'/name).write_text(s)
 b=read(name); (stage/'patches'/(name+'.patch')).write_text(''.join(difflib.unified_diff(b.splitlines(True),s.splitlines(True),fromfile='a/ios/BlindAssist/'+name,tofile='b/ios/BlindAssist/'+name)))
# Main ownership is an explicit checked bridge because these legacy ObservableObject
# classes predate global-actor annotations. No async wait occurs inside the bridge.
s=read('JourneyStore.swift').replace('    private var recorder:', '''    private let connectedIO: (any ConnectedJourneyRuntimeIO)?
    private let journeySHA256: SpatialMapSHA256
    private lazy var connected = MainActor.assumeIsolated {
        ConnectedJourneyRuntime(io: connectedIO ?? FoundationJourneyRuntimeIO(url: directory.appendingPathComponent("connected-state.json")),
            sha256: journeySHA256)
    }
    func withConnectedJourney<T>(_ operation: @MainActor (ConnectedJourneyRuntime) throws -> T) rethrows -> T {
        try MainActor.assumeIsolated { try operation(connected) }
    }
    private var recorder:''')
s=s.replace('    init() {', '    init(connectedIO: (any ConnectedJourneyRuntimeIO)? = nil, journeySHA256: @escaping SpatialMapSHA256 = RegisteredIndoorNavigation.platformSHA256) {\n        self.connectedIO = connectedIO; self.journeySHA256 = journeySHA256')
s=s.replace('''        } catch { message = "Journey storage unavailable." }
    }''','''        } catch { message = "Journey storage unavailable." }
        withConnectedJourney { runtime in
            runtime.onChange = { [weak self] in self?.objectWillChange.send() }
            runtime.restore()
        }
    }''')
s=s.replace('func begin() { finish();', 'func begin() { withConnectedJourney { $0.cameraRestarted() }; finish();')
s=s.replace('func breakTracking() { recorder?.breakTracking() }', 'func breakTracking() { withConnectedJourney { $0.cameraRestarted() }; recorder?.breakTracking() }')
s=s.replace('''    func finish() {
        guard''','''    func finish() {
        withConnectedJourney { $0.cameraRestarted() }
        guard''')
# Connected private state is not a legacy raw Journey and is never decoded as one.
s=s.replace('.filter { $0.pathExtension == "json" }', '.filter { $0.pathExtension == "json" && $0.lastPathComponent != "connected-state.json" }')
put('JourneyStore.swift',s)
s=read('IndoorNavigator.swift').replace('    var onSpatialOutputRetired:', '''    var onJourneyMapOwnershipWithdrawn: ((UUID) -> Void)?
    var onJourneyMapPublished: ((UUID, SpatialMapInstallation?, SpatialMapBinding?) -> Void)?
    var registeredJourneyInstallation: SpatialMapInstallation? {
        guard let registered, !mapIOPending, !registered.ioPending, !registered.ioBlocked else { return nil }
        return registered.installation
    }
    var onSpatialOutputRetired:''')
s=s.replace('''        revision = UUID(); let expected = revision
        alignmentRevision''','''        let previousJourneyBinding = registered?.installation?.binding
        revision = UUID(); let expected = revision
        onJourneyMapOwnershipWithdrawn?(expected)
        alignmentRevision''')
s=s.replace('''                completion(.success(()))
            case .failure(let error):''','''                self.onJourneyMapPublished?(expected, loaded?.installation, previousJourneyBinding)
                completion(.success(()))
            case .failure(let error):''',1)
s=s.replace('''        invalidatePosition(); revision = UUID(); mapIOPending = true
        registered?.suspend''','''        invalidatePosition(); revision = UUID(); mapIOPending = true
        onJourneyMapOwnershipWithdrawn?(revision)
        registered?.suspend''')
put('IndoorNavigator.swift',s)
s=(stage/'native-proposal/NavigationModel.swift').read_text()
s=s.replace('    private var plannedIndoorGoalRevision: String?', '    private var plannedIndoorGoalRevision: String?\n    private var journeyConversationGoal = ""\n    private var journeyConversationSourceID: String?')
# Snapshot the restored conversation owner at the end of init. Goal mutation paths
# then synchronously fence connected output before any persistence or model work.
a=s.index('    override init() {'); b=s.index('{',a); depth=1; end=b+1
while depth:
 if s[end]=='{':depth+=1
 if s[end]=='}':depth-=1
 end+=1
s=s[:end-1]+'    journeyConversationGoal = companionWorkingState.goal; journeyConversationSourceID = companionWorkingState.goalSource?.sourceID\n    '+s[end-1:]
s=s.replace('''    private func persistWorkingState() {
''','''    private func persistWorkingState() {
        if journeyConversationGoal != companionWorkingState.goal || journeyConversationSourceID != companionWorkingState.goalSource?.sourceID {
            try? journeys.withConnectedJourney { try $0.cancel(origin: .trustedInterface) }
            journeyConversationGoal = companionWorkingState.goal; journeyConversationSourceID = companionWorkingState.goalSource?.sourceID
        }
''')

s=s.replace('''        indoor.onSpatialOutputRetired = { [weak self] in self?.spatialRouteOutput.retire() }''','''        indoor.onSpatialOutputRetired = { [weak self] in self?.spatialRouteOutput.retire() }
        journeys.withConnectedJourney { runtime in
            runtime.onOutputRetired = { [weak self] in self?.spatialRouteOutput.retire() }
            runtime.onClarificationRetired = { [weak self] id in self?.feedback.stopRequestedSpeech(id) }
        }
        indoor.onJourneyMapOwnershipWithdrawn = { [weak self] revision in
            guard let self, self.indoor.revision == revision else { return }
            self.journeys.withConnectedJourney { $0.mapOwnershipWithdrawn() }
        }
        indoor.onJourneyMapPublished = { [weak self] revision, installation, removed in
            guard let self, self.indoor.revision == revision else { return }
            do {
                try self.journeys.withConnectedJourney {
                    if let installation { try $0.install(installation) }
                    else { try $0.mapRemovalSettled(removed) }
                }
            } catch { self.message = "Journey map context is unavailable. Guidance remains paused." }
        }
        if indoor.mapIOPending { journeys.withConnectedJourney { $0.mapOwnershipWithdrawn() } }
        else if let installation = indoor.registeredJourneyInstallation {
            try? journeys.withConnectedJourney { try $0.install(installation) }
        }''')
s=s.replace('''            if self.finishSelectedPhotoSpeech(id: id, text: text, outcome: outcome) { return }''','''            if self.finishSelectedPhotoSpeech(id: id, text: text, outcome: outcome) { return }
            if self.journeys.withConnectedJourney({ $0.clarificationSpeechFinished(id: id, text: text,
                outcome: outcome, now: ProcessInfo.processInfo.systemUptime) }) { return }''')
s=s.replace('''        try indoor.plan(from: from, to: to, goalRevision: goal)''','''        if let installation = indoor.registeredJourneyInstallation {
            // The selected endpoint is intent, never evidence that `from` is our pose.
            try journeys.withConnectedJourney { try $0.setDestination(binding: installation.binding, nodeID: to, origin: .trustedInterface) }
        } else { try? journeys.withConnectedJourney { try $0.cancel(origin: .trustedInterface) } }
        try indoor.plan(from: from, to: to, goalRevision: goal)''')
s=s.replace('''              goalRevision == companionWorkingState.goalRevision,
              UUID(uuidString: goalRevision) == ticket.goalRevision,''','''              UUID(uuidString: goalRevision) == ticket.goalRevision,''')
s=s.replace('''        return indoor.permitsSpatialOutput(ticket, now: now)
    }
    func indoorBeacon''','''        if journeys.withConnectedJourney({ $0.goal != nil }) {
            return journeys.withConnectedJourney { $0.goal?.revision == ticket.goalRevision && $0.permits(ticket, now: now) }
        }
        return goalRevision == companionWorkingState.goalRevision && indoor.permitsSpatialOutput(ticket, now: now)
    }
    func indoorBeacon''')
s=s.replace('''        spatialRouteOutput.revalidate()
        guard indoor.hasActiveRoute''','''        spatialRouteOutput.revalidate()
        if journeys.withConnectedJourney({ $0.goal != nil }) { connectedJourneyBeacon(automatic: automatic); return }
        guard indoor.hasActiveRoute''')
# Do not retire the durable journey for a harmless question or room/context update.
# Only the explicit task-control switch and explicit goal handlers below own it.
s=s.replace('''        case .pause:
            everydayTasks.pause(); everydayTicket = nil''','''        case .pause:
            try? journeys.withConnectedJourney { try $0.hold(origin: .trustedInterface) }
            everydayTasks.pause(); everydayTicket = nil''')
s=s.replace('''        case .resume:
            everydayTasks.resume()''','''        case .resume:
            try? journeys.withConnectedJourney { try $0.resume(origin: .trustedInterface) }
            everydayTasks.resume()''')
s=s.replace('''        case .cancel:
            heldSearchIntent.cancel()''','''        case .cancel:
            try? journeys.withConnectedJourney { try $0.cancel(origin: .trustedInterface) }
            heldSearchIntent.cancel()''')
task_start=s.index('    private func handleConversationTaskControl(')
task_end=s.index('    private func conversationCaptureIsCurrent(',task_start)
task=s[task_start:task_end].replace('        persistWorkingState(); persistDialogue()', '        journeyConversationGoal = companionWorkingState.goal; journeyConversationSourceID = companionWorkingState.goalSource?.sourceID\n        persistWorkingState(); persistDialogue()')
s=s[:task_start]+task+s[task_end:]
s=s.replace('''    func setAssistantObjective() {
''','''    func setAssistantObjective() {
        try? journeys.withConnectedJourney { try $0.cancel(origin: .trustedInterface) }
''')
for sig in ['if let destination = AssistantControl.explicitGoal(text) {','if let goal = ConversationIntent.explicitTaskGoal(text) {']:
 # one occurrence each in the trusted conversation route, not regex-generated model routing
 start=s.index(sig,s.index('    func receiveCompanionUtterance'))
 s=s[:start]+s[start:].replace(sig,sig+'\n            try? journeys.withConnectedJourney { try $0.cancel(origin: .trustedInterface) }',1)
s=s.replace('''        if routeSelectedPhotoInquiry(text, origin: origin) { return }''','''        if routeSelectedPhotoInquiry(text, origin: origin) { return }
        if routeConnectedJourneyCommand(text, origin: origin) { return }''')
# Preserve photo, DEBUG and familiar privacy prefix. Retirement remains synchronous
# and comes after those established revocations, before any task/storage mutation.
s=s.replace('''        retireHeldSearchForPrivacyDeletion()
        everydayTasks.cancelAll();''','''        retireHeldSearchForPrivacyDeletion()
        try? journeys.withConnectedJourney { try $0.eraseHistory(origin: .trustedInterface) }
        everydayTasks.cancelAll();''')
a=s.index('    func startReturn() {');b=s.index('    func stopReturn()',a)
s=s[:a]+'''    func startReturn() {
        // Raw AR session breadcrumbs are history, never current return clearance.
        do {
            let request = try journeys.withConnectedJourney { try $0.requestReturn(origin: .trustedInterface, arabic: arabic) }
            switch request {
            case .selected:
                returnStatus = arabic ? "حُفظ هدف العودة. يلزم تحديد الموقع الحالي قبل الإرشاد." : "Return target retained. Fresh location is required before guidance."
                _ = speakOperation(returnStatus)
            case .clarify(let question):
                returnStatus = question.text
                if journeys.withConnectedJourney({ $0.beginClarificationSpeech(question) }) {
                    if !speakRequested(question.text, speechID: question.id) {
                        _ = journeys.withConnectedJourney { $0.clarificationSpeechFinished(id: question.id, text: question.text,
                            outcome: .interrupted, now: ProcessInfo.processInfo.systemUptime) }
                    }
                }
            }
        } catch {
            returnStatus = arabic ? "لا توجد نقطة عودة متحققة متاحة. لن أستنتج الاتجاه من المسار القديم." : "No verified return reference is available. I won't infer directions from the old trail."
            _ = speakOperation(returnStatus)
        }
    }
''' + s[b:]
# Add code-owned commands and output sink methods; evidence intake stays explicit
# and is deliberately NOT called from ordinary ARKit frames or image recognition.
anchor='    func stopReturn()'
methods=(root/'verification/native-journey-methods.swift.txt').read_text()
s=s.replace(anchor,methods+'\n'+anchor,1)
put('NavigationModel.swift',s)
s=read('DashboardView.swift')
s=s.replace('Button(model.returning ? t("Stop return guidance"', 'Button(model.hasReturnIntent ? t("Stop return guidance"')
s=s.replace('if model.returning { model.stopReturn() } else { model.startReturn() }', 'if model.hasReturnIntent { model.cancelReturnIntent() } else { model.startReturn() }')
s=s.replace('if model.returning { Button(t("Repeat direction", "كرر الاتجاه")) { model.speakReturnCue() } }', 'if model.hasReturnIntent { Button(t("Repeat direction", "كرر الاتجاه")) { model.indoorBeacon() } }')
put('DashboardView.swift',s)
for name in ['ConnectedJourneyRuntime.swift']:
 (stage/'native-proposal'/name).write_bytes((root/'Sources/NativeJourneyAdapter'/name).read_bytes())
(stage/'evidence/preimages.json').write_text(json.dumps({p.name:{'base':hashlib.sha256(p.read_bytes()).hexdigest(),'proposal':hashlib.sha256((stage/'native-proposal'/p.name).read_bytes()).hexdigest()} for p in (stage/'native-baseline').glob('*.swift')},indent=2)+'\n')
