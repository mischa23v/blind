import Foundation
import XCTest
import BlindCore
import NativeJourneyAdapter
@testable import NativeLifecycleReplay

private actor NativeIO: ConnectedJourneyRuntimeIO {
    var bytes: Data?
    func read() -> Data? { bytes }
    func write(_ payload: JourneyRuntimeWrite) throws { bytes = try payload.envelope().encoded() }
}
@MainActor final class NativeLifecycleIntegrationTests: XCTestCase {
    typealias F = ConnectedFixture
    private func settle(_ store: JourneyStore) async throws {
        for _ in 0..<3000 {
            if store.withConnectedJourney({ !$0.loading && $0.pendingMapWorkCount == 0 && $0.pendingWriteCount == 0 }) { return }
            try await Task.sleep(nanoseconds: 1_000_000)
        }
        XCTFail("Native lifecycle settlement timed out")
    }
    private func harness() async throws -> LifecycleHarness {
        let store = JourneyStore(connectedIO:NativeIO(),journeySHA256:F.sha256)
        try await settle(store)
        let maps = try F.catalog()
        try store.withConnectedJourney { owner in
            for map in maps.installations.values { try owner.install(map,portals:maps.portals) }
        }
        try await settle(store)
        try store.withConnectedJourney { try $0.setDestination(binding:F.c,nodeID:"p",origin:.trustedInterface) }
        try await settle(store)
        return LifecycleHarness(journeys:store)
    }
    private func observe(_ value:LifecycleHarness,time:Double) throws {
        let session = try XCTUnwrap(value.journeys.withConnectedJourney { $0.expectedSessionID })
        let c = SpatialLocalizationCapture(sessionID:session,binding:F.a,floorID:"ground",roomID:"bedroom",
            position:.init(1,1.3,3),bodyYaw: -.pi/2,source:.alignedMapPose,headingSource:.bodyAligned,
            trackingNormal:true,positionUncertainty:0.05,headingUncertainty:0.05,capturedAt:time)
        try value.journeys.withConnectedJourney { try $0.accept(c,support:SpatialIntegrationFixture.support(c),now:time) }
    }
    func testActualPauseQuietResumeBodiesRetainUnderlyingJourneyAndSearchWork() async throws {
        let value = try await harness(), revision = value.journeys.withConnectedJourney { $0.goal?.revision }
        _ = try value.configureConnectedJourney(body:F.body,limits:F.limits,binding:F.a)
        try observe(value,time:1); try await settle(value.journeys); try observe(value,time:1.1)
        let ticket = try value.journeys.withConnectedJourney { try $0.next(now:1.1) }
        value.stopDescriptions()
        XCTAssertTrue(value.heldSearchIntent.hasIntent)
        XCTAssertTrue(value.journeys.withConnectedJourney { $0.permits(ticket.route,now:1.1) })
        value.freshView = false; value.resumeDescriptions(); XCTAssertNil(value.objectSearch)
        value.freshView = true; value.resumeDescriptions(); XCTAssertEqual(value.objectSearch?.target,"my backpack")
        value.handleConversationTaskControl(.pause)
        XCTAssertEqual(value.journeys.withConnectedJourney { $0.goal?.status },.paused)
        XCTAssertFalse(value.journeys.withConnectedJourney { $0.permits(ticket.route,now:1.1) })
        value.handleConversationTaskControl(.resume)
        try await settle(value.journeys)
        XCTAssertEqual(value.journeys.withConnectedJourney { $0.goal?.revision },revision)
        XCTAssertThrowsError(try value.journeys.withConnectedJourney { try $0.next(now:1.1) })
        // Resume must work on a new capture without reconfiguring the adapter.
        try observe(value,time:2)
        XCTAssertNoThrow(try value.journeys.withConnectedJourney { try $0.next(now:2) })
        XCTAssertTrue(value.feedback.alertActive); XCTAssertTrue(value.running); XCTAssertTrue(value.voice.microphoneActive)
        print("EXTRACTED_NATIVE_PAUSE_RESTORATION=realGoalRetained:true,oldTicket:false,resumeNeedsFresh:true,freshRouteRestored:true,quietSearchRestored:true")
    }
    func testActualJourneyStoreCameraLifecycleDoesNotResetDurableDestination() async throws {
        let value = try await harness(), revision = value.journeys.withConnectedJourney { $0.goal?.revision }
        value.journeys.begin(); value.journeys.breakTracking(); value.journeys.finish(); value.journeys.begin()
        XCTAssertEqual(value.journeys.withConnectedJourney { $0.goal?.revision },revision)
        XCTAssertNil(value.journeys.withConnectedJourney { $0.expectedSessionID })
        XCTAssertThrowsError(try value.journeys.withConnectedJourney { try $0.next(now:1) })
        XCTAssertTrue(value.feedback.alertActive)
    }
    func testActualCommandRouterRejectsUnverifiedReturnAndHarmlessQuestionPreservesGoal() async throws {
        let value = try await harness(), revision = value.journeys.withConnectedJourney { $0.goal?.revision }
        XCTAssertFalse(value.routeConnectedJourneyCommand("take me back",origin:.unverifiedMicrophone))
        XCTAssertFalse(value.routeConnectedJourneyCommand("what day is it?",origin:.trustedInterface))
        XCTAssertEqual(value.journeys.withConnectedJourney { $0.goal?.revision },revision)
        XCTAssertEqual(value.journeys.withConnectedJourney { $0.goal?.status },.active)
        value.handleConversationTaskControl(.cancel)
        XCTAssertEqual(value.journeys.withConnectedJourney { $0.goal?.status },.cancelled)
    }
}
