import Foundation
import XCTest
@testable import NativeQuietReplay
final class NativeQuietReplayTests: XCTestCase {
    func testQuietRetainsSearchIntentAndResumesOnlyWithFreshEvidence() {
        let value = QuietHarness(), priorStart = value.objectSearch!.startedAt
        let goal = value.routeGoal, route = value.route
        value.stopDescriptions()
        XCTAssertNil(value.objectSearch)
        XCTAssertTrue(value.heldSearchIntent.hasIntent, "REGRESSION: quiet destroys search intent")
        XCTAssertEqual(value.routeGoal, goal); XCTAssertEqual(value.route, route)
        XCTAssertTrue(value.feedback.alertActive); XCTAssertTrue(value.voice.microphoneActive); XCTAssertTrue(value.running)
        value.freshView = false
        XCTAssertTrue(value.handleAssistantControl("resume"))
        XCTAssertNil(value.objectSearch); XCTAssertEqual(value.searchStarts, 0)
        value.freshView = true
        XCTAssertTrue(value.handleAssistantControl("resume"))
        XCTAssertEqual(value.objectSearch?.target, "my backpack", "REGRESSION: resume changes narration only, not underlying work")
        XCTAssertGreaterThan(value.objectSearch?.startedAt ?? 0, priorStart)
        XCTAssertEqual(value.searchStarts, 1)
        XCTAssertTrue(value.feedback.alertActive)
    }
    func testHomeToggleUsesSameFreshResumePath() {
        let value = QuietHarness()
        value.toggleHomeDescriptions()
        XCTAssertTrue(value.heldSearchIntent.hasIntent); XCTAssertFalse(value.ambientDescriptions)
        value.toggleHomeDescriptions()
        XCTAssertEqual(value.objectSearch?.target, "my backpack")
        XCTAssertEqual(value.searchStarts, 1); XCTAssertTrue(value.ambientDescriptions)
        XCTAssertTrue(value.feedback.alertActive); XCTAssertTrue(value.running); XCTAssertTrue(value.voice.microphoneActive)
    }
    /// Known unresolved native integration gap, NOT a passing route-resume
    /// acceptance test. The extracted handler still cancels its legacy route.
    func testKnownNativePauseGapWitnessDoesNotPretendGoalTextRestoresRoute() {
        let value = QuietHarness()
        value.handleConversationTaskControl(.pause)
        value.handleConversationTaskControl(.resume)
        XCTAssertEqual(value.companionWorkingState.goal, "bathroom")
        XCTAssertTrue(value.indoor.route.isEmpty)
        XCTAssertEqual(value.indoor.replans, 0)
        XCTAssertFalse(value.returning)
        print("KNOWN_NATIVE_PAUSE_GAP=goalTextRetained:true,routeRestored:false,returnRestored:false,status:OPEN")
    }
    func testForgetItemFailedStorageStillRetiresHeldRequestAndNativeLeaseStaysOwned() {
        let value = QuietHarness(); value.stopDescriptions()
        let lease = UUID(); value.objectSearchNativeLease = lease
        XCTAssertFalse(value.forgetItem(.init(key: "my backpack", name: "my backpack"))) // Fake storage intentionally absent.
        XCTAssertFalse(value.heldSearchIntent.hasIntent)
        XCTAssertEqual(value.objectSearchNativeLease, lease)
        value.objectSearchNativeLease = nil
        _ = value.handleAssistantControl("resume")
        XCTAssertNil(value.objectSearch); XCTAssertEqual(value.searchStarts, 0)
        XCTAssertTrue(value.feedback.alertActive)
    }
    func testConversationAndRoomPictureDeletionClearRetainedSearchText() {
        for conversation in [true, false] {
            let value = QuietHarness(); value.stopDescriptions()
            if conversation { value.clearAssistantConversation() } else { value.forgetRoomPictures("room") }
            XCTAssertFalse(value.heldSearchIntent.hasIntent)
            _ = value.handleAssistantControl("resume")
            XCTAssertNil(value.objectSearch); XCTAssertEqual(value.searchStarts, 0)
            XCTAssertTrue(value.feedback.alertActive)
        }
    }
    func testRoomPictureDeletionDoesNotOrphanBusyUnrelatedModelTurn() {
        let value = QuietHarness(); value.stopDescriptions()
        value.busy = true; value.questionTask = .init(); value.questionTimeoutTask = .init()
        let originalRequest = value.requestID
        value.forgetRoomPictures("bedroom")
        XCTAssertEqual(value.requestID, originalRequest)
        XCTAssertTrue(value.busy); XCTAssertNotNil(value.questionTask)
        // The existing model callback's ownership check can still settle its turn.
        if value.requestID == originalRequest { value.busy = false }
        XCTAssertFalse(value.busy)
    }
    func testQuietWaitsForOldNativeLeaseAndNewGoalCannotReviveSearch() {
        let value = QuietHarness()
        value.stopDescriptions(); value.objectSearchNativeLease = .init()
        _ = value.handleAssistantControl("resume")
        XCTAssertNil(value.objectSearch); XCTAssertEqual(value.searchStarts, 0)
        value.objectSearchNativeLease = nil
        _ = value.handleAssistantControl("resume")
        XCTAssertEqual(value.searchStarts, 1)
        value.stopDescriptions(); value.companionWorkingState.goalRevision = "new-goal"
        _ = value.handleAssistantControl("resume")
        XCTAssertNil(value.objectSearch); XCTAssertEqual(value.searchStarts, 1)
    }
}
