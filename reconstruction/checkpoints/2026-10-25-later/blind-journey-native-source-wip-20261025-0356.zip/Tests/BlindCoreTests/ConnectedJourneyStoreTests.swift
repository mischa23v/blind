import Foundation
import XCTest
@testable import BlindCore
import NativeJourneyAdapter

final class ConnectedJourneyStoreTests: XCTestCase {
    typealias F = ConnectedFixture
    func testAtomicPersistenceRestoresLatestGoalWithUnknownPoseAndDeletion() async throws {
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString), storage = directory.appendingPathComponent("current.json")
        defer { try? FileManager.default.removeItem(at: directory) }
        let catalog = try F.catalog()
        let store = try ConnectedJourneyStore(storage: storage, catalog: catalog, body: F.body, limits: F.limits)
        try await store.transact { owner, persist in
            try F.begin(&owner, F.endpoint(F.a,"s"), time: 1)
            try owner.markStart(at: F.endpoint(F.a,"s"), origin: .trustedInterface, now: 1, recordedAt: F.date, persist: persist)
            try owner.setDestination(F.endpoint(F.c,"p"), origin: .trustedInterface, recordedAt: F.date, persist: persist)
        }
        let bytes = try Data(contentsOf: storage), saved = try ConnectedJourneySnapshot(data: bytes)
        let restored = try ConnectedJourneyStore(storage: storage, catalog: catalog, body: F.body, limits: F.limits)
        let result = try await restored.restore(catalog: catalog, body: F.body, limits: F.limits)
        XCTAssertEqual(saved, result)
        let pose = await restored.currentPose(now: 1); XCTAssertNil(pose)
        try await restored.deleteHistory(origin: .trustedInterface, recordedAt: F.date, catalog: catalog, body: F.body, limits: F.limits)
        XCTAssertFalse(FileManager.default.fileExists(atPath: storage.path))
        let empty = await restored.snapshot(); XCTAssertNil(empty.goal); XCTAssertNil(empty.start); XCTAssertTrue(empty.events.isEmpty)
    }
    func testRestoreCannotRollBackAnAlreadyStartedFailedNewCommand() async throws {
        let catalog = try F.catalog(), directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: directory) }
        let store = try ConnectedJourneyStore(storage: directory.appendingPathComponent("current.json"), catalog: catalog, body: F.body, limits: F.limits,
            writer: { _, _ in throw ConnectedJourneyError.persistenceRequired })
        do { try await store.transact { value, persist in
            try value.setDestination(F.endpoint(F.c,"p"), origin: .trustedInterface, recordedAt: F.date, persist: persist)
        }; XCTFail() } catch { }
        do { _ = try await store.restore(catalog: catalog, body: F.body, limits: F.limits); XCTFail() } catch { }
        let saved = await store.snapshot()
        XCTAssertEqual(saved.goal?.target.endpoint, F.endpoint(F.c,"p"))
    }
    func testMalformedFileFailsWithoutSilentlyReplacingHistory() async throws {
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString), storage = directory.appendingPathComponent("current.json")
        defer { try? FileManager.default.removeItem(at: directory) }
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        let original = Data("not valid history".utf8); try original.write(to: storage)
        let catalog = try F.catalog(), store = try ConnectedJourneyStore(storage: storage, catalog: catalog, body: F.body, limits: F.limits)
        do { _ = try await store.restore(catalog: catalog, body: F.body, limits: F.limits); XCTFail() } catch { }
        XCTAssertEqual(try Data(contentsOf: storage), original)
        let pose = await store.currentPose(now: 1); XCTAssertNil(pose)
    }
    func testSlowWriterDoesNotBlockIndependentExecutorAndLatestCancelWins() async throws {
        final class Gate: @unchecked Sendable {
            let started = DispatchSemaphore(value: 0), release = DispatchSemaphore(value: 0)
        }
        let gate = Gate(), catalog = try F.catalog()
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString), storage = directory.appendingPathComponent("current.json")
        defer { try? FileManager.default.removeItem(at: directory) }
        let store = try ConnectedJourneyStore(storage: storage, catalog: catalog, body: F.body, limits: F.limits, writer: { bytes, url in
            gate.started.signal(); _ = gate.release.wait(timeout: .now() + 3)
            try ConnectedJourneyStore.protectedAtomicWrite(bytes, url)
        })
        let first = Task {
            try await store.transact { owner, persist in
                try owner.setDestination(F.endpoint(F.c,"p"), origin: .trustedInterface, recordedAt: F.date, persist: persist)
            }
        }
        let started = await Task.detached { gate.started.wait(timeout: .now() + 3) == .success }.value
        XCTAssertTrue(started)
        // This marker executes while actor/file IO is held. It is not a measured
        // iPhone hazard-latency claim; no hazard code runs through this store.
        let independentMarker = await Task.detached { 42 }.value; XCTAssertEqual(independentMarker, 42)
        let cancel = Task { try await store.transact { owner, persist in try owner.cancel(origin: .trustedInterface, recordedAt: F.date, persist: persist) } }
        gate.release.signal(); try await first.value
        let cancelStarted = await Task.detached { gate.started.wait(timeout: .now() + 3) == .success }.value
        XCTAssertTrue(cancelStarted); gate.release.signal(); try await cancel.value
        let final = await store.snapshot(); XCTAssertEqual(final.goal?.status, .cancelled)
        XCTAssertEqual(try ConnectedJourneySnapshot(data: Data(contentsOf: storage)).goal?.status, .cancelled)
    }
}
