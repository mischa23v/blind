import Foundation
import XCTest
import BlindCore
import NativeJourneyAdapter

private actor RuntimeIO: ConnectedJourneyRuntimeIO {
    var data: Data?
    var writes: [JourneyRuntimeEnvelope] = []
    var holdWrites = false
    var failWrites = false
    var waiters: [CheckedContinuation<Void, Never>] = []
    init(_ data: Data? = nil) { self.data = data }
    func read() -> Data? { data }
    func write(_ payload: JourneyRuntimeWrite) async throws {
        if holdWrites { await withCheckedContinuation { waiters.append($0) } }
        if failWrites { throw JourneyRuntimeError.storageUnavailable }
        let envelope = try payload.envelope()
        data = try envelope.encoded(); writes.append(envelope)
    }
    func configure(hold: Bool, fail: Bool = false) { holdWrites = hold; failWrites = fail }
    func release() { holdWrites = false; waiters.forEach { $0.resume() }; waiters = [] }
    func blocked() -> Bool { !waiters.isEmpty }
}

@MainActor final class ConnectedJourneyRuntimeTests: XCTestCase {
    typealias F = ConnectedFixture
    private func until(_ condition: @escaping @MainActor () -> Bool) async throws {
        for _ in 0..<3000 { if condition() { return }; try await Task.sleep(nanoseconds: 1_000_000) }
        XCTFail("Timed out waiting for bounded runtime work")
    }
    private func installed(_ io: RuntimeIO = RuntimeIO()) async throws -> ConnectedJourneyRuntime {
        let runtime = ConnectedJourneyRuntime(io: io, sha256: F.sha256)
        runtime.restore(); try await until { !runtime.loading }
        let catalog = try F.catalog()
        // Deliberate burst proves the one-latest catalog task retains ALL accepted
        // installations rather than dropping a map when coalescing work.
        for map in catalog.installations.values { try runtime.install(map, portals: catalog.portals) }
        XCTAssertLessThanOrEqual(runtime.pendingMapWorkCount, 2)
        try await until { runtime.pendingMapWorkCount == 0 && runtime.pendingWriteCount == 0 }
        XCTAssertTrue(runtime.durable); return runtime
    }
    private func capture(_ runtime: ConnectedJourneyRuntime, _ endpoint: JourneyEndpoint, time: Double, yaw: Double = -.pi/2) throws -> SpatialLocalizationCapture {
        let position = try F.catalog().node(endpoint).position
        return .init(sessionID: try XCTUnwrap(runtime.expectedSessionID), binding: endpoint.binding,
            floorID: endpoint.floorID, roomID: endpoint.roomID, position: .init(position.x,1.3,position.z),
            bodyYaw: yaw, source: .alignedMapPose, headingSource: .bodyAligned, trackingNormal: true,
            positionUncertainty: 0.05, headingUncertainty: 0.05, capturedAt: time)
    }
    private func observe(_ runtime: ConnectedJourneyRuntime, _ endpoint: JourneyEndpoint, time: Double, yaw: Double = -.pi/2) throws {
        let value = try capture(runtime, endpoint, time: time, yaw: yaw)
        try runtime.accept(value, support: SpatialIntegrationFixture.support(value), now: time)
    }
    func testDormantNativeRuntimePersistsDestinationButCannotInventCalibrationOrPose() async throws {
        let io = RuntimeIO(), runtime = try await installed(io)
        try runtime.setDestination(binding: F.c, nodeID: "p", origin: .trustedInterface)
        try await until { runtime.pendingWriteCount == 0 }
        XCTAssertEqual(runtime.goal?.target.endpoint.nodeID, "p")
        XCTAssertThrowsError(try runtime.beginLocalization(in: F.a))
        XCTAssertThrowsError(try runtime.next(now: 1))
        let restored = ConnectedJourneyRuntime(io: io, sha256: F.sha256)
        restored.restore(); try await until { !restored.loading }
        XCTAssertEqual(restored.goal?.revision, runtime.goal?.revision)
        XCTAssertNil(restored.expectedSessionID)
        XCTAssertThrowsError(try restored.next(now: 1))
        let savedBytes = await io.read()
        let saved = try JourneyRuntimeEnvelope(data: XCTUnwrap(savedBytes))
        XCTAssertEqual(saved.installations.count, 3)
        XCTAssertEqual(saved.portals.count, 2)
    }
    func testCancelIsSynchronousAndLatestOnlyWhileWriterIsBlocked() async throws {
        let io = RuntimeIO(), runtime = try await installed(io)
        try runtime.configure(body: F.body, limits: F.limits)
        try runtime.setDestination(binding: F.c, nodeID: "p", origin: .trustedInterface)
        try await until { runtime.pendingWriteCount == 0 }
        _ = try runtime.beginLocalization(in: F.a)
        try observe(runtime, F.endpoint(F.a,"s"), time: 1)
        try await until { runtime.pendingWriteCount == 0 }
        try observe(runtime, F.endpoint(F.a,"s"), time: 1.1)
        let ticket = try runtime.next(now: 1.1)
        XCTAssertTrue(runtime.permits(ticket.route, now: 1.1))
        await io.configure(hold: true)
        var retired = 0; runtime.onOutputRetired = { retired += 1 }
        for i in 0..<50 { try runtime.setDestination(binding: F.c, nodeID: i % 2 == 0 ? "p" : "m", origin: .trustedInterface) }
        try runtime.cancel(origin: .trustedInterface)
        XCTAssertEqual(runtime.goal?.status, .cancelled)
        XCTAssertFalse(runtime.permits(ticket.route, now: 1.1))
        XCTAssertLessThanOrEqual(runtime.pendingWriteCount, 2)
        XCTAssertGreaterThan(retired, 0)
        // Main owner remains responsive; independent hazards are not on this IO path.
        let independentHazardMarker = 42; XCTAssertEqual(independentHazardMarker, 42)
        await io.release(); try await until { runtime.pendingWriteCount == 0 }
        let written = await io.read()
        XCTAssertEqual(try JourneyRuntimeEnvelope(data: XCTUnwrap(written)).journey.goal?.status, .cancelled)
        XCTAssertThrowsError(try runtime.next(now: 1.1))
        print("NATIVE_RUNTIME_SLOW_IO=cancelImmediate:true,pendingWritesAtMost:2,latestDiskGoal:cancelled,oldTicket:false")
    }
    func testPauseRestartAndResumeRetainRealGoalButNeedFreshEvidence() async throws {
        let runtime = try await installed()
        try runtime.configure(body: F.body, limits: F.limits)
        try runtime.setDestination(binding: F.c, nodeID: "p", origin: .trustedInterface)
        try await until { runtime.pendingWriteCount == 0 }
        _ = try runtime.beginLocalization(in: F.a)
        try observe(runtime, F.endpoint(F.a,"s"), time: 1)
        try await until { runtime.pendingWriteCount == 0 }
        try observe(runtime, F.endpoint(F.a,"s"), time: 1.1)
        let ticket = try runtime.next(now: 1.1), revision = runtime.goal?.revision
        try runtime.hold(origin: .trustedInterface)
        XCTAssertEqual(runtime.goal?.status, .paused); XCTAssertFalse(runtime.permits(ticket.route, now: 1.1))
        runtime.cameraRestarted(); XCTAssertEqual(runtime.goal?.revision, revision)
        try runtime.resume(origin: .trustedInterface)
        try await until { runtime.pendingWriteCount == 0 }
        XCTAssertThrowsError(try runtime.next(now: 1.1))
        _ = try runtime.beginLocalization(in: F.a)
        try observe(runtime, F.endpoint(F.a,"s"), time: 2)
        XCTAssertNoThrow(try runtime.next(now: 2))
        XCTAssertEqual(runtime.goal?.target.endpoint.binding, F.c)
    }
    func testFailedSaveNewCommandAndEraseCannotReviveSupersededGoal() async throws {
        let io = RuntimeIO(), runtime = try await installed(io)
        try runtime.setDestination(binding: F.c, nodeID: "p", origin: .trustedInterface)
        try await until { runtime.pendingWriteCount == 0 }
        await io.configure(hold: false, fail: true)
        try runtime.setDestination(binding: F.b, nodeID: "m", origin: .trustedInterface)
        try await until { runtime.pendingWriteCount == 0 }
        XCTAssertTrue(runtime.storageError)
        try runtime.cancel(origin: .trustedInterface)
        XCTAssertEqual(runtime.goal?.status, .cancelled)
        try await until { runtime.pendingWriteCount == 0 }
        await io.configure(hold: false)
        try runtime.retryPersistence(); try await until { runtime.pendingWriteCount == 0 }
        let written = await io.read()
        XCTAssertEqual(try JourneyRuntimeEnvelope(data: XCTUnwrap(written)).journey.goal?.status, .cancelled)
        try runtime.eraseHistory(origin: .trustedInterface)
        XCTAssertNil(runtime.goal); XCTAssertNil(runtime.snapshot.start)
        try await until { runtime.pendingWriteCount == 0 }
        let restored = ConnectedJourneyRuntime(io: io, sha256: F.sha256)
        restored.restore(); try await until { !restored.loading }
        XCTAssertNil(restored.goal); XCTAssertTrue(restored.snapshot.events.isEmpty)
    }
    func testSyntheticFullNativeRuntimeOutAndBackRequiresDeliveredOneUseChoice() async throws {
        let runtime = try await installed(), catalog = try F.catalog()
        try runtime.configure(body: F.body, limits: F.limits)
        try runtime.setDestination(binding: F.c, nodeID: "p", origin: .trustedInterface)
        try await until { runtime.pendingWriteCount == 0 }
        var time = 10.0, output: [String] = []
        _ = try runtime.beginLocalization(in: F.a)
        try observe(runtime, F.endpoint(F.a,"s"), time: time)
        try await until { runtime.pendingWriteCount == 0 }
        time += 0.1; try observe(runtime, F.endpoint(F.a,"s"), time: time)
        for binding in [F.a,F.b,F.c] {
            if binding != F.a {
                _ = try runtime.beginLocalization(in: binding)
                time += 0.1; try observe(runtime, F.endpoint(binding,"s"), time: time)
                try await until { runtime.pendingWriteCount == 0 }
                time += 0.1; try observe(runtime, F.endpoint(binding,"s"), time: time)
            }
            for node in ["m","p"] {
                let ticket = try runtime.next(now: time), cue = try XCTUnwrap(ticket.route.directionalCue())
                XCTAssertEqual(ticket.route.target.id,node)
                output.append("\(binding.mapID):\(node):\(String(format: "%.1f",cue.distance))")
                time += 0.1; try observe(runtime, F.endpoint(binding,node), time: time)
                try await until { runtime.pendingWriteCount == 0 }
                XCTAssertFalse(runtime.permits(ticket.route,now:time))
            }
        }
        XCTAssertEqual(runtime.goal?.status,.arrived)
        try runtime.saveReference(origin:.trustedInterface,now:time)
        try await until { runtime.pendingWriteCount == 0 }
        guard case .clarify(let question) = try runtime.requestReturn(origin:.trustedInterface,arabic:false) else { return XCTFail() }
        XCTAssertThrowsError(try runtime.resolveReturn(.journeyStart,origin:.trustedInterface,now:time))
        XCTAssertTrue(runtime.beginClarificationSpeech(question))
        XCTAssertFalse(runtime.clarificationSpeechFinished(id:UUID(),text:question.text,outcome:.completed,now:time))
        XCTAssertTrue(runtime.clarificationSpeechFinished(id:question.id,text:question.text,outcome:.completed,now:time))
        // Harmless fresh camera samples must not destroy semantic delivery receipts.
        time += 0.1; try observe(runtime,F.endpoint(F.c,"p"),time:time,yaw:.pi/2)
        try runtime.resolveReturn(.journeyStart,origin:.trustedInterface,now:time)
        XCTAssertThrowsError(try runtime.resolveReturn(.savedReference,origin:.trustedInterface,now:time))
        try await until { runtime.pendingWriteCount == 0 }
        time += 0.1; try observe(runtime,F.endpoint(F.c,"p"),time:time,yaw:.pi/2)
        for binding in [F.c,F.b,F.a] {
            if binding != F.c {
                _ = try runtime.beginLocalization(in:binding)
                time += 0.1; try observe(runtime,F.endpoint(binding,"p"),time:time,yaw:.pi/2)
                try await until { runtime.pendingWriteCount == 0 }
                time += 0.1; try observe(runtime,F.endpoint(binding,"p"),time:time,yaw:.pi/2)
            }
            for node in ["m","s"] {
                let ticket = try runtime.next(now:time), cue = try XCTUnwrap(ticket.route.directionalCue())
                output.append("\(binding.mapID):\(node):\(String(format:"%.1f",cue.distance))")
                XCTAssertEqual(ticket.route.target.id,node)
                time += 0.1; try observe(runtime,F.endpoint(binding,node),time:time,yaw:.pi/2)
                try await until { runtime.pendingWriteCount == 0 }
            }
        }
        XCTAssertEqual(runtime.goal?.status,.arrived)
        XCTAssertEqual(runtime.snapshot.events.filter { $0.kind == .portalEndpointsAssociated }.count,4)
        XCTAssertEqual(output,["bedroom-map:m:1.0","bedroom-map:p:1.0","hall-map:m:2.0","hall-map:p:2.0","study-map:m:1.0","study-map:p:1.0","study-map:m:1.0","study-map:s:1.0","hall-map:m:2.0","hall-map:s:2.0","bedroom-map:m:1.0","bedroom-map:s:1.0"])
        XCTAssertEqual(catalog.installations.count,3)
        print("SYNTHETIC_NATIVE_RUNTIME_FULL_SEQUENCE=" + output.joined(separator:","))
    }
    func testMapIOWithdrawalInvalidGoalAndDeletionFenceStaleOutput() async throws {
        let runtime = try await installed()
        try runtime.configure(body:F.body,limits:F.limits)
        try runtime.setDestination(binding:F.c,nodeID:"p",origin:.trustedInterface)
        try await until { runtime.pendingWriteCount == 0 }
        _ = try runtime.beginLocalization(in:F.a)
        try observe(runtime,F.endpoint(F.a,"s"),time:1)
        try await until { runtime.pendingWriteCount == 0 }
        try observe(runtime,F.endpoint(F.a,"s"),time:1.1)
        let ticket = try runtime.next(now:1.1)
        runtime.mapOwnershipWithdrawn()
        XCTAssertFalse(runtime.permits(ticket.route,now:1.1))
        _ = try runtime.beginLocalization(in:F.a)
        try observe(runtime,F.endpoint(F.a,"s"),time:1.2)
        XCTAssertThrowsError(try runtime.next(now:1.2))
        try runtime.mapRemovalSettled(F.c)
        try await until { runtime.pendingMapWorkCount == 0 && runtime.pendingWriteCount == 0 }
        XCTAssertEqual(runtime.goal?.target.endpoint.binding,F.c)
        XCTAssertThrowsError(try runtime.setDestination(binding:F.a,nodeID:"unknown",origin:.trustedInterface))
        try runtime.retryPersistence(); try await until { runtime.pendingWriteCount == 0 }
        XCTAssertThrowsError(try runtime.next(now:1.2))
    }

}
