import Foundation
import XCTest
@testable import BlindCore
@testable import NativeJourneyAdapter

/// Native output controller is copied byte-for-byte, while callback transport and
/// all geometry/poses are explicit synthetic fixtures. No AVFoundation execution
/// or human hearing is claimed by these callback-ledger tests.
final class ConnectedJourneyNativeOutputTests: XCTestCase {
    typealias F = ConnectedFixture
    final class Replay {
        var journey: ConnectedJourneyCoordinator
        var now = 1.0
        var held: ConnectedJourneyRouteTicket?
        var ledger = SpeechDeliveryLedger()
        var speechToken: UUID?
        var completed: [String] = []
        var retirements = 0
        var hazardActive = false
        init(_ journey: ConnectedJourneyCoordinator) { self.journey = journey }
    }
    func controller(_ replay: Replay) -> SpatialRouteOutputController {
        let output = SpatialRouteOutputController()
        output.permits = { ticket, goal in
            guard !replay.hazardActive, let held = replay.held,
                  held.route.routeID == ticket.routeID, goal == ticket.goalRevision.uuidString else { return false }
            return replay.journey.permits(held, now: replay.now)
        }
        output.stopSpeech = { _ in
            replay.retirements += 1
            if let token = replay.speechToken { _ = replay.ledger.finish(token: token, outcome: .interrupted, now: replay.now) }
            replay.speechToken = nil
        }
        output.stopBeacon = { _ in } // Route-specific fake sink, no independent alert stop.
        return output
    }
    func deliver(_ replay: Replay, _ output: SpatialRouteOutputController, finish: Bool = true) throws {
        let held = try replay.journey.next(now: replay.now); replay.held = held
        let cue = try XCTUnwrap(held.route.directionalCue())
        let text = "\(held.route.target.name), approximately \(String(format: "%.1f", cue.distance)) meters."
        XCTAssertTrue(output.deliver(ticket: held.route, goalRevision: held.route.goalRevision.uuidString,
            speech: { id in
                let attempt = replay.ledger.begin(text: text, priority: .mobility, destination: .requested(id), transport: .synthesized)
                replay.speechToken = attempt?.token; return attempt != nil
            }, beacon: { _ in true }))
        if finish {
            let token = try XCTUnwrap(replay.speechToken)
            let callback = try XCTUnwrap(replay.ledger.finish(token: token, outcome: .completed, now: replay.now))
            XCTAssertEqual(callback.outcome, .completed)
            replay.completed.append(callback.attempt.text)
            replay.speechToken = nil
        }
    }
    func drive(_ replay: Replay, _ output: SpatialRouteOutputController, reverse: Bool) throws {
        while let leg = replay.journey.currentLeg {
            switch leg {
            case .local(_, let to):
                while true {
                    try deliver(replay, output)
                    let target = try XCTUnwrap(replay.held).route.target.id
                    replay.now += 0.1
                    try F.observe(&replay.journey, F.endpoint(to.binding,target), time: replay.now, yaw: reverse ? .pi/2 : -.pi/2)
                    output.revalidate(); XCTAssertNil(output.active)
                    try replay.journey.advanceWaypoint(now: replay.now)
                    if target == to.nodeID { break }
                }
                try replay.journey.completeLocalLeg(now: replay.now, recordedAt: F.date, persist: { _ in })
            case .portal(_, _, let to):
                XCTAssertThrowsError(try replay.journey.next(now: replay.now))
                try replay.journey.armPortal(now: replay.now, recordedAt: F.date)
                try replay.journey.beginLocalization(in: to.binding)
                replay.now += 0.1
                try F.observe(&replay.journey, to, time: replay.now, yaw: reverse ? .pi/2 : -.pi/2)
                try replay.journey.completePortal(now: replay.now, recordedAt: F.date, persist: { _ in })
            }
        }
    }
    func testSyntheticFullSequenceCompletesNativeOutputCallbacksOutAndBack() throws {
        let replay = Replay(try F.prepared()), output = controller(replay)
        try replay.journey.setDestination(F.endpoint(F.c,"p"), origin: .trustedInterface, recordedAt: F.date, persist: { _ in })
        try replay.journey.plan(from: F.endpoint(F.a,"s"), now: replay.now)
        try drive(replay, output, reverse: false)
        _ = try replay.journey.requestReturn(origin: .trustedInterface, recordedAt: F.date, persist: { _ in })
        replay.now += 0.1; try F.observe(&replay.journey, F.endpoint(F.c,"p"), time: replay.now, yaw: .pi/2)
        try replay.journey.plan(from: F.endpoint(F.c,"p"), now: replay.now)
        try drive(replay, output, reverse: true)
        XCTAssertEqual(replay.completed, ["m, approximately 1.0 meters.","p, approximately 1.0 meters.",
            "m, approximately 2.0 meters.","p, approximately 2.0 meters.","m, approximately 1.0 meters.","p, approximately 1.0 meters.",
            "m, approximately 1.0 meters.","s, approximately 1.0 meters.","m, approximately 2.0 meters.","s, approximately 2.0 meters.",
            "m, approximately 1.0 meters.","s, approximately 1.0 meters."])
        XCTAssertEqual(replay.journey.snapshot.goal?.status, .arrived)
        XCTAssertNil(output.active); XCTAssertNil(replay.ledger.active)
        print("SYNTHETIC_NATIVE_ROUTE_CALLBACK_OUTPUT=" + String(decoding: try JSONEncoder().encode(replay.completed), as: UTF8.self))
    }
    func testNewGoalAndIndependentHazardRetireExactOldSpeechOnly() throws {
        let replay = Replay(try F.prepared()), output = controller(replay)
        try replay.journey.setDestination(F.endpoint(F.c,"p"), origin: .trustedInterface, recordedAt: F.date, persist: { _ in })
        try replay.journey.plan(from: F.endpoint(F.a,"s"), now: replay.now)
        try deliver(replay, output, finish: false)
        let old = try XCTUnwrap(output.active), oldToken = try XCTUnwrap(replay.speechToken)
        try replay.journey.setDestination(F.endpoint(F.b,"p"), origin: .trustedInterface, recordedAt: F.date, persist: { _ in })
        output.revalidate(); XCTAssertNil(output.active); XCTAssertNil(replay.ledger.active)
        XCTAssertNil(replay.ledger.finish(token: oldToken, outcome: .completed, now: replay.now))
        let hazard = try XCTUnwrap(replay.ledger.begin(text: "Synthetic independent hazard", priority: .danger, transport: .synthesized, independentAlert: true))
        replay.hazardActive = true
        output.retire(id: old.id)
        XCTAssertEqual(replay.ledger.active?.token, hazard.token)
        XCTAssertTrue(replay.hazardActive)
    }
}
