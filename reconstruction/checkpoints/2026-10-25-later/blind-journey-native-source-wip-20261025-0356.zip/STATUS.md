# Connected journey restoration: reviewed staging checkpoint

Status: additive Core implementation and Foundation store implemented and executed in an isolated package. No live source changes or push. The native quiet/search patch is a separate method-level proposal. Native journey lifecycle wiring is ongoing, not complete.

Verified checkpoint:
- Full copied Core projection: 1,087 tests, zero failures, evidence/full-core-final.log. This includes 30 new Core cases, not Apple runtime.
- Focused package: 36 Core/store/native-output tests plus 7 extracted native lifecycle tests, zero failures in evidence/focused-final-review.log. One lifecycle test is explicitly an OPEN-gap witness that the legacy native pause handler preserves goal text but does not restore its route. It is not successful native pause acceptance.
- Existing native SpatialRouteOutputController copied byte-for-byte, exercised with the real SpeechDeliveryLedger and exact synthetic speech callbacks for multi-map outbound/return. Simulated transport callbacks are not AVFoundation or proof of hearing.
- Exact synthetic 3-map / 2-floor route and speech outputs are captured in focused logs. All links, maps, poses, support and uncertainty are synthetic; no measured/live localization claim.
- Native syntax parsing passed for default and DEBUG/familiar configurations. This is not Apple SDK typechecking.

Core behavior: bounded typed local-only history/reference anchors/goals; unknown pose on restart; no goal resets on room/map transitions; explicit map/frame/revision/digest/floor bindings; source/endpoint/transform-complete portals with authored direction; reuse of IndoorMap planner and SpatialRouteOwner collision/fresh-capture gates; current restrictions rather than old traversed path; delivery-backed one-use return clarification; command-origin guards; failed-save authority fences and retained restriction retry owner; no portal crossing command. Portal history records associated endpoints, not proof of actual traversal.

Native quiet failure-before evidence: evidence/quiet-native-fail-before.log, exact extracted old methods, 2 tests and 6 failing assertions. The proposal retains only request identity, reacquires fresh views after explicit resume and respects in-flight native operation ownership. Privacy erasure retires retained search intent without orphaning unrelated model callbacks. The old official preimage predates photo integration; quiet-current-projection/ separately proves a method-level rebase preserving photo cleanup. Do not copy old whole NavigationModel over newer work.

Known gaps requiring continued wiring: no native calibrated pose/heading/floor-support issuer; multi-map artifact catalog and sourced portal import not connected to native library; actual camera/restart/goal/return/hold callbacks not yet owned by the new coordinator; native main-thread output retirement must happen before awaiting store IO; actor mailbox admission is not bounded; true Apple audio, privacy file protection, hardware and device behavior unverified. Legacy ReturnTrail remains session-only and must not be reinterpreted as durable physical authority.
