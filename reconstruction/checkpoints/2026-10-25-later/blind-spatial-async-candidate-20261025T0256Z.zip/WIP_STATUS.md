# Asynchronous map IO candidate

Staged source only. Not applied, pushed, deployed or Apple-device verified. A final preimage check and rebase over the separately repaired observation/privacy integration is required before application. The optional observation purge callback and map-binding accessor are preserved as inert hooks here; this candidate does not implement or claim that observation storage repair.

## Implemented

- One utility serial worker owns bounded file reads, JSON/map validation, hashing, encoding and protected atomic writes. The main owner retains mutable route state; no IO lock is held during file operations or callbacks.
- At most one running job, one latest pending job, and one non-droppable delete barrier. Generation plus installation-revision/artifact context is checked before commit and again at actual main publication. A stale or uncertain write restores prior bounded bytes before later jobs. Failed rollback or delete blocks later writes until an explicit successful deletion barrier.
- Delete/replace/restriction requests immediately withdraw pose/output authority. Pending additive restrictions retain their union until durable. Canceled or newly attempted goals cannot be restored by a delayed replan completion.
- Actual native restore/import/community/keep-out/delete paths use asynchronous APIs. File import never reads the full file on main. Community-cache intents, privacy purges, captions and UI busy state are independently owned, so stale completions cannot overwrite newer work.
- The existing IndoorMap planner, NavigationSurface collision logic and spatial lease remain in use. There is no replacement planner, database, SLAM, invented transform or confidence certificate.

## Verification

The latest standalone package passes 86 tests: 10 installation, 23 route-owner, 11 real Foundation adapter, 16 IO race/failure, 9 complete extracted IndoorNavigator controller, 3 extracted community-preparation, 10 output-controller and 4 extracted Feedback tests. New Node replay executes 39 of the IO/adapter/controller tests from actual projected source, not a rewritten state model. Final focused Node passes 47/47, zero skips, including the fresh 39-test spatial replay and unchanged 25-test actual WorkingState replay. These overlap the standalone coverage and are not additional unique spatial scenarios.

Default and DEBUG native syntax parsing pass. The Xcode project is regenerated with actual current source names and the new IO/test source memberships. CommunityTests content outside its two spatial classes and a new IO-wait helper is byte-identical to the current published-memory-preserving baseline.

All map/pose/support inputs are explicitly authored synthetic fixtures. Blocked writers, cache tasks and publication delivery are deliberate controlled test dependencies. Warning/control probes prove that the main queue can execute while the worker is blocked, not real audible latency or hardware responsiveness.

## Remaining boundaries

No calibrated native map-position/body-heading uncertainty or same-capture ground-support issuer is supplied. No Apple SDK typecheck, real UIKit/Combine/VoiceOver/audio/haptic/device acceptance is claimed. The hosted CommunityTests and two Apple-only caption tests remain unexecuted here; exact-source controller extraction uses explicit unrelated platform stubs.

No dynamic observed-clearance protocol reopens conservative restrictions. Storage is single-owner per file in the app's shared NavigationModel; cross-process writers are not coordinated. Crash recovery midway through an unfinished atomic write/rollback is not a completed delete or durable-save receipt. This increment does not move route planning, every unrelated storage path, or every map-context calculation off main, and it is not complete all-day restoration or live guidance.
