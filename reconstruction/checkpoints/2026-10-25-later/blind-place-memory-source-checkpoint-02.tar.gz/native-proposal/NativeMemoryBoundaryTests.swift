import XCTest
@testable import BlindCore
final class NativeMemoryBoundaryTests: XCTestCase {
    func scope(_ place: String) -> CompanionMemoryScope {
        .init(map: .init(mapID: place, frameID: place, revision: "1"), placeID: place, floorID: "floor-1", roomID: "kitchen", objectInstanceID: "fridge")!
    }
    func testPM019IdenticalWordsDoNotLaunderEarlierSourceIDOrTime() {
        var state = CompanionWorkingState(), dialogue = AssistantDialogue()
        let text = "The milk is fresh"
        let oldTime = Date(timeIntervalSince1970: 1000), newTime = Date(timeIntervalSince1970: 2000)
        state.transitionMemoryScope(scope("A"))
        state.record(text, at: oldTime)
        dialogue.record(role: "user", text: text)
        let oldID = state.memoryToolReports(from: dialogue, query: "milk").first!.id
        let oldDialogueID = dialogue.userRecords.first!.id
        state.transitionMemoryScope(scope("B"))
        dialogue.record(role: "assistant", text: "What would you like to check?")
        state.record(text, at: newTime)
        dialogue.record(role: "user", text: text)
        let boundary = ExtractedNativeMemoryBoundary(assistantDialogue: dialogue, companionWorkingState: state, items: ItemMemory())
        let reports = boundary.read(query: "milk").evidence
        XCTAssertEqual(reports.count, 1)
        XCTAssertEqual(reports.first?.observedAt, newTime)
        XCTAssertNotEqual(reports.first?.id, oldID)
        XCTAssertNotEqual(reports.first?.id, oldDialogueID)
        XCTAssertEqual(state.scopedTaskHistory.last?.reports.first?.time, oldTime)
        print("PM-019 PASS | Identical child words at fridge A/time 1000 and B/time 2000 retain separate source IDs; A never inherits B's date.")
    }
    func testPM018ActualNativeToolSelectionWithholdsOtherFridgeAndUnknownIdentity() {
        let time = Date(timeIntervalSince1970: 1000)
        var state = CompanionWorkingState(), dialogue = AssistantDialogue(), items = ItemMemory()
        state.transitionMemoryScope(scope("A"))
        state.record("The milk is fresh", at: time)
        dialogue.record(role: "user", text: "The milk is fresh")
        items.remember(name: "milk", at: time, scope: scope("A"))
        state.transitionMemoryScope(scope("B"))
        state.record("The milk is spoiled", at: time.addingTimeInterval(1))
        dialogue.record(role: "user", text: "The milk is spoiled")
        items.remember(name: "milk", at: time.addingTimeInterval(1), scope: scope("B"))
        var boundary = ExtractedNativeMemoryBoundary(assistantDialogue: dialogue, companionWorkingState: state, items: items)
        let result = boundary.read(query: "milk")
        XCTAssertFalse(result.evidence.contains { $0.text == "The milk is fresh" })
        XCTAssertTrue(result.evidence.contains { $0.text == "The milk is spoiled" && $0.observedAt == time.addingTimeInterval(1) })
        XCTAssertEqual(result.evidence.filter { $0.kind == .historicalMemory }.count, 1)
        boundary.companionWorkingState.transitionMemoryScope(nil)
        XCTAssertTrue(boundary.read(query: "milk").evidence.isEmpty)
        print("PM-018 PASS | Child A: The milk is fresh. | Child B: The milk is spoiled. | Actual native savedMemory selection returns only B's original dated report and B's historical item. Identity loss withholds both.")
    }
}
