import XCTest
@testable import BlindCore
final class PlaceMemoryOriginalFailureTests: XCTestCase {
    // Authored scenario labels only: baseline has no place/instance ownership API.
    func testPM001SameGoalDifferentFridgeLeaksPriorProgress() {
        var state = CompanionWorkingState()
        state.changeGoal("Check the fridge")
        state.reportedCompletedSteps = ["User reported checking milk in house A downstairs fridge"]
        state.changeGoal("Check the fridge") // arrival at house B is not representable
        print("PM-001 BASELINE | Child: Check the fridge. | fixture transition A/downstairs/fridge-1 -> B/upstairs/fridge-2 | retained progress: \(state.reportedCompletedSteps)")
        XCTAssertTrue(state.reportedCompletedSteps.isEmpty, "Missing physical-scope transition: baseline keeps another fridge's progress")
    }
    func testPM002DistinctPlaceReportsOverwriteEachOther() {
        var book = CompanionFactBook()
        let t = Date(timeIntervalSince1970: 1000)
        book.record(object: "milk", place: "in house A fridge", tense: .current, hedged: false, at: t)
        book.record(object: "milk", place: "in house B fridge", tense: .current, hedged: false, at: t.addingTimeInterval(1))
        print("PM-002 BASELINE | distinct fridge contents retained: \(book.facts.count)")
        XCTAssertEqual(book.facts.count, 2, "Missing scope ownership: second fridge destroys first report")
    }
}
