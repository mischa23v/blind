from pathlib import Path
import shutil
root=Path(__file__).parent/'proposal';out=Path(__file__).parent/'replay'
for file in ['CompanionFacts.swift','CompanionMemoryScope.swift','ItemMemory.swift','CompanionTaskSource.swift','CompanionMemoryRetrieval.swift']:
    shutil.copyfile(root/'BlindCore/Sources/BlindCore'/file,out/'Sources/BlindCore'/file)
shutil.copyfile(root/'BlindCore/Tests/BlindCoreTests/CompanionMemoryScopeTests.swift',out/'Tests/BlindCoreTests/CompanionMemoryScopeTests.swift')
s=(root/'ios/BlindAssist/LocalImageAssistant.swift').read_text(); start=s.index('struct CompanionTaskUpdate:'); end=s.index('\n#if canImport(FoundationModels)',start);(out/'Sources/BlindCore/ExtractedAppWorkingState.swift').write_text('import Foundation\n'+s[start:end])
s=(root/'ios/BlindAssistTests/CommunityTests.swift').read_text();start=s.index('final class CompanionWorkingStateTests:');end=s.index('\n/// EgoBlind-style',start);(out/'Tests/BlindCoreTests/ExtractedAppWorkingStateTests.swift').write_text('import XCTest\n@testable import BlindCore\n'+s[start:end])
