"""Extract the actual native report-selection + retrieval invocation.
Unrelated preference/place/list collectors are empty fixtures, not native evidence.
"""
from pathlib import Path
r=Path(__file__).parent
s=(r/'native-proposal/NavigationModel.swift').read_text()
a=s.index('            let reports =', s.index('private func readSavedCompanionMemory'))
b=s.index('            var preferences =',a)
c=s.index('            return CompanionMemoryRetrieval.read',b)
d=s.index('\n    }',c)
source='''import Foundation
struct ExtractedNativeMemoryBoundary {
    var assistantDialogue: AssistantDialogue
    var companionWorkingState: CompanionWorkingState
    var items: ItemMemory
    var observedObjects = ObservedObjectMemory()
    func read(query: String) -> CompanionToolResult {
        let savedPlaces: [CompanionPlaceMemory] = []
        let preferences: [CompanionMemoryNote] = []
        let taskNotes: [CompanionMemoryNote] = []
'''+s[a:b]+s[c:d]+'''\n    }\n}\n'''
(r/'replay/Sources/BlindCore/ExtractedNativeMemoryBoundary.swift').write_text(source)
