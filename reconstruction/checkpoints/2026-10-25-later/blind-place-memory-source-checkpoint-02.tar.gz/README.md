# Place-scoped task/item memory proposal

Stage only. No live repository edits, commits, publication, Apple SDK build, model execution, camera input or real identity/localization validation.

## What changed

- Reuse existing `SpatialMapBinding` for map/frame/revision ownership. Add bounded place/floor/room/object-instance IDs. A label, goal, category, or nil is not a current identity. This type is ownership metadata, not a localization/recognition issuer or geometry authority.
- Existing `CompanionFactBook` and `ItemMemory` retain separate same-name records per scope. Corrections reject older replay in that scope; source timestamps survive JSON restart. Exact source/record deletion cannot delete another scoped item. Ambiguous name-only deletion/description is withheld. Legacy item lookup does not return scoped records.
- Existing working state has explicit `transitionMemoryScope`. Same identity preserves repeated-goal progress. Changed house/floor/room/map revision/fridge or identity loss preserves the conversational goal and original goal source, archives old reports/progress, rotates the generation, and clears current progress, proposed steps, pronoun target, search receipts and parent/suspended physical progress. Restart never restores live scope.
- Model task updates carry the generation read by the model; delayed A updates cannot commit into B or unknown identity. Scoped context cannot backfill from unscoped dialogue. Reports have stable source IDs; identical wording in A and B never joins A's ID to B's date.
- The small scoped recall selector reuses already-gated `CompanionEvidence` freshness and rejects future/expired, wrong-scope, empty-target and spatial observations. Fresh matching observations outrank older reports; newer corrections remain reports; historical recall never asserts current presence. This selector is not a detector, issuer, or persistence store.
- A separate narrow NavigationModel proposal filters the actual savedMemory boundary (source-owned reports and exact-scoped saved items), withholds legacy category observations once scoped because they lack exact revision/container binding, blocks dialogue backfill and adds generation fences to speech/stream candidates. It does not rotate requestID or alter cancellation lifecycle.

## Evidence and reproduction

All PM fixtures are authored household/fridge/child-word scenarios. They test actual Swift state/retrieval code, not real camera accuracy, a child trial, physical matching or safe mobility.

- `baseline-source.tar` preserves original source.
- `baseline/replay/Tests/BlindCoreTests/PlaceMemoryOriginalFailureTests.swift` and `evidence/failed-before.log`: two expected baseline failures. The baseline has no physical-scope input; its same-goal API cannot distinguish repeating at A from arriving at B. The second failure is global same-name report replacement.
- `evidence/review-failures-before.log`: three reviewer-discovered failures executed before their fixes (long scope key silently loses retrieval, legacy exact/fuzzy lookup leaks scoped items, empty observation target admitted).
- `evidence/aggregate-after.log`: final entire Core suite plus exact extracted app working-state tests and native report/retrieval boundary tests. The prepare scripts extract actual source, not a rewritten model of it. Native boundary collectors for unrelated preferences, places and shopping lists are explicitly empty fixtures.
- `evidence/native-parse.log`: syntax parse only, not an Apple SDK typecheck/link/device test.
- `evidence/conversation-traces.txt`: code-printed PM outputs. No model-generated or real sensor accuracy claims.

Reproduction uses the already installed Swift toolchain, HOME/cache paths in the assignment, and `swift test -j 2`. `proposal/tools/prepare-working-state-replay.py` creates a fresh disposable package; `sync-replay.py` refreshes the changed Core/native state/tests in existing stage scratch. `prepare-native-boundary-replay.py` extracts the native report selection and final retrieval invocation. Copy `native-proposal/NativeMemoryBoundaryTests.swift` into scratch Tests/BlindCoreTests. No downloads/dependencies are added.

## Mandatory remaining native integration

This proposal does NOT make the current app discover a house/floor/room/fridge identity. The scope issuer is still missing/unvalidated. Do not infer IDs from dialogue, room names, category boxes, GPS alone, RoomPlan labels, or map selection. Native callbacks must bind source-owned identities at capture; never stamp a delayed observation with the latest scope.

1. Apply/rebase only the narrow proposal after the journey changes. Parent owns live application. Verify baseline hashes, especially NavigationModel; do not replace the whole file.
2. Connect `transitionMemoryScope` only to independently established identity, and to nil on genuine identity loss, camera/session restart, incompatible map revision or target identity uncertainty. Existing saved schemas retain historical source ownership; no live pose is restored.
3. A real scope transition must coherently cancel old generation/model work and queued speech, preventing an orphaned busy/model task. The proposal only adds candidate and final state-generation fences, not a complete queue lifecycle. Preserve conversational goal and goalSource.sourceID. Coordinate journey geometry/output invalidation without cancelling the typed destination; journey owner is preparing that context-change seam.
4. Capture scope + generation + observation timestamp/source ID at acquisition and revalidate at delivery. Integrate scoped recall only with an independently gated on-device observation/identity adapter. Do not treat the selector's returned enum as a physical-output permit. No distance, pickup, movement, clearance, negative-presence or complete-fridge inventory claim is authorized.
5. Native saved-item writes must pass actual source scope and use record ID for scoped correction/deletion; appearance assets are still keyed by old item names and need explicit migration/instance ownership before scoped recognition. Existing unscoped data stays historical, never automatically assigned to a house.
6. Native UI/review for archived scoped task reports, explicit cross-place historical retrieval, source-ID-specific correction UX, exact Apple typechecking, on-device model behavior, privacy/deletion/restart integration, and supervised identity tests remain open. The existing generic private JSON store is reused; no new database, synchronization, cloud path or network dependency.

Do not mark same-goal physical-place continuity as completed in the native app until this wiring and its evidence exist. Preserve source-only versus native/device acceptance distinctions in central tracking documents.
