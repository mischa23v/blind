# Long-trip actual-route continuation (required, not implemented)

The bounded checkpoint is not the final all-day design and does not close R19/R29/R30/R31. The next increment must preserve useful active-trip history without making a child clear a recorder after about an hour. The 512 KiB/min logical-payload budget remains provisional, not measured phone flash, latency, battery or thermal cost.

## Reuse boundary

Reuse the pinned GRDB dependency, `MemoryStore` protected/no-backup directory factory, `NativeObservationStore` dedicated-writer and transaction/test patterns, and the existing bounded admission/durability machinery. Do NOT repurpose the raw observation table: its 64-record/2 MiB FIFO intentionally evicts history and would silently destroy a trip start. Do not implement a database engine or SLAM. Keep raw image/depth history separate from compact route samples.

## 1. Active-trip identity and pinned references

Introduce a durable private trip ID independent of AR session, room, floor and current goal. An interrupted/changed goal or restart must not create a new trip or erase its origin. Track immutable monotonically increasing trip sequence IDs and exact source-session/frame/observation provenance.

The first actually accepted observation can mark an unlabelled trip start, without inferring a home, building or entrance. Add typed named references for observed start, entrance and meeting point, each pinned to an actual sample/segment and optional independently established map/portal association. A user label remains a label, not place recognition or measured geometry. Validate authorized input and exact target before changing a reference. Never create an entrance from an appearance guess or coarse location. Keep a clear distinction between ending an active trip, pausing recording and changing a conversational goal.

## 2. Incremental private GRDB schema and paging

Use a dedicated protected SQLite file/writer rather than the synchronous places-memory lock. Proposed migrations: `recordedTrip`, immutable `recordedRouteSample`, typed `recordedRouteGap`, `recordedRouteReference`, optional `recordedRoutePortalAssociation`, and monotonic state/erasure-generation records. Keys include profile, trip ID and sequence. Store source-frame/convention/map-revision metadata in immutable referenced rows to avoid duplicating it per sample; retain the actual full matrix/times/IDs and do not silently downsample already accepted records.

Append small bounded transactions with unique observation IDs; identical retries are no-ops and conflicting IDs fail. Validate payload sizes/types with SQLite length/metadata before materializing BLOBs, as the raw-history store does. Update durable tail/byte accounting in the same transaction. Keep one extraction slot, one pending append batch and one admitted page read. Return exact committed sequence ranges and explicit dropped/volatile ranges, not the full retained ID set.

Expose forward/reverse keyset pages (`sequence < cursor`, fixed LIMIT), not OFFSET or whole-trip arrays. Bound each returned page by both records and payload bytes. A reverse cursor carries trip/revision/erase generation and cannot cross a privacy clear or history replacement. Playback requests the next page only as needed; no whole-outing decoding on the main/hazard loop.

## 3. Storage policy without silent start loss

Before selecting a production byte cap, measure actual compact-schema bytes and GRDB/WAL costs at realistic moving/stationary rates for 8-, 24- and 72-hour generated trips. A 5 Hz upper bound alone does not prove an all-day capacity. Keep limits explicit and test with forced tiny quotas.

Prioritize active-trip samples and pinned start/entrance/meeting references over completed unpinned trips. Bound older completed history according to an explicit retention policy; deletion must record what range is no longer available. If active-trip storage itself fills, preserve its pinned origin and references, roll to a new bounded segment with an explicit loss/gap range and continue accepting useful current history rather than requiring the child to clear a screen. Never relabel a retained start as the newest point, concatenate around evicted geometry or claim a complete same-route return across missing samples. Reserve small metadata space for gap/retention and erase-state receipts even when the normal payload quota is exhausted.

That degradation keeps current recording useful but cannot provide an exact path across an evicted range. Surface the limitation briefly when relevant to return, and make storage policy reviewable by the helper. Do not claim unlimited or all-day exact history without a measured duration/capacity envelope. Consider adaptive pre-admission sampling only after validating its effect on geometry and gap semantics; never rewrite accepted provenance or call a simplified path exact.

## 4. Return cursor and measured transitions

Return to a named actual sample uses descending sequence order, never a newly optimized path to its endpoint. Preserve detours and loop order. Validate each historical source-frame/body/node association using the later independently calibrated issuer/mapper; separately validate fresh current localization, body heading/support and target-specific obstacle coverage immediately before output.

Persist typed observed portal associations that identify both actual endpoint sample IDs, their frames/map revisions, observed times and independently established portal/transport evidence. An entrance label or changed mapTarget is not a portal. Unknown walking/vehicle/lift/stair mode remains unknown. Never turn a recorded vehicle journey into pedestrian directions. Cross-floor/building segments can remain history until the exact transition is supported. A closed/newly blocked segment pauses exact retrace; an alternative route requires a distinct authorized goal and must be announced as a different path.

## 5. Failure/erasure migration and testing

Migrate the reviewed bounded chunks transactionally, preserving IDs, order, unknowns and every gap. Keep the original files until verified import commits; do not race import with new capture, playback or clear. Durable erasure-generation/tombstone handling must prevent a failed privacy operation from being silently forgotten on restart where storage can persist that state. Never claim deletion when disk operations fail.

Required actual-code tests:
- Generated 8/24/72-hour trips under realistic and deliberately tiny quotas, with bounded working set/read sizes/transaction counts and all pinned references retained.
- Blank start, incremental map ownership, rooms/floors/buildings, mapped→unmapped→mapped, loop/detour and named return anchors. Keep synthetic labels explicit.
- Exact reverse-page traversal, overlapping page retries, concurrent append, source/session/time rollback, capacity rollover, corruption and explicit missing-range receipts.
- New obstacle/closed door with a shorter alternate path: exact retrace does not silently reroute.
- Source-frame/portal/transport ambiguity, real recorded camera trajectory ingestion and synthetic multi-floor assignments clearly separated.
- Goal interruption, parent-contact handoff, cold unrecognized restart and late narration callbacks, with preserved history but no resurrected pose/clearance.
- Real GRDB transaction failure/retry, malformed SQLite rows/oversized BLOBs, disk-full, failed delete, clear during append/read/import, held publication and process restart.
- Apple SDK compile, on-device mounting/alignment, exposure/capture coverage, storage/energy/thermal/latency measurement and independent supervised safety acceptance remain separate release gates.

Recommended order: implement/test the paginated GRDB trip/reference repository first; then bounded native recording/migration; then reverse cursor/portal integration through the existing connected owner. Publish each honest partial checkpoint, never a collection of isolated tests as a finished whole outing.
