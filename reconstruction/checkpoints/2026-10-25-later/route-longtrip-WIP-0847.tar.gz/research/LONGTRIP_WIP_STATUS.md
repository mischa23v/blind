# Long-trip recorded-route WIP checkpoint — 2026-10-25

**WIP, NOT APPLIED, NOT RELEASE-READY.** This archive preserves source only. It contains no databases, private recordings, raw dataset assets, models, binaries or build caches.

Implemented in this stage:
- GRDB active-trip identity survives camera/goal/restart changes, with automatic pinned actual start and bounded user-labelled observed entrance/meeting anchors.
- Immutable bounded append batches and indexed reverse pages (max64 records). Trip/erase epoch, selected reference and previously encountered gap state travel with the cursor; a new append cannot enter an already captured return snapshot.
- Pinned samples are protected while unpinned oldest samples roll out under a configurable accounted quota. Minimum256-byte accounting bounds metadata rows and a max1,024-candidate bulk eviction operation; exact missing sequence ranges remain explicit. Quota is not measured SQLite/phone cost.
- Constant-memory native sampler (one previous sample, max64 pending samples) replaces terminal20k in-memory recording. Volatile overflow preserves the original unsaved start and marks explicit durability gaps. Separate bounded extraction/read/anchor/flush/clear slots; no whole-trip payload load.
- Typed camera source/frame/session/convention/map revision and unknown transport retained. Legacy bounded chunks import in bounded batches with a durable completion marker; original files remain until privacy clear.
- Exact-way, entrance and meeting-point code paths staged as narrow Navigation patches. No shortest-path substitution, invented map/body alignment, floor or portal association, or native physical guidance issuer.
- Current route-owner source is rebased over body/terrain checkpoint15. Native observation adapter preserves the subsequent Apple SDK fixes for plane boundary arrays and mesh index-pointer naming.

Executed evidence at this checkpoint:8 real-GRDB repository tests passed, including small-payload quota eviction, oversized SQLite payload rejection, stale clear/cursor ownership, pinned anchor retention and a synthetic sparse72-hour timestamp episode. The episode is NOT72 hours at5Hz or measured device endurance. An earlier native run passed4 actual native-store/GRDB integration tests. Revalidation, broader lifecycle/migration/ownership regression tests, final source freeze and independent review remain ongoing. Initial toolchain link/resource-bundle setup failures are retained outside this source-only archive; they are not hidden as passing checks.

Not complete: independently calibrated map/body/transport and portal association, cross-map actionable playback, fresh real-world obstacle authority, complete family outing acceptance, Apple SDK/device validation, maximum-density all-day capacity/cost evidence and a complete multi-trip archive/outing-lifecycle UX. One active trip per profile is the implemented durable identity. No requirement R19/R29/R30/R31 is marked complete.

The parent owns ordered live integration and publishing. Preserve current reader/boarding/voice/native-issuer hooks while applying only narrow Navigation methods. Do not replace the live model wholesale.
