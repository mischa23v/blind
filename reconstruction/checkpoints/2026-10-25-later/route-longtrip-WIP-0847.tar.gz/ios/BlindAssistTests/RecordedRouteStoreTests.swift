import XCTest
import BlindCore
import BlindMemory
#if canImport(BlindAssist)
@testable import BlindAssist
#endif

final class RecordedRouteStoreTests: XCTestCase {
    final class Clock: @unchecked Sendable {
        let lock = NSLock(); private var value = 0.0
        func read() -> Double { lock.lock(); defer { lock.unlock() }; return value }
        func set(_ n: Double) { lock.lock(); value = n; lock.unlock() }
    }
    private func record(_ session: UUID, time: Double) -> NativeObservationRecord {
        var c = NativeCameraTransform.identity.columns; c[12] = time*0.01
        return .init(sessionID: session, coordinateFrameID: "source-\(session.uuidString)", producer: .arkit,
            sourceID: "frame-\(time)", capturedAt: time, receivedAt: time, observedAt: Date(), tracking: .normal,
            cameraConvention: .arKitRightUpBack, cameraToSessionWorld: .init(columns: c),
            intrinsics: .init(width: 2, height: 2, fx: 1, fy: 1, cx: 1, cy: 1), depth: nil)
    }
    private func snapshot(_ store: RecordedRouteStore) -> RecordedRouteStore.Snapshot? {
        var result: RecordedRouteStore.Snapshot?; let done = expectation(description: "snapshot")
        store.preview { result = $0; done.fulfill() }; wait(for: [done], timeout: 5); return result
    }
    func testConstantMemoryQuotaRollsPastOldLimitWhilePinningStartAndMeeting() throws {
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: directory) }
        let clock = Clock(), session = UUID()
        let store = RecordedRouteStore(url: directory.appendingPathComponent("routes.sqlite"), now: clock.read,
            factory: { try RecordedRouteRepository(path: $0, payloadQuota: 8192) })
        store.begin(sessionID: session); clock.set(60)
        let first = record(session, time: 60); store.offer(sessionID: session, at: 60) { first }; _ = snapshot(store)
        let pin = expectation(description: "named observed point")
        store.pinLatest(kind: .meetingPoint, label: "Family", origin: .trustedInterface) { XCTAssertTrue($0); pin.fulfill() }
        wait(for: [pin], timeout: 5)
        for i in 1..<180 {
            let time = 60 + Double(i)*0.21; clock.set(time)
            let sample = record(session, time: time); store.offer(sessionID: session, at: time) { sample }
            XCTAssertLessThanOrEqual(snapshot(store)?.volatileSampleCount ?? 1000, 64)
        }
        store.stop(); let result = try XCTUnwrap(snapshot(store))
        XCTAssertGreaterThan(result.trip?.nextSequence ?? 0, 100)
        XCTAssertEqual(result.trip?.anchors.filter { $0.kind == .start }.first?.sequence, 0)
        XCTAssertEqual(result.trip?.anchors.filter { $0.kind == .meetingPoint }.count, 1)
        XCTAssertGreaterThan(result.trip?.evictedCount ?? 0, 0)
        XCTAssertFalse(result.capacityReached)
        XCTAssertTrue(result.preview?.gaps.contains(.retentionLoss) == true)
    }
    func testActiveTripSurvivesNewSessionAndRestartWithBoundedReversePages() throws {
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: directory) }
        let url = directory.appendingPathComponent("routes.sqlite"), clock = Clock(), session = UUID()
        let store = RecordedRouteStore(url: url, now: clock.read); store.begin(sessionID: session); clock.set(60)
        for i in 0..<90 {
            let time = 60 + Double(i)*0.21; clock.set(time)
            let sample = record(session, time: time); store.offer(sessionID: session, at: time) { sample }; _ = snapshot(store)
        }
        store.stop(); let prior = try XCTUnwrap(snapshot(store))
        let reopened = RecordedRouteStore(url: url, now: clock.read)
        reopened.begin(sessionID: UUID())
        let current = try XCTUnwrap(snapshot(reopened))
        XCTAssertEqual(current.trip?.id, prior.trip?.id)
        XCTAssertLessThanOrEqual(current.preview?.reverseSamples.count ?? 0, 64)
        XCTAssertNotNil(current.nextPage)
        let page = expectation(description: "earlier page")
        reopened.page(cursor: current.nextPage, reference: nil) { next in
            XCTAssertLessThanOrEqual(next.preview?.reverseSamples.count ?? 0, 64)
            XCTAssertEqual(next.preview?.reverseSamples.last?.sourceID, "frame-60.0")
            page.fulfill()
        }
        wait(for: [page], timeout: 5)
    }
    func testColdBudgetHasBoundedVolatileLossAndKeepsOriginalStart() throws {
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: directory) }
        let clock = Clock(), session = UUID(), store = RecordedRouteStore(url: directory.appendingPathComponent("routes.sqlite"), now: clock.read)
        store.begin(sessionID: session)
        let first = record(session, time: 0)
        for i in 0..<100 {
            let sample = i == 0 ? first : record(session, time: Double(i)*0.21)
            store.offer(sessionID: session, at: sample.capturedAt) { sample }; _ = snapshot(store)
        }
        let pending = try XCTUnwrap(snapshot(store))
        XCTAssertEqual(pending.volatileSampleCount, 64); XCTAssertEqual(pending.droppedVolatileSampleCount, 36)
        XCTAssertEqual(pending.preview?.reverseSamples.last?.observationID, first.id)
        XCTAssertTrue(pending.preview?.gaps.contains(.durabilityLoss) == true)
        clock.set(120); store.stop()
        XCTAssertEqual(snapshot(store)?.durableSampleCount, 64)
    }
    func testClearRetiresQueuedReadAndStaleAnchorCannotResurrect() throws {
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: directory) }
        let clock = Clock(), session = UUID(), store = RecordedRouteStore(url: directory.appendingPathComponent("routes.sqlite"), now: clock.read)
        store.begin(sessionID: session); clock.set(60)
        let sample = record(session, time: 60); store.offer(sessionID: session, at: 60) { sample }; _ = snapshot(store)
        let old = expectation(description: "withheld read")
        store.preview { XCTAssertTrue($0.busy); XCTAssertNil($0.preview); old.fulfill() }
        Thread.sleep(forTimeInterval: 0.05)
        let clear = expectation(description: "clear")
        store.clear { XCTAssertTrue($0); clear.fulfill() }; wait(for: [old,clear], timeout: 5)
        XCTAssertNil(snapshot(store)?.preview)
        let denied = expectation(description: "stale last sample unavailable")
        store.pinLatest(kind: .entrance, label: "Old", origin: .trustedInterface) { XCTAssertFalse($0); denied.fulfill() }; wait(for: [denied], timeout: 5)
    }
}
