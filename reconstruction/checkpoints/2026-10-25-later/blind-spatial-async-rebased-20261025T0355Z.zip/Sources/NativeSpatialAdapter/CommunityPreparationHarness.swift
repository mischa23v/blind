// HARNESS ONLY: three exact view methods. SwiftUI, package cache and model shell are explicit stubs.
import Foundation
import BlindCore
final class CommunityPreparationHarness {
 var preparationID: UUID? { didSet { if preparationID == nil { onIdle?() } } }
 var onIdle: (() -> Void)?
 var error = ""
 let model: CommunityPreparationModelStub
 let library = CommunityPreparationLibraryStub()
 init(indoor: IndoorNavigator) { model = .init(indoor: indoor) }
 var busy: Bool { preparationID != nil }
 func start(_ package: PlacePackage) { library.preview = package; prepareCommunityRoute(package) }
 func claim() -> UUID { beginPreparation() }
 func finish(_ id: UUID) -> Bool { finishPreparation(id) }
 private func beginPreparation() -> UUID {
        let id = UUID(); preparationID = id; return id
    }
@discardableResult private func finishPreparation(_ id: UUID) -> Bool {
        guard preparationID == id else { return false }
        preparationID = nil; return true
    }
private func prepareCommunityRoute(_ package: PlacePackage) {
        let preparation = beginPreparation()
        model.stopReturn()
        let intent = model.indoor.beginCommunityImport(package)
        Task { @MainActor in
            var handedOff = false
            defer { if !handedOff { finishPreparation(preparation) } }
            do {
                _ = try await CommunityPackageStorage().install(package)
                guard preparationID == preparation, model.indoor.ownsCommunityImport(intent) else { return }
                guard library.preview?.id == package.id, library.preview?.revision == package.revision else {
                    model.indoor.failCommunityImport(intent); return
                }
                library.reload(); handedOff = true
                model.indoor.completeCommunityImport(package, intent: intent) { result in
                    guard self.finishPreparation(preparation) else { return }
                    switch result {
                    case .success: self.error = ""
                    case .failure(let failure):
                        if failure as? SpatialMapIOError != .superseded { self.error = failure.localizedDescription }
                    }
                }
            } catch {
                guard preparationID == preparation, model.indoor.ownsCommunityImport(intent) else { return }
                model.indoor.failCommunityImport(intent); self.error = error.localizedDescription
            }
        }
    }
}
final class CommunityPreparationModelStub { let indoor: IndoorNavigator; init(indoor: IndoorNavigator){self.indoor=indoor}; func stopReturn() {} }
final class CommunityPreparationLibraryStub { var preview: PlacePackage?; func reload() {} }
