// Generated from exact applied Feedback methods. Source SHA256: 542c3c5d1efc74cbb74e9ca036fff0647f575c3f5151636b8fcf69717e066e04
// Only platform stubs and DEBUG diagnostics are substituted. This is not Apple playback.
import Foundation
import XCTest
@testable import BlindCore
@testable import NativeSpatialAdapter
private final class AVSpeechSynthesizer {}
private final class AVSpeechUtterance {}
private final class RecordingPlayer { var stops = 0; func stop() { stops += 1 } }
private final class ExtractedFeedback {
    var currentSpatialRouteID: UUID?
    var currentUtterance: AVSpeechUtterance?
    var spatialRoutePermission: ((UUID) -> Bool)?
    var requestedSpeechPermission: ((UUID, String) -> Bool)?
    var delivery = SpeechDeliveryLedger()
    var beaconOwnership = SpatialRouteBeaconOwnership()
    let player = RecordingPlayer()
    var terminal: [NarrationDelivery] = []
    var platformStopRequests = 0
    func finishActive(outcome: NarrationDelivery, stopSynthesizer: Bool, diagnosticCause: String = "test") {
        guard let token = delivery.active?.token, let completion = delivery.finish(token: token, outcome: outcome, now: 10) else { return }
        currentSpatialRouteID = nil; currentUtterance = nil
        terminal.append(completion.outcome)
        if stopSynthesizer { platformStopRequests += 1 }
    }
    func stopSpatialRouteSpeech(_ id: UUID) {
        guard currentSpatialRouteID == id, let active = delivery.active,
              active.destination == .requested(id), !active.independentAlert else { return }
        finishActive(outcome: .interrupted, stopSynthesizer: true,
                     diagnosticCause: "route.ticketRetired")
    }
    func stopSpatialRouteBeacon(_ id: UUID) {
        guard beaconOwnership.retire(id) else { return }
        player.stop()
    }
    func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didStart utterance: AVSpeechUtterance) {
        guard utterance === currentUtterance, let active = delivery.active, active.transport == .synthesized else { return }
        if case .requested(let id) = active.destination, requestedSpeechPermission?(id, active.text) == false {
            finishActive(outcome: .interrupted, stopSynthesizer: true,
                         diagnosticCause: "source.expiredBeforePlayback"); return
        }
        if let routeID = currentSpatialRouteID, spatialRoutePermission?(routeID) != true {
            finishActive(outcome: .interrupted, stopSynthesizer: true,
                         diagnosticCause: "route.expiredBeforePlayback"); return
        }
    }
}
final class ExtractedSpatialFeedbackTests: XCTestCase {
    func testActualMobilityRetirementFinishesExactRouteLedgerAttempt() throws {
        let sink = ExtractedFeedback(), id = UUID()
        sink.currentSpatialRouteID = id
        _ = sink.delivery.begin(text: "Synthetic route cue", priority: .mobility,
            destination: .requested(id), transport: .synthesized)
        sink.stopSpatialRouteSpeech(id)
        XCTAssertNil(sink.delivery.active); XCTAssertEqual(sink.terminal, [.interrupted])
        XCTAssertEqual(sink.platformStopRequests, 1)
    }
    func testActualLateRouteRetirementCannotStopSensorStatusOrHazard() throws {
        for priority in [SpeechPriority.mobility, .danger] {
            let sink = ExtractedFeedback(), old = UUID(), current = UUID()
            sink.currentSpatialRouteID = old // Even a stale tag cannot override alert provenance.
            _ = sink.delivery.begin(text: "Synthetic sensor warning", priority: priority,
                destination: .requested(current), transport: .synthesized, independentAlert: true)
            sink.stopSpatialRouteSpeech(old); sink.stopSpatialRouteSpeech(current)
            XCTAssertNotNil(sink.delivery.active); XCTAssertEqual(sink.platformStopRequests, 0)
        }
    }
    func testActualDidStartRejectsExpiredRouteButNotOldUtteranceAgainstNewAttempt() throws {
        let sink = ExtractedFeedback(), id = UUID(), oldUtterance = AVSpeechUtterance()
        sink.currentSpatialRouteID = id; sink.currentUtterance = AVSpeechUtterance()
        sink.spatialRoutePermission = { _ in false }
        _ = sink.delivery.begin(text: "Synthetic route cue", priority: .mobility,
            destination: .requested(id), transport: .synthesized)
        sink.speechSynthesizer(AVSpeechSynthesizer(), didStart: oldUtterance)
        XCTAssertNotNil(sink.delivery.active)
        sink.speechSynthesizer(AVSpeechSynthesizer(), didStart: try XCTUnwrap(sink.currentUtterance))
        XCTAssertNil(sink.delivery.active); XCTAssertEqual(sink.terminal, [.interrupted])
    }
    func testActualRequestedSourceExpiryGateRemainsBeforeRoutePermission() throws {
        let sink = ExtractedFeedback(), id = UUID()
        sink.currentSpatialRouteID = id; sink.currentUtterance = AVSpeechUtterance()
        var routeGateCalls = 0
        sink.requestedSpeechPermission = { owner, text in
            XCTAssertEqual(owner, id); XCTAssertEqual(text, "Synthetic expired request")
            return false
        }
        sink.spatialRoutePermission = { _ in routeGateCalls += 1; return true }
        _ = sink.delivery.begin(text: "Synthetic expired request", priority: .mobility,
            destination: .requested(id), transport: .synthesized)
        sink.speechSynthesizer(AVSpeechSynthesizer(), didStart: try XCTUnwrap(sink.currentUtterance))
        XCTAssertNil(sink.delivery.active); XCTAssertEqual(sink.terminal, [.interrupted])
        XCTAssertEqual(routeGateCalls, 0); XCTAssertEqual(sink.platformStopRequests, 1)
    }
    func testActualBeaconRetirementCannotStopReplacementAlert() {
        let sink = ExtractedFeedback(), id = UUID()
        sink.beaconOwnership.replace(routeID: id)
        sink.stopSpatialRouteBeacon(id); XCTAssertEqual(sink.player.stops, 1)
        sink.beaconOwnership.replace(routeID: nil)
        sink.stopSpatialRouteBeacon(id); XCTAssertEqual(sink.player.stops, 1)
    }
}
