from pathlib import Path
import json,hashlib,zipfile
p=Path(__file__).resolve().parents[1];live=Path('/workspace/shared/blind-rebuild');sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
files=json.loads((p/'APPLY_MANIFEST.json').read_text())['files']
for f in files:
 current=live/f['target'];assert (sha(current) if current.exists() else None)==f['baseSHA256']
 assert sha(p/f['source'])==f['proposedSHA256']
logs=['verification/rebased-final-swift.log','verification/rebased-final-node.log','verification/rebased-contextual-node.log','verification/rebased-native-syntax.log','verification/rebased-project-membership.txt','verification/rebase-proof.json','verification/community-test-preservation.txt','verification/feedback-extraction-proof.json']
assert 'Executed 89 tests, with 0 failures' in (p/logs[0]).read_text()
for f,n in [(logs[1],47),(logs[2],11)]:
 s=(p/f).read_text();assert f'tests {n}' in s and f'pass {n}' in s and 'fail 0' in s and 'skipped 0' in s
assert 'error:' not in (p/logs[3]).read_text()
verification={'status':'Frozen rebased staging candidate; not applied or pushed. Parent09 live aggregate gate and explicit apply authorization remain required.','tested':{'standaloneSwift':{'passed':89,'failed':0,'skipped':0},'focusedNode':{'passed':47,'failed':0,'skipped':0,'includesActualSpatialReplay':41,'includesUnchangedWorkingStateReplay':25},'additionalCurrentObservationLifecycleNode':{'passed':11,'failed':0,'skipped':0},'nativeSyntax':['default','DEBUG'],'nativeProject':'50 app Swift source names, no removed photo/observation source membership','preservation':'Photo sheet exact; observation purge lifecycle retained; unrelated CommunityTests exact; no NavigationModel/NativeMapping edits'},'files':files,'evidence':{f:sha(p/f) for f in logs},'runtimeInputs':{str(f.relative_to(p)):sha(f) for d in ['Sources','Tests'] for f in sorted((p/d).rglob('*.swift'))},'applyManifestSHA256':sha(p/'APPLY_MANIFEST.json'),'patchSHA256':sha(p/'async-map-io.patch'),'limits':['Explicit synthetic fixture map/pose/support only.','Unrelated Apple UI, cache, model shells are explicitly stubbed in extraction.','No calibrated native capture issuer, physical guidance/device accuracy or Apple SDK validation claim.','Single app owner per file; no cross-process coordination or power-loss durability guarantee.']}
(p/'verification-manifest.json').write_text(json.dumps(verification,indent=2)+'\n')
selected=[]
for d in ['BlindCore','Sources','Tests','ios','tools','base']:selected.extend(f for f in (p/d).rglob('*') if f.is_file() and f.suffix != '.orig')
selected.extend(p/n for n in ['Package.swift','WIP_STATUS.md','INTEGRATION.md','APPLY_MANIFEST.json','verification-manifest.json','async-map-io.patch'])
selected.extend(f for f in (p/'verification').iterdir() if f.is_file() and f.suffix in {'.py','.mjs','.json','.patch'})
selected=sorted(set(selected));sm={str(f.relative_to(p)):sha(f) for f in selected};(p/'SOURCE_MANIFEST.json').write_text(json.dumps(sm,indent=2)+'\n')
z=Path('/workspace/shared/blind-spatial-async-rebased-20261025T0355Z.zip')
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED) as out:
 for f in selected+[p/'SOURCE_MANIFEST.json']:out.write(f,str(f.relative_to(p)))
with zipfile.ZipFile(z) as inp:
 assert inp.testzip() is None
 for n,h in sm.items():assert hashlib.sha256(inp.read(n)).hexdigest()==h
print(json.dumps({'archive':str(z),'bytes':z.stat().st_size,'members':len(selected)+1,'sha256':sha(z),'verificationManifestSHA256':sha(p/'verification-manifest.json'),'applyManifestSHA256':sha(p/'APPLY_MANIFEST.json')},indent=2))
