from pathlib import Path
import hashlib,json,re,difflib
p=Path.cwd(); original=Path('/workspace/shared/blind-spatial-async-stage');live=Path('/workspace/shared/blind-rebuild')
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
old=(original/'base/ios/BlindAssist/DashboardView.swift').read_text(); frozen=(original/'ios/BlindAssist/DashboardView.swift').read_text(); now=(live/'ios/BlindAssist/DashboardView.swift').read_text(); proposed=(p/'ios/BlindAssist/DashboardView.swift').read_text()
photo='''        .sheet(isPresented: $model.showPhotoReference) {
            NavigationStack { ExplorePictureView(model: model) }
        }
'''
assert now.replace(photo,'')==old
assert proposed.replace(photo,'')==frozen
nav=(p/'ios/BlindAssist/IndoorNavigator.swift').read_text(); liveNav=(live/'ios/BlindAssist/IndoorNavigator.swift').read_text()
assert 'var clearObservationHistory: ((@escaping (Bool) -> Void) -> Void)?' in nav and 'var clearObservationHistory: ((@escaping (Bool) -> Void) -> Void)?' in liveNav
assert 'guard let self, self.revision == expected else' in nav and 'registered.externalPreparationFailed()' in nav
assert nav.index('clearObservationHistory {')<nav.index('registered.delete(completion: done)')
assert 'guard let registered, !registered.ioPending, !registered.ioBlocked else { return nil }' in nav
baseProject=(live/'ios/BlindAssist.xcodeproj/project.pbxproj').read_text();nextProject=(p/'ios/BlindAssist.xcodeproj/project.pbxproj').read_text()
refs=lambda s:set(re.findall(r'path = "([^"]+\.swift)";',s))
assert refs(baseProject)<=refs(nextProject)
assert (p/'base/ios/BlindAssistTests/CommunityTests.swift').read_bytes()==(live/'ios/BlindAssistTests/CommunityTests.swift').read_bytes()
(p/'verification/rebase-proof.json').write_text(json.dumps({'photoSheetPreservedExactly':True,'dashboardOtherThanAsyncImporterEqualsLivePhotoBase':True,'observationPurgeHookPreserved':True,'ownedPurgeFailureSettlesPendingButStaysBlocked':True,'observationTargetUnknownDuringPendingOrBlockedIO':True,'removedSwiftProjectMembers':sorted(refs(baseProject)-refs(nextProject)),'addedSwiftProjectMembers':sorted(refs(nextProject)-refs(baseProject)),'untouchedNativeOwners':{n:sha(live/'ios/BlindAssist'/n) for n in ['NavigationModel.swift','NativeMapping.swift']},'sourceHashes':{n:sha(p/'ios/BlindAssist'/n) for n in ['DashboardView.swift','IndoorNavigator.swift']}},indent=2)+'\n')
