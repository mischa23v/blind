from pathlib import Path
import re
src=Path('base/ios/BlindAssistTests/CommunityTests.swift').read_text()
s=src; cursor=0
pattern=re.compile(r'try (nav|navigator)\.(loadCommunity|load)\(')
while m:=pattern.search(s,cursor):
 i=m.end(); depth=1; quote=False;escape=False
 while depth:
  c=s[i]
  if quote:
   if escape:escape=False
   elif c=='\\':escape=True
   elif c=='"':quote=False
  elif c=='"':quote=True
  elif c=='(':depth+=1
  elif c==')':depth-=1
  i+=1
 args=s[m.end():i-1]; throwing='package(' in args or 'JSONEncoder' in args
 rep=f'try awaitIndoorIO {{ done in {"try " if throwing else ""}{m[1]}.{m[2]}({args}, completion: done) }}'
 s=s[:m.start()]+rep+s[i:]; cursor=m.start()+len(rep)
s=s.replace('        let restored = navigator()','        let restored = try restoredNavigator()')
a=s.index('    private func navigator() -> IndoorNavigator');b=s.index('\n    private func map()',a)
s=s[:b]+'''
    private func restoredNavigator() throws -> IndoorNavigator {
        let done = expectation(description: "actual asynchronous restore")
        var result: Result<Void, Error>?
        let nav = IndoorNavigator(storage: directory.appendingPathComponent("route.json"), restoreCompletion: { result = $0; done.fulfill() })
        wait(for: [done], timeout: 10); try XCTUnwrap(result).get(); return nav
    }
''' +s[b:]
s+='''
private extension XCTestCase {
    func awaitIndoorIO(_ action: (@escaping IndoorNavigator.MapCompletion) throws -> Void) throws {
        let done = expectation(description: "actual asynchronous indoor map IO")
        var result: Result<Void, Error>?
        try action { result = $0; done.fulfill() }
        wait(for: [done], timeout: 10); try XCTUnwrap(result).get()
    }
}
'''
Path('ios/BlindAssistTests').mkdir(parents=True,exist_ok=True);Path('ios/BlindAssistTests/CommunityTests.swift').write_text(s)
def remove_class(text,name):
 start=text.index('final class '+name); brace=text.index('{',start); end=brace+1;depth=1
 while depth:
  if text[end]=='{':depth+=1
  elif text[end]=='}':depth-=1
  end+=1
 return text[:start]+text[end:]
new=s[:s.rindex('\nprivate extension XCTestCase')]
for name in ['IndoorSituationTests','IndoorGoalContinuityTests']:
 src=remove_class(src,name);new=remove_class(new,name)
assert src==new, 'Non-spatial test preservation failed'
Path('verification/community-test-preservation.txt').write_text('PASS: All content outside IndoorSituationTests, IndoorGoalContinuityTests and newly appended IO-wait helper is byte-exact to current published-memory-preserving live file.\n')
