from pathlib import Path
import re,json,hashlib
root=Path(__file__).resolve().parents[1]
source=Path('/workspace/shared/blind-rebuild/ios/BlindAssist/Feedback.swift')
extracted=root/'Tests/BlindCoreTests/ExtractedSpatialFeedbackTests.swift'
s=source.read_text();t=extracted.read_text();methods=[]
for marker in ['    func stopSpatialRouteSpeech(', '    func stopSpatialRouteBeacon(', '    func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didStart']:
 start=s.index(marker);depth=0
 for i in range(s.index('{',start),len(s)):
  if s[i]=='{':depth+=1
  elif s[i]=='}':
   depth-=1
   if not depth:
    method=s[start:i+1];break
 method=re.sub(r'\s*#if DEBUG\n[\s\S]*?#endif','',method)
 assert method in t,marker
 methods.append({'method':marker.strip(),'liveBodySHA256AfterDiagnosticRemoval':hashlib.sha256(method.encode()).hexdigest(),'exactlyPresentInExecutedHarness':True})
result={'source':'ios/BlindAssist/Feedback.swift','sourceSHA256':hashlib.sha256(source.read_bytes()).hexdigest(),'executedHarnessSHA256':hashlib.sha256(extracted.read_bytes()).hexdigest(),'methods':methods,'limitations':['Explicit platform playback stubs; DEBUG diagnostic block removal only.','No Apple playback latency or hardware behavior claimed.','Includes applied requestedSpeechPermission source-expiry guard before route permission.']}
(root/'verification/feedback-extraction-proof.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
