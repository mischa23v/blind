import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
const source = readFileSync(new URL('../ios/BlindAssist/IndoorNavigator.swift', import.meta.url), 'utf8');
// Exact full controller, except unavailable Combine import. No function body,
// IO call, generation guard, route mutation or callback is reimplemented.
const extracted = source.replace(/^import Combine\n/m, '');
writeFileSync(new URL('../Sources/NativeSpatialAdapter/IndoorNavigator.swift', import.meta.url), extracted);
writeFileSync(new URL('./indoor-extraction.json', import.meta.url), JSON.stringify({
 sourceSHA256: createHash('sha256').update(source).digest('hex'),
 extractedSHA256: createHash('sha256').update(extracted).digest('hex'),
 changes: ['Remove import Combine only; unavailable unrelated platform types use explicit stubs.'],
 limits: ['No Combine subscription, Apple UI, community storage, diagnostic file or IndoorSituation behavior is tested.']
}, null, 2) + '\n');
