from pathlib import Path
import shutil
stage=Path(__file__).resolve().parents[1];live=Path('/workspace/shared/blind-rebuild');out=stage/'validation-tree'
for directory in ['BlindCore','ios','tools','server']:
 for source in (live/directory).rglob('*'):
  if not source.is_file() or any(p in {'.build','node_modules','.git','artifacts'} for p in source.relative_to(live).parts):continue
  if source.suffix not in {'.swift','.mjs','.json','.pbxproj','.plist','.h','.mm','.c','.md','.yml','.entitlements','.xcconfig','.txt'}:continue
  target=out/source.relative_to(live);target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,target)
# Snapshot only actual live source. The paused observation increment is not
# projected into membership or apply preimages; a later authorized rebase is required.
for name in ['NativeARObservationAdapter.swift','NativeARObservationBridge.swift']:
 path=out/'ios/BlindAssist'/name
 if path.exists() and not (live/'ios/BlindAssist'/name).exists(): path.unlink()
for directory in ['BlindCore','ios','tools']:
 for source in (stage/directory).rglob('*'):
  if not source.is_file():continue
  target=out/source.relative_to(stage);target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,target)
