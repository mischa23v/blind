# Bounded map IO integration

## APIs and ownership

RegisteredIndoorNavigation now receives completion callbacks for restore, install, importFile, installCommunity, addRestrictions, blockNextLegAndReplan and delete. Completions run on main and return a validated immutable Loaded value only after serial persistence and both ownership checks. Pending or failed IO cannot authorize pose, planning, tickets or delivery. Configuration accepts an already-validated immutable installation through SpatialRouteOwner.restoreValidated rather than performing another main-thread JSON/hash pass.

IndoorNavigator synchronously invalidates route/pose ownership when an operation begins and publishes map/UI state only for the current operation. Task-only cancelRoute keeps durable maps and alignment rules separate. Public plan attempts retire an older replan continuation even if storage is busy. Its initializer reports asynchronous restoration through an optional completion. Existing hosted tests await this completion; they no longer assume file IO finished during init.

DashboardView hands a security-scoped URL to the worker. The worker checks descriptor size and reads at most maximumEnvelopeBytes plus one sentinel byte in bounded chunks. Legacy preview maps retain the stricter maximumMapBytes bound. The worker owns the security-scoped access lifetime.

CommunityMapsView admits a typed map intent before awaiting its community cache. The completion must match the intent, selected package and independent view-preparation ID. A stale completion still releases its own busy flag, never a newer operation's. IndoorNavigator's optional observation-history purge precedes the delete barrier and is fenced by the same map operation revision. Diagnostic purge remains DEBUG-only and independently coalesced.

## IO transaction boundary

The worker retains bounded previous bytes before an atomic write. A token includes a fresh generation and the expected process-local storage revision plus map artifact. Commit and main publication each compare the exact token. The worker asynchronously waits for the main publication acknowledgement before advancing to the next file job; it never blocks main waiting for IO. A superseded write is rolled back to the prior file, not treated as permission to delete the last committed map. A failed rollback/deletion fences subsequent non-delete jobs. Explicit deletion is an ordered barrier and is reported successful only after the actual deletion completes while still owning its request.

The process-local revision includes restriction-only changes, not merely geometry version. Additive pending restrictions are coalesced as a bounded union. A newer empty update cannot clear a positive restriction, and a replacement must include pending positive history. This is not a dynamic-obstacle clearing protocol.

## Reproduction

Run the standalone Package.swift with the approved Swift toolchain and one compiler job. Its platform stubs are test-only and must never be added to the app target.

Set BLIND_SWIFTC to the approved compiler and run tools/test/spatial-map-io-native-state.test.mjs in the projected/merged repository. It creates a separate minimal package from exact production files, records input SHA-256 hashes, runs 41 tests, and retains its execution log. Its only controller transformation removes the unavailable Combine import; three CommunityMapsView methods are extracted verbatim. The platform/cache/diagnostic/model shells are explicitly stubbed. The independently hosted iOS tests use the actual app module.

APPLY_MANIFEST.json lists only this increment's owned files and actual live preimages. No NavigationModel, NativeMapping or observation-store file is part of this patch. The current rebase preserves the live photo sheet and observation hooks/project members. Recheck every live preimage before applying; any later overlap requires another narrow rebase. Do not replay a whole older source file over another increment.
