// swift-tools-version: 5.9
import PackageDescription
let package = Package(name: "SpatialIntegrationCheckpoint", products: [.library(name: "BlindCore", targets: ["BlindCore"])],
    targets: [.target(name: "BlindCore"),
              .target(name: "NativeSpatialAdapter", dependencies: ["BlindCore"]),
              .testTarget(name: "BlindCoreTests", dependencies: ["BlindCore", "NativeSpatialAdapter"])])
